<?php
/*
 Plugin Name: My Pro Timeline
 Plugin URI: http://codecanyon.net/oqrwta125o/
 Description: Display posts in the timeline.Adjust styles with editor.Choose vertical or horizontal timeline.
 Author: oqrwta125o
 Version: 1.0
 Author URI: http://codecanyon.net/orqwta125o/
 */
$dir=plugin_dir_path(__FILE__);
require_once $dir.'includes/traits/traits.php';
require_once $dir.'includes/class/class-general-plugin.php';
require_once $dir.'includes/modules/class-my-general-module.php';
if(!class_exists("Class_My_Pro_Timeline_Main_Class")){
    class Class_My_Pro_Timeline_Main_Class extends Class_My_Framework_Plugin_Class{
        use MySingleton,MyDebug;
        private $data;
        protected $global_debug=0;
        protected $use_case="my_framework";
        protected $myIsPlugin=1;
        protected $tableObjects;//objects
        protected $tableObjectsMeta;//objects meta
        
        function __construct($options=array()){
            if(!$this->myIsPlugin){
                $dir=get_template_directory().'/';
                $url=get_template_directory_uri().'/';
            }else {
                $url=plugin_dir_url(__FILE__);
                $dir=plugin_dir_path(__FILE__);
            }
            parent::__construct(array(
                'dir'=>$dir,
                'url'=>$url,
                
            ));
            $this->plugin_dir=plugin_dir_path(__FILE__);
            $this->plugin_url=$url;
            $this->loadFunctions('activate.php');
            $this->loadFunctions('deactivate.php');
            register_activation_hook(__FILE__, 'wp_my_pro_timeline_activate');
            register_deactivation_hook(__FILE__, 'wp_my_pro_timeline_deactivate');
            
        }
        protected function loadGlobalClass($class='',$options=array()){
            switch($class){
                case 'Class_My_Framework_Scripts_Class':
                    $file=$this->class_dir.'class-my-scripts.php';
                    require_once $file;
                    $this->scripts_class=Class_My_Framework_Scripts_Class::singleton($options);
                    break;
                default:
                    
                    
                    //case 'Class_My_Framwork_Scripts_Class':
            }
        }
        public function admin_notices(){
            $tmp_1=MY_PRO_TIMELINE_TMP_DIRNAME;
           // $tmp_2=MY_PRO_TIMELINE_TMP_UPLOADS_DIRNAME;
            $tmp_3=MY_PRO_TIMELINE_TMP_ERRORS_DIRNAME;
            if(!is_writable($tmp_1) || (!is_writeable($tmp_3)) ){
                ?>
        						<div class="error">
        							<?php if(version_compare(PHP_VERSION, '5.4.0', '<')){?>
        							<p><strong><?php echo __("My Pro  Stream : Facebook API needs at least 5.4.0 PHP version ","my_support_theme");?></strong>
        
        							<?php }?>
        							<?php if(!is_writable($tmp_1)) {?>
        							<p><strong><?php echo __("My Pro Timeline : Please make this folder writeable by server ","my_support_theme");?> : <?php echo $tmp_1?></strong>
        
        							<?php }?>
        							<?php /*if(!is_writable($tmp_2)) {?>
        							<p><strong><?php echo __("My Support theme : Please make this folder writeable by server ","my_support_theme");?> : <?php echo $tmp_2?></strong>
        
        							<?php }*/ ?>
        								<?php if(!is_writable($tmp_3)) {?>
        							<p><strong><?php echo __("My Pro Timeline : Please make this folder writeable by server ","my_social_posts_domain");?> : <?php echo $tmp_3?></strong>
        
        							<?php }?>
        						</div>
        						<?php
        						}
        
        		}
       private function setScriptsOptionsMain(){
            $options['assets_url']=$this->url.'assets/';
            $options['debug']=$this->debug;
            $options['use_case']=$this->use_case;
        	$this->loadGlobalClass('Class_My_Framework_Scripts_Class',$options);
        }
        /**
         * Load plugin functions
         */
        private function load_functions(){
            $dir=$this->functions_dir;
            $files=array('general.php','functions.php');
            foreach($files as $k=>$v){
                $f=$dir.$v;
                if(file_exists($f)){
                    require_once $f;
                }else {
                    trigger_error(__("Load functions function file not exists","my_support_theme").$f,E_USER_NOTICE);
                }
            }
           
        }
        function init($options=array()){
            $debug=$this->global_debug;
            $this->init_constants();
             $this->setScriptsOptionsMain();
            $debugClass=$this->modules_dir.'debug/class.php';
           
            require_once $debugClass;
            Class_My_Module_Debug::$doDebug=$debug;
            Class_My_Module_Debug::$url=$this->modules_url.'debug/';
            Class_My_Module_Debug::init();
            Class_My_Module_Debug::$tmp_debug=MY_PRO_TIMELINE_TMP_DIRNAME;
            Class_My_Framework_Scripts_Class::addIncludes('fontawesome');
            $this->load_functions();
            parent::init(array('debug'=>$this->global_debug));
            $debug=$this->global_debug;
            $save_errors=$this->getOptionByKey('save_errors');
            Class_My_Module_Debug::$tmp_debug=MY_PRO_TIMELINE_TMP_DIRNAME;
            Class_My_Module_Debug::$saveErrors=$save_errors;
            Class_My_Module_Debug::add_section('modules', $this->modules,$this->use_case,false);
            self::setDebugOptions($this->use_case);
            self::debug("url", $this->url);
            add_action('admin_notices',array(&$this,'admin_notices'));
            //add_action("after_switch_theme", array(&$this,'activate'));
        }
        /*public function activate($new_name,$new_theme){
            self::debug("new_theme_name", $new_name);
            self::debug("new_theme", $new_theme);
            
            $file=MY_PRO_TIMELINE_FUNCTIONS_DIRNAME.'activate.php';
            require_once $file;
            wp_MY_PRO_TIMELINE_activate();
        }*/
        private function init_constants(){
            $this->global_modules_dir=$this->plugin_dir.'includes/modules/';
            /**
             * Dirnames
             */
            define('MY_PRO_TIMELINE_DIRNAME',$this->plugin_dir);
            define('MY_PRO_TIMELINE_TMP_DIRNAME',$this->plugin_dir.'tmp/');
            define('MY_PRO_TIMELINE_TMP_UPLOADS_DIRNAME',$this->plugin_dir.'tmp/uploads/');
            define('MY_PRO_TIMELINE_TMP_ERRORS_DIRNAME',$this->plugin_dir.'tmp/errors/');
            define('MY_PRO_TIMELINE_TMP_DEBUG_DIRNAME',$this->plugin_dir.'tmp/debug/');
            define('MY_PRO_TIMELINE_CLASS_DIRNAME',$this->plugin_dir.'includes/class/');
            define('MY_PRO_TIMELINE_VIEWS_DIRNAME',$this->plugin_dir.'includes/views/');
            define('MY_PRO_TIMELINE_CONTROLLERS_DIRNAME',$this->plugin_dir.'includes/controllers/');
            define('MY_PRO_TIMELINE_FUNCTIONS_DIRNAME',$this->plugin_dir.'includes/functions/');
            define('MY_PRO_TIMELINE_MODELS_DIRNAME',$this->plugin_dir.'includes/models/');
            define('MY_PRO_TIMELINE_GLOBAL_MODULES_DIRNAME',$this->global_modules_dir);
            define('MY_PRO_TIMELINE_LOCAL_MODULES_DIRNAME',$this->plugin_dir.'includes/modules/');
            define('MY_PRO_TIMELINE_SHORTCODES_DIRNAME',$this->plugin_dir.'includes/modules/shortcodes/');
            define('MY_PRO_TIMELINE_ADDONS_DIRNAME',$this->plugin_dir.'includes/modules/addons/');
            define('MY_PRO_TIMELINE_URL',$this->plugin_url);
            /**
             * URLS
             */
            define('MY_PRO_TIMELINE_CSS_URL',$this->plugin_url.'assets/css/');
            define('MY_PRO_TIMELINE_IMAGES_URL',$this->plugin_url.'assets/images/');
            define('MY_PRO_TIMELINE_JSCRIPT_URL',$this->plugin_url.'assets/jscript/');
            define('MY_PRO_TIMELINE_MODULES_URL',$this->plugin_url.'includes/modules/');
            define('MY_PRO_TIMELINE_ADDONS_URL',$this->plugin_url.'includes/modules/addons/');
            /**
             * db tables
             */
            global $wpdb;
            $this->tableObjects=$wpdb->prefix . 'my_pro_timeline_objects';;
            $this->tableObjectsMeta= $wpdb->prefix . 'my_pro_timeline_object_meta';
            define('MY_PRO_TIMELINE_TABLE_OBJECTS',$this->tableObjects);
            define('MY_PRO_TIMELINE_TABLE_OBJECTS_META',$this->tableObjectsMeta);
            
        
        }
        
    }
    
}
if(class_exists("Class_My_Pro_Timeline_Main_Class")){
    global $Class_My_Pro_Timeline_Main_Class;
    $Class_My_Pro_Timeline_Main_Class=new Class_My_Pro_Timeline_Main_Class();
   // $Class_My_Pro_Timeline_Main_Class->init();
   add_action('plugins_loaded',array($Class_My_Pro_Timeline_Main_Class,'init'));
}
        