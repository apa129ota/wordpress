<?php
if(!defined('ABSPATH'))die('');
$info=array(
		'title'=>'Meta Form',
		'description'=>'Module is used to work with custom metas',
		'class'=>'Class_My_Module_Meta',

);
return $info;
