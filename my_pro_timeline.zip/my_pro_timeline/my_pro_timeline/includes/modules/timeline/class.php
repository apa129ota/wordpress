<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Module_Timeline')){
    class Class_My_Module_Timeline extends Class_My_General_Module{
        use MySingleton;
        protected $postTypekey="my_timeline";
        protected $postTypeCat="my_timeline_category";
        protected $postTypeTerm="my_timeline_term";
        protected $postMetaPrefix="_my_pro_timeline_1234_";
        protected $postTypeArr;
        protected $postTypeCatArr;
        protected $postTypeTermArr;
        protected $formMetaboxHtml="";
        protected $isMyPost=false;
        protected $isPostEdit=false;
        protected $isEditPage=false;
        protected $myPostID="";
        protected $isShortcodePage=false;
        protected $isPreviewPage=false;
        protected $ajax_action="my_pro_timeline_ajax";
        protected $ajaxNonceStr="";
        protected $termClassObj="";
        protected $frontClassObj="";
        protected $metaKeys;
        protected $timelineID="";
        protected $moduleErrors=array();
        protected $layoutArr=array();
        protected $post_columns=array();
        protected $enableStars;
        protected $moduleOk=array();
        /**
         * construct module
         * @param array $options
         */
        function __construct($options=array()){
            $options['url']=plugin_dir_url(__FILE__);
            $options['dir']=plugin_dir_path(__FILE__);
            $options['use_case']="my_module_timeline";
            //$options['debug']=0;
            parent::__construct($options);
            $this->enableStars=wp_my_pro_timeline_get_option('enable_stars_comments');
            $this->layoutArr=array(
                '1600'=>array(
                    'title'=>__("Page width is grater than 1600px","my_support_theme"),
                    'tooltip'=>__("Adjust display for views grater than 1600px wide.","my_support_theme"),
                    'cols'=>'5',
                    'height'=>'50'
                    
                ),
                '1280'=>array(
                    'title'=>__("Page width is grater than 1280px","my_support_theme"),
                    'tooltip'=>__("Adjust display for views grater than 1280px wide.","my_support_theme"),
                    'cols'=>'4',
                    'height'=>'60'
                    
                    
                ),
                '960'=>array(
                    'title'=>__("Page width is grater than 960px","my_support_theme"),
                    'tooltip'=>__("Adjust display for views grater than 960px wide.","my_support_theme"),
                    'cols'=>'3',
                    'height'=>'70'
                    
                    
                ),
                '700'=>array(
                    'title'=>__("Page width is grater than 700px","my_support_theme"),
                    'tooltip'=>__("Adjust display for views grater than 700px wide.","my_support_theme"),
                    'cols'=>'2',
                    'height'=>'80'
                    
                    
                ),
                '0'=>array(
                    'title'=>__("Page width is smaller than 700px","my_support_theme"),
                    'tooltip'=>__("Adjust display for views less than 700px wide.","my_support_theme"),
                    'cols'=>'1',
                    'height'=>'100'
                    
                    
                ),
            );
            $this->post_columns=array(
                'myStars'=>__("Stars","my_support_theme"),
                'myStarsNum'=>__("Star comments","my_support_theme"),
                'myLikes'=>__("Likes","my_support_theme"),
                'myDate'=>__("Post Date","my_support_theme"),
                'myCat'=>__("Categories","my_support_theme"),
                'myTerms'=>__("Terms","my_support_theme"),
                
            );
            
            if(empty($this->enableStars)){
                unset($this->post_columns['myStars']);
                unset($this->post_columns['myStarsNum']);
            }
        }
        /**
         * backend ajax
         */
        public function backendAjax(){
            $this->global_plugin->loadController("class-my-general-controller.php");
            $ajax_options=$this->loadOptions("ajax_actions.php");
            $this_options=$ajax_options['backend'];
            $this_options['module_class']=$this;
            $this_options['module']=$this;
            $this_options['plugin_object']=$this->global_plugin;
            $this_options['nonce_str']=$this->ajaxNonceStr;
            $my_set_debug=0;
            if($this->debug){
                $my_set_debug=1;
            }
            self::debug("ajax_options", $this_options);
            /*self::debug("session",$_SESSION,false);
             self::debug("session_name", $this->session_name,false);
             */
            $this->routeAjax($this_options);
            
        }
        /**
         * get saved id
         * @return string|Ambigous
         */
        public function getSavedId(){
            return $this->timelineID;
        }
        /**
         * 
         * @param unknown $type
         * @param unknown $data
         * @return string
         */
        public function saveTimeline($type,$data){
            $module_dir=$this->global_plugin->getDir('modules');
            wp_my_general_load_module_function($module_dir, "new_form", "functions.php");
            if($type=="horizontal"){
                $addData=array();
                $elements=$this->loadOptions('horizontalForm.php');
                $arr=$this->layoutArr;
                foreach ($arr as $k=>$v){
                    $keyL="layout_".$k;
                    $keyC=$keyL.'_cols';
                    $keyH=$keyL.'_height';
                    $keyP=$keyL.'_select';
                    $elements[$keyC]['type']='text';
                    $elements[$keyH]['type']='text';
                    $val="%";
                    if(isset($data['layout_'.$k.'_height_html_form_id_select'])){
                        $val=$data['layout_'.$k.'_height_html_form_id_select'];
                    }
                    $addData[$keyP]=$val;    
                }
               
            }else if($type=="vertical"){
                $elements=$this->loadOptions('verticalForm.php');
                $addData=array();
            }else return __("Not supported module","my_support_theme");
            
            $saveData=my_new_form_clean_data($data,$elements);
            if(!empty($data["height_html_form_id_select"])){
                $unit=$data["height_html_form_id_select"];
                if(!in_array($unit,array("px","%")))$unit="px";
                $saveData["height_unit"]=$unit;
                $saveData["height"]=$saveData["height"];   
            }
            if(isset($addData)){
                
                foreach($addData as $k=>$v){
                    $saveData[$k]=$v;
                }
                /**
                 * If full width then set to full width template
                 */
                if(!empty($saveData['full_width'])){
                    $options=$this->global_plugin->loadOptions("meta_options.php");
                    $this->initMetaModule($options);
                    
                    $my_tmpl_12=$saveData['postTemplate'];
                    self::debug("myTmplId", $my_tmpl_12);
                    $saveTmpl12="template_11";
                    if(preg_match('/^[0-9]+$/', $my_tmpl_12)){
                        $tmplParent=$this->metaModuleObj->get_object_meta($my_tmpl_12, 'template');
                        self::debug("templateParent", $tmplParent);
                        if($tmplParent==$saveTmpl12){
                            $saveTmpl12=$my_tmpl_12;
                        }
                    }
                    $saveData['postTemplate']=$saveTmpl12;
                }
                
            }
            $options=$this->global_plugin->loadOptions("meta_options.php");
            $this->initMetaModule($options);
            $id=@$_POST['id'];
            $title=$saveData['title'];
            self::debug("saveData", $saveData);
            if(!empty($id)){
                self::debug("uppdateId", $id);
                $this->metaModuleObj->insert_update_object($title, "my_timeline",$id);
            }else {
                $id=$this->metaModuleObj->insert_update_object($title, "my_timeline","");
                
            }
            $this->timelineID=$id;
            $this->metaModuleObj->add_update_object_meta($id, "form", $saveData);
            $this->metaModuleObj->add_update_object_meta($id, "type", $type);
            
            return true;
        }
        public function post_columns($columns){
            self::debug("post_columns", $columns);
           
            
            $c=array();
            foreach ($columns as $key=>$val){
                if($key=='date'){
                    foreach($this->post_columns as $k1=>$v1){
                        $c[$k1]=$v1;
                    }
                    $c[$key]=$val;
                }else {
                    $c[$key]=$val;
                }
            }
            $columns=$c;
            return $columns;
        }
        /**
         * 
         * @param unknown $join
         * @return string
         */
        public function my_posts_join($join){
            global $wpdb;
            //$wpdb->show_errors();
            $old_terms='';
            if(isset($_REQUEST['my_test_terms']))$old_terms=@$_REQUEST['my_test_terms'];
            if(!empty($old_terms)){
                $join.=" LEFT join ".$wpdb->term_relationships." AS my_t ON ID=my_t.object_id";
            }
            return $join;
        }
        /**
         * 
         * @param unknown $where
         * @return string|void
         */
        public function my_posts_where($where){
            global $wpdb;
            $old_terms='';
            if(isset($_REQUEST['my_test_terms']))$old_terms=@$_REQUEST['my_test_terms'];
            if(!empty($old_terms)){
                $whereNew=" AND my_t.term_taxonomy_id=%d ";
                $whereNew=$wpdb->prepare($whereNew, array($old_terms));
                $where.=$whereNew;
            }
            return $where;
        }
        /**
         * Restrinc mange posts
         */
        public function my_restrict_manage_posts(){
            $terms=get_terms($this->postTypeCat,array('hide_empty'=>0));
            if(!empty($terms)){
                $old_terms='';
                if(isset($_REQUEST['my_test_terms']))$old_terms=@$_REQUEST['my_test_terms'];
                ?>
				<select name="my_test_terms">
					<option value="">----<?php echo __("Filter by categories","my_support_theme")?>----</option>
					<?php foreach($terms as $key=>$val){?>
					<option <?php if($old_terms==$val->term_id)echo 'selected="selected"'?> value="<?php echo $val->term_id?>"><?php echo $val->name;?></option>
					<?php }?>
					<?php ?>
				</select>
				<?php 
			}
			
		}
		
        /**
         * init module options
         * {@inheritDoc}
         * @see Class_My_General_Module::init()
         */
        function init($options=array()){
            $this->metaKeys=array(
                'myLike','myStars','includeTime','timeInt',
                'postDate','postDateInt','isVideoPost',
                'videoType'
            );
            global $pagenow;
            if($pagenow=='edit.php'){
                $my_p_t=@$_GET['post_type'];
                if(!empty($my_p_t)&&$my_p_t==$this->postTypekey){
                    $this->isEditPage=true;
                }
            }
            add_filter('manage_edit-'.$this->postTypekey.'_columns',array(&$this,'post_columns'));
            add_action( 'manage_'.$this->postTypekey.'_posts_custom_column' , array(&$this,'custom_post_column'), 10, 2 );
            add_filter( 'manage_edit-'.$this->postTypekey.'_sortable_columns', array(&$this,'sortableColumns'));
            global $pagenow;
            if($pagenow=='edit.php'){
                    if($this->isEditPage){
                    add_action('pre_get_posts',array(&$this,'orderPosts'));
                    add_action('restrict_manage_posts',array(&$this,'my_restrict_manage_posts'));
                    add_filter('posts_join',array(&$this,'my_posts_join'));
                    add_filter('posts_where',array(&$this,'my_posts_where'));
                }
            }
            
            $this->frontClassObj=$this->loadSubModule('front');
            $this->frontClassObj->init();
            $this->ajaxNonceStr=$this->get_ajax_nonce_str($this->ajax_action);
            parent::init($options);
            $page=@$_GET['page'];
            add_action('wp_ajax_'.$this->ajax_action,array($this,'backendAjax'));
            if(!empty($page)){
                if($page=="my_pro_timeline_add_new"){
                    $this->isShortcodePage=true;
                }else if($page=="my_pro_timeline_preview"){
                    $this->isPreviewPage=true;
                }
            }
            add_action('init', array($this,'registerPostType'));
            add_action( 'add_meta_boxes', array(&$this,'add_metaboxes'), 10, 2 );
            if(is_admin()&&!defined("DOING_AJAX")){
                //$this->isPostPage();
                //$this->renderMetaboxForm();
                add_action('init',array($this,'renderForm'));
                add_action('admin_head', array($this,'admin_head'),PHP_INT_MAX);
                add_action('admin_enqueue_scripts',array($this,'admin_scripts'),PHP_INT_MAX);
                add_action('admin_footer',array($this,'admin_footer'),PHP_INT_MAX);
                add_action('save_post',array($this,'savePostAction'));
            }
            
        }
        public function orderPosts($query){
            if(!empty($_REQUEST['orderby'])){
                $orderby=$_REQUEST['orderby'];
                $order=@$_REQUEST['order'];
                if(!in_array($order,array('asc','desc'))){
                    $order='asc';
                    
                }
                if($orderby=="myDate"){
                    if ($query->is_main_query()) {
                        $key=$this->postMetaPrefix.'postDateInt';
                        $query->set('orderby', 'meta_value_num');
                        $query->set('meta_key',$key);
                        $query->set('order', $order);
                    }
                }else if($orderby=="myStars"){
                    if ($query->is_main_query()) {
                        $key=$this->postMetaPrefix.'stars';
                        $query->set('orderby', 'meta_value_num');
                        $query->set('meta_key',$key);
                        $query->set('order', $order);
                    }
                }else if($orderby=="myStarsNum"){
                    if ($query->is_main_query()) {
                        $key=$this->postMetaPrefix.'starsCount';
                        $query->set('orderby', 'meta_value_num');
                        $query->set('meta_key',$key);
                        $query->set('order', $order);
                    }
                }else if($orderby=="myLikes"){
                    if ($query->is_main_query()) {
                        $key=$this->postMetaPrefix.'hearts';
                        $query->set('orderby', 'meta_value_num');
                        $query->set('meta_key',$key);
                        $query->set('order', $order);
                    }
                }
            }
        }
        /**
         * Custom column
         * @param unknown $col
         * @param unknown $post_id
         */
        public function custom_post_column($col,$post_id){
            switch($col){
                case 'myTerms':
                    $terms=wp_get_post_terms($post_id,$this->postTypeTerm);
                    // print_r($terms);
                    $str="";
                    foreach($terms as $k=>$v){
                        if(strlen($str)>0)$str.=",";
                        $str.=$v->name;
                    }
                    echo $str;
                    
                break;    
                case 'myLikes':
                    $meta_key=$this->postMetaPrefix.'hearts';
                    $heartsCount=get_post_meta($post_id,$meta_key,true);
                    if(empty($heartsCount)){
                        $heartsCount=0;
                    }
                    echo $heartsCount;
                break;    
                case 'myStarsNum':
                    $metaKey=$this->postMetaPrefix.'starsCount';
                    $commCount=get_post_meta($post_id,$metaKey,true);
                    if(empty($commCount)){
                        $commCount=0;   
                    }
                    echo $commCount;
                break;    
                case 'myStars':
                    $metaKey=$this->postMetaPrefix.'stars';
                    $stars=get_post_meta($post_id,$metaKey,true);
                    if(empty($stars)){
                        /*$stars=4;
                        $num=rand(0,10);
                        $add=$num/10;
                        $stars+=$add;*/
                        $stars=0;
                    }
                    ob_start();
                    
                    ?>
                    <?php echo __("Stars : ","my_support_theme").$stars.'<br/>';?>
                    	<div class="my_meta_stars">
							<ul class="my_stars">
								<?php
			                        
		                             $diffC=floor($stars);
			                         $diff=($stars-$diffC)*100;
			                         self::debug("diff",$diff);
			                         for($i=1;$i<6;$i++){?>
										<li class="<?php if($i<=$stars)echo "my_active";?>">
											<i class="fa fa-star"></i>
										</li>
									<?php }
			                         if($diff>0){
			                             if(!isset($my_added_diff)&&$i>$stars){
			                             $my_added_diff=1;
			                             ?>
			     						<li data-diff="<?php echo esc_attr($diff)?>" class="my_stars_diff my_active" style="">
			     							<i class="fa fa-star"></i>
			     						</li>
			     						<?php 
			                             }
			                         }
			                     ?>
							</ul>
                    		</div>
                    <?php 
                            $html=ob_get_clean();
                            echo $html;
                break;    
                case 'myDate':
                    $metaKey=$this->postMetaPrefix.'postDate';
                    $postDate=get_post_meta($post_id,$metaKey,true);
                    echo $postDate." ";
                    $metaKey=$this->postMetaPrefix.'timeInt';
                    $isTime=get_post_meta($post_id,$metaKey,true);
                    if(!empty($isTime)){
                        echo  '<br/>'.__("Time : ","my_support_theme");
                        $metaKey=$this->postMetaPrefix.'hour';
                        $val=get_post_meta($post_id,$metaKey,true);
                        if(!empty($val)){
                            echo $val;
                            echo ":";
                        }
                        $metaKey=$this->postMetaPrefix.'min';
                        $val=get_post_meta($post_id,$metaKey,true);
                        if(!empty($val)){
                            echo $val;
                            echo ":";   
                        }
                        $metaKey=$this->postMetaPrefix.'sec';
                        $val=get_post_meta($post_id,$metaKey,true);
                        if(!empty($val)){
                            echo $val;
                            
                        }
                        
                    }
                    
                break;  
                case 'myCat':
                    $terms=wp_get_post_terms($post_id,$this->postTypeCat);
                   // print_r($terms);
                   $str="";
                   foreach($terms as $k=>$v){
                        if(strlen($str)>0)$str.=",";
                        $str.=$v->name;
                   }
                   echo $str;
                   
                break;    
            }
        }
        /**
         * 
         * @param unknown $columns
         * @return unknown
         */
        public function sortableColumns($columns){
            $columns['myDate']='myDate';
            if($this->enableStars){
                $columns['myStars']='myStars';
                $columns['myStarsNum']='myStarsNum';
            }
            $columns['myLikes']='myLikes';
            return $columns;
        }
        /**
         * count days from 0 year including leap years
         * @param unknown $date
         * @return mixed
         */
        public function countDays($date){
            $arr=explode("/",$date);
            if(count($arr)==3){
                $y=$arr[0];
                $m=$arr[1];
                $d=$arr[2];
                $c=$y;
                $countLeaps=0;
                for($i=0;$i<$c;$i++){
                    if((($i % 4) == 0) && ((($i % 100) != 0) || (($i % 400) == 0))){
                        $countLeaps++;
                     }
                }
                $months=array(31,28,31,30,31,30,31,31,30,31,30,31);
                $daysTotal=366*$countLeaps+(365*($y-1-$countLeaps));
                $year=$y;
                $isLeap=((($year % 4) == 0) && ((($year % 100) != 0) || (($year % 400) == 0)));
                if(!empty($isLeap)){
                    $months[1]=29;
                }
                for($t=0;$t<$m;$t++){
                    $daysTotal+=$months[$t];
                }
                $daysTotal+=$d-1;
                return $daysTotal;
            }
        }
        /**
         * Save post action
         * @param unknown $post_id
         */
        public function savePostAction($post_id){
            if ( wp_is_post_revision( $post_id ) )
                return;
                $initKeys=array(
                    'hearts','starsCount','stars'
                );
                foreach($initKeys as $key=>$val){
                    $meta_key=$this->postMetaPrefix.$val;
                    $val=get_post_meta($post_id,$meta_key,true);
                    if(empty($val)){
                        $up=0;
                        if($val=='stars'){
                            $up=5;
                        }
                        update_post_meta($post_id, $meta_key, $up);
                        
                        
                    }
                }
                $post_type = get_post_type($post_id);
                if($post_type==$this->postTypekey){
                    static $myCustomSavedPost=0;
                    if(!empty($myCustomSavedPost))return;
                   
                    $inclTime=@$_POST['includeTime_timeline_form'];
                    $meta_key=$this->postMetaPrefix.'includeTime';
                    $myAddTimeFloat=0;
                    if(empty($inclTime)){
                        update_post_meta($post_id, $meta_key, 0);
                        $meta_key=$this->postMetaPrefix.'timeInt';
                        update_post_meta($post_id,$meta_key,0);
                    }else {
                        update_post_meta($post_id, $meta_key, 1);
                        $timestamp=0;
                        $hour=@$_POST['hour_timeline_form'];
                        if(empty($hour))$hour=12;
                        $timestamp+=$hour*3600;
                        $meta_key=$this->postMetaPrefix.'hour';
                        update_post_meta($post_id, $meta_key, $hour);
                        $min=@$_POST['min_timeline_form'];
                        if(empty($min))$min=0;
                        $timestamp+=$min*60;
                        $meta_key=$this->postMetaPrefix.'min';
                        update_post_meta($post_id, $meta_key, $min);
                        $sec=@$_POST['sec_timeline_form'];
                        if(empty($sec))$sec=0;
                        $timestamp+=$sec;
                        $myAddTimeFloat=((float)$timestamp/(float)86400);
                        $myAddTimeFloat=round($myAddTimeFloat,4);
                        $meta_key=$this->postMetaPrefix.'sec';
                        update_post_meta($post_id, $meta_key, $sec);
                        $meta_key=$this->postMetaPrefix.'timeInt';
                        update_post_meta($post_id,$meta_key,$timestamp);
                        self::debug("timestamp", $timestamp);
                        
                        
                        
                    }
                    $postDate=@$_POST['postDate_timeline_form'];
                    if(empty($postDate)){
                        $postDate=date("Y/m/d");
                    }
                    $meta_key=$this->postMetaPrefix.'postDate';
                    update_post_meta($post_id, $meta_key, $postDate);
                    $timestampDay=$this->countDays($postDate);
                    if(!empty($myAddTimeFloat)){
                        $timestampDay+=$myAddTimeFloat;
                    }
                    $meta_key=$this->postMetaPrefix.'postDateInt';
                    update_post_meta($post_id, $meta_key, $timestampDay);
                    
                    $isVideoPost=@$_POST['isVideoPost_timeline_form'];
                    if(!empty($isVideoPost)){
                        $meta_key=$this->postMetaPrefix.'isVideoPost';
                        update_post_meta($post_id, $meta_key, 1);
                    }else {
                        $meta_key=$this->postMetaPrefix.'isVideoPost';
                        update_post_meta($post_id, $meta_key, 0);
                    }
                    if(!empty($isVideoPost)){
                        
                        $videoType=@$_POST['my_video_type'];
                       
                        $videoPoster=@$_POST['video_poster_timeline_form'];
                        if(!empty($videoPoster)){
                            $meta_key=$this->postMetaPrefix.'videoPoster';
                            update_post_meta($post_id, $meta_key, $videoPoster);
                        }
                        switch($videoType){
                            case 'url':
                                $meta_key=$this->postMetaPrefix.'videoType';
                                update_post_meta($post_id, $meta_key, $videoType);
                                
                                $check=array(
                                    'mp4',
                                    'm4v',
                                    'webm',
                                    'ogv',
                                    'wmv',
                                    'flv',
                                    
                                );
                                foreach ($check as $key=>$val){
                                    $postKey=$val.'_timeline_form';
                                    $value=@$_POST[$postKey];
                                    if(!empty($value)){
                                        $meta_key=$this->postMetaPrefix.$val;
                                        update_post_meta($post_id, $meta_key, $value);
                                    }
                                    
                                }
                            break;    
                            case 'vimeo':
                                $meta_key=$this->postMetaPrefix.'videoType';
                                update_post_meta($post_id, $meta_key, $videoType);
                                
                                $videoId=@$_POST['vimeo_video_id_timeline_form'];
                                $meta_key=$this->postMetaPrefix.'videoId';
                                update_post_meta($post_id, $meta_key, $videoId);
                                
                            break;    
                            case 'youtube':
                                $meta_key=$this->postMetaPrefix.'videoType';
                                update_post_meta($post_id, $meta_key, $videoType);
                                
                                $videoId=@$_POST['youtube_video_id_timeline_form'];
                                $meta_key=$this->postMetaPrefix.'videoId';
                                update_post_meta($post_id, $meta_key, $videoId);
                                
                            break;    
                            case 'wordpress':
                                $meta_key=$this->postMetaPrefix.'videoType';
                                update_post_meta($post_id, $meta_key, $videoType);
                                $video=@$_POST['wordpress_video_timeline_form'];
                                if(!empty($video)){
                                    if(is_array($video)){
                                        $myVideo=$video[0];
                                    }else $myVideo=$video;
                                }else $myVideo="";
                                
                                $meta_key=$this->postMetaPrefix.'wordpressVideo';
                                update_post_meta($post_id, $meta_key, $myVideo);
                                
                            break;    
                        }
                    }
                    $myCustomSavedPost=1;
                }
        }
        public function admin_head(){
            ?>
            <style type="text/css">
                #toplevel_page_my_pro_timeline .wp-submenu-wrap li:nth-child(3){
                   display:none;
                }
            </style>
            <?php if($this->isEditPage){
                $fileCss=$this->global_plugin->getDir('modules').'timeline/assets/css/stars.css';
                $css=file_get_contents($fileCss);
                ?>
           	<style type="text/css">
                <?php echo $css;?>
            </style>
            <script type="text/javascript">
					jQuery(document).ready(function($){
						$(".my_stars_diff").each(function(i,v){
							var diff=parseInt($(v).attr('data-diff'));
							//self.my_debug("Diff",diff);
							var w=parseInt($(v).width());
							var nW=w*diff/100;
							$(v).width(nW+'px');
							$(v).animate({opacity:1});
						});
					});
				</script>
            <?php }?>
            <?php 
            $my_set_debug=0;
            if($this->debug)$my_set_debug=1;
            if($this->isMyPost){
                ?>
                <script type="text/javascript">
					jQuery(document).ready(function($){
						var o={};
						o.my_debug=<?php echo $my_set_debug;?>;
						myAdminPostTimeline_inst=new myAdminPostTimeline(o);
					});
                </script>
                <?php
            }
            if($this->isShortcodePage){
                $id=@$_GET['my_id'];
                if(empty($id))$id="";
                $msgs=$this->loadOptions('admin_msgs.php');
                $options=$this->global_plugin->loadOptions("ajax_options.php");
                $nonce=$this->ajax_get_nonce($this->ajax_action);
                $sub_page=@$_GET['my_subpage'];
                if(empty($sub_page))$sub_page="dashboard";
                $pageUrl=admin_url("admin.php?page=my_pro_timeline_add_new&my_subpage=".$sub_page);
                ?>
                <script type="text/javascript">
				<!--
				jQuery(document).ready(function($){
				o_ajax=<?php echo json_encode($options);?>;
				myGlobalAjaxClass_inst=new myGlobalAjaxClass(o_ajax);
				o3={};
				myAdminMsgs_inst=new myAdminMsgs(o3);
				var o4={};
				o4.my_nonce="<?php echo $nonce;?>";
				o4.ajax_action="<?php echo $this->ajax_action;?>";
				o4.my_debug=<?php echo $my_set_debug;?>;
				o4.id="<?php echo $id;?>";
				o4.msgs=<?php echo json_encode($msgs);?>;
				o4.pageUrl="<?php echo $pageUrl;?>";
				o4.subPage="<?php echo $sub_page;?>";
				o4.previewUrl="<?php echo admin_url('admin.php?page=my_pro_timeline_preview&my_id={id}');?>";
				myAdminTimeline_inst=new myAdminTimeline(o4);			
							});
				//-->
				
			</script>
                <?php 
            }
            
            
        }
        protected function getCategories(){
            $cats=get_terms($this->postTypeCat);
            self::debug("Cats", $cats);
            return $cats;
        }
        public function admin_footer(){
            if($this->isShortcodePage){
                $file=$this->views_dir.'preview_dialog.php';
                require $file;
            }
            
        }
        /**
         * Render home pAGE
         * @return string
         */
        public function renderHomePage(){
            $file=$this->views_dir.'admin/Home.php';
            ob_start();
            require $file;
            $html=ob_get_clean();
            return $html;
        }
        public function renderPreviewPage(){
           // return "preview";
           $data=array(
                'postType'=>$this->postTypekey,
                'postMetaPrefix'=>$this->postMetaPrefix,
                'metaKeys'=>$this->metaKeys,
                'postStatus'=>array('publish'),
                'orderBy'=>array(
                    'meta_key'=>$this->postMetaPrefix.'postDateInt',
                    'order'=>array('meta_value_num'=>'DESC'),
                 ),
                'limit'=>50
           );
           return $this->frontClassObj->renderPreview($data);
        }
        /**
         * 
         */
        public function getTermsObj(){
            if(!empty($this->termClassObj))return $this->termClassObj;
            $this->global_plugin->loadModel('class-my-model-terms.php');
            $opts=array(
                'taxonomy'=>$this->postTypeTerm,
                'postType'=>$this->postTypekey,
                'debug'=>$this->debug
            );
            $this->termClassObj=new Class_My_General_Terms_Model($opts);
            return $this->termClassObj;
            
        }
        public function renderModuleErrors(){
                if(!empty($this->moduleErrors)){
                    foreach($this->moduleErrors as $key=>$val){
                        echo wp_my_pro_timeline_error_msg($val['msg'],$val['typee']);
                     }
                }
        }
        public function renderOkMsgs(){
            if(!empty($this->moduleOk)){
                foreach($this->moduleOk as $key=>$val){
                    echo wp_my_pro_timeline_ok_msg($val['msg'],$val['type']);
                }
            }
        }
        /**
         * 
         * @param unknown $msg
         * @param string $type
         */
        public function addModuleError($msg,$type='general'){
            $this->moduleErrors[]=array('msg'=>$msg,'type'=>$type);
        }
        /**
         * 
         * @param unknown $msg
         * @param string $type
         */
        public function addModuleOk($msg,$type='general'){
            $this->moduleOk[]=array('msg'=>$msg,'type'=>$type);
        }
        
        /**
         * get userr templates
         */
        protected function getUserTemplates(){
            global $wpdb;
            $table=$this->global_plugin->getProperty('tableObjects');
            $userTemplates=array();
            $query="SELECT * from ".$table." WHERE object_type=%s";
            $query=$wpdb->prepare($query, array('template_style'));
            $res=$wpdb->get_results($query);
            self::debug("userResTemplates", $res);
            if(!empty($res)){
                foreach($res as $k=>$v){
                  $userTemplates[$v->ID]=$v->title;
                }
            }
            return $userTemplates;
        }
        /**
         * Render shortcode page
         * @return string
         */
        public function renderShortcodesPage(){
            //return 'shortcodes';
            $subPage="dashboard";
            if(!empty($_GET['my_subpage'])){
                $subPage=@$_GET['my_subpage'];
            }
            $pages=array(
              'dashboard'=>__("Dashobard","my_support_theme"),
              'horizontal'=>__("Horizontal Timeline","my_support_theme"),
              'vertical'=>__("Vertical Timeline","my_support_theme"),
            );
            $options=$this->global_plugin->loadOptions("meta_options.php");
            $this->initMetaModule($options);
            
            switch($subPage){
                case 'dashboard':
                    $deleteMsg=__("Timeline has been deleted !","my_support_theme");
                    
                    $myAction=@$_POST['my_action'];
                    if(!empty($myAction)){
                        if($myAction=='delete'){
                            $myId=@$_POST['my_object_id'];
                            $is=$this->metaModuleObj->is_exists_object($myId);
                            if(!empty($is)){
                                $object=$this->metaModuleObj->get_object($myId);
                                if($object->object_type=="my_timeline"){
                                    $this->metaModuleObj->delete_object($myId,"my_timeline");
                                    $this->addModuleOk($deleteMsg);
                                }
                            }
                        }
                    }
                    $file=$this->views_dir.'admin/Dashboard.php';
                     $page=1;
                    $per_page=10;
                    $order_col="";
                    $order="";
                    $count=$this->metaModuleObj->countObjects("my_timeline");
                    $total_pages=ceil($count/$per_page);
                    if(!empty($_REQUEST['my_order_col'])){
                        $order_col=$_REQUEST['my_order_col'];
                        $order=$_REQUEST['my_order'];
                    }
                    if(!empty($_REQUEST['my_page'])){
                        $page=$_REQUEST['my_page'];
                        if($page<1){
                            $page=1;
                        }
                        if($page>$total_pages)$page=1;
                    }
                    $results=$this->metaModuleObj->pagerQuery("my_timeline", $page, $per_page, $order_col, $order);
                    if(!empty($results)){
                        foreach ($results as $k=>$v){
                            $object_id=$v->ID;
                            $type=$this->metaModuleObj->get_object_meta($object_id, 'type');
                            $results[$k]->type=$type;
                            $results[$k]->shortcode='[my_pro_timeline id="'.$v->ID.'"]';
                        }
                    }
                    $module_dir=$this->global_plugin->getDir('modules');
                    wp_my_general_load_module($module_dir, "tableview");
                    self::debug("results", $results);
                    self::debug("metaTotal", array('page'=>$page,'total_pages'=>$total_pages,'count'=>$count));
                    $options1=array(
                        'show_pagination_num'=>10,
                        'id'=>'my_timeline',
                        
                        'data'=>array(
                            'form_params'=>array(
                                'my_action'=>'pager',
                                'my_page'=>$page,
                                'my_order_col'=>$order_col,
                                'my_order'=>$order
                            ),
                            'count'=>$count,
                            'per_page'=>$per_page,
                            'page'=>$page,
                            'pages'=>$total_pages,
                            ),
                        'columns'=>array(
                            'title'=>array('title'=>__("Title","my_support_theme"),'order'=>true),
                            'created'=>array('title'=>__("Created","my_support_theme"),'order'=>true),
                            'updated'=>array('title'=>__("Updated","my_support_theme"),'order'=>true),
                            'shortcode'=>array('title'=>__("Shortcode","my_support_theme"),'order'=>false),
                        ),
                        'translate'=>array(
                            'shortcode'=>'[my_pro_timeline id="{id}"]'
                        ),
                        'actions'=>array(
                            'delete'=>__("Delete","my_support_theme"),
                            'preview'=>array('title'=>__("Preview","my_social_posts_domain"),'href'=>admin_url("admin.php?page=my_pro_timeline_preview"),'class'=>'my_preview_posts'),
                            
                            'edit'=>array('title'=>__("Update","my_social_posts_domain"),'href'=>'','class'=>'my_update_posts')
                            
                        )			
                    );
                    $options1['debug']=$this->debug;
                    $options1['actions']['edit']['href']=admin_url('admin.php?page=my_pro_timeline_add_new&my_subpage={type}');
                    
                    $options1['data']['results']=$results;
                    $tableView=new Class_Wp_My_Module_Table_View($options1);
                    ob_start();
                    echo $tableView->render();
                    $tableHtml=ob_get_clean();
                    $this->set_template_vars("tableHtml", $tableHtml);
                    
                break;    
                case 'horizontal':
                    $moduleGoogledir=$this->global_plugin->getDir('modules').'google_font/includes/functions.php';
                    require $moduleGoogledir;
                    $wp_my_google_fonts_fonts=wp_my_google_fonts_get_fonts_arr();
                    
                    $cats=$this->getCategories();
                    $form=$this->loadOptions('horizontalForm.php');
                    $form['postTerms']['nonce_str']=wp_create_nonce($this->ajaxNonceStr);
                    if(!empty($cats)){
                        foreach($cats as $key=>$val){
                            $name=$val->name;
                            $id=$val->term_id;
                            $form['postCategories']['values'][$id]=$name;
                        }
                    }
                    $layouts=$form['layout'];
                    unset($form['layout']);
                    $userTmpls=$this->getUserTemplates();
                    if(!empty($userTmpls)){
                        foreach($userTmpls as $key=>$val){
                            $form['postTemplate']['values'][$key]=$val;
                        }
                    }
                    $form['font_family']['values']=$wp_my_google_fonts_fonts;
                    $arr=$this->layoutArr;
                    foreach ($arr as $k=>$v){
                        $keyL="layout_".$k;
                        $form[$keyL]=$layouts;
                        $form[$keyL]['title']=$v['title'];
                        $form[$keyL]['tooltip']=$v['tooltip'];
                       
                        $form[$keyL]['elements']['cols']['value']=$v['cols'];
                        $form[$keyL]['elements']['height']['value']=$v['height'];
                        
                        
                    }
                    
                    $id=@$_GET['my_id'];
                    if(!empty($id)){
                        self::debug("id", $id);
                        $is=$this->metaModuleObj->is_exists_object($id);
                        if(empty($is)){
                            $this->addModuleError(__("Timeline with this id don't exist!"));
                        }else {
                           $type=$this->metaModuleObj->get_object_meta($id, "type");
                           self::debug("metaType", $type);
                           if($type!="horizontal"){
                               $this->addModuleError(__("Timeline don't exist!"));
                           }else {
                               $object=$this->metaModuleObj->get_object($id);
                               $formVals=$this->metaModuleObj->get_object_meta($id, "form");
                               self::debug("formValues", $formVals);
                               if(!empty($formVals)){
                                    foreach($formVals as $key=>$val){
                                        if(isset($form[$key])){
                                            if($form[$key]['type']=="on_off"){
                                                if(empty($val)){
                                                    $form[$key]['default']=0;
                                                }else $form[$key]['default']=1;
                                            }
                                            else $form[$key]['value']=$val;
                                        }
                                    }
                                    $arr=$this->layoutArr;
                                    foreach($arr as $key=>$val){
                                        $keyL="layout_".$key;
                                        $keyC="layout_".$key."_cols";
                                        $keyH="layout_".$key."_height";
                                        $keyU="layout_".$key."_select";
                                        $valC="";
                                        if(isset($formVals[$keyC])){
                                            $valC=$formVals[$keyC];
                                            $form[$keyL]['elements']['cols']['value']=$valC;
                                        }
                                        $valH="";
                                        if(isset($formVals[$keyH])){
                                            $valH=$formVals[$keyH];
                                            $form[$keyL]['elements']['height']['value']=$valH;
                                        }
                                        if(isset($formVals[$keyU])){
                                            $valU=$formVals[$keyU];
                                            $form[$keyL]['elements']['height']['default_unit']=$valU;
                                        }
                                        
                                        
                                    }
                               }
                           }      
                        }
                    }
                   
                    self::debug("formEl", $form);
                    $ID=@$_GET['my_id'];
                    if(empty($ID))$ID="";
                    else {
                        //load timeline options and populate form
                    }
                    $my_set_debug=0;
                    $this->global_plugin->loadModuleClass("new_form");
                    $options=array(
                        'id'=>'html_form',
                        'elements'=>$form,
                        'hidden'=>array(
                            
                        ),
                        'element_template'=>'my_li.php',
                        'form_template'=>'my_form.php',
                        'my_debug'=>$my_set_debug
                    );
                    $form_class=new Class_Wp_My_Module_New_Form($options);
                    ob_start();
                    $form_class->render_form();
                    $formHtml=ob_get_clean();
                    $file=$this->views_dir.'admin/Horizontal.php';
                break;
                case 'vertical':
                    $moduleGoogledir=$this->global_plugin->getDir('modules').'google_font/includes/functions.php';
                    require $moduleGoogledir;
                    $wp_my_google_fonts_fonts=wp_my_google_fonts_get_fonts_arr();
                    
                    $cats=$this->getCategories();
                    $form=$this->loadOptions('verticalForm.php');
                    $form['postTerms']['nonce_str']=wp_create_nonce($this->ajaxNonceStr);
                    if(!empty($cats)){
                        foreach($cats as $key=>$val){
                            $name=$val->name;
                            $id=$val->term_id;
                            $form['postCategories']['values'][$id]=$name;
                        }
                    }
                    $userTmpls=$this->getUserTemplates();
                    if(!empty($userTmpls)){
                        foreach($userTmpls as $key=>$val){
                            $form['postTemplate']['values'][$key]=$val;
                        }
                    }
                    $id=@$_GET['my_id'];
                    if(!empty($id)){
                        self::debug("id", $id);
                        $is=$this->metaModuleObj->is_exists_object($id);
                        if(empty($is)){
                            $this->addModuleError(__("Timeline with this id don't exist!"));
                        }else {
                            $type=$this->metaModuleObj->get_object_meta($id, "type");
                            self::debug("metaType", $type);
                            if($type!="vertical"){
                                $this->addModuleError(__("Timeline don't exist!"));
                            }else {
                                $object=$this->metaModuleObj->get_object($id);
                                $formVals=$this->metaModuleObj->get_object_meta($id, "form");
                                self::debug("formValues", $formVals);
                                if(!empty($formVals)){
                                    foreach($formVals as $key=>$val){
                                        if(isset($form[$key])){
                                            if($form[$key]['type']=="on_off"){
                                                if(empty($val)){
                                                    $form[$key]['default']=0;
                                                }else $form[$key]['default']=1;
                                            }
                                            else $form[$key]['value']=$val;
                                        }
                                    }
                                   
                                }
                            }
                        }
                    }
                    
                    self::debug("formEl", $form);
                    $form['font_family']['values']=$wp_my_google_fonts_fonts;
                    $ID=@$_GET['my_id'];
                    if(empty($ID))$ID="";
                    else {
                        //load timeline options and populate form
                    }
                    $my_set_debug=0;
                    $this->global_plugin->loadModuleClass("new_form");
                    $options=array(
                        'id'=>'html_form',
                        'elements'=>$form,
                        'hidden'=>array(
                            
                        ),
                        'element_template'=>'my_li.php',
                        'form_template'=>'my_form.php',
                        'my_debug'=>$my_set_debug
                    );
                    $form_class=new Class_Wp_My_Module_New_Form($options);
                    ob_start();
                    $form_class->render_form();
                    $formHtml=ob_get_clean();
                    $file=$this->views_dir.'admin/Vertical.php';
                break;    
            }
            $html="";
            if(file_exists($file)){
                ob_start();
                require $file;
                $html=ob_get_clean();
                self::debug("file", $file);
                self::debug("html", $html);
            }
            $pageUrl=admin_url("admin.php?page=my_pro_timeline_add_new");
            //$this->set_template_vars("subPage", $subPage);
            $viewFile=$this->views_dir.'admin/shortcodesPage.php';
            ob_start();
            require $viewFile;
            $html=ob_get_clean();
            return $html;
        }
        public function admin_scripts(){
            if($this->isMyPost){
                wp_enqueue_script('jquery');
                wp_enqueue_script("jquery-touch-pounch");
                wp_enqueue_script('jquery-ui-core');
                wp_enqueue_script("jquery-ui-widget");
                wp_enqueue_script("jquery-ui-dialog");
                wp_enqueue_script('jquery-effects-core');
                wp_enqueue_script("jquery-ui-tooltip");
                wp_enqueue_script("jquery-ui-resizable");
                wp_enqueue_script("jquery-ui-draggable");
                wp_enqueue_script("jquery-ui-droppable");
                //wp_enqueue_media();
                $url=$this->global_plugin->getUrl('jscript').'admin/my_ajax.js';
                wp_enqueue_script('my_framework_ajax',$url);
                $url=$this->global_plugin->getUrl('jscript').'admin/admin_msgs.js';
                wp_enqueue_script("my_framework_msgs",$url);
                
                $url=$this->global_plugin->getUrl('css').'msgs.css';
                wp_enqueue_style("my_testimonials_msgs_form",$url);
                $url=$this->global_plugin->getUrl('css').'admin.css';
                wp_enqueue_style("my_testimonials_admin_css",$url);
                $url=$this->global_plugin->getUrl('css').'admin_menu.css';
                wp_enqueue_style("my_testimonials_admin_menu",$url);
                $url=$this->global_plugin->getUrl('css').'jquery-ui.css';
                wp_enqueue_style("my_testimonials_jquery_ui",$url);
                
                
                $url=$this->getUrl('jscript');
                wp_enqueue_script('my_mapper_admin_js',$url.'myPost.js');
                //wp_enqueue_script('my_mapper_front_js',$url.'front.js');
                
                $css_url=$this->getUrl('css');
                
                wp_enqueue_style('my_framework_templates_form_css',$css_url.'form.css');
                
                
                $dialog_jscript=$this->global_plugin->getUrl('jscript').'admin/myUiDialog.js';
                wp_enqueue_script('myUiDialog',$dialog_jscript);
                
                
                
            }else if($this->isShortcodePage){
                wp_enqueue_script('jquery');
                wp_enqueue_script("jquery-touch-pounch");
                wp_enqueue_script('jquery-ui-core');
                wp_enqueue_script("jquery-ui-widget");
                wp_enqueue_script("jquery-ui-dialog");
                wp_enqueue_script('jquery-effects-core');
                wp_enqueue_script("jquery-ui-tooltip");
                wp_enqueue_script("jquery-ui-resizable");
                wp_enqueue_script("jquery-ui-draggable");
                wp_enqueue_script("jquery-ui-droppable");
               // wp_enqueue_script("jquery-ui-dialog");
                //wp_enqueue_media();
                $url=$this->global_plugin->getUrl('jscript').'admin/my_ajax.js';
                wp_enqueue_script('my_framework_ajax',$url);
                $url=$this->global_plugin->getUrl('jscript').'admin/admin_msgs.js';
                wp_enqueue_script("my_framework_msgs",$url);
                
                $url=$this->global_plugin->getUrl('css').'msgs.css';
                wp_enqueue_style("my_testimonials_msgs_form",$url);
                $url=$this->global_plugin->getUrl('css').'admin.css';
                wp_enqueue_style("my_testimonials_admin_css",$url);
                $url=$this->global_plugin->getUrl('css').'admin_menu.css';
                wp_enqueue_style("my_testimonials_admin_menu",$url);
                $url=$this->global_plugin->getUrl('css').'jquery-ui.css';
                wp_enqueue_style("my_testimonials_jquery_ui",$url);
                
                
                $url=$this->getUrl('jscript');
                wp_enqueue_script('my_timeline_admin_js',$url.'myTimelineAdmin.js');
                //wp_enqueue_script('my_mapper_front_js',$url.'front.js');
                
                $css_url=$this->getUrl('css');
                
                wp_enqueue_style('my_framework_templates_form_css',$css_url.'form.css');
                
                
                $dialog_jscript=$this->global_plugin->getUrl('jscript').'admin/myUiDialog.js';
                wp_enqueue_script('myUiDialog',$dialog_jscript);
                
            }
        }
        public function renderForm(){
            $this->isPostPage();
            $this->renderMetaboxForm();
        }
        protected function isPostPage(){
            global $pagenow;
            if($pagenow=='post-new.php'){
                $type=@$_GET['post_type'];
                if(!empty($type)){
                    if($type==$this->postTypekey)$this->isMyPost=true;
                }
            }else if($pagenow=='post.php'){
                $action=@$_GET['action'];
                if(!empty($action)){
                    if($action=='edit'){
                        $post_id=@$_GET['post'];
                        $post=get_post($post_id);
                        //global $post;
                        //self::debug($key, $val)
                        if($post->post_type==$this->postTypekey){
                            $this->isMyPost=true;
                            $this->myPostID=$post_id;
                            $this->isPostEdit=true;
                        }
                    }
                }
            }
        }
        protected function renderMetaboxForm(){
            if($this->isMyPost){
                $form=$this->loadOptions('postMetaboxForm.php');
                for($i=0;$i<24;$i++){
                    $form['hour']['values'][$i]=$i;
                }
                $this->set_template_vars("currTab", "wordpress");
                if($this->isPostEdit){
                    $post_id=$this->myPostID;
                    $meta_key=$this->postMetaPrefix.'includeTime';
                    $inclTime=get_post_meta($post_id,$meta_key,true);
                    if(!empty($inclTime)){
                        $form['includeTime']['default']=1;
                        $meta_key=$this->postMetaPrefix.'hour';
                        $value=get_post_meta($post_id,$meta_key,true);
                        $form['hour']['value']=$value;
                        $meta_key=$this->postMetaPrefix.'min';
                        $value=get_post_meta($post_id,$meta_key,true);
                        $form['min']['value']=$value;
                        $meta_key=$this->postMetaPrefix.'sec';
                        $value=get_post_meta($post_id,$meta_key,true);
                        $form['sec']['value']=$value;
                        
                        
                    }
                    $meta_key=$this->postMetaPrefix.'postDate';
                    $postDate=get_post_meta($post_id,$meta_key,true);
                    $form['postDate']['value']=$postDate;
                    $meta_key=$this->postMetaPrefix.'isVideoPost';
                    $isVideoPost=get_post_meta($post_id,$meta_key,true);
                    if(!empty($isVideoPost)){
                        $form['isVideoPost']['default']=1;
                        $meta_key=$this->postMetaPrefix.'videoType';
                        
                        $videoType=get_post_meta($post_id,$meta_key,true);
                        self::debug("videoType", $videoType);
                        
                       
                        $this->set_template_vars("currTab", $videoType);
                        $meta_key=$this->postMetaPrefix.'videoPoster';
                        $videoPoster=get_post_meta($post_id,$meta_key,true);
                        if(!empty($videoPoster)){
                            $form['video']['video_poster']['value']=$videoPoster;
                        }
                        switch($videoType){
                            case 'url':
                                $check=array(
                                'mp4',
                                'm4v',
                                'webm',
                                'ogv',
                                'wmv',
                                'flv',
                                
                                );
                                foreach ($check as $key=>$val){
                                    $meta_key=$this->postMetaPrefix.$val;
                                    $value=get_post_meta($post_id,$meta_key,true);
                                    if(!empty($value)){
                                        $form['video'][$val]['value']=$value;
                                    }
                                }
                            break;    
                            case 'wordpress':
                                $meta_key=$this->postMetaPrefix.'wordpressVideo';
                                $wordpressVideo=get_post_meta($post_id,$meta_key,true);
                                $form['video']['wordpress_video']['value']=array($wordpressVideo);
                            break;   
                            case 'vimeo':
                                $meta_key=$this->postMetaPrefix.'videoId';
                                $video=get_post_meta($post_id,$meta_key,true);
                                $form['video']['vimeo_video_id']['value']=$video;
                            break;    
                            case 'youtube':
                                $meta_key=$this->postMetaPrefix.'videoId';
                                $video=get_post_meta($post_id,$meta_key,true);
                                $form['video']['youtube_video_id']['value']=$video;
                            break;    
                        }
                    }
                }
                $video=$form['video'];
                unset($form['video']);
                $this->loadFormModule();
                ob_start();
                echo $this->formModuleObj->renderElements($form);
                $this->formMetaboxHtml=ob_get_clean();
                ob_start();
                $file=$this->views_dir.'admin/metabox.php';
                require $file;
                $this->formMetaboxHtml.=ob_get_clean();
            }
        }
        public function add_metaboxes(){
            add_meta_box('my_timeline', __("Adjust post type params","my_support_theme"), array(&$this,'metabox'),$this->postTypekey,'normal','default');
            
        }
        public function metabox(){
           // echo 'metabox';
           echo $this->formMetaboxHtml; 
        }
        
        public function registerPostType(){
            $this->postTypeArr=$this->loadOptions('post-type.php');
            register_post_type($this->postTypekey,$this->postTypeArr);
            $this->postTypeCatArr=$this->loadOptions('post-terms.php');
            $this->postTypeTermArr=$this->loadOptions('post-terms1.php');
            register_taxonomy($this->postTypeCat, $this->postTypekey,$this->postTypeCatArr);
            register_taxonomy($this->postTypeTerm, $this->postTypekey,$this->postTypeTermArr);
        }
    }
}
        