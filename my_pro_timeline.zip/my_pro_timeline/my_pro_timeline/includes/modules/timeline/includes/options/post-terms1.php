<?php
if(!defined('ABSPATH'))die('');
$arr=array(
    'label'=>__("My Timelines Terms","my_support_theme"),
    'labels'=>array(
        'name'=>__("My Timelines Term","my_support_theme"),
        'singular_name'=>__("My Timeline Term","my_support_theme"),
        'menu_name'=>__("Terms","my_support_theme"),
    ),
    'public'=>true,
    'show_ui'=>true,
    'show_in_menu'=>true,
    'show_in_quick_edit'=>true,
    'description'=>__("Group timeline by terms. Allow to filter testimonials by category.","my_support_theme"),
    'hierarchical'=>false,
    
);
return $arr;