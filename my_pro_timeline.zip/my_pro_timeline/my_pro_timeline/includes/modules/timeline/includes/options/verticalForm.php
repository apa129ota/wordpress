<?php
if(!defined('ABSPATH'))die('');
$units = array(
    'px' => 'px',
    '%' => '%');
$arr=array(
    'title'=>array(
        'layout_class'=>'my_col_100',
        'type'=>'text',
        'title'=>__("Title","my_related_posts_domain"),
        'tooltip'=>__("Add shortcode title","my_related_posts_domain"),
        'placeholder'=>__("Title","my_related_posts_domain"),
    ),
    'postCategories'=>array(
        'layout_class'=>'my_col_50',
        'type'=>'jscript_dropdown',
        'title'=>__("Categories","my_related_posts_domain"),
        'tooltip'=>__("Select Categories of posts","my_related_posts_domain"),
        'widths'=>array(
            600=>'100%',
            1200=>'25%',
            
        ),
        'jscript'=>array(
            'max_c'=>100000,
            'max_sel'=>__("Maximum elements are selected","my_related_posts_domain"),
            'duration'=>500,
            'animation'=>'fadein',
            'choose_value'=>__("Plese Select value","my_related_posts_domain"),
        ),
        'show_filter'=>1,
        'multiple'=>true,
        'choose_value'=>__("Plese Select value","my_related_posts_domain"),
        'default'=>array(),
        'values'=>array(
            
               
        )
    ),
    'postTerms'=>array(
        'layout_class'=>'my_col_50',
        'type'=>'jscript_autocomplete',
        'tooltip'=>__("Post terms","my_related_posts_domain"),
        'title'=>__("Filter posts by terms","my_related_posts_domain"),
        'nonce_str'=>'',
        'multiple'=>true,
        'show_values'=>true,
        'jscript'=>array(
            'show_values'=>1,
            'url'=>admin_url('admin-ajax.php'),
            'my_action'=>'getPostTerms',
            'action'=>'my_pro_timeline_ajax',
            'max_c'=>-1,
            'max_sel'=>__("Maximum elements are selected","my_related_posts_domain"),
            'duration'=>500,
            'animation'=>'fadein',
            'events'=>array(
                'select_event'=>'function(obj,val){console.log("Select event",val);}',
                'close_event'=>'function(obj,val){console.log("cLOSE event",val);}'
            )
            
        )
    ),
    'show_line'=>array(
        'layout_class'=>'my_col_33',
        'type'=>'on_off',
        'default'=>1,
        'title'=>__("Show Line Dates","my_support_theme"),
        'tooltip'=>__("If you enable this option, line with dates will be showed at top of timeline.","my_support_theme"),
        
    ),
    'theme'=>array(
        'layout_class'=>'my_col_33',
        'type'=>'jscript_dropdown',
        'title'=>__("Theme","my_related_posts_domain"),
        'tooltip'=>__("Select general theme","my_related_posts_domain"),
        'default'=>'blueTheme',
        'values'=>array(
            'defaultTheme'=>__("Default","my_support_theme"),
            'blueTheme'=>__("Blue theme","my_support_theme"),
                    )
    ),
    'font_family' => array(
        'layout_class' => 'my_col_33',
        'type' => 'jscript_dropdown',
        'title' => __("Font", "my_support_theme"),
        'tooltip' => __("Choose default font or some google fonts", "my_support_theme"),
        'jscript' => array(
            'max_c' => 1,
            'max_sel' => __("Maximum elements are selected", "my_support_theme"),
            'duration' => 500,
            'animation' => 'fadein',
            'choose_value' => __("Plese Select value", "my_support_theme")
        ),
        'show_filter' => 1,
        'multiple' => false,
        'choose_value' => __("Plese Select value", "my_support_theme"),
        'default' => 'default',
        'translate' => array(
            'class' => '.my_testimonial_item *:not(i)',
            'property' => 'font-family'
        )
        
    ),
    
    'postTemplate'=>array(
        'layout_class'=>'my_col_33',
        'type'=>'jscript_dropdown',
        'title'=>__("Template","my_related_posts_domain"),
        'tooltip'=>__("Select post template","my_related_posts_domain"),
        'default'=>'template_1',
        'values'=>array(
            'template_11'=>__("Full image","my_support_theme"),
            'template_1' => __("Template 1", "my_support_theme"),
            'template_2' => __("Template 2", "my_support_theme"),
            'template_6' => __("Template 3", "my_support_theme"),
            'template_8' => __("Template 4", "my_support_theme"),
            'template_10' => __("Blue Template", "my_support_theme")
            
        )
    ),
    'startDate'=>array(
            'layout_class'=>'my_col_33',
            'type'=>'date',
            'title'=>__("Start Date","my_related_posts_domain"),
            'tooltip'=>__("Start date of the timeline.Leave empty if you doont want to display posts from the date.","my_related_posts_domain"),
        
    ),
    'endDate'=>array(
        'layout_class'=>'my_col_33',
        'type'=>'date',
        'title'=>__("End Date","my_related_posts_domain"),
        'tooltip'=>__("End date of the timeline.Leave empty if you doont want to display posts until the date.","my_related_posts_domain"),
        
    ),
    
    
    'openDialog'=>array(
        'layout_class'=>'my_col_33',
        'type'=>'jscript_dropdown',
        'default'=>'dialog',
        'title'=>__("Open full post","my_related_posts_domain"),
        'tooltip'=>__("Open full post in the samw window like dialog, or in the slider area, or in new href.","my_related_posts_domain"),
        'widths'=>array(
            600=>'100%',
            1200=>'25%',
            
        ),
        'jscript'=>array(
            'max_c'=>100000,
            'max_sel'=>__("Maximum elements are selected","my_related_posts_domain"),
            'duration'=>500,
            'animation'=>'fadein',
            'choose_value'=>__("Plese Select value","my_related_posts_domain"),
        ),
        'show_filter'=>0,
        'multiple'=>false,
        
        'values'=>array(
            'dialog'=>__("Dialog in the same window","my_support_theme"),
            //'sliderArea'=>__("Slider area","my_support_theme"),
            'href'=>__("New browser tab","my_support_theme"),
           // 'newWindow'=>__("New window","my_support_theme")
        )
        
    ),
    'prettyPhoto'=>array(
        'layout_class'=>'my_col_33',
        'type'=>'on_off',
        'default'=>0,
        'title'=>__("Pretty Photo","my_support_theme"),
        'tooltip'=>__("If you enable this option all images will be showed in pretty photo window.","my_support_theme"),
        
    ),
    /*
    'swipeOn'=>array(
        'layout_class'=>'my_col_33',
        'type'=>'on_off',
        'default'=>1,
        'title'=>__("Swipe on","my_support_theme"),
        'tooltip'=>__("If you enable this option mouse swipe will be enabled.","my_support_theme"),
        
    ),
    */
    'duration'=>array(
        'layout_class'=>'my_col_33',
        'type'=>'jscript_spinner',
        'default'=>"1500",
        'title'=>__("Animation duration","my_support_theme"),
        'tooltip'=>__("If you enable this option mouse swipe will be enabled.","my_support_theme"),
        
    ),
    
    'easing'=>array(
        'layout_class'=>'my_col_33',
        'type'=>'jscript_dropdown',
        'title'=>__("Animation Easing","my_related_posts_domain"),
        'tooltip'=>__("Select Animation Easing type","my_related_posts_domain"),
        'widths'=>array(
            600=>'100%',
            1200=>'25%',
            
        ),
        'jscript'=>array(
            'max_c'=>100000,
            'max_sel'=>__("Maximum elements are selected","my_related_posts_domain"),
            'duration'=>500,
            'animation'=>'fadein',
            'choose_value'=>__("Plese Select value","my_related_posts_domain"),
        ),
        'show_filter'=>1,
        'multiple'=>false,
        'choose_value'=>__("Plese Select value","my_related_posts_domain"),
        'default'=>'linear',
        'values'=>array(
            'linear'=>__("Linear","my_support_theme"),
            'swing'=>__("Swing","my_support_theme"),
            'easeInQuad'=>__("Ease In Quad","my_support_theme"),
            'easeOutQuad'=>__("Ease Out Quad","my_support_theme"),
            'easeInOutQuad'=>__("Ease In Out Quad","my_support_theme"),
            'easeInCubic'=>__("Ease In Cubic","my_support_theme"),
            'easeOutCubic'=>__("Ease Out Cubic","my_support_theme"),
            'easeInOutCubic'=>__("Ease In Out Cubic","my_support_theme"),
            'easeInQuart'=>__("Ease In Quart","my_support_theme"),
            'easeOutQuart'=>__("Ease Out Quart","my_support_theme"),
            'easeInOutQuart'=>__("Ease In Out Quart","my_support_theme"),
            'easeInQuint'=>__("Ease In Quint","my_support_theme"),
            
            'easeOutQuad'=>__("Out Quad","my_support_theme"),
            'easeOutQuint'=>__("Ease Out Quint","my_support_theme"),
            'easeInOutQuint'=>__("Ease In Out Quint","my_support_theme"),
            'easeInSine'=>__("Ease In Sine","my_support_theme"),
            'easeOutSine'=>__("Ease Out Sine","my_support_theme"),
            'easeInOutSine'=>__("Ease In Out Sine","my_support_theme"),
            'easeInExpo'=>__("Ease In Expo","my_support_theme"),
            'easeOutExpo'=>__("Ease Out Expo","my_support_theme"),
            'easeInOutExpo'=>__("Ease In Out Expo","my_support_theme"),
            'easeInCirc'=>__("Ease In Circ","my_support_theme"),
            'easeOutCirc'=>__("Ease Out Circ","my_support_theme"),
            'easeInOutCirc'=>__("Ease In Out Circ","my_support_theme"),
            'easeInElastic'=>__("Ease In Elastic","my_support_theme"),
            'easeOutElastic'=>__("Ease Out Elastic","my_support_theme"),
            'easeInOutElastic'=>__("Ease In Out Elastic","my_support_theme"),
            'easeInBack'=>__("Ease In Back","my_support_theme"),
            'easeOutBack'=>__("Ease Out Back","my_support_theme"),
            'easeInOutBack'=>__("Ease In Out Back","my_support_theme"),
            'easeInBounce'=>__("Ease In Bounce","my_support_theme"),
            'easeOutBounce'=>__("Ease Out Bounce","my_support_theme"),
            'easeInOutBounce'=>__("Ease In Out Bounce","my_support_theme"),
            
        )
    ),
   /* 
    'sliderCursor'=>array(
        'layout_class'=>'my_col_33',
        'type'=>'jscript_dropdown',
        'title'=>__("Slider Cursor","my_related_posts_domain"),
        'tooltip'=>__("Select slider left,right cursors type","my_related_posts_domain"),
        'widths'=>array(
            600=>'100%',
            1200=>'25%',
            
        ),
        'jscript'=>array(
            'max_c'=>1,
            'max_sel'=>__("Maximum elements are selected","my_related_posts_domain"),
            'duration'=>500,
            'animation'=>'fadein',
            'choose_value'=>__("Plese Select value","my_related_posts_domain"),
        ),
        'show_filter'=>0,
        'multiple'=>false,
        'choose_value'=>__("Plese Select value","my_related_posts_domain"),
        'default'=>'images',
        'values'=>array(
            'default'=>__("Default","my_support_theme"),
            'images'=>__("Post Images","my_support_theme")
            
        )
    ),*/
    'animation'=>array(
        'layout_class'=>'my_col_33',
        'type'=>'jscript_dropdown',
        'title'=>__("Javascript animation","my_related_posts_domain"),
        'tooltip'=>__("Animate posts when they are showed in vertical timeline.","my_related_posts_domain"),
        'widths'=>array(
            600=>'100%',
            1200=>'25%',
            
        ),
        'jscript'=>array(
            'max_c'=>1,
            'max_sel'=>__("Maximum elements are selected","my_related_posts_domain"),
            'duration'=>500,
            'animation'=>'fadein',
            'choose_value'=>__("Plese Select value","my_related_posts_domain"),
        ),
        'show_filter'=>0,
        'multiple'=>false,
        'choose_value'=>__("Plese Select value","my_related_posts_domain"),
        'default'=>'fadein',
        'values'=>array(
            'none'=>__("None","my_support_theme"),
            
            'fadein'=>__("Fadein","my_support_theme"),
            'scale'=>__("Scale","my_support_theme"),
            'fromLeft'=>__("Slide from left","my_support_theme"),
            'fromRight'=>__("Slide from right","my_support_theme"),
            'fromUp'=>__("Slide from up","my_support_theme"),
            
            //'from'=>__("Slide from top","my_support_theme"),
            'fromBottom'=>__("Slide from bottom","my_support_theme"),
           
            
        )
    ),
    'limit'=>array(
        'layout_class'=>'my_col_33',
        'type'=>'text',
        'default'=>"10",
        'title'=>__("Limit posts per page load","my_support_theme"),
        'tooltip'=>__("Limit posts per page load, Ajax will load new posts after scroll to the bottom of timelline area.","my_support_theme"),
    ),
    "height"=>array(
        'title'=>__("Height","my_support_theme"),
        'type'=>'jscript_spinner',
        'layout_class'=>'my_col_33',
        "default"=>"400",
        "default_unit"=>"px",
        "units"=>array("px"=>__("px","my_support_theme"))
    )
   /* 'showThumbs'=>array(
        'layout_class'=>'my_col_33',
        'type'=>'on_off',
        'default'=>1,
        'title'=>__("Show thumbs slider","my_support_theme"),
        'tooltip'=>__("If you enable this option,thumbs will be showed at the bottom or top of slider.","my_support_theme"),
    ),
    'thumbPosition'=>array(
        'layout_class'=>'my_col_33',
        'type'=>'jscript_radio_list',
        'default'=>"bottom",
        'title'=>__("Thumbs position","my_support_theme"),
        'tooltip'=>__("If you enaable thumbs , then this is option for position of thumbs slider , top or bottom of slider.","my_support_theme"),
        'values'=>array(
            'top'=>__("Top","my_support_theme"),
            'bottom'=>__("Bottom","my_support_theme"),
        )
        
    ),
    */
    /*'loadMore'=>array(
        'layout_class'=>'my_col_33',
        'type'=>'on_off',
        'default'=>1,
        'title'=>__("Load More","my_support_theme"),
        'tooltip'=>__("If we have more posts in the timeline,add load more button so earlier posts will be loaded in separet horizontal timeline.","my_support_theme"),
    ),*/
    /*
    'enableSearchByDate'=>array(
        'layout_class'=>'my_col_33',
        'type'=>'on_off',
        'default'=>1,
        'title'=>__("Enable Search by date","my_support_theme"),
        'tooltip'=>__("If you enable this option ,date autocomplete will be showed where they can enter date and show posts on that date.","my_support_theme"),
    ),
    'enableSearchByTitle'=>array(
        'layout_class'=>'my_col_33',
        'type'=>'on_off',
        'default'=>1,
        'title'=>__("Enable Search by title","my_support_theme"),
        'tooltip'=>__("If you enable this option ,title autocomplete will be show where they can show post by that title .","my_support_theme"),
    ),
    */
    /*
    'autoplay'=>array(
        'layout_class'=>'my_col_33',
        'type'=>'on_off',
        'default'=>0,
        'title'=>__("Autoplay","my_support_theme"),
        'tooltip'=>__("If you enable this option ,autoplay will be enabled by default .","my_support_theme"),
    ),
    'autoplay_timeout'=>array(
        'title'=>__("Autoplay timeout in milisecs","my_support_theme"),
        'type'=>'jscript_spinner',
        'tooltip'=>__("Autoplay Timeout in seconds","my_support_theme"),
        
        "default"=>"5000",
       
    )*/
    
    );
/*
$arr['layout']=array(
    'type'=>'multi',
    'isInline'=>true,
    'layout_class'=>'my_col_33',
    'elements'=>array(
        'cols'=>array(
            
            'title'=>__("Columns","my_support_theme"),
            'type'=>'jscript_spinner',
            'units'=>"",
            "default"=>"3"   
        ),
        "height"=>array(
            'title'=>__("Height","my_support_theme"),
            'type'=>'jscript_spinner',
            
            "default"=>"80",
            "default_unit"=>"%",
            "units"=>$units
        )
        )
);
*/
return $arr;