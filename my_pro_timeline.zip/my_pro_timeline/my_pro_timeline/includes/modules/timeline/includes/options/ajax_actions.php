<?php
if(!defined('ABSPATH'))die('');
$arr['backend']=array(
	'controller_file'=>'class-my-pro-timeline-ajax-controller.php',
	'controller_name'=>'Class_My_Timeline_Module_Backend_Ajax_Controller',
	'my_actions'=>array(
	    'saveTimeline'=>array(
	        'is_logged'=>1,
	        'capability'=>'manage_options'
	    ),
	    'getPostTerms'=>array(
	        'is_logged'=>1,
	        'capability'=>'manage_options'
	    ),
	    
	    
	)
);
return $arr;