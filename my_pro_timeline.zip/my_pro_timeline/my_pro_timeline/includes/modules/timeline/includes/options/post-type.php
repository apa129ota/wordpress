<?php
if(!defined('ABSPATH'))die('');
$arr=array(
		'label'=>__("My Timeline","my_support_theme"),
		'labels'=>array(
			'name'=>__("My Timeline","my_support_theme"),
			'singular_name'=>__("My Timeline","my_support_theme"),
			'add_new'=>__("Add New My Timeline","my_support_theme"),
			'add_new_item'=>__("Add New My Timeline","my_support_theme"),
			'edit_item'=>__("Edit My Timeline","my_support_theme"),
			'new_item'=>__("New My Timeline","my_support_theme"),
			'view_item'=>__("View My Timeline","my_support_theme"),
			'search_items'=>__("Search My Timeline","my_support_theme"),
			'not_found'=>__("Not Found","my_support_theme"),
			'not_found_in_trash'=>__("Not Found in trash","my_support_theme"),
			'parent_item_colon'=>__("Parent","my_support_theme"),
			'all_items'=>__("All My Timeline","my_support_theme"),
			'archives'=>__("Archives","my_support_theme"),
			'insert_into_item'=>__("Insert Into My Timeline","my_support_theme"),
			'uploaded_to_this_item'=>__("Uploaded to this My Timeline item","my_support_theme"),
		),
		'public'=>true,
		'exclude_from_search'=>true,
		'publicly_queryable'=>true,
		'show_ui'=>true,
		'show_in_nav_menus'=>true,
		'menu_position'=>5,
		'map_meta_cap'=>true,
		'capability_type'=>'post',
		'supports'=>array('title','editor','excerpt','thumbnail')
			
);
//$ret['my_help']=$arr;
return $arr;