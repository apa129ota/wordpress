<?php
if(!defined('ABSPATH'))die('');
$arr=array(
    'postDate'=>array(
        'type'=>'date',
        'title'=>__("Timeline post date","my_support_theme"),
        'tooltip'=>__("Timeline post date in format yyyy/mm/dd, showed in navigation bar and posts are ordered by this value in your timeline.","my_support_theme"),      
    ),
    'includeTime'=>array(
        'type'=>'on_off',
        'default'=>0,
        'title'=>__("Include time in date","my_support_theme"),
        'tooltip'=>__("If you have more posts per day, you can add time of the post.","my_support_theme"),
    ),
    'hour'=>array(
        'title'=>__("Hour","my_support_theme"),
        'tooltip'=>__("Hour in 24 format.","my_support_theme"),
        
        'type'=>'select',
        'value'=>'12',
        'values'=>array(
            
        )
    ),
    'min'=>array(
        'title'=>__("Minutes","my_support_theme"),
        'tooltip'=>__("Minutes.","my_support_theme"),
        
        'type'=>'text',
        'default'=>"10"
    ),
    'sec'=>array(
        'title'=>__("Seconds","my_support_theme"),
        'tooltip'=>__("Seconds.","my_support_theme"),
        'default'=>"10",
        'type'=>'text'
    ),
   
    'isVideoPost'=>array(
        'type'=>'on_off',
        'default'=>0,
        'title'=>__("Is Video Post","my_support_theme"),
        'tooltip'=>__("You can choose a video posts in your timelines","my_support_theme"),     
    )
    );
$options['form']=array(
    /*'video_type'=>array(
        'type'=>'jscript_dropdown',
        'jscript'=>array(
            'max_c'=>1,
            'max_sel'=>__("Maximum elements are selected","my_support_theme"),
            'duration'=>500,
            'animation'=>'fadein',
            'choose_value'=>__("Plese Select value","my_support_theme"),
        ),
        'title'=>__("Video Type","my_support_theme"),
        'tooltip'=>__("","my_support_theme"),
        'show_filter'=>0,
        'multiple'=>false,
        'default'=>'wordpress',
        'values'=>array(
            'youtube'=> __("Youtube Video","my_support_theme"),
            'vimeo'=>__("Vimeo","my_support_theme"),
            'wordpress'=>__("Media Video","my_support_theme"),
            'url'=>__("Add Video url","my_support_theme"),
        ),
    ),*/
    'wordpress_video'=>array(
        'type'=>'jscript_media',
        'jscript'=>array(
            'max_c'=>1,
            'max_sel'=>__("Maximum elements are selected","my_support_theme"),
            'duration'=>500,
            'animation'=>'fadein',
            'choose_value'=>__("Plese Select value","my_support_theme"),
            'filter_type'=>'video',
            'multiple'=>0,
            'add_html'=>0
            
        ),
        'choose_title'=>__("Add video","my_support_theme"),
        
        'title'=>__("Wordpress video","my_support_theme"),
        'tooltip'=>__("Add video from wordpress embed","my_support_theme"),
        'show_filter'=>0,
        'show_values'=>1,
        'multiple'=>false,
        
    ),
    /*
     'video_attrs'=>array(
     'style'=>array('display','none'),
     'title'=>__("Video Attributes","my_support_theme"),
     'tooltip'=>__("Change video attributes","my_support_theme"),
     'type'=>'multi',
     'elemenst'=>array(
     'preload'=>array(
     'type'=>'checkbox',
     'label'=>__("Load Video when page is loadded","my_support_theme")
     )
     )
         
     ),*/
    'video_poster'=>array(
        'type'=>'thumb',
        'title'=>__("Video Poster","my_support_theme"),
        'tooltip'=>__("Add Video poster thumb this value has no effects on videos from youtube or vimeo..","my_support_theme"),
        'property'=>array(
            'class'=>'{class}',
            'property'=>'background'
        ),
        'choose_title'=>__("Change Thumb","my_related_posts_domain"),
        'no_image'=>__("No Image","my_related_posts_domain"),
        'choose_title'=>__("Choose Media","my_related_posts_domain"),
        'remove'=>__("Remove Media","my_related_posts_domain"),
        'jscript'=>array(
            'can_remove'=>true,
            'multiple'=>0,
            'show_values'=>1,
            'max_c'=>1,
            'choose_title'=>__("Choose Media","my_related_posts_domain"),
            'media_title'=>__("Choose Image","my_related_posts_domain"),
            'button_text'=>__("Insert","my_related_posts_domain"),
            'filter_type'=>'image',//audio video image
            
        )),
    'youtube_video_id'=>array(
        'type'=>'text',
        'title'=>__("Video Id","my_support_theme"),
        'tooltip'=>__("Youtube video id or vimeo video id.","my_support_theme"),
        'default'=>'',
    ),
    'vimeo_video_id'=>array(
        'type'=>'text',
        'title'=>__("Video Id","my_support_theme"),
        'tooltip'=>__("Youtube video id or vimeo video id.","my_support_theme"),
        'default'=>'',
    ),
    
    'mp4'=>array(
        /*'classes'=>array(
          'my_hide_el_12'  
        ),*/
        'layout_class'=>'my_col_33',
        'type'=>'text',
        'title'=>__("Mp4 video link","my_support_theme"),
        'tooltip'=>__("Mpv video type url","my_support_theme"),
        'default'=>'',
    ),
    'm4v'=>array(
        'layout_class'=>'my_col_33',
        'type'=>'text',
        'title'=>__("M4v video link","my_support_theme"),
        'tooltip'=>__("Mv4 video url","my_support_theme"),
        'default'=>'',
    ),
    'webm'=>array(
        'layout_class'=>'my_col_33',
        'type'=>'text',
        'title'=>__("Webm video link","my_support_theme"),
        'tooltip'=>__("Webm video url","my_support_theme"),
        'default'=>'',
    ),
    'ogv'=>array(
        'layout_class'=>'my_col_33',
        'type'=>'text',
        'title'=>__("Ogv video link","my_support_theme"),
        'tooltip'=>__("Ogg video link","my_support_theme"),
        'default'=>'',
    ),
    'wmv'=>array(
        'layout_class'=>'my_col_33',
        'type'=>'text',
        'title'=>__("Wmv video link","my_support_theme"),
        'tooltip'=>__("Wmv video link","my_support_theme"),
        'default'=>'',
    ),
    'flv'=>array(
        'type'=>'text',
        'title'=>__("Flv video link","my_support_theme"),
        'tooltip'=>__("Flv video type link","my_support_theme"),
        'default'=>'',
    ),
    'video_ratio'=>array(
        'title'=>__("Video ratio tag","my_support_theme"),
        'jscript'=>array(
            'max_c'=>1,
            'max_sel'=>__("Maximum elements are selected","my_support_theme"),
            'duration'=>500,
            'animation'=>'fadein',
            'choose_value'=>__("Plese Select value","my_support_theme"),
        ),
        'show_filter'=>0,
        'multiple'=>false,
        'default'=>'16_9',
        'values'=>array(
            '16_9'=> __("16:9","my_support_theme"),
            '16_10'=>__("16:10","my_support_theme"),
            '4_3'=>__("4:3","my_support_theme"),
            
        ),
        
    ),
    
    /*
     'video_url'=>array(
         
     'title'=>__("Video Urls","my_support_theme"),
     'tooltip'=>__("Select video urls for different types","my_support_theme"),
         
     'type'=>'multi',
     'elements'=>array(
     'mp4'=>array(
     'layout_class'=>'my_col_33',
     'type'=>'text',
     'title'=>__("Mp4 video link","my_support_theme"),
     'tooltip'=>__("Mpv video type url","my_support_theme"),
     'default'=>'',
     ),
     'm4v'=>array(
     'layout_class'=>'my_col_33',
     'type'=>'text',
     'title'=>__("M4v video link","my_support_theme"),
     'tooltip'=>__("Mv4 video url","my_support_theme"),
     'default'=>'',
     ),
     'webm'=>array(
     'layout_class'=>'my_col_33',
     'type'=>'text',
     'title'=>__("Webm video link","my_support_theme"),
     'tooltip'=>__("Webm video url","my_support_theme"),
     'default'=>'',
     ),
     'ogv'=>array(
     'layout_class'=>'my_col_33',
     'type'=>'text',
     'title'=>__("Ogv video link","my_support_theme"),
     'tooltip'=>__("Ogg video link","my_support_theme"),
     'default'=>'',
     ),
     'wmv'=>array(
     'layout_class'=>'my_col_33',
     'type'=>'text',
     'title'=>__("Wmv video link","my_support_theme"),
     'tooltip'=>__("Wmv video link","my_support_theme"),
     'default'=>'',
     ),
     'flv'=>array(
     'type'=>'text',
     'title'=>__("Flv video link","my_support_theme"),
     'tooltip'=>__("Flv video type link","my_support_theme"),
     'default'=>'',
     ),
     )
     ),*/
    /*'video_id'=>array(
        'type'=>'text',
        'title'=>__("Video id","my_support_theme"),
        'tooltip'=>__("","my_support_theme"),
        'defalt'=>''
    )*/
);
$arr['video']=$options['form'];
return $arr;