<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_image_mapper_tmpl_data my_clearfix">
<div class="my_social_menus">
<ul>
<?php 
foreach($pages as $k=>$v){
?>
<li class="<?php if($subPage==$k)echo "myActiveLi";?>">
<a href="<?php echo $pageUrl.'&my_subpage='.urlencode($k);?>" class="myPage_<?php echo $k;?>" data-key="<?php echo $k;?>">
				<?php echo $v;?>
			</a>
			</li>
<?php     
}
?>
</ul>
</div>
</div>
<div class="my_page_html">
	<?php echo $html;?>
</div>