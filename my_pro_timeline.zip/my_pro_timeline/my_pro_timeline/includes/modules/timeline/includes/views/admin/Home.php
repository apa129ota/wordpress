<?php
if(!defined('ABSPATH'))die('');
?>
<p>
<?php echo __("My Pro Timeline displays timeline posts in the slider (horizontal timeline) or vertical timeline","my_support_theme");?>.<br/>
<?php echo __("You can add posts from wordpress backend (custom post type called ","my_support_theme");?><b>My Timeline</b>)&nbsp;<a href="<?php echo admin_url('post-new.php?post_type=my_timeline')?>"><?php echo __("Add new post","my_support_theme");?></a><br/>
<?php echo __("Timeline posts can include videos","my_support_theme");?>.<br/>
<?php echo __("Timelines are included by shortcodes to wordpress pages to create shortcode go to :","my_support_theme");?>&nbsp;<a href="<?php echo admin_url('admin.php?page=my_pro_timeline_add_new')?>"><?php echo __("Add new","my_support_theme");?></a>.<br/>

<?php echo __("You can adjust styles to temlates in the page :","my_support_theme");?>&nbsp;<a href="<?php echo admin_url('admin.php?page=my_pro_timeline_templates')?>"><?php echo __("Templates","my_support_theme");?></a>.<br/>

</p>