<?php
if(!defined("ABSPATH"))die('');
$tabs=array(
    'wordpress'=>__("Wordpress embed","my_support_theme"),
    'youtube'=>__("Youtube","my_support_theme"),
    'vimeo'=>__("Vimeo","my_support_theme"),
    'url'=>__("Url","my_support_theme"),
);

//$currTab='wordpress';
$currTab=$this->get_template_var('currTab');
if(empty($currTab))$currTab="wordpress";
ob_start();
?>
                <div class="my_timeline_video" style="display:none">
                <h2><?php echo __("Video Options","my_support_theme");?></h2>
               
                <ul class="alert-blue">
					<li><?php echo __("You can add video from media library , just choose Add Video button.","my_support_theme")?></li>
					<li><?php echo __("You can add video from youtube, choose type youtube and add video id.","my_support_theme")?><br/>
					<?php echo __("In example youtube link is : ","my_support_theme")?>https://www.youtube.com/watch?v=<b>v5P4LsUyXV4</b><?php echo __(" id is boldded text.","my_support_theme")?></li>
					<li><?php echo __("You can add video from Vimeo, choose type Vimeo and add video id.","my_support_theme")?><br/>
					<?php echo __("In this example Vimeo link is : ","my_support_theme")?>https://vimeo.com/<b>189131291</b><?php __(" id is boldded text","my_support_theme")?></li>
					<li><?php echo __("You can add video by adding url of video files form mp4 wmv etc.Choose Url video type","my_support_theme")?>
					</li>
				</ul>
				<input type="hidden" name="my_video_type" id="my_video_type_id" value="<?php echo esc_attr($currTab);?>"/>
                <?php 
                echo $this->formModuleObj->renderElements(array('video_poster'=>$video['video_poster']));
                ?>
                <ul class="my_blue_tabs">
                <?php
                
                foreach($tabs as $key=>$val){
                    ?>
                    <li class="<?php if($key==$currTab)echo 'my_blue_active';?>"><a href="#javascript" data-key="<?php echo esc_attr($key);?>" class="my_tab_a <?php if($key==$currTab)echo 'my_tab_current';?>"><?php echo $val;?></a>
                    <?php 
                }
                
                //echo $this->formModuleObj->renderElements($video);
                
                ?>
                </ul>
                <?php 
                foreach ($tabs as $key=>$val){
                   ?>
                   <div class="my_tab_<?php echo $key?>" style="<?php if($currTab!=$key)echo 'display:none;'?>">
                    <?php 
                    switch($key){
                        case 'url':
                            $arr=array(
                                'mp4'=>$video[ 'mp4'],
                                'm4v'=>$video['m4v'],
                                'webm'=>$video['webm'],
                                'ogv'=>$video['ogv'],
                                'wmv'=>$video['wmv'],
                                'flv'=>$video['flv']
                            );
                            echo $this->formModuleObj->renderElements($arr);
                        break;    
                        case 'wordpress':
                            echo $this->formModuleObj->renderElements(array('wordpress_video'=>$video['wordpress_video']));
                        break;
                        case 'youtube':
                            ?>
                            <div class="alert-blue">
                            	 <ul>
									<li><?php echo __("You can add video from youtube, choose type youtube and add video id.","my_support_theme")?><br/>
									<?php echo __("In example youtube link is : ","my_support_theme")?>https://www.youtube.com/watch?v=<b>v5P4LsUyXV4</b><?php echo __(" id is boldded text.","my_support_theme")?></li>
									
								
								</ul>
                            </div>
                            <?php 
                            echo $this->formModuleObj->renderElements(array('youtube_video_id'=>$video['youtube_video_id']));
                        break; 
                        case 'vimeo':
                            ?>
                            <div class="alert-blue">
                            	<ul>
                            	<li><?php echo __("You can add video from Vimeo, choose type Vimeo and add video id.","my_support_theme")?></li>
                            		<li><?php echo __("In this example Vimeo link is : ","my_support_theme")?>https://vimeo.com/<b>189131291</b><?php __(" id is boldded text","my_support_theme")?>
									</li>
                            	</ul>
                            </div>
                            
                            <?php 
                            echo $this->formModuleObj->renderElements(array('vimeo_video_id'=>$video['vimeo_video_id']));
                        break;    
                    }
                    ?>
                    </div>
                   <?php  
                }
                ?>
                </div>
                <?php 