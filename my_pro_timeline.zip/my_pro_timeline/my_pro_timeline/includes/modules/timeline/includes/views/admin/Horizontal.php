<?php
if(!defined('ABSPATH'))die('');
?>
<h2><?php echo __("Horizontal Timeline","my_support_theme");?></h2>
<?php 
$this->renderModuleErrors();
if(isset($object)){
    ?>
    <h2><?php echo __("Edit Timeline","my_support_theme");?></h2>
    <ul>
    	<li><label><?php echo  __("Create date","my_support_theme") ?> : <?php echo $object->created;?></label></li>
		<li><label><?php echo  __("Update date","my_support_theme") ?> : <?php echo $object->updated;?></label></li>
    	    	
    	
    </ul>
    <?php 
}
?>
<div class="myFormActions">
<form class="my_form_get_social_posts" data-key="previewTimeline">
	<input type="hidden" name="my_type" value="<?php echo esc_attr('horizontal');?>"/>
		
	<input data-msg="<?php echo __("Generating Timeline Preview","my_support_theme")?>" type="submit" data-page="1"   class="myFormSubmit" id="" value="<?php echo __("Preview Timeline","my_support_theme") ?>"/>
		
</form>	
<form class="my_form_get_social_posts" data-key="saveTimeline">
	<input type="hidden" name="my_type" value="<?php echo esc_attr('horizontal');?>"/>
	<input type="hidden" name="my_id" value="<?php echo esc_attr($ID);?>"/>
		
	<input data-msg="<?php echo __("Saving Timeline","my_support_theme")?>" type="submit" data-page="1"   class="myFormSubmit" id="" value="<?php echo __("Save Timeline","my_support_theme") ?>"/>
		
</form>	
</div>
<h2><?php echo __("Horizontal Timeline Form","my_support_theme");?></h2>
<div class="myShortcodeForm">
<?php echo $formHtml;?>	
</div>
