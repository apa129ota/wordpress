<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Timeline_Module_Backend_Ajax_Controller')){
    class Class_My_Timeline_Module_Backend_Ajax_Controller extends Class_My_General_Controller{
        
        public function __construct($options=array()){
            $options["use_case"]="timeline_ajax";
            
            parent::__construct($options);
        }
        /**
         * Save timeline
         */
        protected function saveTimeline(){
            $formData=$this->parsePostData("form");
            $timeline=$this->plugin_object->getModule("timeline");
            $type=@$_POST['type'];
           
            $r=$timeline->saveTimeline($type,$formData);
            
            if($r===true){
                $this->ret['id']=$timeline->getSavedId();
                $this->ajaxOk(__("Success","my_support_theme"));
            }else {
                $this->ajaxError($r);
            }
            
        }
        /**
         * get post terms
         */
        protected function getPostTerms(){
            $term=@$_POST['term'];
            if(empty($term)){
                $this->ajaxError(__("Term is not set","my_support_theme"));
            }else {
                $term=preg_replace("/[%]+/ims","", $term);
                self::debug("term", $term);
                //$term.="%";
                $classTerm=$this->module->getTermsObj();
                $terms=$classTerm->likeTerms($term);
                self::debug("terms", $terms);
                $this->ret['error']=0;
                $this->ret['count']=count($terms);
                $this->ret['data']=array();
                if(!empty($terms)){
                    foreach($terms as $k=>$v){
                        $this->ret['data'][]=array("id"=>$v->term_id,"label"=>$v->name);
                    }
                }
            }
        }
    }
}
        