(function($) { 
	myFrontTimeline=function(o){
		var self;
		this.my_working=false;
		this.debug=false;
		this.transitions=false;
		self=this;
		this.working=false;
		this.loadedVideo="";
		this.timelines={};
		this.useRecaptcha=false;
		this.defaults={
			ajax_options:{
				timeout:60000,
				type:'POST',
				dataType:'json',
			}
		};
		this.init=function(o){
			self.options=$.extend(self.defaults,o);
			self.my_debug("Options",self.options);
			self.transitions=self.hasTransitions();
			if(self.transitions){
				self.my_debug("Has transitions",{pfx:self.pfx,prop:self.prop});
			}
			if($(".my_dialog_stars #my_recaptcha").length>0){
				self.my_debug("Use recapctha");
				self.useRecaptcha=true;
			}
			$(".my_timeline_object").each(function(i,v){
				var id=$(v).attr('id');
				var index=$(v).attr('data-id');
				var type=$(v).attr('data-type');
				var open=$(v).attr('data-open');
				self.timelines[index]={id:id,type:type,open:open};
				
			});
			self.my_debug("Timelines",self.timelines);
			if($("#mySelectViewId").length>0){
				var w=$(".my_timeline_inner").width();
				self.width=w;
				$("#mySelectViewId option").each(function(i,v){
					var val=$(v).val();
					self.my_debug("Val",val);
					if(val<w){
						$("#mySelectViewId").val(val);
						return false;
					}
				});
				$("#mySelectViewId").change(function(e){
					var val=$("#mySelectViewId").val();
					self.my_debug("Val",val);
					if(val<self.width){
						$(".my_timeline_object").width(val+'px');
						$(".my_timeline_outter").width(val+'px');
						$(window).trigger("resize");
						$(".my_timeline_outter").css('margin','auto');
					}
					
				});
			}
			self.initActions();
			self.positionStarCeil();
			self.loadVideoPost();
		};
		/**
		 * Show star
		 */
		this.showStars=function(e){
			var i=$(this).attr('data-i');
			self.my_debug("i",i);
			if(i<=5){
				//if(i==1)i=2;
				$(this).parents(".my_stars").find("li").each(function(p,v){
					var t=p+1;
					if(i>=t){
						$(v).addClass("my_active");
					}else {
						$(v).removeClass("my_active");
						
					}
				});
			}
			
		};
		this.loadVideoOnly=function(){
			//var is=$(".").attr('data-my-is');
			
			$(window).resize(function(e){
				var w=$(".my_video_div_1 video").width();
				var h=Math.round(w*9/16);
				var hD=$(".my_dialog_video .my_shortcode_content").height();
				h=hD;
				w=h*16/9-50;
				$(".my_dialog_video .my_shortcode_content").width(w);
				self.my_debug("Height/Width",{h:h,w:w});
			});
			if(typeof is=="undefined"){
				$(".my-wp-video").attr('data-my-is',1);
				//$(".my-wp-video iframe").on("load",function(e){
					$(".my_dialog_preview_loading").fadeOut();
					var w=$(".my_video_div_1 video").width();
					var h=Math.round(w*9/16);
					var hD=$(".my_dialog_video .my_shortcode_content").height();
					h=hD;
					w=h*16/9-50;
					$(".my_dialog_video .my_shortcode_content").width(w);	
					self.my_debug("Height/Width",{h:h,w:w});
					//$(this).parent().height(h);
					$(".my_video_div_1 video").animate({opacity:1});
				//});
			}
		};
		this.loadVideoPost1=function(){
			var is=$(".my-wp-video").attr('data-my-is');
			
			$(window).resize(function(e){
				var w=$(".my-wp-video iframe").width();
				var h=Math.round(w*9/16);
				var hD=$(".my_dialog_video .my_shortcode_content").height();
				h=hD;
				w=h*16/9-50;
				$(".my_dialog_video .my_shortcode_content").width(w);
				self.my_debug("Height/Width",{h:h,w:w});
			});
			if(typeof is=="undefined"){
				$(".my-wp-video").attr('data-my-is',1);
				$(".my-wp-video iframe").on("load",function(e){
					$(".my_dialog_preview_loading").fadeOut();
					var w=$(this).width();
					var h=Math.round(w*9/16);
					var hD=$(".my_dialog_video .my_shortcode_content").height();
					h=hD;
					w=h*16/9-50;
					$(".my_dialog_video .my_shortcode_content").width(w);	
					self.my_debug("Height/Width",{h:h,w:w});
					//$(this).parent().height(h);
					$(this).animate({opacity:1});
				});
			}
		};
		this.loadVideoPost=function(){
			$(".my-wp-video-new iframe").on("load",function(e){
				var w=$(this).parent().width();
				var h=Math.round(w*9/16);
				self.my_debug("Iframe Height",{h:h,w:w});
				$(this).parent().height(h);
				$(this).animate({opacity:1});
			});
		};
		this.positionStarCeil=function(){
			$(".my_stars_diff").each(function(i,v){
				var diff=parseInt($(v).attr('data-diff'));
				self.my_debug("Diff",diff);
				var w=parseInt($(v).width());
				var nW=w*diff/100;
				$(v).width(nW+'px');
				$(v).animate({opacity:1});
			});
		};
		/**
		 * Post comment
		 */
		this.postComment=function(e){
			//sometimes recapctha is empty if we use wait until we have response
			if(self.useRecaptcha){
				if(typeof self.callInt=="undefined"){
					self.callInt=0;
					myAdminMsgs_inst.my_show_working_window(self.options.msgs.postComm);
					
				}
				if(self.callInt==0){
					grecaptcha.execute();
				}
				var token=grecaptcha.getResponse();
				self.callInt++;
				self.my_debug("I/token",{i:self.callInt,token:token});
				if(self.callInt<10&&token==""){
				setTimeout(function(){
					self.postComment(e);
				},3000);
				return;
				}else {
					
					delete self.callInt;
				}
			}
				
			
			var postID=self.commentPostId;
			self.my_debug('postId',postID);
			var val=$("#myCommId").val();
			var re=new RegExp(/^[\r\n|\n]*$/g);
			if(val==""||re.test(val)){
				myAdminMsgs_inst.show_remove(self.options.msgs.emptyText,1);
				$("#myCommId").focus();
				return;
				
			}
			var num=$(".my_post_comments .my_post_comment").length;
			stars=0;
			$(".my_dialog_stars .my_stars li").each(function(i,v){
				if($(v).hasClass("my_active")){
					stars++;
				}
			})
			var o1={};
			o1.data={
				action:self.options.ajax_action,
				my_nonce:self.options.ajax_nonce,
				my_action:"postComm",
				post_id:postID,
				comm:val,
				stars:stars,
				num:num
			};
			if(self.useRecaptcha){
				self.my_debug("Reccaptcha execute");
				
				o1.data.recaptcha=grecaptcha.getResponse();
				var i=0;
				self.my_debug("Check catcha",{i:i,token:o1.data.recaptcha});
				if(o1.data.recaptcha==""){
					
				}
				/*while(i<10&&o1.data.recaptcha==""){
					grecaptcha.execute();
					o1.data.recaptcha=grecaptcha.getResponse();
					i++;
					self.my_debug("Check catcha",{i:i,token:o1.data.recaptcha});
				}*/
			}
			self.my_debug("Post comment",o1);
			if(!self.useRecaptcha){
				myAdminMsgs_inst.my_show_working_window(self.options.msgs.postComm);
			}
			
			o1.success=self.postCommentCallback;
			o1.error=self.error;
			self.callAjax(o1);
		};
		/**
		 * Loading comments
		 */
		this.loadComments=function(e){
			//if(self.working)return;
			//self.working=true;
			var postID=$(".my_post_comments_div").attr('data-post-id');
		
			var msg=self.options.msgs.loadingComm;
			var totalPages=$(this).attr('data-pages');
			var currPage=$(this).attr('data-page');
			self.my_debug("Load comments Pages/Page",{post_id:postID,total:totalPages,curr:currPage});
			if(currPage<totalPages){
				var o1={};
				currPage++;
				
				if(currPage==totalPages){
					$(this).animate({opacity:0},function(){$(this).remove()});
				}
				o1.data={
					action:self.options.ajax_action,
					my_nonce:self.options.ajax_nonce,
					my_action:"loadComm",
					post_id:postID,
					page:currPage
				};
				self.my_debug("Data",o1);
				myAdminMsgs_inst.my_show_working_window(msg);
				
				o1.success=self.loadCommCallback;
				o1.error=self.error;
				self.callAjax(o1);
			}
		};
		/**
		 * Load comment callback
		 */
		this.loadCommCallback=function(data){
			self.working=false;
			myAdminMsgs_inst.my_remove_window();
			if(data.error==0){
				$(".my_post_comments_div").append(data.html);
				var p=$(".myLoadMoreComments").attr('data-page');
				p++;
				$(".myLoadMoreComments").attr('data-page',p);
			}else {
				myAdminMsgs_inst.show_remove(data.msg,1);
			}
		}
		/**
		 * Like post
		 */
		this.likePost=function(e){
			var is=$(this).attr('data-is');
			if(is==1)return;
			var post_id=$(this).parents(".my_post_class").attr('data-post-id');
			self.my_debug("post_id",post_id);
			var o1={};
			o1.data={
				action:self.options.ajax_action,
				my_nonce:self.options.ajax_nonce,
				my_action:"likePost",
				post_id:post_id
			};
			self.$thisCall=$(this);
			myAdminMsgs_inst.my_show_working_window(self.options.msgs.likePost);
			
			o1.success=self.likePostCallback;
			o1.error=self.error;
			self.callAjax(o1);
		};
		this.postCommentCallback=function(data){
			myAdminMsgs_inst.my_remove_window();
			if(self.useRecaptcha){
				grecaptcha.reset();
			}
			if(data.error==0){
				if(typeof data.html!="undefined"){
					$(".my_post_comments_div > h4").after(data.html);
				}
				$("#myCommId").val('');
				$(".myTotalChars").text(0);
				self.dialog_stars.my_close();
				
				myAdminMsgs_inst.show_remove(data.msg,0);
				
			}else {
				myAdminMsgs_inst.show_remove(data.msg,1);
			}
		};
		/**
		 * Like post callback
		 * when user likes post then this
		 * callback is called
		 */
		this.likePostCallback=function(data){
			myAdminMsgs_inst.my_remove_window();
			if(data.error==0){
				$(self.$thisCall).attr('data-is',1);
				if(data.num<1000){
					$(self.$thisCall).find(".my_post_templates_hearts").html(data.num);
				}
				myAdminMsgs_inst.show_remove(data.msg,0);
				
			}else {
				myAdminMsgs_inst.show_remove(data.msg,1);
			}
		};
		this.loadVideo=function(e){
			e.preventDefault();
			e.stopPropagation();
			/*
			var is=$(".my_video_dialog").attr('data-my-is');
			if(typeof is=="undefined"){
				$(".my_video_dialog").attr('data-my-is',1);
				$(".my_dialog_form").mCustomScrollbar(
	    				{axis:'y',
	        				advanced:{
	        					updateOnContentResize:true
	        					}});
				
			}*/
			var post_id=$(this).parents(".my_post_class").attr('data-post-id');
			self.my_debug("post_id",post_id);
			self.videoId=post_id;
			if(self.loadedVideo==post_id){
				self.dialog_video.my_open();
				return;
			}
			$(".my_dialog_preview_loading").show();
			$(".my_video_dialog .my_shortcode_content").hide();
			var o1={};
			o1.data={
				action:self.options.ajax_action,
				my_nonce:self.options.ajax_nonce,
				my_action:"loadVideo",
				post_id:post_id
			};
			o1.success=self.showVideo;
			o1.error=self.error;
			self.callAjax(o1);
			self.dialog_video.my_open();
		};
		this.showVideo=function(data){
			if(data.error==0){
				
				//$(".my_dialog_preview_loading").fadeOut();
				$(".my_video_div_1").html(data.html);
				
				setTimeout(function(){
					if($(".my_video_div_1 iframe").length>0){
						self.loadVideoPost1();
						self.loadedVideo=self.videoId;
					}else {
						self.loadVideoOnly();
						$(".my_dialog_preview_loading").fadeOut();
						
					}
				},300);
			}else {
				alert(data.msg);
			}
			
		}
		/**
		 * Call ajax
		 */
		this.callAjax=function(obj){
			if(self.working)return;
			self.working=true;
			var o=$.extend(self.options.ajax_options,obj);
			self.my_debug("Call Ajax",o);
			self.obj=obj;
			o.success=self.success;
			o.error=self.error;
			$.ajax(o);
		};
		/**
		 * Success ajax call
		 */
		this.success=function(data,status,jq){
			self.working=false;
			self.my_debug("Ajax data",data);
			if(typeof self.obj.success!='undefined'){
				
				self.obj.success(data);
				
			}
		};
		/**
		 * 
		 */
		this.error=function(jq,status){
			myAdminMsgs_inst.my_remove_window();
			self.working=false;
			alert(self.options.msgs.ajaxError);
		};
		/**
		 * 
		 */
		this.openPostShare=function(e){
				e.preventDefault();
				self.myThisShareEl=$(this);
				var html=$(this).parents(".my_post_template").find(".my_post_share_div").html();
				var id=$(this).find(".my_post_share_div ul").data('id');
				var off=$(this).offset();
				self.my_debug("open ppost share",{html:html,id:id});
				$(".my_post_share_popup").find(".my_post_row").html(html);
				$(".my_post_share_popup").css('top','-10000px');
				$(".my_post_share_popup").css('left','-10000px');
				var wP=$(".my_post_share_popup").outerWidth(true);
				var hP=$(".my_post_share_popup").outerHeight(true);
				var top=off.top-hP-15;
				if(typeof self.options.isPost!="undefined"){
					top=off.top-hP-10;
				}
				var wP1=$(this).width();
				var left=off.left;
				
				//console.log('Click post share',{html:html,id:id,wP:wP,wP1:wP1,hP:hP});
				
				left=left-wP/2+wP1/2;
				if(self.my_post_showed_dialog){
					if(id==self.my_post_showed_id){
						$(".my_post_share_popup").fadeOut();//.animate({opacity:0});
					}
					self.my_post_showed_id='';
					self.my_post_showed_dialog=false;
					return;
					
				}else {
					
						$(".my_post_share_popup").css('top',top+'px').css('left',left+'px').fadeIn(function(){
							//my_showed_dialog=true;
							
						
				});
						if(typeof self.closeBodyEvt=='undefined'){
							self.closeBodyEvt;
							$("body").bind("click",self.closeBody);
						}
						self.my_post_showed_dialog=true;
						self.my_post_showed_id=id;
				
				}
		
			
		};
		/**
		 * close share div
		 */
		this.closeBody=function(e){
			self.my_debug("e",e);
			if(typeof self.my_post_showed_dialog!='undefined'){
				if(self.my_post_showed_dialog){
					var elClass=$(e.target).attr('class');
					self.my_debug("Class",elClass);
					//var oldId=
					if($(e.target).parents(".my_post_share_div_12").length>0){
						self.my_debug("Click not  el my_post_share div");
						
					}
					else if(typeof elClass=='undefined'){
						self.my_debug("Click not on el my_post_share");
						$(self.myThisShareEl).trigger('click');
					}
					else if(elClass.indexOf('my_post_share')==-1){
						self.my_debug("Click not on el my_post_share");
						$(self.myThisShareEl).trigger('click');
					}else {
						self.my_debug("Click on el my_post_share");
					}
				}
			}
		};
		/**
		 * count hars in comment area
		 */
		this.countChars=function(e){
			if(self.limitComment>0){
				var total=$(this).val().length;
				var limit=$(".myTotalChars").attr('data-limit');
				self.my_debug("Total/Limit",{total:total,limit:limit});
				if(total>limit){
					var msg=$(this).val();
					msg=msg.substring(0,limit);
					$(this).val(msg);
				}else {
					$(".myTotalChars").text(total);
				}
			}
		};
		/**
		 * init actions
		 */
		this.initActions=function(){
			$(document).on('click',".myLoadMoreComments",self.loadComments);
			$(document).on('click',"#myCommentsFormSubmit",self.postComment);
			self.limitComment=$(".my_dialog_stars .myTotalChars").length;
			self.my_debug("limit",self.limitComment);
			$("#myCommId").bind("paste",self.countChars);
			
			$("#myCommId").keyup(self.countChars);
			$(document).on("mouseover",".my_dialog_stars .my_stars li",self.showStars);
			$(document).on('click','.my_post_hearts',self.likePost);
			$(document).on('click',".my_video_tag",self.loadVideo);
			$(document).on('click',".my_post_share",self.openPostShare);
			$(document).on('click',".my_post_share_popup a:not(a.my_share_email)",self.myOpenDialog);
			//open stars popup
			var o={
					key:'stars',
					debug:self.debug,
					dw:600,
					dh:300,
					diff:0,
					modal:true,
					hideOverflow:self.options.hideOverflow
				};
			self.dialog_stars=new myVusualBuilderDialog(o);
			var o={
					key:'video',
					debug:self.debug,
					dw:500,
					dh:350,
					diff:20,
					modal:true,
					hideOverflow:self.options.hideOverflow
				};
			self.dialog_video=new myVusualBuilderDialog(o);
			//self.dialog_video.my_open();
			$(document).on("click",".my_meta_stars_row",function(e){
				self.my_debug("open dialog stars");
				var post_id=$(this).parents(".my_post_class").attr('data-post-id');
				self.my_debug("Post id",post_id);
				self.commentPostId=post_id;
				self.dialog_stars.my_open();
			});
			//if dialog is openned then on body click close
			/*
			$(document).on('click',"body",function(e){
				self.my_debug("e",e);
				if(typeof self.my_post_showed_dialog!='undefined'){
					if(self.my_post_showed_dialog){
						var elClass=$(e.target).attr('class');
						self.my_debug("Class",elClass);
						//var oldId=
						if(elClass.indexOf('my_post_share')==-1){
							self.my_debug("Click not on el my_post_share");
							$(self.myThisShareEl).trigger('click');
						}else {
							self.my_debug("Click on el my_post_share");
						}
					}
				}
				
			});
			*/
		};
		/**
		 * Open share dialog
		 */
		this.myOpenDialog=function(e){
			e.preventDefault();
			var href=$(this).attr('href');
			var v_ww=window.outerWidth;
			var v_hh=window.outerHeight;
			var ww=800;
			var hh=400;
			if(v_ww<ww){
				ww=v_ww;
			}
			if(v_hh<hh){
				hh=v_hh;
			}
			var left=Math.floor((v_ww-ww)/2);
			var top=Math.floor((v_hh-hh)/2);
			var win=window.open(href, "my_social_share", "scrollbars=1,menubar=0,location=0,toolbar=0,status=0,width="+ww+", height="+hh+", top="+top+", left="+left);
			
		};
		/**
		 * has transitions
		 */
		this.hasTransitions=function(){
			var obj = document.createElement('div'),
            props = ['perspectiveProperty', 'WebkitPerspective', 'MozPerspective', 'OPerspective', 'msPerspective'];
        for (var i in props) {
          if ( obj.style[ props[i] ] !== undefined ) {
            self.pfx = props[i].replace('Perspective','').toLowerCase();
            self.prop = "-" + self.pfx + "-transform";
            return true;
          }
        }
        return false;
		};
		this.my_debug=function(t,o){
			if(self.debug){
				console.log("Timeline Front \n"+t+" : ",o);
			}
		};
		this.init(o);
	};
})(jQuery);