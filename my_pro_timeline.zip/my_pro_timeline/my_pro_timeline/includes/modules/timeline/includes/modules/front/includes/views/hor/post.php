<?php
if(!defined('ABSPATH'))die('');
$template=$data['form']['template'];
$obj=$value['obj'];
$post=$value['post'];
$post_title=$post->post_title;
$post_content=$post->post_content;
$post_excerpt=$post->post_excerpt;
$post_url=get_permalink($post_id);
$has_thumb=false;
$thumbs=array();
$style='background-image:none';
global $wp_my_timeline_thumb_sizes;
if(!empty($obj['post_thumb'])){
	$has_thumb=true;
	$thumb_id=$obj['post_thumb'];
	$thumbs=wp_my_timeline_get_thumbs($thumb_id);
	if($template=='default'){
	$style='background-image:url(\''.$thumbs['medium'][0].'\')';
	}else {
		$style='background-image:url(\''.$thumbs['large'][0].'\')';
	}
}
if(!empty($obj['override_post_title'])){
	$post_title=$obj['post_title'];
}
if(!empty($obj['override_post_content'])){
	$post_content=$obj['post_content'];
	$post_excerpt=$post_content;
	$post_content=$post_excerpt;
	//$post_content=wp_my_timeline_get_post_excerpt('',$post_content,$post_excerpt);
}else {
	$post_content=wp_my_timeline_get_post_excerpt($post_id,$post_content,$post_excerpt);
}
$p_photo='';
if(isset($thumbs['large'])){
	$p_photo=$thumbs['large'][0];
}else if(isset($thumbs['medium'])){
	$p_photo=$thumbs['medium'][0];
}else $p_photo=$thumbs['thumbnail'][0];
$alt=wp_my_timeline_get_att_alt($thumb_id);
$timestamp=strtotime($post->post_date);
$my_show_date=true;
if(empty($data['form']['show_date'])){
	$my_show_date=false;
}
$my_show_share=false;
if(!empty($data['form']['show_share'])){
	$my_show_share=true;
}
$my_is_vertical_post=0;

?>
<div class="my_timeline_item <?php if(empty($has_thumb))echo 'my_timeline_item_no_thumb'?> <?php echo 'my_template_'.$template ?>">
	<?php if($template=='full_image'){
	
		?>
	<div style="<?php echo $style;?>" class="my_timeline_media" data-images="<?php echo json_encode($thumbs)?>">
		<div class="my_timeline_media_overlay"></div> 
		<div class="my_timeline_image_sizes">
		<?php echo json_encode($thumbs)?>
		</div>
		<div class="my_timeline_media_icon">
			<i class="fa fa-search"></i>
		</div>
		<div class="my_timeline_header <?php if(!empty($my_show_share)) echo 'my_timeline_header_has_share'?>">
		<div class="my_timeline_title <?php if(empty($my_show_date)&&empty($my_show_share))echo 'my_timeline_title_no_date'?>">
			<a target="<?php if($data['form']['open_link']=='blank')echo '_blank';else if($data['form']['open_link']=='same')echo '_self';?>" href="<?php echo $post_url;?>" data-post-type="post" data-post-id="<?php echo esc_attr($post_id)?>" class="my_timeline_open_link"><?php echo $post_title ?></a>
			
		</div>
			
			<?php if(!empty($my_show_date) || !empty($my_show_share)){?>
			<div class="my_timeline_date">
				
				<?php /*
				<i class="fa fa-clock-o"></i>&nbsp;&nbsp;<span class="my_timeline_date_span"><?php echo date("F j,Y",$timestamp)?></span>
				*/ ?>
				<?php
				$my_is_vertical_post=1;
				if(!empty($my_show_share)){
					$file=$view_dir.'share.php';
					require $file;
				}
				?>	
			</div>
			<?php }?>
			<div class="my_timeline_preview_image">
				<span class="my_timeline_span"><?php echo __("Preview Image","my_related_posts_domain")?></span>
				<a data-alt="<?php echo esc_attr($alt)?>"  href="<?php echo $p_photo?>" rel="my_timeline_img_<?php echo $timeline_id?>">
				<i class="fa fa-arrows-alt"></i>
				</a>
		
			</div>
			
		</div>
	</div>
	<div class="my_timeline_content <?php if($my_show_share)echo 'my_timeline_has_share'?>">
		
		
		<div class="my_timeline_text">
		<?php //echo 'Thumb id'.$thumb_id;?>
			<?php /*<pre><?php print_r($thumbs);?></pre>*/ ?>
			<?php 
			
			echo $post_content;
			?>
		</div>	
		<div class="my_timeline_read_more">
			<a href="<?php echo $post_url;?>"><?php echo __("Read more","my_related_posts_domain");?></a>
		</div>
	</div>
	
	<?php }?>
	<?php if($template=='default'){?>
	<?php if(!empty($has_thumb)){?>
	<div style="<?php echo $style;?>" class="my_timeline_media" data-images="<?php echo json_encode($thumbs)?>">
		<div class="my_timeline_media_overlay"></div> 
		<a data-alt="<?php echo esc_attr($alt)?>"  href="<?php echo $p_photo?>" rel="my_timeline_img_<?php echo $timeline_id?>"></a>
		<div class="my_timeline_image_sizes">
		<?php echo json_encode($thumbs)?>
		</div>
		<div class="my_timeline_media_icon">
			<i class="fa fa-search"></i>
		</div>
	</div>
	<?php }?>
	<div class="my_timeline_content <?php if($my_show_share)echo 'my_timeline_has_share'?>">
		<div class="my_timeline_header">
		<div class="my_timeline_title <?php if(empty($my_show_date)&&empty($my_show_share))echo 'my_timeline_title_no_date'?>">
			<a target="<?php if($data['form']['open_link']=='blank')echo '_blank';else if($data['form']['open_link']=='same')echo '_self';?>" href="<?php echo $post_url;?>" data-post-type="post" data-post-id="<?php echo esc_attr($post_id)?>" class="my_timeline_open_link"><?php echo $post_title ?></a>
			
		</div>
			
			<?php if(!empty($my_show_date) || !empty($my_show_share)){?>
			<div class="my_timeline_date">
				
				
				<i class="fa fa-clock-o"></i>&nbsp;&nbsp;<span class="my_timeline_date_span"><?php echo date("F j,Y",$timestamp)?></span>
				<?php 
				if(!empty($my_show_share)){
					$file=$view_dir.'share.php';
					require $file;
				}
				?>	
			</div>
			<?php }?>
			
		</div>
		
		<div class="my_timeline_text">
		<?php //echo 'Thumb id'.$thumb_id;?>
			<?php /*<pre><?php print_r($thumbs);?></pre>*/ ?>
			<?php 
			
			echo $post_content;
			?>
		</div>	
		<div class="my_timeline_read_more">
			<a href="<?php echo $post_url;?>"><?php echo __("Read more","my_related_posts_domain");?></a>
		</div>
	</div>
	<?php }?>
</div>
