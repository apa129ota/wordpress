(function($) { 
	myTimelineVertical=function(o){
		var self;
		this.my_working=false;
		this.debug=false;
		this.options=o;
		this.div_id='';
		this.id='';
		this.page=1;
		this.pages="";
		this.my_working=false;
		this.positionsTop=[];
		this.defaults={
			topGap:100,	
			tooltip_hide:500,
			gap:100,	
			divClass:'.my_timeline_ver_out_div',
			mainDivClass:'.my_timiline_ver_div',
			postClass:".my_post_class",
			scrollDiffGap:300,
			oneGap:150,
			marginBottom:50
		};
		self=this;
		this.init=function(o){
			self.my_debug("Set o",o);
			self.options=$.extend(self.defaults,o);
			self.my_debug("Options",self.options);
			//$("#"+self.options.div_id+" .my_timeline_ver_load_more a").click(self.my_load_more);
			this.div_id="#my_timeline_"+self.options.id;
			this.id=self.options.id;
			this.page=1;
			var w=$(self.div_id).find(self.options.postClass+" .my_post_template").width();
			$(self.div_id).find(self.options.postClass+" .my_post_template").attr("data-w",w);
			
			self.transitions=function() {
          var obj = document.createElement('div'),
              props = ['perspectiveProperty', 'WebkitPerspective', 'MozPerspective', 'OPerspective', 'msPerspective'];
          for (var i in props) {
            if ( obj.style[ props[i] ] !== undefined ) {
              self.pfx = props[i].replace('Perspective','').toLowerCase();
              self.prop = "-" + self.pfx + "-transform";
              return true;
            }
          }
          return false;
        }();
         	 self.initTimeline();
         	 if(self.options.form.openDialog=="dialog"){
         		$(document).on("click",self.div_id+" .my_woo_view_a",self.open_dialog_maybe);
         		$(document).on('click','.my_timeline_modal_close',function(e){
         	    	e.preventDefault();
         	    	if(self.transitions){
         				
         	    		$(".my_timeline_modal").animate({
         					my_scale:0,
         					opacity:0
         				},{
         					step:function(now,fx){
         						//fx.start=0;
         						if(fx.prop=='my_scale'){
         							//my_admin_debug("Now",now);
         							my_trans=self.prop;
         							$(this).css(my_trans,'scale('+now+')');	
         						}
         					}
         				,duration:1000,complete:function(){
         					$(this).hide();
         					self.dialog_is_open=false;
         					$(".my_timeline_modal").find(".my_timeline_modal_load").mCustomScrollbar('destroy');
         					$(".my_timeline_modal").find(".my_timeline_modal_load").css('height','');
         					$(".my_timeline_modal").find(".my_timeline_modal_load").hide();
         					$("body").css("overflow",self.overflow_css);
         				}
         	    	}
         	    		);
         				
         				
         			}else {
         				$(".my_timeline_modal").fadeOut(1000,function(){
         					$("body").css('overflow',self.overflow_css);
         					self.dialog_is_open=false;
         					$(".my_timeline_modal").find(".my_timeline_modal_load").mCustomScrollbar('destroy');
         					$(".my_timeline_modal").find(".my_timeline_modal_load").css('height','');
         					$(".my_timeline_modal").find(".my_timeline_modal_load").hide();
         				});
         			}
         	    });
         	 }
         	 
		};
		this.open_dialog_maybe=function(e){
	    	
	    	e.preventDefault();
	    	var open_link_type=self.options.form.openDialog;//$(this).parents('li').data('open');
	    	self.my_debug("open_dialog_maybe:open link type",open_link_type);
	    	var href=$(this).attr('href');
	    	$(".my_timeline_modal").find(".my_timeline_modal_loading").css('opacity',1).show();
	    	self.my_debug("open_dialog_maybe:href",href);
	    	
	    	if(typeof open_link_type!='undefined'){
	    		if(open_link_type=='dialog'){
	    			$(".my_timeline_modal").attr('id',self.options.id+"_modal");
	    			self.dialog_is_open=true;
	    			$(".my_timeline_modal_load iframe").attr('src',href);
	    			$(".my_timeline_modal_load iframe").on("load",function(e){
	    				$(".my_timeline_modal").find(".my_timeline_modal_loading").fadeOut(function(){
		    				$(".my_timeline_modal").find(".my_timeline_modal_load").fadeIn(function(){
		    					var ht=$(".my_timeline_modal").find(".my_timeline_modal_header").outerHeight(true);
		    	    			var otV=self.getViewportSize();//my_slider.vars_12.h;
		    	    			var ot=otV.h;
		    	    			var p=ot-ht-10;
		    	    			$(".my_timeline_modal").find(".my_timeline_modal_load").height(p);
		    	    			self.my_debug("open_dialog_maybe:Heights",{otV:otV,ot:ot,p:p,ht:ht});
		    	    			/*if(typeof is=='undefined'){
		    	    			setTimeout(function(){
		    	    				$(".my_timeline_modal").find(".my_timeline_modal_load").mCustomScrollbar(
		    	    	    				{axis:'y',
		    	    	    				advanced:{
		    	    	    					updateOnContentResize:true
		    	    	    					}});
		    	    			},400);
		    	    			}*/
		    	    			
		    				});
	    	    			
		    			});
	    			});	
	    		
	    			e.preventDefault();
	    			self.overflow_css=$("body").css("overflow");
	    			self.my_debug('open_dialog_maybe:Overrflow',self.overflow_css);
	    			$("body").css('overflow','hidden');
	    			var v=self.getViewportSize();
	    			self.my_debug('open_dialog_maybe:Widths',v);
	    			var top=$(window).scrollTop();
	    			self.vars_12=v;
	    			//$(".my_timeline_modal").css('top',top+'px');
	    			//$(".my_timeline_modal").width(v.w);
	    			$(".my_timeline_modal").height(v.h); 			
	    			$(".my_timeline_modal").find(".my_timeline_modal_load").hide();
	    			$(".my_timeline_modal").find(".my_timeline_modal_loading").show();
	    			var hH=parseInt($(".my_timeline_modal").outerHeight(true));
	    			var hL=v.h-hH;
	    			$(".my_timeline_modal").find(".my_timeline_modal_load").height(hL);
	    			//my_slider.my_debug("Heights",{view:v,hH:hH,hL:hL});
	    			
	    			if(self.transitions){
	    				$(".my_timeline_modal").css(self.prop,'center center');
	        					
	    				$(".my_timeline_modal").css(self.prop,'scale(0)');
	    				$(".my_timeline_modal").css('opacity',0);
	    				$(".my_timeline_modal").show();
	    				//$(".my_timeline_modal").css(my_slider.prop+'-transform','scale(1)');
	    				
	    				//$(".my_timeline_modal").css(my_slider.prop+'-transition-duration','1s;');
	    				$(".my_timeline_modal").animate({
							my_scale:1,
							opacity:1
						},{
							step:function(now,fx){
								//fx.start=0;
								if(fx.prop=='my_scale'){
									//my_admin_debug("Now",now);
									my_trans=self.prop;
									$(this).css(my_trans,'scale('+now+')');	
								}
							}
						,duration:1000});
	    				
	    			}else {
	    				$(".my_timeline_modal").fadeIn();
	    			}
	    			/*
	    			var post_id=$(this).parents('li').data('post-id');
	    			var post_type=$(this).parents('li').data('post-type');
	    			my_slider.my_debug("Post",{post_id:post_id,post_type:post_type});
	    			var data={
	    					action:my_slider.vars.ajax_action,
	    					post_id:post_id,
	    					post_type:post_type,
	    					nonce:my_slider.vars.ajax_nonce,
	    					timeline_id:my_slider.vars.id
	    			}
	    			my_slider.my_debug("Get post",data);
	    			$.ajax({
	    				url:my_slider.vars.ajax_url,
	    				dataType:'json',
	    				cache:false,
	    				timeout:my_slider.vars.ajax_timeout,
	    				type:'POST',
	    				data:data,
	    				success:function(data){
	    					
	    					$(".my_timeline_modal").find(".my_timeline_modal_load").html(data.html);
	    					/*$(".my_timeline_modal").find(".my_timeline_modal_load").fadeIn(function(){
	    						
	    					});
	    	    			$(".my_timeline_modal").find(".my_timeline_modal_loading").fadeOut(function(){
	    	    				$(".my_timeline_modal").find(".my_timeline_modal_load").fadeIn(function(){
	    	    					var ht=$(".my_timeline_modal").find(".my_timeline_modal_title").outerHeight();
	    	    	    			var ot=my_slider.vars_12.h;
	    	    	    			var p=ot-ht;
	    	    	    			$(".my_timeline_modal").find(".my_timeline_modal_load").height(p);
	    	    	    			
	    	    	    			//if(typeof is=='undefined'){
	    	    	    			setTimeout(function(){
	    	    	    				$(".my_timeline_modal").find(".my_timeline_modal_load").mCustomScrollbar(
	    	    	    	    				{axis:'y',
	    	    	    	    				advanced:{
	    	    	    	    					updateOnContentResize:true
	    	    	    	    					}});
	    	    	    			},400);
	    	    	    			
	    	    				});
	        	    			
	    	    			});
	    	    			var ht=$(".my_timeline_modal").find(".my_timeline_modal_title").outerHeight();
	    	    			var ot=my_slider.vars_12.h;
	    	    			var p=ot-ht;
	    	    			$(".my_timeline_modal").find(".my_timeline_modal_load").height(p);
	    	    			
	    	    				$(".my_timeline_modal").find(".my_timeline_modal_load").mCustomScrollbar(
	    	    	    				{axis:'y',
	    	    	    				advanced:{
	    	    	    					updateOnContentResize:true
	    	    	    					}});
	    	    		
	    				},
	    				error:function(){
	    					alert('Error');
	    				}
	    			});
	    			*/
	    		}
	    	}
	    };
		this.afterLoadMore=function(){
			
			self.adjustPostImageHeight();
			var oldWidth=self.myOldPostWidth;
			var isTwo=self.myIsTwo;
			
			if(isTwo){
				if(oldWidth>self.postWidth){
					$(self.div_id).find(self.options.postClass+" .my_post_template").width(self.postWidth+'px');
					//$(self.div_id).find(self.options.postClass+" .my_post_content_div_row").width(self.postWidth+"px");
					//console.log("setPostWidth",self.postWidth);
				}else {
					$(self.div_id).find(self.options.postClass+" .my_post_template").width(oldWidth+'px');
					//console.log("setPostWidth",oldWidth);
					//$(self.div_id).find(self.options.postClass+" .my_post_content_div_row").width(+"px");
					
				}
			}else {
				$(self.div_id).find(self.options.postClass+" .my_post_template").width(self.postWidth+'px');
			}
			
			$(self.div_id).find(self.options.postClass).width(self.layoutWidth+'px');
			
			//$(self.div_id).find(self.options.postClass+" .my_post_template").width(self.postWidth+'px');
			//self.my_debug("width",w);
			self.loadImages();
			//$(self.div_id).find(self.options.postClass+" .my_post_template").width(self.postWidth);
			self.my_debug("Init timeline After load");
			self.positionElements();
			self.init_scroll();
			
			if(self.options.form.animation!='none'){
				if(self.options.form.animation!='fadein'){
					
						
				$(self.div_id).find(".my_post_class[data-new-load='0']").each(function(i,v){
				var is=$(v).attr('data-is-animated');
				if(typeof is=="undefined"){
					$(v).removeAttr('data-new-post');
					self.my_debug("After load set display none",{postID:$(v).attr('data-post-id')})
					$(v).css('display','none');
					$(v).css('opacity',0)
					}
				});
				}
				}
			self.findImages();
			self.animateElements();			
		};
		this.findImages=function(){
			//var prettyPhotoImages=[];
			if(typeof self.prettyPhotoImages=="undefined"){
				self.prettyPhotoImages=[];
			}
			$(self.div_id).find(".my_post_class").each(function(i,v){
    			var postID=$(this).attr('data-post-id');
    			var is=$(v).attr('data-is-indexed-img');
    			if(typeof is=="undefined"){
    				$(v).attr('data-is-indexed-img',"1");
    				if(typeof self.options.images[postID]!='undefined'){
    					var thumbs=self.options.images[postID];
    					var url="";
    					if( typeof thumbs['full']!='undefined'){
    						url=thumbs['full'][0];
    					}
    					self.my_debug("pretty",{postID:postID,url:url,thumbs:thumbs});
    					self.prettyPhotoImages[self.prettyPhotoImages.length]=url;
        			//console.log("images"+postID,{url:url,thumbs:thumbs});
    			}
    			}
    		});
    		/*$.each(my_slider.vars.images,function(i,v){
    			var href=v['full'][0];
    			prettyPhotoImages[prettyPhotoImages.length]=href;
    			
    		});*/
    		self.my_debug("Pretty photo images",self.prettyPhotoImages);
    		//self.prettyImages=prettyPhotoImages;
    		
		};
		this.initPrettyPhoto=function(){
			if(self.options.form.prettyPhoto==1){
				
	    		$("a[rel^='my_images']").prettyPhoto();
	    		self.findImages();
	    		var prettyPhotoImages=[];
	    		$(document).on('click',self.div_id+" .my_post_thumb",function(e){
	    			if($(e.target).hasClass("my_video_tag")||$(e.target).parents(".my_video_tag").length>0){
	    				self.my_debug("Click on video tag");
	    				return;
	    			}
	    			var pos=parseInt($(this).parents(".my_post_class").data('pos'))-1;
	    			self.my_debug("Open pretty photo images",pos);
	    			$.prettyPhoto.open(self.prettyPhotoImages,[],[],pos);
	    		});
	    	}
		};
		this.foundImages=function(){
			$(self.div_id).find(".my_post_class").each(function(i,v){
    			var postID=$(this).attr('data-post-id');
    			if(typeof my_slider.vars.images[postID]!='undefined'){
    				var thumbs=my_slider.vars.images[postID];
    				var url="";
    				if( typeof thumbs['full']!='undefined'){
    					url=thumbs['full'][0];
    				}
    				my_slider.my_debug("pretty",{postID:postID,url:url,thumbs:thumbs});
    				prettyPhotoImages[prettyPhotoImages.length]=url;
        			
    			}
    		});
		};
		this.init_scroll=function(){
	    	if((self.options.form.postTemplate=="template_6")||(self.options.form.postTemplate=="template_8")){
	    		self.my_debug("Init scrolls");
	    		$(self.div_id).find(".my_post_content_row").each(function(i,v){
	    		var is=$(v).data('is-scroll-init');
	    		self.my_debug("Is init custom scroll bar",is);
	    		if(typeof is=='undefined'){
	    			self.my_debug('Init scrolls');
	    			$(v).mCustomScrollbar(
	    				{axis:'y',
	    				advanced:{
	    					updateOnContentResize:true
	    					}});
	    			$(v).data('is-scroll_init',1);
	    		}else {
	    			//$(my_slider).find(".my_timeline_text").mCustomScrollbar('update');
	    		}
	    	});}
	    	
		
	    };
	    /**
	     * init timeline
	     */
		this.initTimeline=function(){
			if(self.options.form.animation!='none'){
				$(self.div_id).addClass("my_has_animation");
			}
			self.my_debug("Init timeline");
			var width=$(self.div_id).parent("div").width();
			self.divWidth=width;
			self.my_debug("initTimeline Width",width);
			
			
			self.my_resize();
			self.adjustPostImageHeight();
			self.initPrettyPhoto();
			self.positionElements();
			self.init_scroll();
			self.loadImages();
			//self.initLines();
			//self.initLinesPos();
			$(window).scroll(self.scroll);
			if(self.options.form.animation!='none'){
				if(self.options.form.animation!='fadein'){
					
				
				$(self.div_id).find(".my_post_class").css('display','none');
				}
				}
			$(self.div_id).animate({opacity:1},1000,function(){
				self.animateElements();
			});
			$(window).resize(self.my_resize);
			$(self.div_id).find(".myLoadMoreButton").on('click',self.my_load_more);
			
		};
		/**
		 * animate elements
		 */
		this.animateElements=function(els){
			if(self.options.form.animation=='none')return;
			self.my_debug("Animate elements");
			
			if(arguments.length==0){
				var els=self.getElements();
			}
			self.my_debug('els',els);
			$.each(els,function(i,v){
					
				var $el=$(self.div_id).find(self.options.postClass+":eq("+v+")");
				var postId=$el.attr('data-post-id');
				self.my_debug("Animate el",{i:i,v:v,postId:postId});
				var animDuration=parseInt(self.options.form.duration);
				var is=$(this).attr("data-is-animated");
				if(typeof is!='undefined'){
					self.my_debug("Animated el");
					return;
				}
				if(self.options.form.animation!='fadein')$($el).css('opacity',1);
				if(self.options.form.animation=='fadein'){
					$($el).animate({opacity:1},animDuration,self.options.form.easing,function(){
						$(this).attr('data-is-animated',1);
					})
				}
				if(self.options.form.animation=='scale'){
					$($el).show({
						effect:"scale",
						direction:"horizontal",
						easing:self.options.form.easing,
						duration:animDuration,
						complete:function(){
							$(this).attr("data-is-animated",1);
						}
					});
					
				}
				if(self.options.form.animation=='fromLeft'){
					/*var layout=self.layout;
					var left=$($el).data('data-pos-left');//+$(self.div_id).offset().left;
					var leftN=left-self.postWidth;
					self.my_debug("Layouts",{layout:layout,left:left,leftN:leftN,title:$($el).find(".my_post_title").text()});
					$($el).css('width','0px');
					$($el).css('opacity','1');
					
					$($el).css('left',leftN+'px');
					$($el).animate({left:left},animDuration,self.options.form.easing,function(){
						$(this).attr('data-is-animated',1);
					})
					
					*/
					
					$($el).show({
						effect:"slide",
						direction:"left",
						easing:self.options.form.easing,
						duration:animDuration,
						complete:function(){
							$(this).attr("data-is-animated",1);
						}
					});
				}else if(self.options.form.animation=='fromBottom'){
					$($el).show({
						effect:"slide",
						direction:"down",
						easing:self.options.form.easing,
						duration:animDuration,
						complete:function(){
							$(this).attr("data-is-animated",1);
						}
					});
				}else if(self.options.form.animation=='fromUp'){
					$($el).show({
						effect:"slide",
						direction:"up",
						easing:self.options.form.easing,
						duration:animDuration,
						complete:function(){
							$(this).attr("data-is-animated",1);
						}
					});
				}else if(self.options.form.animation=='fromRight'){
					$($el).show({
						effect:"slide",
						direction:"right",
						easing:self.options.form.easing,
						duration:animDuration,
						complete:function(){
							$(this).attr("data-is-animated",1);
						}
					});
				}
				
			});
		};
		/**
		 * scroll event
		 */
		this.scroll=function(e){
			if(self.options.form.animation!='none'){
				self.animateElements();
			}
			var top=$(window).scrollTop();
			//self.my_debug("Scroll Top",top);
			var t=self.top;
			var diff=Math.abs(top-t);
			//self.my_debug("Scroll diff",diff);
			if(diff<self.options.scrollDiffGap){
				self.my_debug("Scroll Loading more");
				//self.my_load_more();
				$(self.div_id).find(".myLoadMoreButton").trigger('click');
			}
			
		};
		this.getElements=function(){
			var v=self.getViewportSize();
			var h=v.h;
			self.my_debug("H",h);
			var top=$(window).scrollTop();
			self.my_debug("getElements Scroll top",top);
			var bottom=top+h;
			var els=[];
			//if(top==0)return els;
			var scrollTop=$(window).scrollTop();
			var isFirstCall=false;
			if(scrollTop!=0&&typeof self.firstCallAnimate=="undefined"){
				if(self.options.form.animation!='none'){
					isFirstCall=true;
					self.my_debug("getElements Scroll top is grater than 0");
					//$(self.div_id).find(self.options.postClass).css('opacity',0);
					//self.options.form.animation="fadein";
					self.firstCallAnimate=1;
					//self.options.form.animation='none';
					//$(self.div_id).find(self.options.postClass).css('opacity','0').fadeIn();
					
					//return els;
				}
			}
			self.firstCallAnimate=1;
			//bottom=scrollTop;
			if(self.layout==1){
				var margin=50;
				var height=parseInt(self.options.form.height);
				var total=margin+height;
				var i=Math.floor(top/total);
				self.my_debug("getElements i",{total:total,i:i});
				els[els.length]=i;
				var nextTop=i*height;
				if(nextTop<bottom){
					var e=i+1;
					if($(self.div_id).find(".my_post_template").length>e){
						els[els.length]=i+1;
					}
				}
				
				self.my_debug("Get Elements",els);
				return els;
			}
			$.each(self.positionsTop,function(i,v){
				var topEl=v+$(self.div_id).offset().top;
				self.my_debug('getElemnts topEl',topEl);
				var bottomEl=v+self.postHeight;
				if(topEl>bottom){
					self.my_debug('getElemnts Top is grater than bottom',{topEl:topEl,bottom:bottom});
					
					return false;
				}
				/*if(typeof self.myIsScroll&&top!=0){
					if(topEl<top){
						
					}
				}*/
				if(topEl<top){//&&bottomEl>top){
					els[els.length]=i;
					self.my_debug("getElements Add element",i);
				}else if(topEl>top){
					els[els.length]=i;
					self.my_debug("getElements Add element",i);
				}
			});
			return els;
		};
		/**
		 * resize event
		 */
		this.my_resize=function(e){
			var width=$(self.div_id).parent("div").width();
			//self.debug=true;
			if(typeof e=="undefined"){
				var w=$(self.div_id).find(self.options.postClass+" .my_post_template").width();
				$(self.div_id).find(self.options.postClass+" .my_post_template").attr("data-w",w);
				self.myOldPostWidth=w;
			}
			var height=$(self.div_id).find(self.options.postClass).outerHeight(true);
			self.postHeight=height;
			
			
			self.divWidth=width;
			self.my_debug("Resize Div Width",width);
			/*if(width<400){
				self.postWidth=350;
			}
			else if(width>600)self.postWidth=(width-4*self.options.gap);
			else if(width>=400&&width<=600)self.postWidth=(width-2*self.options.gap);
			*/
			self.my_debug("Resize Post width",self.postWidth);
			var isTwo=false;
			if(width>800){
				isTwo=true;
				self.postWidth=(width-self.options.gap)/2;
				self.layoutWidth=width/2;
			}else {
				$(self.div_id).find(".my_timeline_ver_class").css('top','');
				self.layoutWidth=width;//-self.options.oneGap;
				self.postWidth=width-self.options.oneGap-20;
				
			}
			self.myIsTwo=isTwo;
			$(self.div_id).find(self.options.postClass).width(self.layoutWidth+'px');
			var oldWidth=$(self.div_id).find(self.options.postClass+" .my_post_template").attr("data-w");
			oldWidth=parseInt(oldWidth);
			if(isTwo){
				if(oldWidth>self.postWidth){
					$(self.div_id).find(self.options.postClass+" .my_post_template").width(self.postWidth+'px');
					//$(self.div_id).find(self.options.postClass+" .my_post_content_div_row").width(self.postWidth+"px");
					//console.log("setPostWidth",self.postWidth);
				}else {
					$(self.div_id).find(self.options.postClass+" .my_post_template").width(oldWidth+'px');
					//console.log("setPostWidth",oldWidth);
					//$(self.div_id).find(self.options.postClass+" .my_post_content_div_row").width(+"px");
					
				}
			}else {
				$(self.div_id).find(self.options.postClass+" .my_post_template").width(self.postWidth+'px');
			}
			
			//$(self.div_id).find(self.options.postClass).width(self.postWidth);
			self.my_debug("Resize Post width",{postWidth:self.postWidth,layoutWidth:self.layoutWidth});
			
			if(typeof e!='undefined'){
				self.my_debug("Resize Elements call position");
				self.positionElements(1);
			}
			//$(self.div_id).find(self.options.postClass).height(self.options.form.height);
		};
		/**
		 * 
		 */
		this.initLinesPos=function(){
			/*var top=$(self.div_id).offset().top-50;
			if(top>0){
				$(self.div_id).find(".my_timeline_hor_list").css('top',top);
			}*/
			var w=$(self.div_id).find(".my_timeline_hor_list").outerWidth();
			var m_l=$(self.div_id).find(".my_timeline_hor_list ul li.my_timeline_month").css('margin-left');
			m_l=parseFloat(m_l)*2;
	    	var w1=w-m_l;
	    	self.t_width=w;
	    	self.t_inner_w=w1;
	    	$(self.div_id).find(".my_timeline_hor_list ul li.my_timeline_month").width(w1);
	    	var c=$(self.div_id).find(".my_timeline_hor_list ul li.my_timeline_month").length;
	    	var w2=c*w;
	    	$(self.div_id).find(".my_timeline_hor_list .my_timeline_hor_list_ul").width(w2);
	    	var h=$(self.div_id).find('.my_timeline_hor_list_ul  li ').outerHeight();
	    	var h2=$(self.div_id).find(".my_timeline_hor_list_nav_left").height();
	    	var h1=h-(h2/2);
	    	self.my_debug('Arrows height',{m_l:m_l,h:h,h1:h1,h2:h2});
	    	//change 11 2 2015 set top
	    	var my_test_top=(h2/2)+2;
	    	
	    	h1=my_test_top;
	    	$(self.div_id).find(".my_timeline_hor_list_nav_left").css('top',h1+'px');
	    	$(self.div_id).find(".my_timeline_hor_list_nav_right").css('top',h1+'px');
	    
			
		};
		/**
		 * 
		 */
		this.initLines=function(){
			var arr=[];
	    	$(self.div_id).find(".my_timeline_hor_list_ul li").each(function(i,v){
	    		arr[arr.length]=$(this).data('date');
	    	});
	    	self.hor=arr;
	    	if(self.length<=1){
	    		$(self.div_id).find(".my_line_nav").addClass('my_disabled_05');
	    	}else {
	    		$(self.div_id).find(".my_line_nav").click(self.line_nav);
	    	}
	    	self.my_debug('Lines',arr);
	    	self.current_line=1;
	    	$(self.div_id).find(".my_post_item").attr('datas-is-bind',1);
	    	$(self.div_id).find(".my_post_item").mouseenter(self.show_tooltip);
	    	$(self.div_id).find(".my_post_item").mouseleave(function(e){
	    		self.my_debug("Mouse leave post item set timeout");
				
	    		self.tooltip_timeout=setTimeout(function(){
	    				$(".my_timeline_line_box").fadeOut();
	    			},(2*self.options.tooltip_hide));
	    	});
	    	$(".my_timeline_line_box_div").mCustomScrollbar(
    				{axis:'y',
    				advanced:{
    					updateOnContentResize:true
    					}});
	    	$(document).on("click",".my_timeline_line_box a",self.go_to_post);
	    	$(self.div_id).find(".my_timeline_slider_nav").click(self.my_click_nav);
	    	
		};
		/**
		 * Adjust post template thumb height
		 */
		this.adjustPostImageHeight=function(){
			var width=$(self.div_id).parent("div").width();
			
			/*self.postWidth=(width-self.options.gap);
			
			if(width>800){
				self.postWidth=(width-self.options.gap)/2;
				
			}*/
			//self.debug=true;
			if(typeof self.myImgHeight!="undefined"){
				var imgH=self.myImgHeight;
				self.my_debug("Set Height",imgH);
				$(".my_post_template").find(".my_post_thumb_row").css('height',imgH+"px");
				return;
			}
			
			if(self.options.form.postTemplate!="template_11"){
				var oldWidth=self.myOldPostWidth;
				var isTwo=self.myIsTwo;
				var tmplWidth=self.postWidth;//self.postWidth;//parseInt($(self.di).find("ul li .my_post_row").outerWidth(true));
	    		
				if(isTwo){
					if(oldWidth<tmplWidth){
						tmplWidth=oldWidth;
					}
				}else {
					tmplWidth=oldWidth;
				}
				tmplWidth=Math.round(tmplWidth);
				var h=0;
	    		var hP=parseInt(self.options.form.height);
	    		var tmpH=0;
	    		var max=0;
	    		var addedH=false;
	    		var preEl=0;
	    		var $tmplF=$(self.div_id).find(".my_post_template:eq(0)");
	    			$($tmplF).children(".my_post_row").each(function(i,v){
	    			if(!$(v).hasClass("my_post_thumb_row")&&$(v).is(":visible")){
	    				addedH=false;
	    				tmpH=$(v).outerHeight(true);
	    				var wEl=$(v).outerWidth(true);
	    				self.my_debug("Height:class",$(v).attr("class"));
	    				self.my_debug("Height:width",wEl);
	    				self.my_debug("Height:height",tmpH);
	    				if(preEl!=0)wEl+=preEl;
	    				var obj={
	    						"class":$(v).attr("class"),
	    						height:tmpH,
	    						wEl:wEl,
	    						preEl:preEl,
	    						tmplWidth:tmplWidth
	    				}
	    				self.my_debug("Height:Element",obj);
	    				if((tmplWidth-1)<wEl){
	    					preEl=0;
	    					if(max!=0){
	    						if(max<tmpH){
		    						max=tmpH;
		    						self.my_debug("Height:Max",max);
		    						
		    					}
	    					
	    						self.my_debug("Height:Add max",max);
	    						
	    						h+=max;
	    						max=0;
	    						addedH=true;
	    						
	    					}else {
	    						self.my_debug("Height pre",h);
	    						//if(!addedH)
	    						h+=tmpH;
	    						self.my_debug("Height after",h);
	    					}
	    					
	    				}else {
	    					if(max<tmpH){
	    						max=tmpH;
	    						self.my_debug("Height:Max",max);
	    						
	    					}
	    					preEl+=wEl;
	    				}
	    				self.my_debug("Height:Element",{tmplW:tmplWidth,cl:$(this).attr('class'),tmpH:tmpH,h:h,max:max,wEl:wEl});
	    				
	    				//if(max==0&&!addedH)h+=tmpH;
	    				
	    			}
	    		});
	    			
	    			self.my_debug("Height",h);
	    		var imgH=hP-h;
	    		self.my_debug("Height:Img height",imgH);
	    		$(".my_post_template").find(".my_post_thumb_row").css('height',imgH+"px");
	    		self.myImgHeight=imgH;
	    	}
			//self.debug=false;
		};
		/**
		 * pposition elements
		 */
		this.positionElements=function(){
			
			var animation=self.options.form.animation;
			self.my_debug("Position Elements Animation",animation);
			var doAll=false;
			var layout="";
			var gap=self.options.gap;
			var width=$(self.div_id).parent("div").width();
			var layoutWidth=width/2;
			self.my_debug("Position Elements Width",width);
			if(width>800)layout=2;
			else layout=1;
			//if we have resize
			if(arguments.length==1){
			
				var preWidth=self.rememberWidth;
				//change latout
				//if(preWidth>800&&width<=800){
					doAll=true;
				/*}else if(preWidth<800&&width>800){
					doAll=true;
				}*/
				self.my_debug("Position Elements doAll",{doAll:doAll,preWidth:preWidth,width:width});
			}
			self.layout=layout;
			//$(self.div_id).find(self.options.postClass+" .my_post_template").width(self.postWidth);
			if(layout==1)postWidth=width;
			else postWidth=layoutWidth;
			//self.layoutWidth=postWidth;
			
			if(layout==1){
				$(self.div_id).addClass('myTimelineOneLine');
				
				if(doAll){
					self.my_debug("Position Elements doAll");
					$(self.div_id).addClass("myTimelineTrnasitions");
					//$(self.div_id).find(self.options.postClass).css('left','0px');
					
				}
				self.top=$(self.div_id).find(".my_post_template").length*(parseInt(self.options.form.height)+self.options.marginBottom);
				self.my_debug("Position elements Height",self.top);
				$(self.div_id).find(".my_timeline_ver_ul").height(self.top+'px');
				return;
				//$(self.div_id).find(self.options.postClass).width(postWidth+'px');
				
			}else {
				$(self.div_id).removeClass('myTimelineOneLine')
				
			}
			self.rememberWidth=width;
			
			var postWidth=layoutWidth;
			if(doAll){
				self.positionsTop=[];
				$(self.div_id).addClass("myTimelineTrnasitions");
				setTimeout(function(){
					$(self.div_id).removeClass("myTimelineTrnasitions");
					
				},2500);
			}
			
			self.outerPostWidth=postWidth;
			var top=0;
			var topL=0;
			var topR=self.options.topGap;
			var topPrev;
			var left=0;
			var i=0;
			if(typeof self.topL!='undefined'&&!doAll){
				topL=self.topL;
				i=self.indexI;
				topR=self.topR;
				top=self.top;
				self.my_debug("Position Elements New position",{topL:topL,top:top,topR:topR,i:i})
			}
			if(layout==1){
				$(self.div_id).find(self.options.postClass).removeClass('my_post_class_left');
				$(self.div_id).find(self.options.postClass).removeClass('my_post_class_right');
				$(self.div_id).find(self.options.postClass).addClass('my_post_class_one');
				
					
			}
			$(self.div_id).find(self.options.postClass).each(function(i,v){
				
				var is=$(v).attr('data-set-pos');
				var myDo=false;
				if(doAll){
					myDo=true;
				}
				if(!myDo&&(typeof is=="undefined")){
					myDo=true;
				}
				if(layout==2){
					if(i%2==0){
						$(v).addClass("my_post_class_left");
						left=0;
					}else {
						left=postWidth;
						$(v).addClass("my_post_class_right");
					}
				}else {
					left=gap;
					
					//top+=
				}
				if(myDo){
					$(v).attr('data-set-pos',1);
					self.my_debug("Position Elements position ell",{date:$(v).attr("data-prettyDate"),top:top,i:i,left:left,top:top});
					if(layout==2){
						if(i%2==0){
							top=topL;
						}else top=topR;
					}
					//position els
					//if(animation!="fromLeft" && animation!="fromBottom"){
						$(v).css('top',top+"px");
						$(v).css('left',left+"px");
					/*}else if(animation=='fromLeft'){
						$(v).css('top',top+"px");
						
					}else if(animation=='fromBottom'){
						//$(v).css('top',top+"px");
						$(v).css('left',left+"px");
					}*/
					$(v).data('data-pos-top',top);
					$(v).data('data-pos-left',left);
					$(v).data('data-pos-i',i);
					
					self.positionsTop[self.positionsTop.length]=top;
					if(layout==2){
						
						if(i%2==0){
							
							topL+=self.postHeight+self.options.topGap;
						}else {
							topR+=self.postHeight+self.options.topGap;
						}
						
					}else top+=self.options.topGap/2+self.postHeight;
				i++;
				
				}
			});
			var totalH=topR;
			self.top=topR;
			self.topL=topL;
			self.topR=topR;
			self.layout=layout;
			if(layout==1){
				totalH=top+self.postHeight;
			}else {
				if(topL>topR){
					totalH=topL;
					self.top=topL;
				}
			}
			self.indexI=i;
			
			var t=$(self.div_id).find(".my_timeline_ver_ul").attr('data-c');
			self.my_debug("Position Elements Total h",{total:totalH,i:i,t:t});
			$(self.div_id).find(".my_timeline_ver_ul").height(totalH+"px");
			self.totalH=totalH;
			self.my_debug("Position Elements Total height",totalH);
			
		};
		/**
		 * load images 
		 */
		this.loadImages=function(){
	    	
	    	var height=parseInt(self.options.form.height);//$("").find("li")
	    	var heightI=height;//settings.thumbHeight;
	    	var width=$(self.div_id).find(".my_post_template").width();
	    	self.my_debug("Height",{h:height,heightI:heightI});
	    	$(self.div_id).find(".my_post_class").each(function(i,v){
	    		self.my_debug("I",i);
	    		
	    		//var $li=$(".my_timeline_hor_ul  .my_timeline_li_class[data-pos='"+i+"']");
	    		var postID=$(v).attr('data-post-id');
	    		self.my_debug("postId",postID);
	    		var loadImg=$(v).attr('data-my-load');
	    		if(typeof loadImg=='undefined'){
	    			$(v).attr('data-my-load','1');
	    			var thumbs=self.options.images[postID];
	    			self.my_debug("Thumbs",thumbs);
	    			var curr="";
	    			$.each(thumbs,function(i,v){
	    				var url=v[0];
	    				var h=v[2];
	    				var w=v[1];
	    				if(h>heightI){
	    					if(w>width){
	    						curr=v;
	    					}
	    				}
	    				if(curr==="")curr=v;	
	    			});
	    			var url=curr[0];
	    			self.my_debug("Url",url);
	    			$(v).find(".my_post_bg").removeClass("my_no_post_img");
	    			$(v).find(".my_post_bg i").css("opacity","0");
	    			
	    			$(v).find(".my_post_bg").css('background-image','url("'+url+'")');
	    			
	    		}
	    		
	    	});
	    	
	    	
	    	
	    };
	    /**
	     * get view port size
	     */
		this.getViewportSize=function() {

	        // Use the specified window or the current window if no argument
	    	var w=window;
	        // This works for all browsers except IE8 and before
	        if (w.innerWidth != null) return { w: w.innerWidth, h: w.innerHeight };

	        // For IE (or any browser) in Standards mode
	        var d = w.document;
	        if (document.compatMode == "CSS1Compat")
	            return { w: d.documentElement.clientWidth,
	               h: d.documentElement.clientHeight };

	        // For browsers in Quirks mode
	        return { w: d.body.clientWidth, h: d.body.clientHeight };

	    };
		this.my_load_post=function(e){
			var open_link_type=$(this).data('open');
	    	self.my_debug("open link type",open_link_type);
	    	if(typeof open_link_type!='undefined'){
	    		if(open_link_type=='dialog'){
	    			$(".my_timeline_modal").attr('id',self.id+"_modal");
	    			self.dialog_is_open=true;
	    			e.preventDefault();
	    			//my_slider.overflow_css=$("body").css("overflow");
	    			//my_slider.my_debug('Overrflow',my_slider.overflow_css);
	    			//$("body").css('overflow','hidden');
	    			var v=self.getViewportSize();
	    			self.my_debug('Widths',v);
	    			var top=$(window).scrollTop();
	    			self.vars_12=v;
	    			//$(".my_timeline_modal").css('top',top+'px');
	    			//$(".my_timeline_modal").width(v.w);
	    			$(".my_timeline_modal").height(v.h); 			
	    			$(".my_timeline_modal").find(".my_timeline_modal_load").hide();
	    			$(".my_timeline_modal").find(".my_timeline_modal_loading").show();
	    			if(self.transitions){
	    				$(".my_timeline_modal").css(self.prop,'center center');
	        					
	    				$(".my_timeline_modal").css(self.prop,'scale(0)');
	    				$(".my_timeline_modal").css('opacity',0);
	    				$(".my_timeline_modal").show();
	    				//$(".my_timeline_modal").css(my_slider.prop+'-transform','scale(1)');
	    				
	    				//$(".my_timeline_modal").css(my_slider.prop+'-transition-duration','1s;');
	    				$(".my_timeline_modal").animate({
							my_scale:1,
							opacity:1
						},{
							step:function(now,fx){
								//fx.start=0;
								if(fx.prop=='my_scale'){
									//my_admin_debug("Now",now);
									my_trans=self.prop;
									$(this).css(my_trans,'scale('+now+')');	
								}
							}
						,duration:self.options.animate_dialog_time});
	    				
	    			}else {
	    				$(".my_timeline_modal").fadeIn();
	    			}
	    			var post_id=$(this).data('post-id');
	    			var post_type=$(this).data('post-type');
	    			var data={
	    					action:self.options.ajax_action_1,
	    					post_id:post_id,
	    					post_type:post_type,
	    					timeline_id:self.id,
	    					nonce:self.options.ajax_nonce_1
	    			}
	    			self.my_debug("Get post",data);
	    			$.ajax({
	    				url:self.options.ajax_url,
	    				dataType:'json',
	    				cache:false,
	    				timeout:self.options.ajax_timeout,
	    				type:'POST',
	    				data:data,
	    				success:function(data){
	    					
	    					$(".my_timeline_modal").find(".my_timeline_modal_load").html(data.html);
	    					/*$(".my_timeline_modal").find(".my_timeline_modal_load").fadeIn(function(){
	    						
	    					});*/
	    	    			$(".my_timeline_modal").find(".my_timeline_modal_loading").fadeOut(function(){
	    	    				$(".my_timeline_modal").find(".my_timeline_modal_load").fadeIn(function(){
	    	    					var ht=$(".my_timeline_modal").find(".my_timeline_modal_title").outerHeight();
	    	    	    			var ot=self.vars_12.h;
	    	    	    			var p=ot-ht;
	    	    	    			$(".my_timeline_modal").find(".my_timeline_modal_load").height(p);
	    	    	    			
	    	    	    			//if(typeof is=='undefined'){
	    	    	    			setTimeout(function(){
	    	    	    				$(".my_timeline_modal").find(".my_timeline_modal_load").mCustomScrollbar(
	    	    	    	    				{axis:'y',
	    	    	    	    				advanced:{
	    	    	    	    					updateOnContentResize:true
	    	    	    	    					}});
	    	    	    			},400);
	    	    	    			
	    	    				});
	        	    			
	    	    			});
	    	    			var ht=$(".my_timeline_modal").find(".my_timeline_modal_title").outerHeight();
	    	    			var ot=self.vars_12.h;
	    	    			var p=ot-ht;
	    	    			$(".my_timeline_modal").find(".my_timeline_modal_load").height(p);
	    	    			
	    	    			//if(typeof is=='undefined'){
	    	    				$(".my_timeline_modal").find(".my_timeline_modal_load").mCustomScrollbar(
	    	    	    				{axis:'y',
	    	    	    				advanced:{
	    	    	    					updateOnContentResize:true
	    	    	    					}});
	    	    				//$(".my_timeline_modal").find(".my_timeline_modal_load").data('is-m',1);
	    	    				
	    	    			/*}else {
	    	    				$(".my_timeline_modal").find(".my_timeline_modal_load").mCustomScrollbar('update');
	    	    			}*/
	    				},
	    				error:function(){
	    					alert('Error');
	    				}
	    			});
	    			
	    		}
	    	}
		};
		/**
		 * Load more posts
		 */
		this.my_load_more=function(e){
			e.preventDefault();
			var pages=$(this).parents(".myLoadingMore").data('pages');
			if(pages==self.page)return;
			if(self.my_working)return;
			//self.debug=true;
			self.my_working=true;
			self.my_debug("my_load_more:Pages/page",{pages:pages,page:page});
			var my_page=self.page+1;
			var id=self.options.id;
			var data={
					action:self.options.ajax_action,
					my_nonce:self.options.ajax_nonce,
					id:id,
					page:my_page,
					my_action:"loadMorePosts"
				};
			$(self.div_id+" .myLoadSpan").fadeIn();
			self.my_debug('my_load_more:Data',data);
			$.ajax({
				url:self.options.ajax_url,
				dataType:'json',
				data:data,
				cache:false,
				timeout:self.options.ajax_timeout,
				type:'POST',
				success:function(data,status,jq){
					self.my_debug('my_load_more:Data',data);
					self.my_working=false;
					if(data.error==0){
						self.myLoadMoreFlag=1;
						$(self.div_id).find(".my_timeline_ver_ul").append(data.html);
						self.options.images=$.extend(self.options.images,data.images);
						self.options.sorted=$.extend(self.options.sorted,data.sorted);
						self.page++;
						self.afterLoadMore();
						if(self.page==pages){
								$(".myLoadingMore").fadeOut();
							}
						$(self.div_id+" .myLoadSpan").fadeOut();
						
						/*$("#"+self.div_id+" .my_timeline_ver_posts").append(data.html);
						self.page++;
						$("#"+self.div_id+" .my_timeline_ver_load_more i").hide();
						var t=$("#"+self.div_id).data('total-pages');
						self.init_scroll();
						if(t==self.page){
							$("#"+self.div_id+" .my_timeline_ver_load_more").hide();
							$("#"+self.div_id+" .my_timeline_ver_start_date").show();
						}
						$("a[rel='wp_my_timeline_"+self.id+"']").prettyPhoto();
				        */
						//self.debug=false;
					}else {
						
						alert(data.msg);
					}
				},
				error:function(jq,status){
					alert(self.options.msgs.ajaxError);
					
					self.my_working=false;
				}
			});
			
		};
		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log("Timeline Vertical \n"+t,o);
				}
			}
		};
			this.init(o);
			
	}
})(jQuery);			