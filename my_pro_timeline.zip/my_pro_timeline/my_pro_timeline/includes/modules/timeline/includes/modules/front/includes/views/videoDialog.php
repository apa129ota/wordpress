<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_dialog_video">
	<div class="my_header_dialog">
		<h4 class="my_no_margin"><?php  echo __("Video","my_support_theme")?></h4>
			<div class="my_timeline_modal_close_1">
				<i class="fa fa-close"></i>
			</div>
	</div>
	<div class="my_dialog_form my_shortcode_content">
		<div class="my_dialog_preview_loading">
			<h4><i class="fa fa-spin fa-spinner"></i><?php  echo __("Loading Video","my_support_theme")?></h4>
		</div>
		<div class="my_video_div_1">
			<?php
			/*
			<div class="my_preview_div_2">
			<ul>
				<li><label><?php  echo __("Change Width","my_support_theme")?></label></li>
				<li><select name="my_preview_width" id="my_preview_width_id">
						<option value="100%"><?php  echo __("Full width","my_support_theme")?></option>
						<option value="500px">400px</option>
						<option value="800px">800px</option>
						<option value="1100px">1100px</option>
				</select>
				</li>
			</ul>
			</div>
			*/ ?>
			
		</div>
	</div>
	
</div>