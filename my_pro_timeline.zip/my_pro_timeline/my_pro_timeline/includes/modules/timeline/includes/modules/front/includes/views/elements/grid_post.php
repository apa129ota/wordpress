<?php
if(!defined('ABSPATH'))die('');
$post_id=get_the_ID();
?>
<div class="my_related_post" data-id="<?php echo $post_id;?>" style="width:<?php echo $grid_width; ?>">
	<?php 
	if($show_thumb){
		$thumb_id=get_the_post_thumbnail($post_id);
		
	}
	?>
	<?php if(!empty($thumb_id)){
		$thumb=wp_get_attachment_image_src($thumb_id,$thumb_size);
		$css='background:url("'.$thumb['src'].'");backgurond-size:cover;';
		?>
	<div class="my_related_thumb" style="<?php echo $css;?>">
	<?php 
	
	
		?>
	</div>	
	<?php }?>
</div>
<?php 
unset($thumb);
unset($thumb_id);
unset($css);
?>
