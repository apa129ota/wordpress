<?php
if(!defined('ABSPATH'))die('');
$info=array(
        'name'=>'front',
		'title'=>'Front',
		'description'=>'Module for automatic generation for post templates with wisywig editor',
		'class'=>'Class_My_Module_Timeline_Front',
		
);
return $info;