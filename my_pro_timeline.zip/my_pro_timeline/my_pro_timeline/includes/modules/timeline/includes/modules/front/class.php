<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Module_Timeline_Front')){
    class Class_My_Module_Timeline_Front extends Class_My_General_Module{
        use MySingleton,MyTraitRecaptcha;
        protected $isShortcode=false;
        protected $isAdminShortcode=false;
        protected $shortcodeTag="my_pro_timeline";
        protected $myQueryModel;
        protected $classTmpl="";
        protected $tmpl="template_1";
        protected $data=array();
        protected $timelines=array();
        protected $hasVertical=false;
        protected $hasHorizontal=false;
        protected $addedCssTemplates=array();
        protected $addedThemes=array();
        protected $ret;
        protected $ajaxActions;
        protected $isTimelinePost=false;
        protected $timelinePostId="";
        protected $enableStars=false;
        protected $modelStars;
        protected $limitComm=10;
        protected $isTimelinePosts=false;
        protected $shortcodePosts=array();
        protected $isLoadMorePosts=false;
        function __construct($options=array()){
           //$options["debug"]=1; 
           parent::__construct($options);
           $this->ajaxActions=array(
               //'loadPost'=>array(),
               'loadVideo'=>array(),
               'likePost'=>array(),
               'postComm'=>array(),
               'loadComm'=>array(),
               'loadMorePosts'=>array()
           );
           //get enable stars
           $this->enableStars=wp_my_pro_timeline_get_option('enable_stars_comments');
        }
        protected function getTimelineImages($id){
            $images=array();
            
        }
        public function head(){
            /**
             * Timeline post
             */
            $useRecaptcha=0;
            $useR=wp_my_pro_timeline_get_option('recaptcha');
            if(!empty($useR)){
                $useRecaptcha=1;
            }
            if($this->isTimelinePost ){
                $msgs=$this->loadOptions('admin_msgs.php');
                
                $my_set_debug=0;
                if($this->debug){
                    $my_set_debug=1;
                }
                $my_preview_var=0;
                $enableStars=$this->enableStars;
                
                $css=$this->classTmpl->renderCss("template_1",array('enableStars'=>$enableStars,'onlyMeta'=>1));
                $fileCss=$this->dir.'assets/css/post.css';
                $postCss=file_get_contents($fileCss);
                ?>
                               <style type="text/css">
                                    <?php echo $css;?>  
                                    <?php echo $postCss;?> 
                              </style>
                                <?php 
               
                                ?>
                <?php if(!empty($useRecaptcha)){?>
                 <script src="https://www.google.com/recaptcha/api.js" async defer></script>
     
                <?php }?>
                <script type="text/javascript">
                jQuery(document).ready(function($){
                	var o={};
    				o.my_debug=<?php echo $my_set_debug;?>;
    				myAdminMsgs_inst=new myAdminMsgs(o);
    				
                    var o={};
								o.debug=<?php echo $my_set_debug;?>;
								o.preview=<?php echo $my_preview_var;?>;
								o.mobile=<?php $f=wp_is_mobile();if(!empty($f))echo '1';else echo '0';?>;
								o.isPost=1;
								o.msgs=<?php echo json_encode($msgs);?>;
								o.hideOverflow=0;
								o.ajax_options={};
								o.ajax_options.timeout=60000;
								o.ajax_options.url="<?php echo admin_url('admin-ajax.php');?>";
								o.ajax_options.type="POST";
								o.ajax_options.dataType="json";
								o.ajax_action="<?php echo 'my_timeline_front'?>";
								o.ajax_nonce="<?php echo wp_create_nonce('my_timeline_front');?>";								
								var myFrontTimeline_inst=new myFrontTimeline(o);
							});
						</script>
						<?php 
                
            }
            if(!empty($this->timelines)&&(($this->isAdminShortcode)||$this->isShortcode)){
          
            
            $my_set_debug=0;
            if($this->debug){
                $my_set_debug=1;
            }
            $my_preview_var=0;
            if($this->isAdminShortcode){
                $id=1;
                $my_preview_var=1;
            }
            $myNonce=wp_create_nonce('my_timeline_front');
            //Global front script
            $msgs=$this->loadOptions('admin_msgs.php');
              if(!empty($useRecaptcha)){?>
                 <script src="https://www.google.com/recaptcha/api.js" async defer></script>
     
                <?php }?>
     
            
            <script type="text/javascript">
							jQuery(document).ready(function($){
								var o={};
								o.my_debug=<?php echo $my_set_debug;?>;
								myAdminMsgs_inst=new myAdminMsgs(o);
								
								var o={};
								o.debug=<?php echo $my_set_debug;?>;
								o.preview=<?php echo $my_preview_var;?>;
								o.mobile=<?php $f=wp_is_mobile();if(!empty($f))echo '1';else echo '0';?>;
								o.ajax_options={};
								o.msgs=<?php echo json_encode($msgs);?>;
								o.ajax_options.timeout=60000;
								o.ajax_options.url="<?php echo admin_url('admin-ajax.php');?>";
								o.ajax_options.type="POST";
								o.ajax_options.dataType="json";
								o.ajax_action="<?php echo 'my_timeline_front'?>";
								o.ajax_nonce="<?php echo $myNonce?>";								
								o.hideOverflow=0;
								var myFrontTimeline_inst=new myFrontTimeline(o);
							});
						</script>
            <?php if(!empty($this->timelines)){
                        foreach ($this->timelines as $key=>$val){
                            $timelineType=$val['type'];
                            $form=$val['form'];
                           $arr=array("1600","1280","960","700","0");
                           $data=array();
                           foreach($form as $key1=>$val1){
                                if(strpos($key1,"layout")===false){
                                    $data[$key1]=$val1;
                                }
                           }
                           $tmpl=$form['postTemplate'];
                           $parentTmpl="";
                           if(preg_match("/^[0-9]+$/", $tmpl)){
                                $parentTmpl=$this->metaModuleObj->get_object_meta($tmpl, "template");
                                self::debug("parent template",$parentTmpl);
                           }
                           self::debug("tmpl", $tmpl);
                           if(!isset($this->addedCssTemplates[$tmpl])){
                               $this->addedCssTemplates[$tmpl]=1;
                               //$css=$this->classTmpl->renderCss($tmpl,$form);
                               if(!empty($parentTmpl)){
                                $css=$this->metaModuleObj->get_object_meta($tmpl, "cssCache");
                               }
                               if(empty($css)){
                               
                                   $css=$this->classTmpl->renderCss($tmpl,$form);
                               }
                               self::debug("cssTmpl", $css);
                               ?>
                               <style type="text/css" data-tmpl="<?php echo $tmpl;?>">
                                    <?php echo $css;?>    
                                </style>
                                <?php 
            
                           }
                           if($form['font_family']!='default'){
                                $font=$form['font_family'];
                                ?>
                                <link class="my_timeline_fonts_css" rel="stylesheet" href="https://fonts.googleapis.com/css?family=<?php echo urlencode($font);?>"/>
                                <style type="text/css">
                                    #my_timeline_<?php echo $key?> .my_post_title, .my_timeline_line_box * , .my_dialog_stars *:not(i) , .my_dialog_video *:not(i){font-family:<?php echo $font?>,serif !important;}
                                    #my_timeline_<?php echo $key?> .my_post_content{font-family:<?php echo $font?>,serif !important;} 
                                    #my_timeline_<?php echo $key?> .my_view_a{font-family:<?php echo $font?>,serif !important;} 
                                    #my_timeline_<?php echo $key?> *:not(i){font-family:<?php echo $font?>,serif !important;}
                                
                                </style>
                                <?php 
                           }
                           if($timelineType=="vertical"){
                            ?>
                             <style type="text/css">
                                #my_timeline_<?php echo $key?> .my_post_template{
                                height:<?php echo $form['height'].$form["height_unit"];?> !important;
                                }    
                                <?php if($form["postTemplate"]=="template_11"){?>
                                #my_timeline_<?php echo $key?> .my_post_bg{
                                height:<?php echo $form['height'].$form["height_unit"];?> !important;
                                }
                                <?php }?>
                             </style>   
                            <?php 
                           }
                           if($timelineType=="horizontal"&&!empty($form['full_width'])){
                               ob_start();
                               ?>
                               #my_timeline_<?php echo $key?> .my_timeline_li_class{
                               	padding:0 !important;
                               	margin:0 !important;
                               }
                                #my_timeline_<?php echo $key?> .my_post_template{
                                margin:0 !important;
                                border:none !important;
                                }
                                
                                #my_timeline_<?php echo $key?> .my_post_template:hover{
                                	box-shadow:none !important;
                                	}
                                
                               <?php 
                               $cssV12=ob_get_clean();
                               ?>
                             <style type="text/css">
                                <?php echo $cssV12;?>                    
                             </style>
                             <?php 
                             }   
                           if(!empty($form['swipeOn'])){
                            ?>
                            <style type="text/css">
                                #my_timeline_<?php echo $key;?> *{
                                    -webkit-touch-callout: none;
                                    -webkit-user-select: none;
                                    -khtml-user-select: none;
                                    -moz-user-select: none;
                                    -ms-user-select: none;
                                    user-select: none;
                                } 
                           </style>
                            <?php 
                           }
                           $formVals=$form;
                           $layouts=array();
                           foreach ($arr as $key1=>$val1){
                               $keyL="layout_".$val1;
                               $keyC="layout_".$val1."_cols";
                               $keyH="layout_".$val1."_height";
                               $keyU="layout_".$val1."_select";
                               $valC="3";
                               if(isset($formVals[$keyC])){
                                   $valC=$formVals[$keyC];
                                   //$form[$keyL]['elements']['cols']['value']=$valC;
                               }
                               $valH="100%";
                               if(isset($formVals[$keyH])){
                                   $valH=$formVals[$keyH];
                                                           
                               }
                               $valU="%";
                               if(isset($formVals[$keyU])){
                                   $valU=$formVals[$keyU];
                                   
                               }
                               $layouts[(int)$val1]=array(
                                   'cols'=>$valC,
                                   'height'=>$valH.$valU
                               );
                           }
                           $id=$key;
                           if($parentTmpl=="template_11"){
                                $data['postTemplate']=$parentTmpl;
                           }
                           if($timelineType=='horizontal'){
                        ?>
            <script type="text/javascript">
							jQuery(document).ready(function($){
								var my_timeline_o_<?php echo $id?>={};
								my_timeline_o_<?php echo $id?>.template="<?php echo 'template_1';?>";
								my_timeline_o_<?php echo $id?>.thumbHeight=0.5;
								my_timeline_o_<?php echo $id?>.debug=<?php echo $my_set_debug;?>;
								my_timeline_o_<?php echo $id?>.preview=<?php echo $my_preview_var;?>;
								my_timeline_o_<?php echo $id?>.mobile=<?php $f=wp_is_mobile();if(!empty($f))echo '1';else echo '0';?>;
								my_timeline_o_<?php echo $id?>.ajax_timeout=30000;
								my_timeline_o_<?php echo $id?>.id="<?php echo $id;?>";
								my_timeline_o_<?php echo $id?>.ajax_url="<?php echo admin_url('admin-ajax.php');?>";
								my_timeline_o_<?php echo $id?>.ajax_action="<?php echo 'my_timeline_load_post'?>";
								my_timeline_o_<?php echo $id?>.ajax_nonce="<?php echo wp_create_nonce('my_timeline_load_post_'.$id);?>";								
								my_timeline_o_<?php echo $id?>.form=<?php echo json_encode($data);?>;								
								my_timeline_o_<?php echo $id?>.layout=<?php echo json_encode($layouts);?>;
								my_timeline_o_<?php echo $id?>.sorted=<?php echo  json_encode($this->data[$id]['sorted'])?>;
								my_timeline_o_<?php echo $id?>.sortedA=<?php echo  json_encode($this->data[$id]['sortedA'])?>;
								
								my_timeline_o_<?php echo $id?>.arr=<?php echo  json_encode($value)?>;	
								my_timeline_o_<?php echo $id?>.all_posts=<?php echo  json_encode($this->data[$id]['posts'])?>;
								my_timeline_o_<?php echo $id?>.images=<?php echo json_encode($this->data[$id]['images'])?>;	
								$("#my_timeline_<?php echo $id;?>").myproslider(my_timeline_o_<?php echo $id?>);
								
							});
						</script>
            <?php 
                        }
                        else if($timelineType=='vertical'){
                        ?>
                         <script type="text/javascript">
							jQuery(document).ready(function($){
								var my_timeline_o_<?php echo $id?>={};
								my_timeline_o_<?php echo $id?>.msgs=<?php echo json_encode($msgs);?>;
								my_timeline_o_<?php echo $id?>.template="<?php echo 'template_1';?>";
								my_timeline_o_<?php echo $id?>.thumbHeight=0.5;
								my_timeline_o_<?php echo $id?>.debug=<?php echo $my_set_debug;?>;
								my_timeline_o_<?php echo $id?>.preview=<?php echo $my_preview_var;?>;
								my_timeline_o_<?php echo $id?>.mobile=<?php $f=wp_is_mobile();if(!empty($f))echo '1';else echo '0';?>;
								my_timeline_o_<?php echo $id?>.ajax_timeout=30000;
								my_timeline_o_<?php echo $id?>.id="<?php echo $id;?>";
								my_timeline_o_<?php echo $id?>.ajax_url="<?php echo admin_url('admin-ajax.php');?>";
								my_timeline_o_<?php echo $id?>.ajax_action="<?php echo 'my_timeline_front'?>";
								my_timeline_o_<?php echo $id?>.ajax_nonce="<?php echo $myNonce?>";								
								my_timeline_o_<?php echo $id?>.form=<?php echo json_encode($this->timelines[$id]['form']);?>;								
								my_timeline_o_<?php echo $id?>.sorted=<?php echo  json_encode($this->data[$id]['sorted'])?>;
								my_timeline_o_<?php echo $id?>.all_posts=<?php echo  json_encode($this->data[$id]['posts'])?>;
								my_timeline_o_<?php echo $id?>.images=<?php echo json_encode($this->data[$id]['images'])?>;	
								var myTimelineFront_<?php echo $id?>_inst=new myTimelineVertical(my_timeline_o_<?php echo $id;?>);
							});
							</script>
                        <?php 
                        }
                        }
                }   
            }
        }
        /**
         * parse and get sorted daays
         * @param unknown $data
         */
        protected function parseData(&$data){
            $posts=$data['all_posts'];
            $data['images']=array();
            $data['sorted']=array();
            $data['posts']=array();
            $sorted=array();
            $sortedD=array();
            $sortedA=array();
            $hasMore=array();
            foreach($posts as $key=>$val){
                $postID=$val->getVar("ID");
                $post_thumbs=$val->getVar("post_thumbs");
                $data['images'][$postID]=$post_thumbs;
                $data['posts'][]=$key;
                $postDate=$val->getPostMetaByKeyStored('postDate');
                $postDateArr=explode("/",$postDate);
                if(count($postDateArr)==3){
                    $year=$postDateArr[0];
                    $month=$postDateArr[1];
                    $day=$postDateArr[2];
                }else {
                    $year=date("Y");
                    $month=date("m");
                    $day=date("d");
                }
                $str=$year.'/'.$month;
                $str1=$postDate;
                if(!isset($sorted[$str])){
                    $sorted[$str]=array();
                    
                }
                if(!isset($sortedD[$str1])){
                    $sortedD[$str1]=array();
                }
                $timeInt=0;
                $timeInt=$val->getPostMetaByKeyStored('postTimeInt');
                if(empty($timeInt)){
                   $timeInt=0; 
                }
                /*if(!isset($sortedA[$postID])){
                    $sortedA[$str]=array();
                }*/
                $sortedA[$postID]=$str;
                $sorted[$str][$key]=1;
                $sortedD[$str1][$key]=$timeInt;
                if(count($sortedD[$str1])>1){
                    if(!isset($hasMore[$postDate])){
                        $hasMore[$postDate]=1;
                    }
                }
                self::debug("post_".$key, $timeInt);
            }
            $data['sorted']=$sorted;
            $data['sortedD']=$sortedD;
            $data['sortedA']=$sortedA;
            self::debug("sorted", $data['sorted']);
            if(!empty($hasMore)){
                foreach ($hasMore as $key=>$val){
                    self::debug("hasMore", $key);
                    $arr=$data["sortedD"][$key];
                    self::debug("sortedArr", $arr);
                    asort($data["sortedD"][$key]);
                    self::debug("sortedArrAfter", $data["sortedD"][$key]);
                    
                }
            }
            
        }
        public function addModuleError($msg,$type='general'){
            $this->moduleErrors[]=array('msg'=>$msg,'type'=>$type);
        }
        public function renderModuleErrors(){
            if(!empty($this->moduleErrors)){
                foreach($this->moduleErrors as $key=>$val){
                    echo wp_my_pro_timeline_error_msg($val['msg'],$val['typee']);
                }
            }
        }
        /**
         * Query posts for the timeline
         * @param array $opts
         */
        protected function queryPosts($opts=array(),$id,$offset=''){
            if(empty($opts)){
                $opts=array(
                    'debug'=>$this->debug,
                    'postModel'=>'Class_My_General_Post_Model',
                    'postType'=>$this->parent_module->getProperty('postTypekey'),
                    'postMetaPrefix'=>$this->parent_module->getProperty('postMetaPrefix'),
                    'metaKeys'=>$this->parent_module->getProperty('metaKeys'),
                    'postStatus'=>array('publish'),
                    'orderBy'=>array(
                        'meta_key'=>$this->parent_module->getProperty('postMetaPrefix').'postDateInt',
                        'order'=>array('meta_value_num'=>'DESC'),
                    ),
                    'limit'=>50
                );
            }
            $form=$this->timelines[$id]['form'];
            if(!empty($offset))$opts['offset']=$offset;
            self::debug("offset", $offset);
            if(!empty($form['startDate'])||!empty($form['endDate'])){
                /*$data['dateQuery']=array(
                 'after'=>$form['st']
                 );*/
                $startInt=$this->parent_module->countDays($form['startDate']);
                $endInt=$this->parent_module->countDays($form['endDate']);
                $prefix=$this->parent_module->getProperty('postMetaPrefix');
                $key=$prefix.'postDateInt';
                if(!empty($form['startDate'])&&!empty($form['endDate'])){
                    $opts['metaQuery']=array(
                        array(
                            'key'=>$key,
                            'value'=>array($startInt,$endInt),
                            'type'=>'numeric',
                            'compare'=>'BETWEEN'
                        )
                    );
                }else if(!empty($form['startDate'])){
                    $opts['metaQuery']=array(
                        array(
                            'key'=>$key,
                            'value'=>$startInt,
                            'type'=>'numeric',
                            'compare'=>'>='
                        )
                    );
                    
                } else if(!empty($form['endDate'])){
                    $opts['metaQuery']=array(
                        array(
                            'key'=>$key,
                            'value'=>$endInt,
                            'type'=>'numeric',
                            'compare'=>'<='
                        )
                    );
                    
                }
                //print_r($opts['metaQuery']);
            }
            $postTerms=array(
                'relation'=>'OR',
            );
            $postCatsKey=$this->parent_module->getProperty('postTypeCat');
            $postTermsKey=$this->parent_module->getProperty('postTypeTerm');
            $hasTermsCats=false;
            if(!empty($form['postCategories'])){
                $terms=array();
                $hasTermsCats=true;
                foreach ($form['postCategories'] as $key=>$val){
                    $terms[]=$val;
                }
                // print_r($terms);
                $postTerms[]=array(
                'taxonomy'=>$postCatsKey,
                'field'=>'term_id',
                'terms'=>$terms
                );
            }
            if(!empty($form['postTerms'])){
                $hasTermsCats=true;
                $terms1=array();
                foreach($form['postTerms'] as $ke=>$val){
                    $terms1[]=$val;
                }
                // print_r($terms1);
                $postTerms[]=array(
                'taxonomy'=>$postTermsKey,
                'field'=>'term_id',
                'terms'=>$terms1
                );
            }
            if($hasTermsCats){
                $opts['postTerms']=$postTerms;
            }
            self::debug("queryParams", $opts);
            $this->global_plugin->loadModel('class-post.php');
            $this->global_plugin->loadModel('class-my-model-query.php');
            $type=$this->timelines[$id]['type'];
            //print_r($form);
            //echo 'Id='.$id.' ';
            //print_r($this->timelines);
            if(empty($form['limit'])){
                if($type=="vertical"){
                    $limit=9;
                }else {
                    $limit=100;
                }
            }else $limit=$form['limit'];
            $opts['limit']=$limit;
            /*
             if(!empty($data)){
             foreach($data as $key=>$val){
             $opts[$key]=$val;
             }
             
             }*/
            $this->myQueryModel=new Class_My_General_Model_Query($opts);
            $this->myQueryModel->query();
            $this->shortcodePosts[$id]=$this->myQueryModel->getPostsInModel();
            self::debug("shortCodePosts", $this->shortcodePosts[$id]);
        }
        /**
         * Render preview
         * @param array $data
         * @return string
         */
        public function renderPreview($data=array(),$idS=""){
            $id=@$_GET['my_id'];
            if(!empty($idS)){
                $id=$idS;
            }
            static $isSetMetaModule1234=0;
            if(empty($isSetMetaModule1234)){
                $options=$this->global_plugin->loadOptions("meta_options.php");
                $this->initMetaModule($options);
            }
            if(!empty($id)){
               
                self::debug("id", $id);
                $is=$this->metaModuleObj->is_exists_object($id);
                if(empty($is)){
                    $this->addModuleError(__("Timeline with this id don't exist!"));
                }else {
                    $type=$this->metaModuleObj->get_object_meta($id, "type");
                    self::debug("metaType", $type);
                    if($type=="horizontal"){
                        $hasTimeline=1;
                        $this->hasHorizontal=true;
                    }else if($type=="vertical"){
                        $hasTimeline=1;
                        $this->hasVertical=true;
                    }else {
                        $this->addModuleError(__("Error type is not supported","my_support_theme"));
                    }
                    $this->timelines[$id]=array();
                    $this->timelines[$id]['type']=$type;
                    $this->timelines[$id]['form']=$this->metaModuleObj->get_object_meta($id, "form");
                    $this->timelines[$id]['form']['enableStars']=$this->enableStars;
                    $this->timelines[$id]['object']=$this->metaModuleObj->get_object($id);
                    $this->tmpl=$this->timelines[$id]['form']['postTemplate'];
                }
            }else {
                $this->addModuleError(__("Timeline id is not set !","my_support_theme"));
                
            }
            if(!isset($hasTimeline)){
                
                $this->isShortcode=false;
                ob_start();
                $this->renderModuleErrors();
                $html=ob_get_clean();
                return $html;
                
            }else {    
            $classTmpl=$this->global_plugin->getModule('post_templates');
           
            $this->classTmpl=&$classTmpl;
            $this->queryPosts(array(),$id);
           $posts=$this->myQueryModel->getPostsInModel();
            $strings=$this->loadOptions('strings.php');
            $data=array(
                'autoplay'=>0,
                'dateLong'=>1,
                'form'=>array(
                    'show_line'=>1,
                 ),   
                'all_posts'=>$posts,
                'layout'=>array(
                    '5000'=>array(
                        'cols'=>6,
                        'height'=>'auto'
                    ),
                    '1600'=>array(
                        'cols'=>5,
                        'height'=>'auto'),    
                    '1280'=>array(
                        'cols'=>4,
                        'height'=>'auto'),
                    '980'=>array(
                        'cols'=>3,
                        'height'=>'auto'),
                    '700'=>array(
                        'cols'=>2,
                        'height'=>'auto'),
                    '100'=>array(
                        'cols'=>1,
                        'height'=>'auto'),
                ),
                'show_navigation'=>1,
                'layouts'=>array(
                    '1600'=>__("Width > 1680 px","my_support_theme"),
                    '1280'=>__("Width > 1280 px","my_support_theme"),
                    '980'=>__("Width > 980 px","my_support_theme"),
                    '700'=>__("Width > 700 px","my_support_theme"),
                    '400'=>__("Width > 400 px","my_support_theme"),
                    
                    
                )
            );
             $this->parseData($data);
             $this->data[$id]=$data;
             /*$this->timelines[1]=array(
                 'form'=>array(
                    'type'=>'horizontal',
                    'tmpl'=>'template_1'
                     )
             );*/
            if($type=="horizontal"){ 
                $this->set_template_vars("dataTimeline", $this->timelines[$id]['form']);
                $viewFileTimeline=$this->views_dir.'hor/timeline.php';
               // $id=1;
                $view_dir=$this->views_dir.'hor/';
                $viewFile=$this->views_dir.'preview.php';
                ob_start();
                require $viewFile;
                $html=ob_get_clean();
            }else if($type=="vertical"){
                $totalPages=$this->myQueryModel->getTotalPages();
                $keyOpt="_my_timeline_vertical_".$id."_total_pages_1234";
                update_option($keyOpt, $totalPages,false);
                
                $startDate="";
                $firstPost=$this->myQueryModel->getFirstPost();
                if(!empty($firstPost)){
                    $startDate=$firstPost->getPostMetaByKeyStored('postDate');
                }
                $this->set_template_vars("dataTimeline", $this->timelines[$id]['form']);
                $viewFileTimeline=$this->views_dir.'ver/timeline.php';
               // $id=1;
                $view_dir=$this->views_dir.'ver/';
                $viewFile=$this->views_dir.'preview.php';
                ob_start();
                require $viewFile;
                $html=ob_get_clean();
            }
            return $html;
            }
            
        }
        public function scripts(){
            if($this->isAdminShortcode){
                $url=$this->css_url.'preview.css';
                wp_enqueue_style("my_preview_admin_css",$url);
            }
            /**
             * is timeline post incllude some scripts and css
             */
            if($this->isTimelinePost){
                
                wp_enqueue_script('jquery');
                wp_enqueue_script("jquery-touch-pounch");
                wp_enqueue_script('jquery-ui-dialog');
                $jScriptUrl=$this->global_plugin->getUrl('jscript');
                wp_enqueue_script('my_visual_dialog',$jScriptUrl.'admin/myUiDialog.js');
                wp_enqueue_script('my_mouse_wheel',$jScriptUrl.'jquery.mousewheel.min.js');
                $url=$this->getUrl('css');
                //wp_enqueue_style('my_pretty_photo_css',$url.'prettyPhoto.css');
                $url=$this->getUrl('jscript');
                //wp_enqueue_script("my_pretty_photo_js",$url.'jquery.prettyPhoto.js');
                //$urlE=$jScriptUrl.'jquery.easing.1.3.js';
                //wp_enqueue_script("my_easing_js",$urlE);
                $urlCss=$this->getUrl('css');
                wp_enqueue_style('my_front_css',$urlCss."front.css");
                wp_enqueue_style('my_general_css',$urlCss."general.css");
                
                wp_enqueue_style('my_mCustomScrollbar_css',$urlCss.'jquery.mCustomScrollbar.css');
                wp_enqueue_script('my_scrollBar_js',$url.'jquery.mCustomScrollbar.js');
                $globalUrl=$this->global_plugin->getUrl("plugin");
                wp_enqueue_style('my_fontawesome',$globalUrl.'assets/fontawesome/css/font-awesome.min.css');
                $myJscriptUrl=$this->getUrl('jscript');
                wp_enqueue_script('my_timeline_front_js',$myJscriptUrl.'front.js');
                $url=$this->global_plugin->getUrl('css').'jquery-ui.css';
                wp_enqueue_style("my_timeline_jquery_ui",$url);
                $url=$this->global_plugin->getUrl('jscript').'admin/admin_msgs.js';
                wp_enqueue_script("my_framework_msgs",$url);
                $url=$this->global_plugin->getUrl('css').'msgs.css';
                
                wp_enqueue_style("my_testimonials_msgs_form",$url);
                
            }
            if($this->isShortcode){
                wp_enqueue_script('jquery');
                wp_enqueue_script("jquery-touch-pounch");
                wp_enqueue_script('jquery-ui-dialog');
                wp_enqueue_script('jquery-ui-core');
                wp_enqueue_script('jquery-effects-core');
                wp_enqueue_script('jquery-effects-scale');
                wp_enqueue_script('jquery-effects-slide');
                
                $jScriptUrl=$this->global_plugin->getUrl('jscript');
                wp_enqueue_script('my_visual_dialog',$jScriptUrl.'admin/myUiDialog.js');
                wp_enqueue_script('my_mouse_wheel',$jScriptUrl.'jquery.mousewheel.min.js');
                $url=$this->getUrl('css');
                wp_enqueue_style('my_pretty_photo_css',$url.'prettyPhoto.css');
                $url=$this->getUrl('jscript');
                wp_enqueue_script("my_pretty_photo_js",$url.'jquery.prettyPhoto.js');
                $urlE=$jScriptUrl.'jquery.easing.1.3.js';
                wp_enqueue_script("my_easing_js",$urlE);
                $urlCss=$this->getUrl('css');
                wp_enqueue_style('my_front_css',$urlCss."front.css");
                wp_enqueue_style('my_general_css',$urlCss."general.css");
                 
                wp_enqueue_style('my_mCustomScrollbar_css',$urlCss.'jquery.mCustomScrollbar.css');
                wp_enqueue_script('my_scrollBar_js',$url.'jquery.mCustomScrollbar.js');
                $globalUrl=$this->global_plugin->getUrl("plugin");
                wp_enqueue_style('my_fontawesome',$globalUrl.'assets/fontawesome/css/font-awesome.min.css');
                if($this->hasHorizontal){
                    wp_enqueue_script('my_pro_timeline_pro_slider_js',$url.'myProSlider.js');
                    wp_enqueue_style('my_horizontal_css',$urlCss.'horizontal.css');
                    wp_enqueue_style('my_horizontal_theme_css',$urlCss.'themes/default/horizontal.css');
                }
                if($this->hasVertical){
                    wp_enqueue_style('my_horizontal_css',$urlCss.'horizontal.css');
                    wp_enqueue_style('my_horizontal_theme_css',$urlCss.'themes/default/horizontal.css');
                    wp_enqueue_style('my_vertical_css',$urlCss.'vertical.css');
                    
                    wp_enqueue_script('my_pro_timeline_pro_vertical_js',$url.'myProVertical.js');
                    
                }
                $myJscriptUrl=$this->getUrl('jscript');
                wp_enqueue_script('my_timeline_front_js',$myJscriptUrl.'front.js');
                $url=$this->global_plugin->getUrl('jscript').'admin/admin_msgs.js';
                wp_enqueue_script("my_framework_msgs",$url);
                $url=$this->global_plugin->getUrl('css').'msgs.css';
                
                wp_enqueue_style("my_testimonials_msgs_form",$url);
                $url=$this->global_plugin->getUrl('css').'jquery-ui.css';
                wp_enqueue_style("my_timeline_jquery_ui",$url);
                
                /**
                 * Include themes
                 */
                if(!empty($this->timelines)){
                    foreach($this->timelines as $k=>$v){
                        $theme=$v['form']['theme'];
                        $type=$v['type'];
                        if(!isset($this->addedThemes[$theme])){
                            $this->addedThemes[$theme]=1;
                            if($type=="horizontal"){
                                $url=$this->css_url.'themes/default/'.$theme.".css";
                                wp_enqueue_style("my_timeline_theme_".$theme."_".$type,$url);  
                            }else if($type=="vertical"){
                                $url=$this->css_url.'themes/default/ver/'.$theme.".css";
                                wp_enqueue_style("my_timeline_theme_".$theme."_".$type,$url);
                                
                            }
                        }
                    }
                }
                
                
            }
            
        }
        /**
         * Footer
         * load dialogs for post
         * or shortcode
         */
        public function footer(){
            $useRecaptcha=0;
            $useR=wp_my_pro_timeline_get_option('recaptcha');
            $sitePub="";
            $siteSec="";
            $front_submit_not_logged=wp_my_pro_timeline_get_option('front_submit_not_logged');
            if(!empty($useR)){
                $useRecaptcha=1;
                $sitePub=wp_my_pro_timeline_get_option('recaptcha_public_key');
                $siteSec=wp_my_pro_timeline_get_option('recaptcha_private_key');
            }
            $limitComment=wp_my_pro_timeline_get_option('limitComment');
            if($this->isTimelinePost){
                $this->classTmpl->loadSubTemplate("share_popup.php");
                //$this->classTmpl->loadSubTemplate("stars_popup.php");
                $file=$this->views_dir.'starsDialog.php';
                require $file;
                
            }
            if($this->isShortcode){
                    $file=$this->views_dir.'elements/modal_view.php';
                    require $file;
                    $file=$this->views_dir.'elements/line_box.php';
                    require $file;
                    $file=$this->views_dir.'elements/share_box.php';
                    require $file;
                    $file=$this->views_dir.'videoDialog.php';
                    require $file;
                    $file=$this->views_dir.'starsDialog.php';
                    require $file;
                    
                    $this->classTmpl->loadSubTemplate("share_popup.php");
                    //$this->classTmpl->loadSubTemplate("stars_popup.php");
                    
                    
                }
            
        }
        /**
         * 
         * @param unknown $attrs
         */
        public function shortcode($attrs){
            extract($attrs);
            /*ob_start();
            print_r($attrs);
            $html=ob_get_clean();
            */
            $classTmpl=$this->classTmpl;
            $type=$this->timelines[$id]['type'];
            $data=$this->data[$id];
            //$posts=$this->myQueryModel->getPostsInModel($id);
            $posts=$this->shortcodePosts[$id];
            $strings=$this->loadOptions('strings.php');
            
            if($type=="horizontal"){
                $this->set_template_vars("dataTimeline", $this->timelines[$id]['form']);
                $viewFileTimeline=$this->views_dir.'hor/timeline.php';
               
                ob_start();
                require $viewFileTimeline;
                $html=ob_get_clean();
            }else if($type=='vertical'){
                $startDate="";
                $firstPost=$this->myQueryModel->getFirstPost();
                if(!empty($firstPost)){
                    $startDate=$firstPost->getPostMetaByKeyStored('postDate');
                }
                $totalPages=$this->myQueryModel->getTotalPages();
                $keyOpt="_my_timeline_vertical_".$id."_total_pages_1234";
                update_option($keyOpt, $totalPages,false);
                $this->set_template_vars("dataTimeline", $this->timelines[$id]['form']);
                $viewFileTimeline=$this->views_dir.'ver/timeline.php';
                ob_start();
                require $viewFileTimeline;
                $html=ob_get_clean();
            }
            return $html;
        
            
        }
        /**
         * init data from front end
         * @param unknown $id
         */
        protected function initDataFront($id){
            if(!$this->isLoadMorePosts)
            $this->queryPosts(array(),$id);
            $posts=$this->myQueryModel->getPostsInModel();
            $strings=$this->loadOptions('strings.php');
            $data=array(
                'autoplay'=>0,
                'dateLong'=>1,
                'form'=>array(
                    'show_line'=>1,
                ),
                'all_posts'=>$posts,
                'layout'=>array(
                    '5000'=>array(
                        'cols'=>6,
                        'height'=>'auto'
                    ),
                    '1600'=>array(
                        'cols'=>5,
                        'height'=>'auto'),
                    '1280'=>array(
                        'cols'=>4,
                        'height'=>'auto'),
                    '980'=>array(
                        'cols'=>3,
                        'height'=>'auto'),
                    '700'=>array(
                        'cols'=>2,
                        'height'=>'auto'),
                    '100'=>array(
                        'cols'=>1,
                        'height'=>'auto'),
                ),
                'show_navigation'=>1,
                'layouts'=>array(
                    '1600'=>__("Width > 1680 px","my_support_theme"),
                    '1280'=>__("Width > 1280 px","my_support_theme"),
                    '980'=>__("Width > 980 px","my_support_theme"),
                    '700'=>__("Width > 700 px","my_support_theme"),
                    '400'=>__("Width > 400 px","my_support_theme"),
                    
                    
                )
            );
            $this->parseData($data);
            $this->data[$id]=$data;
        }
        /**
         * Check query
         */
        public function checkQuery(){
            $post_id=get_queried_object_id();
            if(is_post_type_archive("my_timeline")){
                $this->isTimelinePosts=true;
            }
            if(!is_page()){
            $my_post=get_post($post_id);
            
            if(!empty($my_post)&&$my_post->post_type=="my_timeline"){
                self::debug("timelinePost", $post_id);
                $this->isTimelinePost=true;
                $this->timelinePostId=$post_id;
               // wp_my_general_load_module_function($this->global_plugin->getDir('modules'),'new_form','includes/functions.php');
                $classTmpl=$this->global_plugin->getModule('post_templates');
                
                $this->classTmpl=&$classTmpl;
                
            }}else {
                $my_post=get_post($post_id);
                
                if(preg_match_all('/\['.$this->shortcodeTag.'[^\[]+\]/ims', $my_post->post_content,$all_matches)){
                    $this->shortcode_matches=$all_matches[0];
                    if(!empty($this->shortcode_matches)){
                        $this->isShortcode=true;
                        $classTmpl=$this->global_plugin->getModule('post_templates');
                        
                        $this->classTmpl=&$classTmpl;
                        
                        $options=$this->global_plugin->loadOptions("meta_options.php");
                        $this->initMetaModule($options);
                        
                        self::debug("shortcode_matches", $this->shortcode_matches,false);
                        $this->global_plugin->loadModuleClass('meta');
                        $options=$this->global_plugin->loadOptions('meta_options.php');
                        self::debug("meta_options", $options,false);
                        foreach($this->shortcode_matches as $k=>$v){
                            $m=$v;
                            if(preg_match('/id=\"([\d]+)\"/ims', $m,$matches)){
                                $this->isShortcode=true;
                                $id=$matches[1];
                                $is=$this->metaModuleObj->is_exists_object($id);
                                if(!empty($is)){
                                    $type=$this->metaModuleObj->get_object_meta($id, "type");
                                    $this->timelines[$id]=array();
                                    $this->timelines[$id]['type']=$type;
                                    $this->timelines[$id]['form']=$this->metaModuleObj->get_object_meta($id, "form");
                                    $this->timelines[$id]['form']['enableStars']=$this->enableStars;
                                    $this->timelines[$id]['object']=$this->metaModuleObj->get_object($id);
                                    
                                    self::debug("metaType", $type);
                                    $this->queryPosts(array(),$id);
                                    $this->initDataFront($id);
                                    
                                    if($type=="horizontal"){
                                        $hasTimeline=1;
                                        $this->hasHorizontal=true;
                                    }else if($type=="vertical"){
                                        $hasTimeline=1;
                                        $this->hasVertical=true;
                                    }else {
                                        $this->addModuleError(__("Error type is not supported","my_support_theme"));
                                    }
                                    
                                }
                            }
                        }
                    }
                }
            }
            
        }
        /**
         * 
         * @param unknown $post_id
         */
        protected function renderVideoPost($post_id){
            $module=$this->parent_module;
            $postMetaPrefix=$module->getProperty('postMetaPrefix');
            $meta_key=$postMetaPrefix.'isVideoPost';
            $isVideoPost=get_post_meta($post_id,$meta_key,true);
            $ret="";
            if(!empty($isVideoPost)){
                $meta_key=$postMetaPrefix.'videoPoster';
                $videoPoster=get_post_meta($post_id,$meta_key,true);
                if(empty($videoPoster))$videoPoster="";
                else {
                    $videoPoster=wp_get_attachment_image_src($videoPoster,"full");
                    $videoPoster=$videoPoster[0];
                }
                $meta_key=$postMetaPrefix.'videoType';
                $videoType=get_post_meta($post_id,$meta_key,true);
                switch($videoType){
                    case 'url':
                        $check=array(
                        'mp4',
                        'm4v',
                        'webm',
                        'ogv',
                        'wmv',
                        'flv',
                        
                        );
                        $opts=array(
                            'preload'=>'none',
                            'loop'=>'off',
                            'poster'=>$videoPoster,
                            'autoplay'=>'off',
                            
                        );
                        foreach ($check as $key=>$val){
                                $meta_key=$postMetaPrefix.$val;
                                $videoVal=get_post_meta($post_id, $meta_key, true);
                                if(!empty($videoVal)){
                                    $opts[$val]=$videoVal;
                                    //break;
                                }
                            }
                            self::debug("videoOpts", $opts);
                           // print_r($opts);
                            ob_start();
                            echo wp_video_shortcode($opts);
                            $ret=ob_get_clean();
                        
                    break;    
                    case 'vimeo':
                        $meta_key=$postMetaPrefix.'videoId';
                        $videoId=get_post_meta($post_id,$meta_key,true);
                        $videoSrc="https://player.vimeo.com/video/".$videoId."?transparent=0"; 
                        $file=$this->views_dir.'vimeoVideo.php';
                        ob_start();
                        require $file;
                        // echo do_shortcode("[embed width='640' height='390']".$videoSrc."[/embed]");
                        $ret=ob_get_clean();
                        
                    break;    
                    case 'youtube':
                        $meta_key=$postMetaPrefix.'videoId';
                        $videoId=get_post_meta($post_id,$meta_key,true);
                        $videoSrc="https://www.youtube.com/embed/".$videoId;
                        //$videoSrc="https://www.youtube.com/watch?v=".$videoId;
                        
                        $file=$this->views_dir.'youtubeVideo.php';
                        ob_start();
                        require $file;
                       // echo do_shortcode("[embed width='640' height='390']".$videoSrc."[/embed]");
                        $ret=ob_get_clean();
                        /*
                        
                        $opts=array(
                            'src'=>$videoSrc,
                            'preload'=>'none',
                            'loop'=>'off',
                            'poster'=>$videoPoster,
                            'autoplay'=>'off',
                           
                        );
                        // print_r($opts);
                        self::debug("videoOpts", $opts);
                        ob_start();
                        echo wp_video_shortcode($opts);
                        $ret=ob_get_clean();
                        */
                    break;    
                    case 'wordpress':
                        $meta_key=$postMetaPrefix.'wordpressVideo';
                        $videoID=get_post_meta($post_id,$meta_key,true);
                        $metaData=get_post_meta($videoID,"_wp_attachment_metadata",true);
                        $w=640;$h=380;
                        if(!empty($metaData)){
                            if(!empty($metaData['width'])){
                                $w=$metaData['width'];
                            }
                            if(!empty($metaData['height'])){
                                $h=$metaData['height'];
                            }
                        }
                        $videoSrc=wp_get_attachment_url($videoID);
                        //print_r($videoSrc);
                        $arr=explode(".",$videoSrc);
                        $c=count($arr)-1;
                        $type=strtolower($arr[$c]);
                        //ob_start();
                        //print_r($arr);
                        //echo 'Type='.$type;
                      
                       // print_r($src);
                        $opts=array(
                            'src'=>$videoSrc,
                            'preload'=>'none',
                            'loop'=>'off',
                            'poster'=>$videoPoster,
                            'autoplay'=>'off',
                            'width'=>$w,
                            'height'=>$h
                        );
                       // print_r($opts);
                        self::debug("videoOpts", $opts);
                        ob_start();
                        echo wp_video_shortcode($opts);
                        $ret=ob_get_clean();
                    break;    
                }
            }
            return $ret;
            
        }
            
        /**
         * Filter for displaying timeline post
         * @param unknown $content
         * @return unknown
         */
        public function myTimelineContent($content){
           
            $preContent=$content;
            global $post;
            /*if(!$this->isTimelinePost){
                if(!empty($post)){
                    if($post->post_type=="my_timeline"){
                        $this->isTimelineQuery=true;
                        $post_id=$post->ID;
                        $enableStars=$this->enableStars;
                        
                        $module_dir=$this->global_plugin->getDir('modules');
                        wp_my_general_load_module_function($module_dir,"post_templates","functions/functions.php" );
                        $module=$this->parent_module;
                        $postMetaPrefix=$module->getProperty('postMetaPrefix');
                        
                        if(!empty($enableStars)){
                            $meta_key=$postMetaPrefix.'stars';
                            $stars=get_post_meta($post_id,$meta_key,true);
                            
                            if(empty($stars)){
                                $stars=4.5;
                            }
                            $meta_key=$postMetaPrefix.'starsCount';
                            $commCount=get_post_meta($post_id,$meta_key,true);
                            if(empty($commCount)){
                                $commCount=0;
                            }
                        }else {
                            $commCount=0;
                        }
                        $post_id=$post->ID;
                        $my_post=$post;//get_post($post_id);
                        $title=$my_post->post_title;
                        $content=$my_post->post_excerpt;
                        if(empty($content)){
                            $content=$my_post=$my_post->post_content;
                        
                        }
                        if(strlen($content)>200){
                            $content=mb_substr($content, 0,200).'...';
                        }
                        $thumb_id=get_post_thumbnail_id($post_id);
                        $media="";
                        if(!empty($thumb_id)){
                            $media=get_the_post_thumbnail_url($post_id,'full');
                        }
                        $facebook_url=wp_my_post_templates_share_post($post_id, $title, $content,$media,'facebook');
                        $twitter_url=wp_my_post_templates_share_post($post_id, $title, $content,$media,'twitter');;
                        $g_plus=wp_my_post_templates_share_post($post_id, $title, $content,$media,'google');;
                        $p=wp_my_post_templates_share_post($post_id, $title, $content,$media,'pinterest');
                        
                        
                        $meta_key=$postMetaPrefix.'hearts';
                        $heartsCount=get_post_meta($post_id,$meta_key,true);
                        if(empty($heartsCount)){
                            $heartsCount=0;
                        }
                        $meta_key=$postMetaPrefix.'includeTime';
                        $includeTime=get_post_meta($post_id,$meta_key,true);
                        if(!empty($includeTime)){
                            $meta_key=$postMetaPrefix.'hour';
                            $hour=get_post_meta($post_id,$meta_key,true);
                            $meta_key=$postMetaPrefix.'min';
                            $min=get_post_meta($post_id,$meta_key,true);
                            $meta_key=$postMetaPrefix.'sec';
                            $sec=get_post_meta($post_id,$meta_key,true);
                            
                            
                        }
                        $meta_key=$postMetaPrefix.'postDate';
                        $postDate=get_post_meta($post_id,$meta_key,true);
                        $postDateArr=explode("/",$postDate);
                        // echo $postDate;
                        self::debug("postDate", $postDate);
                        if(count($postDateArr)==3){
                            $year=$postDateArr[0];
                            $month=$postDateArr[1]-1;
                            $day=$postDateArr[2];
                        }else {
                            $year=date("Y");
                            $month=date("m")-1;
                            $day=date("d");
                        }
                        $strings=$this->loadOptions('strings.php');
                        $file=$this->views_dir.'shortPostTimeline.php';
                        ob_start();
                        require $file;
                        $content=ob_get_clean();
                    }
                }
            }*/
            if($this->isTimelinePost){
                $postCatsKey=$this->parent_module->getProperty('postTypeCat');
                $postTermsKey=$this->parent_module->getProperty('postTypeTerm');
                $postTerms=wp_get_post_terms($this->timelinePostId,$postTermsKey);
                $postCats=wp_get_post_terms($this->timelinePostId,$postCatsKey);
                $enableStars=$this->enableStars;
                $post_id=$this->timelinePostId;
                $module=$this->parent_module;
                $postMetaPrefix=$module->getProperty('postMetaPrefix');
                if(!empty($enableStars)){
                    $meta_key=$postMetaPrefix.'stars';
                    $stars=get_post_meta($post_id,$meta_key,true);
                    
                    if(empty($stars)){
                        $stars=4.5;
                    }
                    $meta_key=$postMetaPrefix.'starsCount';
                    $commCount=get_post_meta($post_id,$meta_key,true);
                    if(empty($commCount)){
                        $commCount=0;
                    }
                }else {
                    $commCount=0;
                }
                $commFile=$this->views_dir.'postComment.php';
                $comments=array();
                $limitComm=$this->limitComm;
                if(!empty($commCount)){
                    $comments=$this->modelStars->queryComm($post_id,$limitComm);
                    $pages=ceil($commCount/$limitComm);
                }
                $post_id=$this->timelinePostId;
                $my_post=get_post($post_id);
                $title=$my_post->post_title;
                $content=$my_post->post_excerpt;
                if(empty($content)){
                    $content=$my_post=$my_post->post_content;
                }
                $content=strip_shortcodes($content);
                $content=strip_tags($content);
                $thumb_id=get_post_thumbnail_id($post_id);
                $media="";
                if(!empty($thumb_id)){
                    $media=get_the_post_thumbnail_url($post_id,'full');
                }
                $facebook_url=wp_my_post_templates_share_post($post_id, $title, $content,$media,'facebook');
                $twitter_url=wp_my_post_templates_share_post($post_id, $title, $content,$media,'twitter');;
                $g_plus=wp_my_post_templates_share_post($post_id, $title, $content,$media,'google');;
                $p=wp_my_post_templates_share_post($post_id, $title, $content,$media,'pinterest');
                
                
                $meta_key=$postMetaPrefix.'hearts';
                $heartsCount=get_post_meta($post_id,$meta_key,true);
                if(empty($heartsCount)){
                    $heartsCount=0;
                }
                $meta_key=$postMetaPrefix.'includeTime';
                $includeTime=get_post_meta($post_id,$meta_key,true);
                if(!empty($includeTime)){
                        $meta_key=$postMetaPrefix.'hour';
                    $hour=get_post_meta($post_id,$meta_key,true);
                    $meta_key=$postMetaPrefix.'min';
                    $min=get_post_meta($post_id,$meta_key,true);
                    $meta_key=$postMetaPrefix.'sec';
                    $sec=get_post_meta($post_id,$meta_key,true);
                    
                    
                }
                $meta_key=$postMetaPrefix.'postDate';
                $postDate=get_post_meta($post_id,$meta_key,true);
                $postDateArr=explode("/",$postDate);
               // echo $postDate;
               self::debug("postDate", $postDate);
                if(count($postDateArr)==3){
                    $year=$postDateArr[0];
                    $month=$postDateArr[1]-1;
                    $day=$postDateArr[2];
                }else {
                    $year=date("Y");
                    $month=date("m")-1;
                    $day=date("d");
                }
                $strings=$this->loadOptions('strings.php');
                $file=$this->views_dir.'postTimeline.php';
                $videoHtml=$this->renderVideoPost($post_id);
                ob_start();
                require $file;
                $html=ob_get_clean();
                $content=$html.$preContent;
                $file=$this->views_dir.'postComments.php';
                ob_start();
                //echo $content;
                require $file;
                $html=ob_get_clean();
                $content.=$html;
                
                
                
            }
            return $content;
        }
        /**
         * 
         * @param unknown $att
         * @return string
         */
        
        function init($options=array()){
            $useR=wp_my_pro_timeline_get_option('recaptcha');
            $sitePub="";
            $siteSec="";
            if(!empty($useR)){
                $useRecaptcha=1;
                $sitePub=wp_my_pro_timeline_get_option('recaptcha_public_key');
                $siteSec=wp_my_pro_timeline_get_option('recaptcha_private_key');
                $this->myTraitSetRecaptchaKeys($sitePub, $siteSec);
            }
            $module=$this->parent_module;
            $postMetaPrefix=$module->getProperty('postMetaPrefix');
            $opts=array(
                "debug"=>$this->debug,
                "prefix"=>$postMetaPrefix
            );
            $this->global_plugin->loadModel('class-my-model-stars.php');
            $this->modelStars=new Class_My_Model_Stars($opts);
            add_shortcode($this->shortcodeTag, array($this,'shortcode'));
            add_filter('the_content', array(&$this,"myTimelineContent"));
            add_action('wp',array(&$this,'checkQuery'));
            //add_shortcode($this->shortcodeTag, array($this,'shortcode'));
            if(is_admin()){
                $page=$this->getAdminPage();
                if($page=="my_pro_timeline_preview"){
                    $this->isShortcode=true;
                    $this->isAdminShortcode=true;
                    add_action('admin_head', array($this,'head'),PHP_INT_MAX);
                    add_action('admin_enqueue_scripts',array($this,'scripts'),PHP_INT_MAX);
                    add_action('admin_footer',array($this,'footer'),PHP_INT_MAX);
                    
                }
            }else{
                add_action('wp_head', array($this,'head'),PHP_INT_MAX);
                add_action('wp_enqueue_scripts',array($this,'scripts'),PHP_INT_MAX);
                add_action('wp_footer',array($this,'footer'),PHP_INT_MAX);
                
            }
            
            add_action("wp_ajax_my_timeline_front",array(&$this,'frontAjax'));
            add_action("wp_ajax_nopriv_my_timeline_front",array(&$this,'frontAjax'));
        }
        public function frontAjax(){
            $my_action=@$_POST['my_action'];
            $nonce=@$_POST['my_nonce'];
            if(!isset($my_action)){
                $this->ajaxError(__("Error","my_support_theme"));
            }else {
                if(!array_key_exists($my_action, $this->ajaxActions)){
                    $this->ajaxError(__("Error","my_support_theme"));
                }else {
                    if(!wp_verify_nonce($nonce,"my_timeline_front")){
                        $this->ajaxError(__("Error","my_support_theme"));
                    }
                    else $this->$my_action();
                }
            }
            if($this->debug){
                $this->ret['debug']=Class_My_Module_Debug::get_debug();
            }
            echo json_encode($this->ret);
            exit();
        
        }
        /**
         * Email not saved comment
         * @param unknown $comm
         * @param unknown $stars
         */
        protected function emailPostCommNot($post_id,$comm,$stars){
            $postUrl=get_permalink($post_id);
            $post=get_post($post_id);
            $post_title=$post->post_title;
            $notify_msg_not=wp_my_pro_timeline_get_option('notify_msg_not');
            $notify_email=wp_my_pro_timeline_get_option('notify_email');
            if(!empty($notify_email)){
                $url=get_site_url();
                $subject=__("New star comment","my_support_theme");
                $notify_msg_not=str_replace('{site_url}', $url, $notify_msg_not);
                $notify_msg_not=str_replace('{stars}', $stars, $notify_msg_not);
                $notify_msg_not=str_replace('{post_text}', $comm, $notify_msg_not);
                $notify_msg_not=str_replace('{post_url}', $postUrl, $notify_msg_not);
                $notify_msg_not=str_replace('{post_title}', $post_title, $notify_msg_not);
                
                mail($notify_email,$subject,$notify_msg_not);
            }
        }
        protected function emailPostComm($post_id,$comm,$stars){
            $postUrl=get_permalink($post_id);
            $post=get_post($post_id);
            $post_title=$post->post_title;
            $notify_msg_not=wp_my_pro_timeline_get_option('notify_msg');
            $notify_email=wp_my_pro_timeline_get_option('notify_email');
            if(!empty($notify_email)){
                $url=get_site_url();
                $subject=__("New star comment","my_support_theme");
                $notify_msg_not=str_replace('{site_url}', $url, $notify_msg_not);
                $notify_msg_not=str_replace('{stars}', $stars, $notify_msg_not);
                $notify_msg_not=str_replace('{post_text}', $comm, $notify_msg_not);
                $notify_msg_not=str_replace('{post_url}', $postUrl, $notify_msg_not);
                $notify_msg_not=str_replace('{post_title}', $post_title, $notify_msg_not);
                
                mail($notify_email,$subject,$notify_msg_not);
            }
        }
        /**
         * Load comments
         */
        protected function loadComm(){
            $post_id=@$_POST['post_id'];
            //$limitComment=wp_my_pro_timeline_get_option('limitComment');
            $page=@$_POST['page'];
            if(!preg_match('/^[0-9]+$/',$post_id)){
                $this->ajaxError(__("Error","my_support_theme"));
            }else {
                $post=get_post($post_id);
                if($post->post_type!="my_timeline"){
                    $this->ajaxError(__("Error","my_support_theme"));
                }else {
                   $limit=$this->limitComm; 
                   $count=$this->modelStars->getCountComments($post_id);
                   $pages=ceil($count/$limit);
                   if(empty($page)){
                       $this->ajaxError(__("Error","my_support_theme"));
                   }else if($page<=1){
                       $this->ajaxError(__("Error","my_support_theme"));
                   }else if($page>$pages){
                       $this->ajaxError(__("Error","my_support_theme"));
                   }else {
                       $this->ajaxOk(__("Success","my_support_theme"));
                       $comments=$this->modelStars->queryComm($post_id,$this->limitComm,$page);
                       $commFile=$this->views_dir.'postComment.php';
                       ob_start();
                       if(!empty($comments)){
                       foreach($comments as $key=>$val){
                           $comm=$val->text;
                           $stars=$val->stars;
                           $date=$val->created;
                           $timestamp=strtotime($date);
                           $date=date('Y,F d H:i:s',$timestamp);
                           $user_id=$val->userID;
                           require $commFile;
	                       }
                       }
                       $this->ret['html']=ob_get_clean();
                   }
                }
            }
        }
        /**
         * 
         */
        protected function loadMorePosts(){
            $id=@$_POST['id'];
            $page=@$_POST['page'];
            //$this->debug=true;
            $this->isLoadMorePosts=true;
            if(!preg_match('/^[0-9]+$/',$id)){
                $this->ajaxError(__("Error","my_support_theme"));
            }else {
                if(!preg_match('/^[0-9]+$/',$page)){
                    $this->ajaxError(__("Error","my_support_theme"));
                    return;
                }
                $this->global_plugin->loadModuleClass('meta');
                
                $options=$this->global_plugin->loadOptions("meta_options.php");
                $this->initMetaModule($options);
                $is=$this->metaModuleObj->is_exists_object($id);
                if(!empty($is)){
                    $type=$this->metaModuleObj->get_object_meta($id, "type");
                    if($type!='vertical'){
                        $this->ajaxError(__("Error","my_support_theme"));
                    }else {
                        $keyOpt="_my_timeline_vertical_".$id."_total_pages_1234";
                        $opt=get_option($keyOpt);
                        if($page>$opt){
                            $this->ajaxError(__("Error","my_support_theme"));
                        }else {
                            
                            $classTmpl=$this->global_plugin->getModule('post_templates');
                            $this->classTmpl=&$classTmpl;
                            $this->timelines[$id]=array();
                            $this->timelines[$id]['type']=$type;
                            $this->timelines[$id]['form']=$this->metaModuleObj->get_object_meta($id, "form");
                            $this->timelines[$id]['form']['enableStars']=$this->enableStars;
                            $this->timelines[$id]['object']=$this->metaModuleObj->get_object($id);
                            $offset=$this->timelines[$id]['form']['limit']*($page-1);
                            $my_start_12_123=$this->timelines[$id]['form']['limit']*($page-1)+1;
                            $this->set_template_vars("dataTimeline", $this->timelines[$id]['form']);
                            $my_c_12_123=$my_start_12_123;
                            self::debug("metaType", $type);
                            $this->queryPosts(array(),$id,$offset);
                            $this->initDataFront($id);
                            $viewFile=$this->views_dir.'ver/onePost.php';
                            $classTmpl=$this->classTmpl;
                            $type=$this->timelines[$id]['type'];
                            $data=$this->data[$id];
                            $posts=$this->myQueryModel->getPostsInModel($id);
                            //$posts=$this->shortcodePosts[$id];
                            $strings=$this->loadOptions('strings.php');
                            ob_start();
                            require $viewFile;
                            $this->ret['html']=ob_get_clean();
                            $this->ret['images']=$this->data[$id]['images'];
                            $this->ret['sorted']=$this->data[$id]['sorted'];
                            $this->ret["offset"]=$offset;
                            $this->ajaxOk('');
                        }
                    }
                }
            }
            
        }
        /**
         * Post comment from frontedn
         */
        protected function postComm(){
            $post_id=@$_POST['post_id'];
            $limitComment=wp_my_pro_timeline_get_option('limitComment');
            
            if(!preg_match('/^[0-9]+$/',$post_id)){
                $this->ajaxError(__("Error","my_support_theme"));
            }else {
                $post=get_post($post_id);
                if($post->post_type!="my_timeline"){
                    $this->ajaxError(__("Error","my_support_theme"));
                }else {
                    $front_submit_not_logged=wp_my_pro_timeline_get_option('front_submit_not_logged');
                    
                    $useR=wp_my_pro_timeline_get_option('recaptcha');
                    $myDo=true;
                    
                    if(!empty($useR)){
                        $r=@$_POST['recaptcha'];
                        $r=$this->checkRecaptcha($r);
                        if($r!==true){
                            $this->ajaxError(__("Error recapctha is not valid !","my_support_theme"));
                            $myDo=false;
                        }
                    }
                    if(empty($front_submit_not_logged)&&!(is_user_logged_in())){
                        $myDo=false;
                    }
                    if($myDo){
                        $stars=@$_POST['stars'];
                        $comm=@$_POST['comm'];
                        $comm=strip_tags($comm);
                        if(empty($comm)){
                            $myDo=false;
                            $this->ajaxError(__("Comment is required !","my_support_theme"));
                            
                        }
                        if($stars>=1&&$stars<=5){
                           if(!empty($limitComment)){
                                if(strlen($comm)>$limitComment){
                                    $myDo=false;
                                    $this->ajaxError(__("Comment length is gratter than maxximum lenght !","my_support_theme"));
                                    
                                }
                           }
                           if($myDo){
                               $not_save=wp_my_pro_timeline_get_option('not_save');
                               if($stars<$not_save){
                                    $this->emailPostCommNot($post_id, $comm, $stars);
                                    $this->ajaxOk(__("Success","my_support_theme"));
                                    
                               }else {
                                    $can=$this->modelStars->canPostComm($post_id);
                                    if(!empty($can)){
                                        $user_id=0;
                                        if(is_user_logged_in()){
                                            $user_id=get_current_user_id();
                                        }else {
                                            $this->modelStars->saveIp($post_id,"comments");
                                        }
                                       $this->emailPostComm($post_id, $comm, $stars); 
                                       $date=date('Y/m/d H:i:s'); 
                                       $this->modelStars->saveComm($post_id, $stars, $comm,$date);
                                       
                                       $timestamp=strtotime($date);
                                       $date=date('Y,F d H:i:s',$timestamp);
                                       $this->ajaxOk(__("Success","my_support_theme"));
                                       $viewFile=$this->views_dir.'postComment.php';
                                       ob_start();
                                       require $viewFile;
                                       $this->ret['html']=ob_get_clean();
                                    }else {
                                        $this->ajaxError(__("You have already post comment","my_support_theme"));
                                    }
                               }
                           }
                        }else {
                            $this->ajaxError(__("Error recapctha","my_support_theme"));
                            
                        }
                    }
                }
            }
        }
        /**
         * like post
         */
        protected function likePost(){
            $post_id=@$_POST['post_id'];
            if(!preg_match('/^[0-9]+$/',$post_id)){
                $this->ajaxError(__("Error","my_support_theme"));
            }else {
                $post=get_post($post_id);
                if($post->post_type!="my_timeline"){
                    $this->ajaxError(__("Error","my_support_theme"));
                }else {
                    $can=$this->modelStars->canLikePost($post_id);
                    if(!empty($can)){
                        $var=$this->modelStars->likePost($post_id);
                        $this->modelStars->saveIp($post_id);
                        $this->ret['num']=$var;
                        $this->ajaxOk(__("Success","my_support_theme"));
                    }else $this->ajaxError(__("You have liked this post !","my_support_theme"));
                }
            }
        }
        /**
         * Load video from front end
         * timeline
         */
        protected function loadVideo(){
            $post_id=@$_POST['post_id'];
            if(!preg_match('/^[0-9]+$/',$post_id)){
                $this->ajaxError(__("Error","my_support_theme"));
            }else {
                $post=get_post($post_id);
                if($post->post_type!="my_timeline"){
                    $this->ajaxError(__("Error","my_support_theme"));
                }else {
                    $this->ret['html']=$this->renderVideoPost($post_id);
                    $this->ret['error']=0;
                }
            }
        }
        /**
         * load post from frontend
         */
        public function loadPost(){
            $post_id=@$_POST['post_id'];
            $nonce=@$_POST['nonce'];
            $timeline=@$_POST['timeline_id'];
            if(!wp_verify_nonce($nonce,'my_timeline_load_post_'.$timeline)){
                $this->ret['error']=1;
                $this->ret['msg']=__("Error","my_support_theme");
            }else {
                if(!preg_match('/^[0-9]+$/',$post_id)){
                    $this->ret['error']=1;
                    $this->ret['msg']=__("Error","my_support_theme");
                }else {
                    $options=$this->global_plugin->loadOptions("meta_options.php");
                    $this->initMetaModule($options);
                    $is=$this->metaModuleObj->is_exists_object($timeline);
                    if(empty($is)){
                        $this->ret['error']=1;
                        $this->ret['msg']=__("Error","my_support_theme");
                    }else {
                        $type=$this->metaModuleObj->get_object_meta($timeline,"type");
                        if($type=="horizontal"){
                            $file=$this->views_dir.'hor/full_post.php';
                        }
                        $post_type="my_timeline";
                        ob_start();
                        require $file;
                        $this->ret['html']=ob_get_clean();
                        $this->ret['error']=0;
                    }
                }
            }
           //return $ret;
        }
    }
    
}

        