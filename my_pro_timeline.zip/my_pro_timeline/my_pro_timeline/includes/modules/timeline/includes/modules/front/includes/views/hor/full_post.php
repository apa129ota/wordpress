<?php
if(!defined('ABSPATH'))die('');
//echo 'Post type '.$post_type.' id  '.$post_id.'<br/>';
if($post_type=='post'){
$my_query=new WP_Query(array(
		'p'=>$post_id
));
if($my_query->have_posts()){
	while($my_query->have_posts()){
		$my_query->the_post();
		global $post;
		$post_id=$post->ID;
		$thumb_id=get_post_thumbnail_id($post_id);
		$has_thumb=false;
		if(!empty($thumb_id)){
			$has_thumb=true;
			$thumbs=wp_my_timeline_get_thumbs($thumb_id);
			if(isset($thumbs['large'])){
				$image=$thumbs['large'][0];
			}else if(isset($thumbs['medium'])){
				$image=$thumbs['medium'][0];
			}else {
				$image=$thumbs['thumbnail'][0];
			}
		}
		if(!empty($post->post_author)){
			$user_data=get_userdata($post->post_author);
			//print_r($user_data);
			
		}
		$timestamp=strtotime($post->post_date);
?>
<article id="post-<?php the_ID(); ?>" class="my_timeline_article">
		
		<div class="my_timeline_article_content">
		<header class="my-entry-header">
			<div class="my-entry-meta">
				<i class="fa fa-user"></i>&nbsp;&nbsp;<span><?php echo $user_data->user_nicename?></span>
			</div>
			<div class="my-entry-meta">
				<i class="fa fa-clock-o"></i>&nbsp;&nbsp;<span class="my_timeline_date_span"><?php echo date("F j,Y",$timestamp)?></span>		
			</div>	
		</header>
			<h2><a href="<?php echo get_permalink();?>" target="_blank"><?php the_title();?></a></h2>
	
		<?php if($has_thumb){?>
		<a href="<?php the_permalink()?>" target="_blank"><img src="<?php echo $image;?>"/></a>
		<?php }?>
		<p>
		
		
		<?php $content=$post->post_content;$content=strip_shortcodes($content);?>
		<?php echo $content;?>
		</p>
		</div>
</article>
<?php }}
}else {
	//$post=wp_my_timeline_get_object_meta($timeline_id, $post_type.'_'.$post_id);
	$post=wp_my_timeline_get_custom_post($post_id);
	?>
	<?php /*
	<pre><?php print_r($post);?></pre>
	*/ ?>
	<?php 
	$thumb_id=$post->post_thumb;
	$has_thumb=false;
	if(!empty($thumb_id)){
		$has_thumb=true;
		$thumbs=wp_my_timeline_get_thumbs($thumb_id);
		if(isset($thumbs['large'])){
			$image=$thumbs['large'][0];
		}else if(isset($thumbs['medium'])){
			$image=$thumbs['medium'][0];
		}else {
			$image=$thumbs['thumbnail'][0];
		}
	}
	if(!empty($post->user_id)){
		$user_data=get_userdata($post->user_id);
		//print_r($user_data);
			
	}
	$timestamp=strtotime($post->post_date);
	?>
	<article id="post-<?php the_ID(); ?>" class="my_timeline_article">
		
			<div class="my_timeline_article_content">
		<header class="my-entry-header">
			
				<div class="my-entry-meta">
					<i class="fa fa-user"></i>&nbsp;&nbsp;<span><?php echo $user_data->user_nicename?></span>
				</div>
				
				
				<div class="my-entry-meta">
					<i class="fa fa-clock-o"></i>&nbsp;&nbsp;<span class="my_timeline_date_span"><?php echo date("F j,Y",$timestamp)?></span>		
				</div>
			</header>	
						<h2><a href="" target=""><?php echo $post->post_title;?></a></h2>
			
			<?php if($has_thumb){?>
			<a href="" target=""><img src="<?php echo $image;?>"/></a>
			<?php }?>
			<p>
			
			<?php $content=$post->post_content;//$content=strip_shortcodes($content);?>
			<?php echo $content;?>
			</p>
			</div>
	</article>
	<?php
	
}
?>
