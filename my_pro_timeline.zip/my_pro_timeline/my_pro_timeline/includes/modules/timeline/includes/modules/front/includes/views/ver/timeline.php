<?php
if(!defined('ABSPATH'))die('');
//$data['form']['show_list']=true;
$dataTimeline=$this->get_template_var("dataTimeline");
//print_r($dataTimeline);
$all_posts=$data['all_posts'];
$count_sorted=0;

if(!empty($data['sorted'])){
	$count_sorted=count($data['sorted']);
}


$my_added_points=array();
$timeline_id=$id;
?>
<div class="my_timeline_outter">
<div class="my_timiline_ver_div my_timeline_object" data-page="1" data-pages="<?php echo esc_attr($totalPages);?>" data-open="<?php echo esc_attr($dataTimeline['openDialog']);?>" data-id="<?php echo esc_attr($id);?>" data-type="vertical" id="my_timeline_<?php echo esc_attr($id);?>">
	
	<?php 
	
	//$layout_cols=$data['layout']['cols'];
	//$w123=ceil((100/$layout_cols)*(count($all_posts)))+100;
	//$my_c_12_123=1;
	?>
	<div class="my_timeline_ver_out_div">
		
		
	<div class="my_timeline_ver_ul" data-id="<?php echo esc_attr($id)?>" data-c="<?php $c_p_12=count($all_posts);echo $c_p_12;?>">
		<div class="my_timeline_start_date">
			<div class="my_start_date_inner">
				
				<span><?php echo __("Start date","my_support_theme")?> : <?php echo wp_my_pro_timeline_date_pretty($startDate,$strings);?></span><br/>
				<i class="fa fa-circle"></i>
			</div>
		</div>
		<div class="my_timeline_ver_line"></div>
		<?php
		if(!isset($my_c_12_123)){
		    $my_c_12_123=1;
		}
		$my_start_12_123=1;
		$layout_class="";//$data['layout']['layout_class']; 
		foreach($data['all_posts'] as $key=>$value){
			$post_id=$value->getVar("ID");//['post_id'];
			$type='my_timeline';
			$post_url=$value->getVar('permalink');
			$postDate=$value->getPostMetaByKeyStored('postDate');
			$postDateArr=explode("/",$postDate);
			$year=$postDateArr[0];
			$month=$postDateArr[1];
			$day=$postDateArr[2];
			$html=$classTmpl->renderTemplate($value,$dataTimeline['postTemplate'],$dataTimeline);
			$my_id='my_post_'.$type.'_'.$post_id;
			$dateP=wp_my_pro_timeline_date_pretty($postDate,$strings);//$year.", ".$strings['monthsFull'][$month].' '.$day;
			?>
			<div data-prettyDate="<?php echo esc_attr($dateP);?>" data-pos="<?php echo esc_attr($my_start_12_123);$my_start_12_123++;?>" data-i="<?php echo(esc_attr($year));?>" data-date="<?php echo esc_attr($year.'/'.$month.'/'.$day);?>" data-post-id="<?php echo esc_attr($post_id)?>" data-type="<?php echo esc_attr($type);?>" data-i="<?php echo $my_c_12_123++;?>" class="my_post_class  my_timeline_ver_class my_vertical_timeline" data-open="<?php echo esc_attr($dataTimeline['openDialog']); ?>" data-link="<?php echo esc_attr($post_url); ?>" id="<?php echo $my_id;?>" data-type="<?php echo esc_attr($type);?>">
			<div class="my_post_class_line">
				<div class="my_post_class_line_date">
					<?php echo $dateP;?>
				</div>
			</div>
			<?php echo $html;?>
			</div>
			<?php 
			
		}
		
		?>
	</div>
	</div>
	<?php if($totalPages>1){?>
		<div class="myLoadingMore" data-page="1" data-pages="<?php echo  esc_attr($totalPages)?>">
			<div class="myLoadSpan">
				<i class="fa fa-spinner fa-spin"></i><?php echo __("Loading more posts","my_support_theme");?><br/>	
			</div>
			<input type="button" class="myLoadMoreButton" value="<?php echo __("Load more posts","my_support_theme")?>"/>
		</div>
	<?php }?>
</div>
</div>
<?php
