<?php 
if(!defined('ABSPATH'))die('');
//if(!empty($data['form']['show_share'])){
	global $post;
if($my_is_vertical_post==1){
	
}else {
	
}	
$facebook_url=wp_my_timeline_share_posts_new($post_id, $post->post_title, $post->post_content,$p_photo,'facebook');
$twitter_url=wp_my_timeline_share_posts_new($post_id, $post->post_title, $post->post_content);
$pinterest_url=wp_my_timeline_share_posts_new($post_id, $alt,'',$p_photo,'pinterest');
$g_plus=wp_my_timeline_share_posts_new($post_id, $post->post_title, $post->post_content,$p_photo,'google');

	?>
<?php if($my_is_vertical_post){?>
				<span class="my_timeline_span"><?php echo __("Share Post","my_related_posts_domain")?></span>
				<a class="my_share_post_vertical" href="<?php echo $facebook_url?>"><i class="fa fa-facebook my_timeline_icon"></i></a>
			<a class="my_share_post_vertical" href="<?php echo $twitter_url?>"><i class="fa fa-twitter my_timeline_icon"></i></a>
			<a class="my_share_post_vertical" href="<?php echo $pinterest_url?>"><i class="fa fa-pinterest-p my_timeline_icon"></i></a>
			<a class="my_share_post_vertical" href="<?php echo $g_plus?>"><i class="fa fa-google-plus my_timeline_icon"></i></a>
		
<?php 
	 }else {?>
<a href="#javascipt" class="my_show_share" title="<?php echo __("Share this post to social networks","my_related_posts_domain")?>"><i class="fa fa-share-alt"></i></a>		
<div class="my_timeline_share">
		<ul>
			<li>
				<a href="<?php echo $facebook_url?>"><i class="fa fa-facebook"></i></a>
			</li>
			<li>
			<a href="<?php echo $twitter_url?>"><i class="fa fa-twitter"></i></a>
			</li>
			<li>
			<a href="<?php echo $pinterest_url?>"><i class="fa fa-pinterest-p"></i></a>
			</li>
			<li>
			<a href="<?php echo $g_plus?>"><i class="fa fa-google-plus"></i></a>
			</li>	
		</ul>
</div>
<?php }?>