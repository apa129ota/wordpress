<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my-wp-video<?php if(!defined('DOING_AJAX'))echo'-new';?> my-vimeo-video">
	<iframe src="<?php echo $videoSrc;?>"></iframe>
</div>