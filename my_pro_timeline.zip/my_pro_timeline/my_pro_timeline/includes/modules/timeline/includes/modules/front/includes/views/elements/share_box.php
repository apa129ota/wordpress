<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_timeline_share_box" data-class="">
	<div class="my_timeline_share_box_div">
	<ul>
			<li>
				<a href="<?php echo $facebook_url?>"><i class="fa fa-facebook"></i></a>
			</li>
			<li>
			<a href="<?php echo $twitter_url?>"><i class="fa fa-twitter"></i></a>
			</li>
			<li>
			<a href="<?php echo $p?>"><i class="fa fa-pinterest-p"></i></a>
			</li>
			<li>
			<a href="<?php echo $g_plus?>"><i class="fa fa-google-plus"></i></a>
			</li>	
		</ul>
	</div>
</div>	