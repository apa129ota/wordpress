(function ($) {

  //myproslider: Object Instance
  $.myproslider = function(el, options) {
	var my_slider = $(el);
    var default_settings={
    		debug:false,
    		has_timeline:false,
    		slider_timeline_class:'.my_timeline_hor_list',
    		slider_timeline_l_arrow:'.my_timeline_hor_list_nav_left',
    		slider_timeline_r_arrow:".my_timeline_hor_list_nav_right",
    		animate_dialog_time:2000,
    		line_duration:2000,
    		swipeOn:1,
    		marginAnimation:500,
    		regionWidth:150,
    		show_left_right:false,
    		circle_duration:500,
    		form:{
    			
    			addMargin:150,
    			animateMargin:1,
    			circle_duration:800,
    			circle_back_color:'#ccc',
    			circle_hover_color:'#018bb5'
    		},
    		line_easing:'easeOutQuad',
    		duration:2000,
    		easing:"easeOutQuad",
    		use_touch:true,
    		normal_width:960,
    		tooltip_hide:1000,
    		height:'60%',
    		heights:{
    			800:'70%',
    			600:'100%'
    		},
    		lay_keys:['0','700','960','1280','1600','5000'],
    		
    		slider_class:'.my_timeline_hor_out_div'
    			
    };
    my_slider.id=$(my_slider).attr('id');
    my_slider.started = false;
    my_slider.startTimeout = null;
    var settings=$.extend(default_settings,options);
    var gesture = window.navigator && window.navigator.msPointerEnabled && window.MSGesture;
    
    var  touch = (( "ontouchstart" in window ) || gesture || window.DocumentTouch && document instanceof DocumentTouch);
    if(typeof touch=='undefined')touch=false;
    else touch=touch&&settings.use_touch;
    my_slider.working=false;
    my_slider.vars=settings;
    my_slider.hasTouch12=touch;
    //console.log("Touch",touch);
    // my_slider.my_debug("Touch",touch);
    /**
     * get post thumbnaail by position in 
     * the list
     */
    my_slider.getPostThumbnail=function(i){
    	var itemPos=i;
    	
    	var postID=$(my_slider).find("li[data-pos='"+itemPos+"']").attr('data-post-id');
    	my_slider.my_debug("postItemPos",itemPos);
    	my_slider.my_debug('postID',postID)
    	var img="";
    	my_slider.my_debug("postImages",my_slider.vars.images);
    	if(typeof my_slider.vars.images[postID]!="undefined"){
    		var thumbs=my_slider.vars.images[postID];
    		my_slider.my_debug("PostThumbs",thumbs);
    		if(typeof thumbs.thumbnail!='undefined'){
    			img=thumbs.thumbnail[0];
    			
    		}
    	}
    	my_slider.my_debug("Postimg",img);
    	return img;
    };
    /**
     * Animate hover
     */
    my_slider.animateMarginHover=function(){
    	if(my_slider.vars.form.animateMargin==1){
    		if(my_slider.vars.form.sliderCursor=="images"){
    			$(".my_nav_left").mouseenter(function(e){
    				if(my_slider.vars.current_item>1){
    					
    				}else return 1;
    			});
    			$(".my_nav_right").mouseenter(function(e){
    				
    				if(my_slider.vars.current_item<my_slider.vars.total_items){
    					$(".my_timeline_hor_ul").finish();
    					var marginLeft=parseInt($(".my_timeline_hor_ul").css('margin-left'));
    					var addMargin=my_slider.item_total_width*0.5;
    					my_slider.vars.myMarginLeft=marginLeft;
    					var newMargin=marginLeft-addMargin;
    					$(".my_timeline_hor_ul").animate({marginLeft:newMargin},500,'easeOutQuad');
    					
    					
    				}else return 1;
    			});
    			$(".my_nav_right").mouseenter(function(e){
    				$(".my_timeline_hor_ul").finish();
    				var oldMargin=my_slider.vars.myMarginLeft;
    				var addMargin=my_slider.item_total_width*0.5;
    				var newMargin=oldMargin+addMargin;
    				$(".my_timeline_hor_ul").animate({marginLeft:newMargin},500,'easeOutQuad');
					

    			});
    		}else {
    			
    		}
    	}
    };
   /**
    * function for displaying new thumbs left right
    */
    my_slider.adjust_left_right_thumbs=function(){
    	if(my_slider.vars.hasTouch)return;
    	if(my_slider.vars.form.sliderCursor=="images"){
    	var itemClass='#my_timeline_'+my_slider.vars.id+ ' .my_testimonial_next_left  div div ';
    	var iconClass='#my_timeline_'+my_slider.vars.id+ ' .my_nav_left';
    	var type=my_slider.vars.type_hover;
    	var curr_item=my_slider.start_item;//my_slider.vars.current_item;
    	//var itemPos=my_slider;
    	my_slider.my_debug("curr item",{curr:curr_item,type:type});
    	var $myPos='margin-left:84px;border-radius:50%;';
    	if(type=='left'){
    		if(curr_item==1){
    			my_slider.hide_next_prev();
    			
    			return;
    		}else {
    			itemPos=curr_item-1;	
    		}
    	}else {
    		$myPos="margin-left:84px;border-radius:50%;";
    		itemClass='#my_timeline_'+my_slider.vars.id+' .my_testimonial_next_rigth div div';
    		iconClass='#my_timeline_'+my_slider.vars.id+' .my_nav_right';
    		marginLeft='20px';
    		var rightT=my_slider.total_items;//-my_slider.layout.cols;
    		if(curr_item==(rightT)){
    			my_slider.hide_next_prev();
    			return;
    		}else {
    			itemPos=curr_item+1;
    		}
    	}
    	var str=itemPos+'/'+my_slider.total_items;
    	my_slider.vars.my_item_pos_str=str;
    	$(iconClass).find(".my_nav_item").html(str);
    	var img=my_slider.getPostThumbnail(itemPos);
    	
    	var html='<img class="newItem" style="'+$myPos+'" src="'+img+'" width="80px" height="80px" />';
    	if(type=='left'){
    		$(itemClass+" ").append(html);
    		setTimeout(function(){
    		$(itemClass).find("img.oldItem").animate({'margin-left':'-84px'},my_slider.vars.marginAnimation,function(){
    			$(this).remove();
    		});
    		my_slider.my_debug("Margin left",$(itemClass).find("img.newItem").css('margin-left'));
    		
    		$(itemClass).find("img.newItem").animate({'margin-left':'-=84px'},my_slider.vars.marginAnimation,function(){
    			my_slider.my_debug("Margin left",$(itemClass).find("img.newItem").css('margin-left'));
    			$(this).attr('class','oldItem');
    			
        			
    		});
    		},100);
    	}else {
    		$(itemClass+" ").append(html);
    		setTimeout(function(){
        		
    		$(itemClass).find("img.oldItem").animate({'margin-left':'-84px'},my_slider.vars.marginAnimation,function(e){
    			$(this).remove();
    		});
    		$(itemClass).find("img.newItem").animate({'margin-left':'-=84px'},my_slider.vars.marginAnimation,function(){
    			my_slider.my_debug("Margin left",$(itemClass).find("img.newItem").css('margin-left'));
    			
    			$(this).attr('class','oldItem');
    			
    		});}
    		,100);
    	}
    	
    	
    	}
    	
    };
    my_slider.moveMouse=function(e){
    	if(my_slider.vars.myMouseDown){
			var xpos=my_slider.vars.myMouseDownEvent.pageX;
			var xmargin = my_slider.vars.marginLeft-xpos + e.pageX;
			var count=my_slider.vars.myTotalItems;
			var minMargin=-(count-1)*my_slider.item_width;
			if(xmargin<minMargin || xmargin>0 ){
				return;
			}
			my_slider.my_debug("Mouse move",{x:e.pageX,xpos:xpos,xmargin:xmargin,minMargin:minMargin});
			
			$(my_slider).find(".my_timeline_hor_ul").css({marginLeft:xmargin+'px'});
			}
    };
    my_slider.transitions=function() {
          var obj = document.createElement('div'),
              props = ['perspectiveProperty', 'WebkitPerspective', 'MozPerspective', 'OPerspective', 'msPerspective'];
          for (var i in props) {
            if ( obj.style[ props[i] ] !== undefined ) {
              my_slider.pfx = props[i].replace('Perspective','').toLowerCase();
              my_slider.prop = "-" + my_slider.pfx + "-transform";
              return true;
            }
          }
          return false;
        }();
        	
    var div_id='#'+$(el).attr('id');
    my_slider.my_debug=function(t,o){
    	if(settings.debug){
    		if(window.console){
    			console.log('Pro slider :'+t,o);
    		}
    	}
    };
    my_slider.open_dialog_maybe=function(e){
    	if(my_slider.vars.form.openDialog=="href")return;
    	e.preventDefault();
    	var open_link_type=my_slider.vars.form.openDialog;//$(this).parents('li').data('open');
    	my_slider.my_debug("open link type",open_link_type);
    	var href=$(this).attr('href');
    	$(".my_timeline_modal").find(".my_timeline_modal_loading").css('opacity',1).show();
    	if(typeof open_link_type!='undefined'){
    		if(open_link_type=='dialog'){
    			$(".my_timeline_modal").attr('id',my_slider.id+"_modal");
    			my_slider.dialog_is_open=true;
    			$(".my_timeline_modal_load iframe").attr('src',href);
    			$(".my_timeline_modal_load iframe").on("load",function(e){
    				$(".my_timeline_modal").find(".my_timeline_modal_loading").fadeOut(function(){
	    				$(".my_timeline_modal").find(".my_timeline_modal_load").fadeIn(function(){
	    					var ht=$(".my_timeline_modal").find(".my_timeline_modal_header").outerHeight(true);
	    	    			var otV=my_slider.getViewportSize();//my_slider.vars_12.h;
	    	    			var ot=otV.h;
	    	    			var p=ot-ht-10;
	    	    			$(".my_timeline_modal").find(".my_timeline_modal_load").height(p);
	    	    			my_slider.my_debug("Heights",{otV:otV,ot:ot,p:p,ht:ht});
	    	    			/*if(typeof is=='undefined'){
	    	    			setTimeout(function(){
	    	    				$(".my_timeline_modal").find(".my_timeline_modal_load").mCustomScrollbar(
	    	    	    				{axis:'y',
	    	    	    				advanced:{
	    	    	    					updateOnContentResize:true
	    	    	    					}});
	    	    			},400);
	    	    			}*/
	    	    			
	    				});
    	    			
	    			});
    			});	
    		
    			e.preventDefault();
    			my_slider.overflow_css=$("body").css("overflow");
    			my_slider.my_debug('Overrflow',my_slider.overflow_css);
    			$("body").css('overflow','hidden');
    			var v=my_slider.getViewportSize();
    			my_slider.my_debug('Widths',v);
    			var top=$(window).scrollTop();
    			my_slider.vars_12=v;
    			//$(".my_timeline_modal").css('top',top+'px');
    			//$(".my_timeline_modal").width(v.w);
    			$(".my_timeline_modal").height(v.h); 			
    			$(".my_timeline_modal").find(".my_timeline_modal_load").hide();
    			$(".my_timeline_modal").find(".my_timeline_modal_loading").show();
    			var hH=parseInt($(".my_timeline_modal").outerHeight(true));
    			var hL=v.h-hH;
    			$(".my_timeline_modal").find(".my_timeline_modal_load").height(hL);
    			//my_slider.my_debug("Heights",{view:v,hH:hH,hL:hL});
    			
    			if(my_slider.transitions){
    				$(".my_timeline_modal").css(my_slider.prop,'center center');
        					
    				$(".my_timeline_modal").css(my_slider.prop,'scale(0)');
    				$(".my_timeline_modal").css('opacity',0);
    				$(".my_timeline_modal").show();
    				//$(".my_timeline_modal").css(my_slider.prop+'-transform','scale(1)');
    				
    				//$(".my_timeline_modal").css(my_slider.prop+'-transition-duration','1s;');
    				$(".my_timeline_modal").animate({
						my_scale:1,
						opacity:1
					},{
						step:function(now,fx){
							//fx.start=0;
							if(fx.prop=='my_scale'){
								//my_admin_debug("Now",now);
								my_trans=my_slider.prop;
								$(this).css(my_trans,'scale('+now+')');	
							}
						}
					,duration:my_slider.vars.animate_dialog_time});
    				
    			}else {
    				$(".my_timeline_modal").fadeIn();
    			}
    			/*
    			var post_id=$(this).parents('li').data('post-id');
    			var post_type=$(this).parents('li').data('post-type');
    			my_slider.my_debug("Post",{post_id:post_id,post_type:post_type});
    			var data={
    					action:my_slider.vars.ajax_action,
    					post_id:post_id,
    					post_type:post_type,
    					nonce:my_slider.vars.ajax_nonce,
    					timeline_id:my_slider.vars.id
    			}
    			my_slider.my_debug("Get post",data);
    			$.ajax({
    				url:my_slider.vars.ajax_url,
    				dataType:'json',
    				cache:false,
    				timeout:my_slider.vars.ajax_timeout,
    				type:'POST',
    				data:data,
    				success:function(data){
    					
    					$(".my_timeline_modal").find(".my_timeline_modal_load").html(data.html);
    					/*$(".my_timeline_modal").find(".my_timeline_modal_load").fadeIn(function(){
    						
    					});
    	    			$(".my_timeline_modal").find(".my_timeline_modal_loading").fadeOut(function(){
    	    				$(".my_timeline_modal").find(".my_timeline_modal_load").fadeIn(function(){
    	    					var ht=$(".my_timeline_modal").find(".my_timeline_modal_title").outerHeight();
    	    	    			var ot=my_slider.vars_12.h;
    	    	    			var p=ot-ht;
    	    	    			$(".my_timeline_modal").find(".my_timeline_modal_load").height(p);
    	    	    			
    	    	    			//if(typeof is=='undefined'){
    	    	    			setTimeout(function(){
    	    	    				$(".my_timeline_modal").find(".my_timeline_modal_load").mCustomScrollbar(
    	    	    	    				{axis:'y',
    	    	    	    				advanced:{
    	    	    	    					updateOnContentResize:true
    	    	    	    					}});
    	    	    			},400);
    	    	    			
    	    				});
        	    			
    	    			});
    	    			var ht=$(".my_timeline_modal").find(".my_timeline_modal_title").outerHeight();
    	    			var ot=my_slider.vars_12.h;
    	    			var p=ot-ht;
    	    			$(".my_timeline_modal").find(".my_timeline_modal_load").height(p);
    	    			
    	    				$(".my_timeline_modal").find(".my_timeline_modal_load").mCustomScrollbar(
    	    	    				{axis:'y',
    	    	    				advanced:{
    	    	    					updateOnContentResize:true
    	    	    					}});
    	    		
    				},
    				error:function(){
    					alert('Error');
    				}
    			});
    			*/
    		}
    	}
    };
    $(document).on('click','.my_timeline_item .my_timeline_open_link',my_slider.open_dialog_maybe);
    $(document).on('click','.my_timeline_modal_close',function(e){
    	e.preventDefault();
    	if(my_slider.transitions){
			
    		$(".my_timeline_modal").animate({
				my_scale:0,
				opacity:0
			},{
				step:function(now,fx){
					//fx.start=0;
					if(fx.prop=='my_scale'){
						//my_admin_debug("Now",now);
						my_trans=my_slider.prop;
						$(this).css(my_trans,'scale('+now+')');	
					}
				}
			,duration:my_slider.vars.animate_dialog_time,complete:function(){
				$(this).hide();
				my_slider.dialog_is_open=false;
				$(".my_timeline_modal").find(".my_timeline_modal_load").mCustomScrollbar('destroy');
				$(".my_timeline_modal").find(".my_timeline_modal_load").css('height','');
				$(".my_timeline_modal").find(".my_timeline_modal_load").hide();
				$("body").css("overflow",my_slider.overflow_css);
			}
    	}
    		);
			
			
		}else {
			$(".my_timeline_modal").fadeOut(1000,function(){
				$("body").css('overflow',my_slider.overflow_css);
				my_slider.dialog_is_open=false;
				$(".my_timeline_modal").find(".my_timeline_modal_load").mCustomScrollbar('destroy');
				$(".my_timeline_modal").find(".my_timeline_modal_load").css('height','');
				$(".my_timeline_modal").find(".my_timeline_modal_load").hide();
			});
		}
    });
    my_slider.my_debug('Settings',settings);
    my_slider.my_debug('TRansforms',{t:my_slider.transitions,pfx:my_slider.pfx,prop:my_slider.prop});
    my_slider.my_debug('Touch',touch);
    //var has_timeline=false;
    if($(my_slider).find(settings.slider_timeline_class).length>0){
    	my_slider.vars.has_timeline=true;
    }
    /**
     * Animate hoover when slider 
     * cursor is images
     * my_slider.vars.form.sliderCursor='images'
     */
    my_slider.animate_hover=function(el){
    	$(this).finish();
    	var type=my_slider.vars.type_hover;
    	var curr_item=my_slider.vars.current_item;
    	my_slider.my_debug("Animate",{item:curr_item,type:type});
    	var itemPos;										
    	var itemClass='#my_timeline_'+my_slider.vars.id+ ' .my_testimonial_next_left div div ';
    	var iconClass='#my_timeline_'+my_slider.vars.id+ ' .my_nav_left';
    	
    	var marginLeft='-20px';
    	if(type=='left'){
    		if(curr_item==1){
    			return;
    		}else {
    			itemPos=curr_item-1;	
    		}
    	}else {
    		itemClass='#my_timeline_'+my_slider.vars.id+' .my_testimonial_next_rigth div div';
    		iconClass='#my_timeline_'+my_slider.vars.id+' .my_nav_right';
    		marginLeft='20px';
    		var cols=parseInt(my_slider.layout.cols);
    		var rightT=my_slider.total_items;//-cols+1;
    		if(curr_item==rightT){
    			return;
    		}else {
    			itemPos=curr_item+1;
    			
    		}
    	}
    	var str=itemPos+'/'+my_slider.total_items;
    	my_slider.vars.my_item_pos_str=str;
    	$(iconClass).find(".my_nav_item").html(str);
    	my_slider.my_debug("Classes",{itemClass:itemClass,iconClass:iconClass,duration:my_slider.vars.form.circle_duration});
    	var preColor=$(iconClass).css('background-color');
    	my_slider.my_debug("Classes",preColor);
    	$(iconClass).finish();
    	$(iconClass).find(".my_nav_arrow").finish();
    	$(iconClass).find(".my_nav_item").finish();
    	$(itemClass).finish();
    	var color=my_slider.vars.form.circle_hover_color;
    	my_slider.my_debug("Animate color",{color:color});
    	$(iconClass).animate({backgroundColor:color},my_slider.vars.form.circle_duration);
    		$(iconClass).find(".my_nav_arrow").animate({left:'-41px'},my_slider.vars.form.circle_duration/2,function(){
    		$(iconClass).find(".my_nav_item").animate({left:'0px'},my_slider.vars.form.circle_duration/2);
    		
    	});
    	var img=my_slider.getPostThumbnail(itemPos);//$(my_slider).find("li[data-pos='"+itemPos+"'] img").attr('src');
    	var html='<img class="oldItem" src="'+img+'" width="80px" height="80px" style="border-radius:50%"/>';
    	if(type=='left'){
    		$(itemClass+" ").html(html);
    	}else {
    		$(itemClass+" ").html(html);
    	}
    	if(my_slider.transitions){
    	//	self.my_debug('Transitions');
    		$(itemClass).css(my_slider.prop,'scale(0)');
    		$(itemClass).my_scale=0;
    		$(itemClass).animate({
				my_scale:1
			},{
				step:function(now,fx){
					if(fx.prop=='my_scale'){
							var my_trans=my_slider.prop;//+'transform';
							//my_slider.my_debug("Trans",{trans:my_trans,now:now});
							$(this).css(my_trans,'scale('+now+')');
					}
				},
				complete:function(){
					
				},duratuon:my_slider.vars.form.circle_duration
			});
    	}else {
    		//self.my_debug('Fadein');
    		$(itemClass).css('opacity',0);
    		$(itemClass).animate({opacity:1},my_slider.vars.form.circle_duration);
			
    	}
    	
    };
    my_slider.hide_next_prev=function(el){
    	//var el=$(this);
    	$(this).finish();
    	var type=my_slider.vars.type_hover;
    	var curr_item=my_slider.vars.current_item;
    	my_slider.my_debug("Animate close",{item:curr_item,type:type});
    	var itemPos;
    	var itemClass='#my_timeline_'+my_slider.vars.id+ ' .my_testimonial_next_left div div';
    	var iconClass='#my_timeline_'+my_slider.vars.id+ ' .my_nav_left';
    	var marginLeft='-20px';
    	if(type=='left'){
    		if(curr_item==1){
    			//return;
    		}else {
    			itemPos=curr_item-1;	
    		}
    	}else {
    		itemClass='#my_timeline_'+my_slider.vars.id+' .my_testimonial_next_rigth div div';
    		iconClass='#my_timeline_'+my_slider.vars.id+' .my_nav_right';
    		marginLeft='20px';
    		if(curr_item==my_slider.total_items){
    			//return;
    		}else {
    			itemPos=curr_item+1;
    		}
    	}
    	my_slider.my_debug("Classes",{itemClass:itemClass,iconClass:iconClass});
    	
    	$(iconClass).finish();
    	$(iconClass).find(".my_nav_arrow").finish();
    	$(iconClass).find(".my_nav_item").finish();
    	$(itemClass).finish();
    	var color=my_slider.vars.form.circle_back_color;
    	my_slider.my_debug("Animate color",{color:color});
    	$(iconClass).animate({backgroundColor:color},my_slider.vars.form.circle_duration);
    	$(iconClass).find(".my_nav_item").animate({'left':'41px'},my_slider.vars.form.circle_duration/2,function(){
    		$(iconClass).find(".my_nav_arrow").animate({left:'0px'},my_slider.vars.form.circle_duration/2);
    	});
    	/*var img=$(my_slider).find("li[data-pos='"+itemPos+"'] img").attr('src');
    	var html='<img src="'+img+'" width="80px" height="80px" style="bortde-radius:50%"/>';
    	if(type=='left'){
    		$(itemClass+" div").html(html);
    	}else {
    		$(itemClass+" div").html(html);
    	}*/
    	if(my_slider.transitions){
    		//self.my_debug('Transitions');
    		//$(itemClass).css(my_slider.prop+'transform',0);
    		$(itemClass).animate({
				my_scale:0
			},{
				step:function(now,fx){
					if(fx.prop=='my_scale'){
							var my_trans=my_slider.prop;//+'transform';
							//my_slider.my_debug("Trans",{trans:my_trans,now:now});
							$(this).css(my_trans,'scale('+now+')');
					}
				},
				complete:function(){
					
				},duratuon:my_slider.vars.form.circle_duration
			});
    	}else {
    		//self.my_debug('Animat opacity');
    		//$(itemClass).css('opacity',0);
    		$(itemClass).animate({opacity:0},my_slider.vars.form.circle_duration);
			
    	}
    };
    my_slider.hide_nav=function(e){
    	my_slider.my_debug('Mouse leave');
    	my_slider.my_line_nav_timeout=setTimeout(function(){
    		$(my_slider).find(".my_line_nav").fadeOut();
			
    	},200);
    };
    
    my_slider.init_timeline_line=function(){
    	var w=$(my_slider).find(settings.slider_timeline_class).outerWidth();
    	var m_l=$(my_slider).find(settings.slider_timeline_class+" ul li.my_timeline_month").css('margin-left');
    	m_l=parseFloat(m_l)*2;
    	var w1=w-m_l;
    	my_slider.t_width=w;
    	my_slider.t_inner_w=w1;
    	$(my_slider).find(settings.slider_timeline_class +' .my_timeline_month').width(w1);
    	var c=$(my_slider).find(settings.slider_timeline_class +' ul > li.my_timeline_month').length;
    	var w2=c*w;
    	$(my_slider).find(settings.slider_timeline_class+' ul ').width(w2);
    	var h=$(my_slider).find(settings.slider_timeline_class+' ul li ').outerHeight();
    	var h2=$(my_slider).find(my_slider.vars.slider_timeline_l_arrow).height();
    	var h1=h-(h2/2);
    	my_slider.my_debug('Arrows height',{m_l:m_l,h:h,h1:h1,h2:h2});
    	//change 11 2 2015 set top
    	var my_test_top=(h2/2)+2;
    	
    	h1=my_test_top;
    	$(my_slider.vars.slider_timeline_l_arrow).css('top',h1+'px');
    	$(my_slider.vars.slider_timeline_r_arrow).css('top',h1+'px');
    	/*var hp=$(my_slider.vars.slider_timeline_class+" .my_post_item").outerHeight();
    	var of=$(my_slider).find(".my_timeline_hor_list_line").offset().top;
    	of-=hp/2;
    	$(my_slider.vars.slider_timeline_class+" .my_post_item").css('top',of+'px');
    	*/
    	
    };
    my_slider.getViewportSize=function() {

        // Use the specified window or the current window if no argument
    	var w=window;
    	/*if(my_slider.vars.preview){
    		var iframes = window.frames
        	w=iframes[0].window;
        }*/
    	

        // This works for all browsers except IE8 and before
        if (w.innerWidth != null) return { w: w.innerWidth, h: w.innerHeight };

        // For IE (or any browser) in Standards mode
        var d = w.document;
        if (document.compatMode == "CSS1Compat")
            return { w: d.documentElement.clientWidth,
               h: d.documentElement.clientHeight };

        // For browsers in Quirks mode
        return { w: d.body.clientWidth, h: d.body.clientHeight };

    };
    /**
     * init scrollbars
     */
    my_slider.init_scroll=function(){
    	if((my_slider.vars.form.postTemplate=="template_6")||(my_slider.vars.form.postTemplate=="template_8")){
    		my_slider.my_debug("Init scrolls");
    		var is=$(my_slider).find(".my_post_content_row").data('is-scroll-init');
    		my_slider.my_debug("Is init custom scroll bar",is);
    		if(typeof is=='undefined'){
    			my_slider.my_debug('Init scrolls');
    			$(my_slider).find(".my_post_content_row").mCustomScrollbar(
    				{axis:'y',
    				advanced:{
    					updateOnContentResize:true
    					}});
    			$(my_slider).find(".my_post_content_row").data('is-scroll_init',1);
    		}else {
    			//$(my_slider).find(".my_timeline_text").mCustomScrollbar('update');
    		}
    	}
    };
    my_slider.touch=function(){
    	if(my_slider.touch){
            var startX,
              startY,
              offset,
              cwidth,
              dx,
              startT,
              onTouchStart,
              onTouchMove,
              onTouchEnd,
              scrolling = false,
              localX = 0,
              localY = 0,
              accDx = 0;

           
                onTouchStart = function(e) {
                  if (my_slider.working) {
                    e.preventDefault();
                  }else {
                	  my_slider.my_debug('E',e);
                	  cwidth = my_slider.width;
                      startT = Number(new Date());
                      // CAROUSEL:

                      // Local vars for X and Y points.
                      localX = e.originalEvent.touches[0].pageX;
                      localY = e.originalEvent.touches[0].pageY;
                      startX = localX;
                      startY =localY;

                	  $(my_slider).find(".my_timeline_hor_out_div").on('touchmove',onTouchMove);
                	  $(my_slider).find(".my_timeline_hor_out_div").on('touchend',onTouchEnd);
                	  my_slider.my_debug('Touch start',{localX:localX,localY:localY});
                  } 
                };
                onTouchMove = function(e) {
                  // Local vars for X and Y points.

                  localX = e.originalEvent.touches[0].pageX;
                  localY = e.originalEvent.touches[0].pageY;

                  dx = startX - localX;
                  scrolling = (Math.abs(dx) < Math.abs(localY - startY));;
                  my_slider.my_debug('Touch start',{localX:localX,localY:localY});	
                  var fxms = 500;

                  if ( !scrolling || Number( new Date() ) - startT > fxms ) {
                    e.preventDefault();
                    dx = dx/((my_slider.start_item === 1 && dx < 0 || my_slider.start_item === my_slider.total_items && dx > 0) ? (Math.abs(dx)/cwidth+2) : 1);
                    my_slider.my_debug("Touch move",dx);  
                    
                    }
                  
                };

                onTouchEnd = function(e) {
                  // finish the touch by undoing the touch session
                  //el.removeEventListener('touchmove', onTouchMove, false);
                	$(my_slider).find(".my_timeline_hor_out_div").unbind('touchmove',onTouchMove);		
                  if (!scrolling && !(dx === null)) {
                	  if(dx>0){
                		  my_slider.go_next();
                	  }else {
                		  my_slider.go_prev();
                	  }
                  }
                  $(my_slider).find(".my_timeline_hor_out_div").unbind('touchend',onTouchEnd);
                  startX = null;
                  startY = null;
                  dx = null;
                  offset = null;
                };

                $(my_slider).find(".my_timeline_hor_out_div").on('touchstart', onTouchStart);
                
    	}
    };
    /**
     * Set width on resize this is called
     * to set template width
     */
    my_slider.set_widths=function(){
    	var cols=my_slider.layout.cols;
    	var w=$(my_slider).find(my_slider.vars.slider_class).width();
    	var w1=w/cols;
    	if(my_slider.vars.form.full_width==1){
    		w1-=2*parseInt(my_slider.vars.form.gap);
    	}
    	var perc=(100/cols)*(my_slider.total_items+10);
    	$(my_slider).find(my_slider.vars.slider_class +" >ul").css('width',perc+'%')
    	var p=$(my_slider).find(my_slider.vars.slider_class+" > ul > li ").css('padding-right');
    	p=parseFloat(p);
    	w1=w1-p;
    	var marginL=parseInt($(my_slider).find(my_slider.vars.slider_class +" >ul >li .my_post_template").css('margin-left'));
    	var marginR=parseInt($(my_slider).find(my_slider.vars.slider_class +" >ul >li .my_post_template").css('margin-right'));
    	my_slider.marginL=marginL;
    	my_slider.marginR=marginR;
    	var w12=w1-marginL-marginR;
    	my_slider.item_width=w1+p;//$(my_slider).find(my_slider.vars.slider_class+" > ul > li ").outerWidth();
    	my_slider.my_debug('Width',{w:w,w1:w1,p:p});
    	$(my_slider).find(my_slider.vars.slider_class +" > ul > li ").width(w1);
    	$(my_slider).find(".my_post_content_div_row").width(w12);
    	if(my_slider.vars.form.postTemplate=="template_11"){
    		$(my_slider).find(".my_post_bg").width(w1);
    		$(my_slider).find(".my_post_bg").css('height','100%');
    		
        	
    	}
    	my_slider.item_total_width=parseInt($(my_slider).find(".my_timeline_li_class").outerWidth());//w1+p+marginL+marginR;
    	my_slider.my_debug("Margins",{totalWidth:my_slider.item_total_width,marginL:marginL,marginR:marginR});
    	
    };
    my_slider.getLayout=function(){
    	var vars=my_slider.vars.lay_keys;//:['1280','980','700','small'],700,980
    	var w=my_slider.width;
    	if(my_slider.vars.form.full_width==1){
    		my_slider.layout={cols:1,height:my_slider.vars.form.height};
    		my_slider.my_debug("Layout",my_slider.layout);
    		return;
    	}
    	my_slider.my_debug("Slider width",w);
    	var my_found=false;
    	$.each(vars,function(i,v){
    		var v1=parseFloat(v);
    		my_slider.my_debug("Check lkayout",v1);
    		
    		if(w<v1){
    			my_slider.my_debug("return",v1);
        		
    			return false;
    		}
    		if(w>=v1){
    			my_slider.my_debug("Assign layout",v1);
        		
    			my_found=true;
    			my_slider.layout=my_slider.vars.layout[v];
    			//return false;
    		}
    		
    	});
    	if(!my_found){
    		my_slider.layout=my_slider.vars.layout['small'];
    		
    	}
    	my_slider.my_debug("Layout",my_slider.layout);
    };
    my_slider.set_height=function(){
    	
    	var v=my_slider.getViewportSize();
    	my_slider.my_debug('View port size',v);
    	var hp=my_slider.layout.height;
    	/*
    	var hp=my_slider.vars.height;
    	if(v.w<my_slider.vars.normal_width){
    		/*var hs1=my_slider.vars.heeights;
    		$.each(hs1,function(i,v){
    			if(i<v.w){
    				return false;
    			}else {
    				hp=v;
    			}
    		});*/
    	//}
    	
    	var hp_p=parseFloat(hp);
    	var h=0;
    	my_slider.my_debug('Height',hp_p);
    	
    	if(hp.indexOf('%')!==-1){
    			h=v.h*(hp_p/100);
    		
    	}else {
    		h=hp;
    	}
    	my_slider.my_debug('Set height',h);
    	var ht=$(my_slider).find(".my_timeline_text").height();
    	my_slider.my_debug('Height timeline',ht);
    	
    	$(my_slider).find(my_slider.vars.slider_class).height(h);
    	$(my_slider).find(my_slider.vars.slider_class+" .my_timeline_li_class").height(h);
    	var topM=parseInt($(my_slider).find(my_slider.vars.slider_class+" .my_post_template").css('margin-top'));
    	var bottM=parseInt($(my_slider).find(my_slider.vars.slider_class+" .my_post_template").css('margin-bottom'));
    	var hP=parseInt(h)-topM-bottM;
    	my_slider.my_debug("Margin",{top:topM,bottM:bottM,hP:hP});
    	my_slider.vars.heightTmpl=hP;
    	$(my_slider).find(my_slider.vars.slider_class+" .my_post_template").height(hP);
    	if(my_slider.vars.form.postTemplate!="template_11"){
    		var h=0;
    		var tmpH=0;
    		var max=0;
    		var addedH=false;
    		var tmplWidth=parseInt($(my_slider).find("ul li .my_post_row").outerWidth(true));
    		var $tmplF=$(my_slider).find(".my_post_template:eq(0)");
    			$($tmplF).children(".my_post_row").each(function(i,v){
    			if(!$(v).hasClass("my_post_thumb_row")&&$(v).is(":visible")){
    				addedH=false;
    				tmpH=$(v).outerHeight(true);
    				var wEl=$(v).outerWidth(true);
    				if(wEl<tmplWidth){
    					if(max<tmpH){
    						max=tmpH;
    						my_slider.my_debug("Max",max);
    						
    					}
    				}else {
    					
    					if(max!=0){
    						my_slider.my_debug("Add max",max);
    						
    						h+=max;
    						max=0;
    						addedH=true;
    						
    					}
    					my_slider.my_debug("Height pre",h);
    					//if(!addedH)
    					h+=tmpH;
    					my_slider.my_debug("Height after",h);
    					
    				}
    				my_slider.my_debug("Element",{tmplW:tmplWidth,cl:$(this).attr('class'),tmpH:tmpH,h:h,max:max,wEl:wEl});
    				
    				//if(max==0&&!addedH)h+=tmpH;
    				
    			}
    		});
    			my_slider.my_debug("Height",h);
    		var imgH=hP-h;
    		my_slider.my_debug("Img height",imgH);
    		$(".my_post_template").find(".my_post_thumb_row").css('height',imgH+"px");
    	}
    		
    	//$(my_slider).find(".my_timeline_slider_nav").height(h);
    	//var emh_l=$(my_slider).find(".my_timeline_slider_nav i").outerHeight();
    	//var pt_12=(h-emh_1)/2;
    	//$(my_slider).find(".my_timeline_slider_nav i").css('')
    	/*var t1=$(my_slider).find(".my_timeline_header").outerHeight();
    	var t2=$(my_slider).find(".my_timeline_media").outerHeight();
    	var t4=$(my_slider).find(".my_timeline_item").css('padding-top');
    	var t6=$(my_slider).find(".my_timeline_item").css('padding-bottom');
    	
    	var t5=$(my_slider).find(".my_timeline_text").css('margin-top');
    	t4=parseFloat(t4);
    	t5=parseFloat(t5);
    	t6=parseFloat(t6);
    	var t3=h-t1-t2-t4-t5-t6;
    	*/
    	//my_slider.my_debug('Height timeline',{t1:t1,t2:t2,t3:t3,t4:t4,t5:t5,t6:t6});
    	
    	//$(my_slider).find(".my_timeline_text").height(t3);
    	 my_slider.init_scroll();
    };
    my_slider.media_over=function(e){
    	var color=$(this).find('.my_timeline_media_overlay').css('background-color');
    	$(this).find(".my_timeline_media_icon").finish();
    	$(this).find('.my_timeline_media_overlay').finish();
    	if(color.indexOf('rgba')!==0){
    		$(this).find('.my_timeline_media_overlay').animate({opacity:0.4});
    	}else {
    		$(this).find('.my_timeline_media_overlay').animate({opacity:1});
    	}
    		$(this).find(".my_timeline_media_icon").animate({bottom:'50%',opacity:1});
    	
    	//$(this).;
    };
    my_slider.media_out=function(e){
    	//var target=e.target;
    	//my_slider.my_debug('Target')
    	//if($(target).hasClass("my_timeline_media_icon"))return;
    	$(this).find(".my_timeline_media_icon").finish();
    	$(this).find('.my_timeline_media_overlay').finish();
    	$(this).find('.my_timeline_media_overlay').animate({opacity:0});
    	$(this).find(".my_timeline_media_icon").animate({bottom:'0px',opacity:0});
    	
    };
    my_slider.line_nav=function(e){
    	//return;
    	dir='left';
    	if($(this).hasClass('my_timeline_hor_list_nav_right')){
    		dir='right';
    	}
    	var curr=my_slider.vars.current_line;
    	var c=my_slider.vars.hor.length;
    	var w=my_slider.t_width;
    	my_slider.my_debug("Line nav",{dir:dir,curr:curr,c:c,w:w});
    	if(dir=='left'&&curr==1)return;
    	if(dir=='right'&&c==curr)return;
    	var options={duration:my_slider.vars.line_duration,easing:my_slider.vars.line_easing};
    	my_slider.my_debug("Options",options);
    	
    	if(dir=='left'){
    		my_slider.vars.current_line--;
    		$(my_slider).find(".my_timeline_hor_list_ul").animate({'margin-left':'+='+w},options);
    	}else {
    		my_slider.vars.current_line++;
    		$(my_slider).find(".my_timeline_hor_list_ul").animate({'margin-left':'-='+w},options);
    		
    	}
    	
    	
    };
    /**
     * Line go to 
     */
    my_slider.line_go_new=function(i){
    	my_slider.my_debug("line go new I",i);
    	var t=i-1;
    	var postID=$($(".my_timeline_li_class").get(t)).data('post-id');
		my_slider.my_debug("line go new",{postID:postID,i:i,t:t})
    	if(typeof my_slider.vars.sortedA[postID]!="undefined"){
    		var s=my_slider.vars.sortedA[postID];
    		my_slider.my_debug("line go new",{s:s,postID:postID});
    		var lI=0;//my_slider.vars.hor[s];
    		$.each(my_slider.vars.hor,function(i,v){
    			if(v==s){
    				lI=i;
    				my_slider.my_debug("Found i",{i:i,v:v});
    				return false;
    			}
    		});
    		lI+=1;
    		my_slider.my_debug("line go new",{s:s,postID:postID,i:i,lI:lI});
    		
    		my_slider.line_go_to(lI);
    	}
    	
    };
    /**
     * 
     */
    my_slider.go_next=function(){
    	if(my_slider.working)return;
    	my_slider.working=true;
    	var start_item=1;
    	if(typeof my_slider.start_item!='undefined'){
    		start_item=my_slider.start_item;
    	}
    	var total=my_slider.total_items;
    	var diff=1;
    	var diff_m=Math.abs(diff)*my_slider.item_total_width;
    	var speed=my_slider.getSpeed(diff_m);
    	if(start_item<total){
    		
    		
    		var i=start_item+1;
    		my_slider.line_go_new(i);
    		//self.my_debug("Go next post id",postID);
    		
    		my_slider.vars.current_item=i;
    		my_slider.start_item++;
    		
    		my_slider.vars.current_item=my_slider.start_item;
    		my_slider.loadImages();
        	$post=$(my_slider).find(".my_timeline_hor_ul li[data-pos='"+i+"']");
        	//$(".my_slider .my_post_item").removeClass("my_timeline_current");
        	//$post.find(".my_post_item").addClass('my_timeline_current');
        	$(my_slider).find(".my_timeline_hor_ul li").removeClass("my_timeline_current");
        	//$post.find(".my_post_item").addClass('my_timeline_current');
        	//$($post).find(".my_timeline_item").addClass('my_timeline_current');
        	$($post).addClass("my_timeline_current");
    		$(my_slider).find(".my_timeline_hor_ul").animate({'margin-left':"-="+diff_m},speed,my_slider.vars.form.easing,function(){
    			my_slider.working=false;
    			my_slider.adjust_left_right_thumbs();
    			my_slider.vars.marginLeft=parseInt($(this).css('margin-left'));
    			
    		});
    	}else {
    		my_slider.working=false;
    	}
    	
    };
    /**
     * Go prev
     */
    my_slider.go_prev=function(){
    	if(my_slider.working)return;
    	my_slider.working=true;
    	var start_item=1;
    	if(typeof my_slider.start_item!='undefined'){
    		start_item=my_slider.start_item;
    	}
    	var total=my_slider.total_items;
    	var diff=1;
    	var diff_m=Math.abs(diff)*my_slider.item_total_width;
    	var speed=my_slider.getSpeed(diff_m);
    	if(start_item>1){
    		var i=start_item-1;
    		my_slider.vars.current_item=i;
    		my_slider.start_item--;
    		my_slider.vars.current_item=my_slider.start_item;
    		my_slider.line_go_new(i);
    		
    		my_slider.loadImages();
        	$post=$(my_slider).find(".my_timeline_hor_ul li[data-pos='"+i+"']");
        	//$(".my_slider .my_post_item").removeClass("my_timeline_current");
        	//$post.find(".my_post_item").addClass('my_timeline_current');
        	$(my_slider).find(".my_timeline_hor_ul li").removeClass("my_timeline_current");
        	//$post.find(".my_post_item").addClass('my_timeline_current');
        	$($post).addClass('my_timeline_current');
        	
    		$(my_slider).find(".my_timeline_hor_ul").animate({'margin-left':"+="+diff_m},speed,my_slider.vars.form.easing,function(){
    			my_slider.working=false;
    			my_slider.adjust_left_right_thumbs();
    			my_slider.vars.marginLeft=parseInt($(this).css('margin-left'));
    			
    		});
    	}else {
    		my_slider.working=false;
    	}
    	
    };
    /**
     * go to new position of i
     */
    my_slider.go_to=function(i){
    	if(my_slider.working)return;
    	my_slider.working=true;
    	var start_item=my_slider.start_item;
    	my_slider.my_debug("Go to Total width",{start_item:start_item,width:my_slider.item_total_width});
    	var diff=i-start_item;
    	//my_slider.start_item=i;
    	//my_slider.vars.current_item=i;
    	var diff_m=Math.abs(diff)*my_slider.item_total_width;
    	$post=$(my_slider).find(".my_timeline_hor_ul li[data-pos='"+i+"']");
    	$(my_slider).find(".my_timeline_hor_ul > li").removeClass("my_timeline_current");
    	//$post.find(".my_post_item").addClass('my_timeline_current');
    	$($post).addClass('my_timeline_current');
    	my_slider.my_debug("Go to",{i:i,diff:diff,diff_m:diff_m});
    	var speed=my_slider.getSpeed(diff_m);
    	/*if(my_slider.vars.form.full_width==1){
    		var gap=my_slider.vars.form.gap;
    		my_slider.my_debug('Go TO Gap',gap);
    		if(diff>0){
    			diff_m-=parseInt(gap);
    		}else {
    			diff_m+=parseInt(gap);
    		}
    	}*/
    	if(diff<0){
    		$(my_slider).find(".my_timeline_hor_ul").animate({'margin-left':"+="+diff_m},speed,my_slider.vars.form.easing,function(){
    			my_slider.working=false;
    			my_slider.adjust_left_right_thumbs();
    			my_slider.vars.marginLeft=parseInt($(this).css('margin-left'));
    			
    		});
    	}else {
    		$(my_slider).find(".my_timeline_hor_ul").animate({'margin-left':"-="+diff_m},speed,my_slider.vars.form.easing,function(){
    			my_slider.working=false;
    			my_slider.adjust_left_right_thumbs();
    			my_slider.vars.marginLeft=parseInt($(this).css('margin-left'));
    			
    		});
    	}
    	my_slider.line_go_new(i);
		
    	my_slider.loadImages(i);
    	my_slider.start_item=i;
    	my_slider.vars.current_item=i;
    	
    	
    	my_slider.adjust_left_right_thumbs();
    };
    /**
     * images are not loadded
     * load images when is in the view
     */
    my_slider.loadImages=function(){
    	if(typeof my_slider.start_item=="undefined"){
    		my_slider.start_item=1;
    	}
    	
    	var start=my_slider.start_item;
    	var cols=my_slider.layout.cols;
    	var end=cols+start-1;
    	var arr=my_slider.vars.all_posts;
    	my_slider.my_debug("Load images arguments",arguments);
    	
    	if(arguments.length==1){
    		var pass=arguments[0];
    		end=pass;
    	}
    	if(my_slider.vars.form.full_width==1){
    		end++;
    		
    	}
    	if(end>arr.length)end=arr.length;
    	my_slider.my_debug("Load images Start item",{start:start,end:end,cols:cols});
    	var height=my_slider.vars.heightTmpl;//$("").find("li")
    	var heightI=height*settings.thumbHeight;
    	var width=$(".my_post_template").width();
    	my_slider.my_debug("Load images Height",{h:height,heightI:heightI});
    	for(var i=start;i<=end;i++){
    		my_slider.my_debug("Load images I",i);
    		var $li=$(".my_timeline_hor_ul  .my_timeline_li_class[data-pos='"+i+"']");
    		var postID=$($li).attr('data-post-id');
    		my_slider.my_debug("Load images postId",postID);
    		var loadImg=$($li).attr('data-my-load');
    		if(typeof loadImg=='undefined'){
    			$li.attr('data-my-load','1');
    			var thumbs=my_slider.vars.images[postID];
    			my_slider.my_debug("Load images Thumbs",thumbs);
    			var curr="";
    			$.each(thumbs,function(i,v){
    				var url=v[0];
    				var h=v[2];
    				var w=v[1];
    				if(h>heightI){
    					if(w>width){
    						curr=v;
    					}
    				}
    				if(curr==="")curr=v;	
    			});
    			var url=curr[0];
    			my_slider.my_debug("Load images Url",url);
    			$($li).find(".my_post_bg").removeClass("my_no_post_img");
    			$($li).find(".my_post_bg i").css("opacity","0");
    			
    			$($li).find(".my_post_bg").css('background-image','url("'+url+'")');
    			
    		}
    		
    	}
    	
    	
    	
    };
    /**
     * Show tooltip
     */
    my_slider.show_tooltip=function(e){
    	var v=my_slider.getViewportSize();
    	clearTimeout(my_slider.tooltip_timeout);
    	var w=200;
    	var h=100;
    	var top=$(this).offset().top;
    	var left=$(this).offset().left;
    	var sc=$(window).scrollTop();
    	var top_1=top-sc;
    	var top_2=top_1+v.h-h;
    	var diff=10;
    	var diff_1=$(my_slider).find(".my_post_item i").width();
    	diff+=diff_1;
    	$(".my_timeline_line_box").attr('id',my_slider.id+'_line_box');
    	my_slider.my_debug('Tooltip Top Left ',{top:top,left:left});
    	my_slider.my_debug('Tooltip Vars ',{sc:sc,top_1:top_1,top_2:top_2,diff:diff});
    	
    	var html=$(this).find(".my_timeline_tooltip_item").html();
    	$(".my_timeline_line_box_div").html(html);
    	var new_top,new_left,pos_class='my_timeline_left_arrow';
    	$(".my_timeline_line_box").mCustomScrollbar('update');
    	var has_pos=false;
    	if(my_slider.vars.preview){
    		
        	has_pos='bottom';
			new_left=left-w/2+diff_1/2;
			new_top=top+5;
			pos_class='my_timeline_top_arrow';
    	}else {
    	if(top_1>(h+diff)){
    		if(left>(w/2)){
    			has_pos='top';
    			new_left=left-w/2+diff_1/2;
    			new_top=top-diff-h;
    			pos_class='my_timeline_bottom_arrow';
    		}
    	}else if(top_2>(h+diff)){
    		if(left>(w/2)){
    			has_pos='bottom';
    			new_left=left-w/2+diff_1/2;
    			new_top=top+10;
    			pos_class='my_timeline_top_arrow';
    		}
    	}
    	else if(top_1>(h/2)){
    		//right or left pos
    		if(left>(w+diff)){
    			has_pos='left';
    			new_left=left-w-diff+diff_1/2;
    			new_top=top-h/2-diff_1/2;
    			pos_class='my_timeline_right_arrow';
    		}else if(v.w>(left+w)){
    			has_pos='right';
    			new_left=left+diff;
    			new_top=top-h/2-diff_1/2;
    			pos_class='my_timeline_left_arrow';
    		}
    	}
    	}
    	//}
    	my_slider.my_debug('Tooltip Find pos',{has_pos:has_pos,new_top:new_top,new_left:new_left,pos_class:pos_class});
    	if(has_pos===false){
    		my_slider.my_debug('Tooltip Not found pos');
    		has_pos='right';
			new_left=left+diff;
			new_top=top-h/2-diff_1/2;
    	}
    	$(".my_timeline_line_box").css('top',new_top+'px');
    	$(".my_timeline_line_box").css('left',new_left+'px');
    	var c=$(".my_timeline_line_box").data('class');
    	if(c!=''){
    		$(".my_timeline_line_box").removeClass(c);
    	}		
    	$(".my_timeline_line_box").data('class',pos_class);
    	$(".my_timeline_line_box").addClass(pos_class);
    	$(".my_timeline_line_box").fadeIn(function(){
    		//$(my_slider).find(".my_post_item").mouseleave(my_slider.show_tooltip);
    		$(".my_timeline_line_box").mouseover(function(){
    			my_slider.my_debug("Tooltip Mouse over box clear timeout");
    			
    			//$(this).fadeOut();
    			clearTimeout(my_slider.tooltip_timeout);
    		});
    		$(".my_timeline_line_box").mouseenter(function(){
    			my_slider.my_debug("Tooltip Mouse over box clear timeout");
    			
    			//$(this).fadeOut();
    			clearTimeout(my_slider.tooltip_timeout);
    			$(".my_timeline_line_box").unbind('mouseleave');
        		$(".my_timeline_line_box").mouseleave(function(){
        			my_slider.my_debug("Tooltip Mouse leave box set timeout");    			
        			my_slider.tooltip_timeout=setTimeout(function(){
        				$(".my_timeline_line_box").fadeOut();
        			},my_slider.vars.tooltip_hide);
        		});  
    		});
    		  		
    	});
    
    };
    my_slider.line_go_to=function(i){
    	//if(my_slider.working)return;
    	//my_slider.working=true;
    	var start_item=1;
    	if(typeof my_slider.vars.current_line!='undefined'){
    		start_item=my_slider.vars.current_line;
    	}
    	if(start_item==i){
    		my_slider.my_debug("Go to line i same",i);
    		return;
    	}
    	var c=$(my_slider).find(my_slider.vars.slider_timeline_class+" > ul > li").length-1;
    	var diff=start_item-i;
    	var diff_abs=Math.abs(diff);
    	my_slider.my_debug('Go to line',{i:i,c:c,start_item:start_item});
    	var options={duration:my_slider.vars.line_duration,easing:my_slider.vars.line_easing};
    	my_slider.my_debug("Go to line Options",options);
    	var w=diff_abs*my_slider.t_width;
    	if(diff<0){
    		
    		my_slider.vars.current_line=i;
    		$(my_slider).find(".my_timeline_hor_list_ul").animate({'margin-left':'-='+w},options,function(){
    			//my_slider.working=false;
    		});
    	}else {
    		my_slider.vars.current_line=i;
    		$(my_slider).find(".my_timeline_hor_list_ul").animate({'margin-left':'+='+w},options,function(){
    			//my_slider.working=false;
    		});
    		
    	}
    	
    };
    my_slider.autoplay=function(){
    	if(my_slider.autoplay_over)return;
    	if(my_slider.dialog_is_open){
      		my_slider.autoplay_timeout=setTimeout(my_slider.autoplay,my_slider.vars.form.autoplay_timeout);
      		return;
    	}
    	var start_item=1;
    	if(typeof my_slider.start_item!='undefined'){
    		start_item=my_slider.start_item;
    	}
    	var total=my_slider.total_items;
    	var dir='right';
    	if(start_item==total){
    		my_slider.autoplay_dir='left';
    	}else if(start_item==1){
    		my_slider.autoplay_dir='right';
    	}else if(typeof my_slider.autoplay_dir=='undefined'){
    		if(start_item<total){
    			my_slider.autoplay_dir='right';
    		}else {
    			my_slider.autoplay_dir='left';
    		}
    	}
    	dir=my_slider.autoplay_dir;
    	if(dir=='left'){
    		my_slider.go_prev();
    	}else {
    		my_slider.go_next();
    	}
    	setTimeout(function(){
    		my_slider.autoplay_timeout=setTimeout(my_slider.autoplay,my_slider.vars.form.autoplay_timeout);
    	},my_slider.vars.duration);
    };
    /**
     * slider ordinary navigation
     */
    my_slider.slider_nav=function(e){
    	var start_item=my_slider.start_item;
    	my_slider.my_debug("Slider",my_slider);
    	var dir=$(this).data('type');
    	var c=my_slider.total_items;//$(my_slider).find(my_slider.vars.slider_class+" > ul > li").length-1;
    	my_slider.my_debug("Go",{dir:dir,start_item:start_item,c:c});
		
    	
    	if(dir=='left'){
    		if(start_item>1){
    			my_slider.my_debug("Go left",{start_item:start_item});
    			var new_item=start_item-1;
    			my_slider.go_to(new_item);
    		}
    	}else if(dir=='right'){
    		if(start_item<c){
    			my_slider.my_debug("Go right",{start_item:start_item});
    			var new_item=start_item+1;
    			my_slider.go_to(new_item);
    		}
    	}
    	
    };
    my_slider.my_click_nav=function(e){
    	e.preventDefault();
    };
    my_slider.go_to_post=function(e){
    	e.preventDefault();
    	var post_type=$(this).data('type');
    	var post_id=$(this).data('id');
    	var id="my_post_"+post_type+"_"+post_id;
    	my_slider.my_debug("Go to post",{post_type:post_type,post_id:post_id,id:id});
    	//$(my_slider).find(".my_post_item").removeClass()
    	var $post=$("#"+id);
    	//$post=$(my_slider).find(".my_timeline_hor_ul li[data-pos='"+i+"']");
    	//$(".my_slider .my_post_item").removeClass("my_timeline_current");
    	//$post.find(".my_post_item").addClass('my_timeline_current');
    	$(my_slider).find(".my_timeline_li_class").removeClass("my_timeline_current");
    	//$post.find(".my_post_item").addClass('my_timeline_current');
    	$($post).addClass('my_timeline_current');
    	
		var date=$($post).data('date');
		var data_i=$($post).data('i');
		var data_pos=$($post).data('pos');
		my_slider.go_to(data_pos);
		$(my_slider).find(".my_post_item").removeClass('my_timeline_start_item');
		/*
		 * If we have displaayed line and click go to post there is no need
		 * to go to line pos
		var i_pos=$(my_slider).find(".my_timeline_month[data-date='"+date+"']").data('i');
		
		my_slider.my_debug("Go to post Start item",{date:date,data_i:data_i,i_pos:i_pos});
		my_slider.line_go_to(i_pos);
		
		$(my_slider).find(".my_timeline_hor_list_ul li[data-date='"+date+"'] .my_post_item[data-i='"+data_i+"']").addClass("my_timeline_start_item");
		*/
    };
    /**
     * Calculaate animation speed
     */
    my_slider.getSpeed=function(diffMargin){
    	var multiply = diffMargin/my_slider.item_total_width;
    	var speed=parseInt(my_slider.vars.duration);
    	speed*=(1+(1/5)*(multiply-1));
    	my_slider.my_debug("Speed",speed);
    	return speed;
    	
    };
    my_slider.goToMargin=function(i){
    	//if(my_slider.working)return;
    	//my_slider.working=true;
    	var start_item=1;
    	if(typeof my_slider.start_item!='undefined'){
    		start_item=my_slider.start_item;
    	}
    	var diff=i-start_item;
    	var diff_m=Math.abs(diff)*my_slider.item_total_width;
    	var marginLeft=parseInt($(my_slider).find(".my_timeline_hor_ul").css('margin-left'));
    	var endMarginLeft;
    	
    	if(i>0){
    		
    		endMarginLeft=-(i-1)*my_slider.item_total_width;;
    	}else {
    		endMarginLeft=0;
    	}
    	if(my_slider.vars.form.full_width==1){
    		var gap=my_slider.vars.form.gap;
    		my_slider.my_debug('Gap',gap);
    		endMarginLeft+=parseInt(gap);
    		//$(my_slider).find(".my_timeline_hor_ul").css('margin-left',gap+"px");
    	}
    	var diffMargin;
    	diffMargin=Math.abs(endMarginLeft-marginLeft);
    	var multiply = diffMargin/my_slider.item_total_width;
    	var speed=parseInt(my_slider.vars.duration);
    	speed*=(1+(1/5)*(multiply-1));
    	my_slider.my_debug("Got to pos margin",{multiply:multiply,speed:speed,i:i,start_item:start_item,marginLeft:marginLeft,endMarginLeft:endMarginLeft,diffMargin:diffMargin});
    	$post=$(my_slider).find(".my_timeline_hor_ul li[data-pos='"+i+"']");
    	$(my_slider).find(".my_timeline_li_class").removeClass("my_timeline_current");
    	//$post.find(".my_post_item").addClass('my_timeline_current');
    	$($post).addClass('my_timeline_current');
    	if(diff<0){
    		my_slider.working=true;
    		$(my_slider).find(".my_timeline_hor_ul").animate({'margin-left':"+="+diffMargin},speed,my_slider.vars.easing,function(){
    			my_slider.working=false;
    			my_slider.vars.marginLeft=parseInt($(this).css('margin-left'));
    			
    		});
    	}else {
    		my_slider.working=true;
    		$(my_slider).find(".my_timeline_hor_ul").animate({'margin-left':"-="+diffMargin},speed,my_slider.vars.easing,function(){
    			my_slider.working=false;
    			my_slider.vars.marginLeft=parseInt($(this).css('margin-left'));
    	    	
    		});
    		
    	}
    	if(my_slider.vars.has_thumbs){
    		my_slider.my_debug("Go to thumbs",i);
    		my_slider.go_thumbs(i);
    	}
    	my_slider.loadImages(i);
    	my_slider.vars.current_item=i;
    	my_slider.start_item=i;
    	my_slider.adjust_left_right_thumbs();
    	
    };
    my_slider.touchEnd1=function(e){
    	//var newx = e.originalEvent.touches[0].pageX,
		//newy = e.originalEvent.touches[0].pageY;
    	var newx=my_slider.vars.my_newx,
		newy=my_slider.vars.my_newy;
    	my_slider.my_debug("Touch end",{newx:newx,newy:newy});
    	my_slider.vars.myTouchStart=false;
    	var marginLeft=parseInt($(my_slider).find(".my_timeline_hor_ul").css('margin-left'));
		var preMargin=my_slider.vars.marginLeft;
		var cols=my_slider.layout.cols;;
		var w=my_slider.item_total_width;
		var c=Math.floor(Math.abs((marginLeft-preMargin))/w);
		var c1=Math.ceil(Math.abs((marginLeft-preMargin))/w);
		var diff=marginLeft-preMargin;
		my_slider.my_debug("c",{c1:c1,c:c,preMargin:preMargin,marginLeft:marginLeft,w:w});
		var start_item=1;
    	if(typeof my_slider.start_item!='undefined'){
    		start_item=my_slider.start_item;
    	} 
    	//var count=$(my_slider).find(".my_timeline_hor_ul > ul >li").length;
    	var count=my_slider.vars.myTotalItems;
    	var newItem=start_item;
    	var upN=4;
		if(c==0){
			if(Math.abs(diff)>(w/upN)){
				if(diff<0){
					newItem++;
					//my_slider.go_to(newItem);
				}else {
					newItem--;
					//my_slider.go_to(newItem);
					
				}
				my_slider.my_debug("Got to new item",{c:c,w:w,cols:cols,start_item:start_item,newItem:newItem});
				my_slider.goToMargin(newItem);
			}else {
				my_slider.my_debug("Remove margin",{diff:diff,c:c,w:w,cols:cols,start_item:start_item,newItem:newItem});
				
				if(diff<0){
					diff=Math.abs(diff);
					$(my_slider).find(".my_timeline_hor_ul").animate({'margin-left':"+="+diff},my_slider.vars.duration/5,function(){
					});
					
				}else {
					$(my_slider).find(".my_timeline_hor_ul").animate({'margin-left':"-="+diff},my_slider.vars.duration/5,function(){
					});
				}
			}
		}else {
			if(diff<0){
				newItem+=c1;
				if(newItem>=count){
					newItem=count-1;
				}
				
			}else {
				newItem-=c1;
				if(newItem<0){
					newItem=0;
				}
				
			}
			
			my_slider.my_debug("Got to new item",{c:c,w:w,cols:cols,start_item:start_item,newItem:newItem});
			my_slider.goToMargin(newItem);	
		}
		my_slider.vars.myTouchHorizontal=false;
		
		
    };
    /**
     * init images slider cursor
     */
    my_slider.init_images_cursor=function(){
     	//init cursor when we have images
    	if(my_slider.vars.form.sliderCursor=="images"){
    		$(".my_nav_left").click(function(e){
    			my_slider.my_debug("Left click");
    			my_slider.go_prev();
    			
    		});
    		$(".my_nav_right").click(function(e){
    			my_slider.my_debug("Right click");
    			my_slider.go_next();
    			
    		});
    		
    	}
    	if(my_slider.vars.form.sliderCursor=='images'&&!my_slider.vars.hasTouch){
    		my_slider.my_debug("Adjust slider thumbs");
        	//my_slider.adjust_left_right_thumbs();        	
    		
    		my_slider.my_debug('Show nav');
    		my_slider.vars.left_next_offset=$(my_slider).find(".my_testimonial_next_left").offset();
    		my_slider.vars.right_next_offset=$(my_slider).find(".my_testimonial_next_rigth").offset(); 
    		my_slider.vars.show_left_right=false;
    		$(my_slider).mouseover(function(e){
    			var x=e.pageX;
    			var y=e.pageY;
    			
    			my_slider.vars.left_next_offset=$(my_slider).find(".my_testimonial_next_left").offset();
        		my_slider.vars.right_next_offset=$(my_slider).find(".my_testimonial_next_rigth").offset(); 
        		var left_x=my_slider.vars.left_next_offset.left;
        		var left_y=$(my_slider).offset().top;
        		var right_x=my_slider.vars.right_next_offset.left+$(my_slider).find(".my_testimonial_next_rigth").width();
        		var right_y=$(my_slider).offset().top;
        		var regionWidth=my_slider.vars.regionWidth;
        		my_slider.my_debug("Region",regionWidth);
        		if(regionWidth>(my_slider.item_width/2)){
        			regionWidth=my_slider.item_width/2-20;
        			my_slider.my_debug("Region",regionWidth);
        		}
        		var h=$(my_slider).height();
        		var inner=false;
        		my_slider.my_debug("Mouse over",{h:h,x:x,y:y,left_x:left_x,left_y:left_y,right_x:right_x,right_y:right_y});
        		var type;
        		var $this;
        		if((x>=left_x)&&(x<(left_x+regionWidth))){
        			if((y>=left_y)&&(y<=(left_y+h))){
        				inner=true;
        				type='left';
        				my_slider.my_debug("Mouse over left regiont");
        				if(typeof my_slider.my_line_nav_timeout!='undefined'){
            				clearTimeout(my_slider.my_line_nav_timeout);
            			}
        				$this=$(my_slider).find(".my_testimonial_next_left");
        			}
        		}else{
        			if((x>=right_x-regionWidth)&&(x<=(right_x))){
            			if((y>=left_y)&&(y<=(left_y+h))){
            				type='right';
            				inner=true;
            				$this=$(my_slider).find(".my_testimonial_next_rigth");
            				my_slider.my_debug("Mouse over left regiont");
            				if(typeof my_slider.my_line_nav_timeout!='undefined'){
                				clearTimeout(my_slider.my_line_nav_timeout);
                			}
            			}
            		
        		}
        		}
        		
        		if(inner&&!my_slider.vars.show_left_right){
        			my_slider.vars.type_hover=type;
        			my_slider.vars.show_left_right=true;
        			my_slider.my_debug("Mouse over show",type);
        			my_slider.animate_hover($this);		
        		}else if(!inner&&my_slider.vars.show_left_right){
        			my_slider.vars.show_left_right=false;
        			my_slider.my_debug("Mouse out");
        			my_slider.hide_next_prev();
        			//my_slider.vars.my_next_timeout=setTimeout(my_slider.hide_next_prev,my_slider.vars.form.circle_duration);
        	    	
        		}
        		
    		});
    		/**
    		 * Animate line nav items
    		 */
    		if(!my_slider.vars.hasTouch){
    			
        		my_slider.find(".my_timeline_hor_out_div .my_line_nav").css({opacity:0});
        		$(my_slider).mouseenter(function(e){
        			my_slider.autoplay_over=true;
        			my_slider.find(".my_timeline_hor_out_div .my_line_nav").animate({opacity:1},150);
        		});
        		$(my_slider).mouseleave(function(e){
        			my_slider.find(".my_timeline_hor_out_div .my_line_nav").animate({opacity:0},150);
        			my_slider.vars.show_left_right=false;
        			my_slider.hide_next_prev();
        		});
        	}
    	}
    };
    my_slider.initSwipeTouch=function(){
    	if(my_slider.vars.hasTouch){
    		$(document).bind('touchend',my_slider.touchEnd1);
    		$(my_slider).bind('touchstart',function(e){
    			my_slider.vars.xposTouch = e.originalEvent.touches[0].pageX,
    			my_slider.vars.yposTouch = e.originalEvent.touches[0].pageY;
    			my_slider.my_debug("Touch start");
    			my_slider.vars.myTouchStart=true;
    			$(my_slider).unbind('touchmove');
    			$(my_slider).bind('touchmove', function(e){
    				
    				var newx = e.originalEvent.touches[0].pageX,
					newy = e.originalEvent.touches[0].pageY;
    				my_slider.vars.my_newx=newx;
    				my_slider.vars.my_newy=newy;
    				if(!my_slider.vars.myTouchHorizontal) {
    					if(Math.abs(newx-my_slider.vars.xposTouch) > Math.abs(newy-my_slider.vars.yposTouch)) {
    						my_slider.vars.myTouchHorizontal = true;
    					}
    				}
    				else if(my_slider.vars.myTouchHorizontal) {
    					e.preventDefault();
    					var xpos=my_slider.vars.xposTouch;
    					var xmargin = my_slider.vars.marginLeft-xpos + newx;
    					var count=my_slider.vars.myTotalItems;
    					var minMargin=-(count-1)*my_slider.item_width;
    					if(xmargin<minMargin || xmargin>0 ){
    						return;
    					}
    					
    					my_slider.my_debug("Touch move",{x:newx,xpos:xpos,xmargin:xmargin,minMargin:minMargin});
    					
    					$(my_slider).find(".my_timeline_hor_ul").css({marginLeft:xmargin+'px'});	
    				}
    			});
    			
    		});
    		
    	}
    	else if(my_slider.vars.form.swipeOn==1){
    		$(document).mousemove(my_slider.moveMouse);
    		$(my_slider).mousedown(function(e){
    			if($(e.target).hasClass("my_video_tag")||($(e.target).parents(".my_video_tag").length>0)||$(e.target).hasClass("my_post_hearts") || $(e.target).parents('li').hasClass("my_post_hearts") || $(e.target).hasClass("my_nav")|| $(e.target).parents(".my_nav").length>0 || $(e.target).hasClass("my_timeline_slider_nav") || $(e.target).parents(".my_timeline_slider_nav").length>0){
    				my_slider.my_debug("Click on nav ignore click");
    				return;
    			}
    			my_slider.my_debug("Mouse down",e.pageX);
    			my_slider.vars.myMouseDown=true;
    			my_slider.vars.myMouseDownEvent=e;
    			my_slider.myXmargin=0;
    			
    			
    		});
    		$(document).on('mouseup',function(e){
    			if(!my_slider.vars.myMouseDown)return;
    			my_slider.vars.myMouseDown=false;
    			var marginLeft=parseInt($(my_slider).find(".my_timeline_hor_ul").css('margin-left'));
    			var preMargin=my_slider.vars.marginLeft;
    			var cols=my_slider.layout.cols;;
    			var w=my_slider.item_total_width;
    			var c=Math.floor(Math.abs((marginLeft-preMargin))/w);
    			var c1=Math.ceil(Math.abs((marginLeft-preMargin))/w);
    			var diff=marginLeft+Math.abs(preMargin);
    			my_slider.my_debug("c",{c1:c1,c:c,preMargin:preMargin,marginLeft:marginLeft,w:w});
    			var start_item=1;
    	    	if(typeof my_slider.start_item!='undefined'){
    	    		start_item=my_slider.start_item;
    	    	} 
    	    	my_slider.my_debug("Mouse up",{start_item:start_item,diff:diff,c:c,c1:c1,marginLeft:marginLeft,preMargin:preMargin});
    	    	//var count=$(my_slider).find(".my_timeline_hor_ul > ul >li").length;
    	    	var count=my_slider.vars.myTotalItems;
    	    	var newItem=start_item;
    	    	var upN=4;
    			if(c==0){
    				if(Math.abs(diff)>(w/4)){
    					if(diff<0){
    						newItem++;
    						//my_slider.go_to(newItem);
    					}else {
    						newItem--;
    						//my_slider.go_to(newItem);
    						
    					}
    					my_slider.my_debug("Got to new item",{c:c,w:w,cols:cols,start_item:start_item,newItem:newItem});
    					my_slider.goToMargin(newItem);
    				}else {
    					my_slider.my_debug("Remove margin",{diff:diff,c:c,w:w,cols:cols,start_item:start_item,newItem:newItem});
        				
    					if(diff<0){
    						diff=Math.abs(diff);
    						$(my_slider).find(".my_timeline_hor_ul").animate({'margin-left':"+="+diff},my_slider.vars.duration/5,function(){
    						});
    						
    					}else {
    						$(my_slider).find(".my_timeline_hor_ul").animate({'margin-left':"-="+diff},my_slider.vars.duration/5,function(){
    						});
    					}
    				}
    			}else {
    				if(diff<0){
    					newItem+=c1;
    					if(newItem>=count){
    						newItem=count-1;
    					}
    					
    				}else {
    					newItem-=c1;
    					if(newItem<0){
    						newItem=0;
    					}
    					
    				}
    				
    				my_slider.my_debug("Got to new item",{c:c,c1:c1,w:w,cols:cols,start_item:start_item,newItem:newItem});
    				my_slider.goToMargin(newItem);	
    			}
    			
    			
    		});
    	}
    
    };
    /**
     * init slider
     */
    my_slider.init=function(){
    	if(my_slider.hasTouch12){
    	
    	}
    	if(my_slider.vars.form.full_width==1){
    		var gap=my_slider.vars.form.gap;
    		my_slider.my_debug('Gap',gap);
    		$(my_slider).find(".my_timeline_hor_ul").css('margin-left',gap+"px");
    		my_slider.vars.marginLeft=gap;
        	
    	}else my_slider.vars.marginLeft=0;
    	
    	if(my_slider.vars.form.swipeOn==1){
    		my_slider.my_debug("Swipe is on then turn off pretty photo");
    		my_slider.vars.form.prettyPhoto=0;
    	}
    	/*$(".my_post_thumb").mouseenter(function(e){
    		if($(this).find(".my_video_tag").length>0){
    			$(this).find(".my_video_tag").animate({opacity:1});
    		}
    	});
    	$(".my_post_thumb").mouseleave(function(e){
    		my_slider.my_debug("Event",e);
    		if($(this).find(".my_video_tag").length>0){
    			$(this).find(".my_video_tag").animate({opacity:0});
    		}
    	});
    	*/
    	my_slider.start_item=1;
    	my_slider.vars.current_item=1;
    	//if we use images slider cursor init them
    	my_slider.init_images_cursor();
    	//Init open dialog script
    	var openDialogType=my_slider.vars.form.openDialog;
    	my_slider.my_debug("Open dialog type",openDialogType);
    	if(openDialogType=='dialog' || openDialogType=='sliderArea'){
    		$(".my_woo_view_a").click(my_slider.open_dialog_maybe);
    	
    	}
    	var count=$(my_slider).find(".my_timeline_hor_out_div > ul >li").length;
    	my_slider.vars.myTotalItems=count;
    	my_slider.my_debug("Total items",count);
    	//init swipe or touch 
    	my_slider.initSwipeTouch();
    	//Animate margin hover
    	//my_slider.animateMarginHover();
    	//set start item to 1
    	
    	var start=1;
    	$(".my_timeline_hor_ul li[data-pos='"+start+"']").addClass("my_timeline_current");
    	//if we have images slider cursow then init thumbs
    	
    	//init prettyPhoto
    	if(my_slider.vars.form.prettyPhoto==1){
    		$("a[rel^='my_images']").prettyPhoto();
    		var prettyPhotoImages=[];
    		$(my_slider).find(".my_timeline_li_class").each(function(i,v){
    			var postID=$(this).attr('data-post-id');
    			if(typeof my_slider.vars.images[postID]!='undefined'){
    				var thumbs=my_slider.vars.images[postID];
    				var url="";
    				if( typeof thumbs['full']!='undefined'){
    					url=thumbs['full'][0];
    				}
    				my_slider.my_debug("pretty",{postID:postID,url:url,thumbs:thumbs});
    				prettyPhotoImages[prettyPhotoImages.length]=url;
        			
    			}
    		});
    		/*$.each(my_slider.vars.images,function(i,v){
    			var href=v['full'][0];
    			prettyPhotoImages[prettyPhotoImages.length]=href;
    			
    		});*/
    		my_slider.my_debug("Pretty photo images",prettyPhotoImages);
    		my_slider.prettyImages=prettyPhotoImages;
    		$(my_slider).find(".my_post_thumb").click(function(e){
    			if($(e.target).hasClass("my_video_tag")||$(e.target).parents(".my_video_tag").length>0){
    				my_slider.my_debug("Click on video tag");
    				return;
    			}
    			var pos=parseInt($(this).parents(".my_timeline_li_class").data('pos'))-1;
    			my_slider.my_debug("Open pretty photo images",pos);
    			$.prettyPhoto.open(my_slider.prettyImages,[],[],pos);
    		});
    	}
    	//added from testimonials slider
    		//added 
    	var w=$(my_slider).find(my_slider.vars.slider_class).outerWidth();
    	my_slider.width=w;
    	my_slider.total_items=$(my_slider).find(my_slider.vars.slider_class+" > ul > li").length;
    	my_slider.getLayout();
    	my_slider.set_height();
    	my_slider.set_widths();
    	my_slider.loadImages();
    	var arr=[];
    	$(my_slider).find(".my_timeline_hor_list_ul li").each(function(i,v){
    		arr[arr.length]=$(this).data('date');
    	});
    	my_slider.vars.hor=arr;
    	if(arr.length<=1){
    		$(my_slider).find(".my_line_nav").addClass('my_disabled_05');
    	}else {
    		$(my_slider).find(".my_line_nav").click(my_slider.line_nav);
    	}
    	my_slider.my_debug('Line Nav Lines',arr);
    	my_slider.vars.current_line=1;
    	my_slider.vars.current_item=1;
    	//init hover to show slider nav
    	if(my_slider.vars.form.sliderCursor!="images"){
    		$(my_slider).find(".my_timeline_hor_out_div").mouseenter(function(e){
    			$(my_slider).find(".my_timeline_slider_nav").fadeIn();
    		});
    		$(my_slider).find(".my_timeline_hor_out_div").mouseleave(function(e){
    			$(my_slider).find(".my_timeline_slider_nav").fadeOut();
    		});
    		$(my_slider).find(".my_timeline_slider_nav").click(my_slider.slider_nav);
    	}
    	$(my_slider).find(".my_post_item").mouseenter(my_slider.show_tooltip);
    	$(my_slider).find(".my_post_item").mouseleave(function(e){
    		my_slider.my_debug("Mouse leave post item set timeout");
			
    		my_slider.tooltip_timeout=setTimeout(function(){
    				$(".my_timeline_line_box").fadeOut();
    			},(2*my_slider.vars.tooltip_hide));
    	});
    	$(".my_timeline_line_box_div").mCustomScrollbar(
    				{axis:'y',
    				advanced:{
    					updateOnContentResize:true
    					}});
    	if(typeof my_slider.vars.start_item!='undefined'){
    		var $post=$("#"+my_slider.vars.start_item);
    		var date=$post.data('date');
    		var data_i=$post.data('i');
    		var data_pos=$post.data('pos');
    		my_slider.go_to(data_pos);
    		var i_pos=$(my_slider).find(".my_timeline_month[data-date='"+date+"']").data('i');
    		$($post).find(".my_timeline_item").addClass('my_timeline_current');
    		
    		my_slider.my_debug("Start item",{date:date,data_i:data_i,i_pos:i_pos});
    		my_slider.line_go_to(i_pos);
    		
    		$(my_slider).find(".my_timeline_hor_list_ul li[data-date='"+date+"'] .my_post_item[data-i='"+data_i+"']").addClass("my_timeline_start_item");
    		
    	}
    	$(document).on("click",".my_timeline_line_box a",my_slider.go_to_post);
    	$(my_slider).find(".my_timeline_slider_nav").click(my_slider.my_click_nav);
    	//$(my_slider).animate({opacity:1});
    	my_slider.touch();
    	my_slider.my_debug('Vars',my_slider.vars);
    	if(typeof my_slider.vars.form.autoplay!='undefined' &&(!my_slider.vars.mobile) && (my_slider.vars.form.autoplay==1)){
    		my_slider.my_debug('Set autoplay');
    		$(my_slider).mouseover(function(e){
    			my_slider.my_debug("Mouse over");
    			my_slider.autoplay_over=true;
    			clearTimeout(my_slider.autoplay_timeout);
    		});
    		$(my_slider).mouseout(function(e){
    			my_slider.my_debug("Mouse out");
    			my_slider.autoplay_over=false;
    			
    			setTimeout(my_slider.autoplay,my_slider.vars.form.autoplay_timeout);
    		});
    		my_slider.autoplay_timeout=setTimeout(my_slider.autoplay,my_slider.vars.form.autoplay_timeout);
    		
    	}
    };
    
    if(my_slider.vars.has_timeline){
    	my_slider.init_timeline_line();
    	//$("#"+div_id+" ")
    }
    $(window).load(function(){
    	my_slider.my_debug("Load event");
    	my_slider.set_height();
    	my_slider.init_scroll();
    	$(my_slider).animate({opacity:1});
    	$(my_slider).data('myproslider',my_slider);
    });
    my_slider.init();
   
    	
    
    $(window).resize(function(e){
    	my_slider.my_debug("Widnow resize");
    	$(".my_timeline_line_box").fadeOut();
    	var w=$(my_slider).find(my_slider.vars.slider_class).outerWidth();
    	my_slider.width=w;
    	var start_item=1;
    	if(typeof my_slider.start_item!='undefined'){
    		start_item=my_slider.start_item;
    	}
    	
    	 my_slider.getLayout();
    	
    	if(my_slider.vars.has_timeline){
    		var normal_width=my_slider.vars.normal_width;
        	my_slider.init_timeline_line();
        	/*if(my_slider.t_width<normal_width){
        		var r=my_slider.t_width/normal_width;
        		my_slider.my_debug("Change widnow",{r:r,normal:normal_width,t_width:my_slider.t_width});
        		$(my_slider).find(settings.slider_timeline_class+" .my_post_item .fa").css(my_slider.prop,'scale('+r+')');
        		
        	}*/
        	//$("#"+div_id+" ")
        }
    	
    	my_slider.set_height();
    	my_slider.set_widths();
    	var diff=-(start_item-1)*my_slider.item_width;
    	if(my_slider.vars.form.full_width==1){
    		var gap=my_slider.vars.form.gap;
    		my_slider.my_debug('Gap',gap);
    		diff+=parseInt(gap);
    		//$(my_slider).find(".my_timeline_hor_ul").css('margin-left',gap+"px");
    	}
    	$(my_slider).find(".my_timeline_hor_ul").css('margin-left',diff);
    	var start_item=1;
    	if(typeof my_slider.start_item!='undefined'){
    		start_item=my_slider.vars.current_line;
    	}
    	diff=-my_slider.t_width*(start_item-1);
    	
    	$(my_slider).find(".my_timeline_hor_list_ul").css('margin-left',diff);
    		
			
    	
    	if(my_slider.dialog_is_open){
    		var v=my_slider.getViewportSize();
			my_slider.my_debug('Widths',v);
			//var top=$(window).scrollTop();
			my_slider.vars_12=v;
    		var ht=$(".my_timeline_modal").find(".my_timeline_modal_title").outerHeight();
			var ot=v.h;
			var p=ot-ht;
			$(".my_timeline_modal").find(".my_timeline_modal_load").height(p);
			
    	}
    	
    });
  };
  
  $.fn.myproslider=function(options){
	  if (options === undefined) { options = {}; }
	  if(typeof options=='object'){
	  return this.each(function() {
		  	var $this = $(this);   
	        if ($this.data('myproslider') === undefined) {
	          new $.myproslider(this, options);
	        }
	      });
	  }else {
		  //Call slider functions
		  var $slider=$(this).data('myproslider');
		  		
		  		if(typeof $slider[options]=='function'){
		  			if(window.console){
		  				//console.log("Call function",options);
		  				//console.log("Arguments",arguments);
		  				
		  			}
		  			 var args = new Array();
		  		    for (var i = 1; i < arguments.length; i++)
		  		        args.push(arguments[i]);

		  		    //window[func].apply(this, args);
		  			$slider[options].apply(this,args);
		  		}
		  }
		  
	  
  };
})(jQuery);