<?php
if(!defined('ABSPATH'))die('');
//$data['form']['show_list']=true;
$dataTimeline=$this->get_template_var("dataTimeline");
//print_r($dataTimeline);
$all_posts=$data['all_posts'];
$count_sorted=0;

if(!empty($data['sorted'])){
    $count_sorted=count($data['sorted']);
}


$my_added_points=array();
$timeline_id=$id;
//$my_start_12_123=1;
//$layout_class=$data['layout']['layout_class'];
foreach($data['all_posts'] as $key=>$value){
    $post_id=$value->getVar("ID");//['post_id'];
    $type='my_timeline';
    $post_url=$value->getVar('permalink');
    $postDate=$value->getPostMetaByKeyStored('postDate');
    $postDateArr=explode("/",$postDate);
    $year=$postDateArr[0];
    $month=$postDateArr[1];
    $day=$postDateArr[2];
    $html=$classTmpl->renderTemplate($value,$dataTimeline['postTemplate'],$dataTimeline);
    $my_id='my_post_'.$type.'_'.$post_id;
    $dateP=wp_my_pro_timeline_date_pretty($postDate,$strings);//$year.", ".$strings['monthsFull'][$month].' '.$day;
    ?>
			<div data-new-load="0" data-prettyDate="<?php echo esc_attr($dateP);?>" data-pos="<?php echo esc_attr($my_start_12_123);$my_start_12_123++;?>" data-i="<?php echo(esc_attr($year));?>" data-date="<?php echo esc_attr($year.'/'.$month.'/'.$day);?>" data-post-id="<?php echo esc_attr($post_id)?>" data-type="<?php echo esc_attr($type);?>" data-i="<?php echo $my_c_12_123;$my_c_12_123++;?>" class="my_post_class  my_timeline_ver_class my_vertical_timeline" data-open="<?php echo esc_attr($dataTimeline['openDialog']); ?>" data-link="<?php echo esc_attr($post_url); ?>" id="<?php echo $my_id;?>" data-type="<?php echo esc_attr($type);?>">
				<div class="my_post_class_line">
					<div class="my_post_class_line_date">
					<?php echo $dateP;?>
					</div>
				</div>
			<?php echo $html;?>
			</div>
			<?php
}