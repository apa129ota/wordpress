<?php
if(!defined('ABSPATH'))die('');
?>
<h4 class="my_post_h4"><?php echo __("Date","my_support_theme")?></h4>
<?php //echo $postDate;?>
<div class="my_post_date">
	<div class="my_date"><i class="fa fa-calendar"></i>&nbsp;&nbsp;<?php echo $strings['monthsFull'][$month]." , ".$day." ".$year;?></div>
	<?php  if(!empty($includeTime)){?>
	<div class="my_time"><i class="fa fa-clock-o"></i>&nbsp;&nbsp;<?php echo $hour.":".$min.":".$sec;?></div>
	<?php }?>
</div>
<h4 class="my_post_h4"><?php echo __("Post Categories","my_support_theme")?></h4>
<?php 
if(empty($postCats))echo __("None","my_support_theme");
else {
    $str="";
    $iT=0;
    ?>
    <ul>
    <?php 
    foreach($postCats as $key=>$val){
        $link=get_term_link($val,$postCatsKey);
        ?>
        <li><?php /*<a href="<?php echo $link;?>" target="_blank">*/ ?><?php echo $val->name;?></li>
        <?php 
    
    }
    ?>
    </ul>
    <?php 
}
?>

<h4 class="my_post_h4"><?php echo __("Post Terms","my_support_theme")?></h4>
<?php 
if(empty($postTerms))echo __("None","my_support_theme");
else {
    $str="";
    $iT=0;
    ?>
    <ul>
    <?php 
    foreach($postTerms as $key=>$val){
        $link=get_term_link($val,$postTermsKey);
        ?>
        <li><?php /*<a href="<?php echo $link;?>" target="_blank"> */?><?php echo $val->name;?></li>
        <?php 
    }
    ?>
    </ul>
    <?php 
}
?>
<h4 class="my_post_h4"><?php echo __("Post Meta","my_support_theme")?></h4>
<div class="my_post_class my_post_template my_template_1 my_post_clear" data-post-id="<?php echo esc_attr($post_id)?>">
	<div class="myPostMeta my_post_clear">
		<div class="my_post_row my_post_meta_row" data-key="post_meta">
		<div class="my_post_meta">
			<ul>
				<li class="my_post_hearts" data-i="<?php echo esc_attr($heartsCount)?>" data-is="0">
					<i class="fa fa-heart"></i>
					<span class="my_post_templates_hearts"><?php echo wp_my_my_pro_timeline_format_number($heartsCount)?></span>
				</li>
				<li class="my_post_comments" data-i="<?php echo esc_attr($commCount)?>">
					<i class="fa fa-comment"></i>
						<span class="my_post_templates_comments"><?php echo wp_my_my_pro_timeline_format_number($commCount)?></span>
				</li>


				<li class="my_post_share" data-i="">
	<div class="my_post_share_div" style="display:none">
		
	<div class="my_post_share_div_12">
		<ul data-id="">
			<li>
			<a href="<?php echo  esc_attr($facebook_url)?>"><i class="fa fa-facebook fa_facebook_share" data-class="fa_facebook_share"> </i></a>
			</li>
			<li>
			<a href="<?php echo  esc_attr($twitter_url);?>"><i class="fa fa-twitter fa_twitter_share" data-class="fa_twitter_share"></i></a>
			</li>
			<li>
			<a href="<?php echo esc_attr($p)?>"><i class="fa fa-pinterest-p fa_pinterest_share" data-class="fa_pinterest_share"></i></a>
			</li>
			<li>
			<a href="<?php echo esc_attr($g_plus);?>"><i class="fa fa-google-plus fa_google_plus_share" data-class="fa_google_plus_share"></i></a>
			</li>	
		</ul>
		<div class="my_post_share_arrow"></div>
    
	</div>
	</div>
	<i class="fa fa-share"></i>
	<span class="my_post_templates_share_text"><?php echo __("Share","my_support_theme")?></span>
	</li> 
			</ul>
		</div>
	</div>
	<?php if(!empty($enableStars)){?>
	<div class="my_post_row my_meta_stars_row" data-key="meta_stars">
		<div class="my_meta_stars">
			<ul class="my_stars">
			<?php 
			$diffC=floor($stars);
			$diff=($stars-$diffC)*100;
			self::debug("diff",$diff);
			for($i=1;$i<6;$i++){?>
			<li class="<?php if($i<=$stars)echo "my_active";?>">
				<i class="fa fa-star"></i>
			</li>
			<?php }
			if($diff>0){
			 if(!isset($my_added_diff)&&$i>$stars){
			     $my_added_diff=1;
			     ?>
			     <li data-diff="<?php echo esc_attr($diff)?>" class="my_stars_diff my_active" style="">
			     	<i class="fa fa-star"></i>
			     </li>
			     <?php 
			 }
			}
			?>
			
		
			</ul>

		</div>
	</div>
	<?php }?>
	</div>
</div>
<?php 
if(!empty($videoHtml)){
    ?>
    <h4 class="my_post_h4"><?php echo __("Video","my_support_theme")?></h4>
    <div class="my_video_div">
    <?php echo $videoHtml;?>
    </div>
    <?php 

}
?>