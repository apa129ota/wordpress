<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_dialog_stars" data-post-id="">
	<div class="my_header_dialog">
		<h4 class="my_no_margin"><?php  echo __("Post comments","my_support_theme")?></h4>
			<div class="my_timeline_modal_close_1">
				<i class="fa fa-close"></i>
			</div>
	</div>
	<div class="my_dialog_form my_shortcode_content">
		<?php 
		$myDo=true;
		if(!is_user_logged_in()&&empty($front_submit_not_logged)){
		    $myDo=false;
		}
		if(!$myDo){
		    ?>
		    <div class="myError"><i class="fa fa-exclamation-circle"></i><?php echo __("You have to login to post comments !","my_support_theme");?></div>
		    <?php 
		}else {
		?>
		<?php if(!empty($useRecaptcha)){?>
		<div id="my_recaptcha" class="g-recaptcha"
          data-sitekey="<?php echo $sitePub;?>"
          data-callback=""
          data-size="invisible"
          
          >
    	</div>
		<?php }?>
		<div class="my_stars_div_1">
		<div class="my_post_row my_meta_stars_row" data-key="meta_stars">
		<div class="myFormLabel">
			<span><?php echo __("Stars","my_support_theme")?></span>
		</div>
		<div class="my_meta_stars">
			<ul class="my_stars">
			<?php 
			$stars=5;
			for($i=1;$i<6;$i++){?>
			<li data-i="<?php echo $i;?>" class="<?php if($i<=$stars)echo "my_active";?>">
				<i class="fa fa-star"></i>
			</li>
			<?php }
			?>
			
		
			</ul>
			</div>
			</div>
		</div>
		<div class="myFormLabel">
			<span><?php echo __("Comment","my_support_theme")?></span>
		</div>
		
		<div class="my_form_text">
			<textarea name="myComm" id="myCommId"></textarea>
		</div>
		<?php if(!empty($limitComment)){
		    ?>
		<div class="myLimitCharsDiv">    
		 <?php 
		 // $limitComment=10;
		    ?>
		<span><?php echo __("Characters number","my_support_theme")?></span>:<span data-limit="<?php echo $limitComment;?>" class="myTotalChars myLimitComment">0</span>
		</div>
		<div class="myFormLabel myFormItalic">
			<?php echo __("Maximum length of the comment is : ","my_support_theme").$limitComment.__(" characters !","my_support_theme");?> 
		</div>
		<?php }?>
		<div class="my_add_button_12">
			<input type="button" value="<?php echo __("Add comment","my_support_theme");?>" id="myCommentsFormSubmit"/>
		</div>
		<?php }?>
		</div>
	</div>
