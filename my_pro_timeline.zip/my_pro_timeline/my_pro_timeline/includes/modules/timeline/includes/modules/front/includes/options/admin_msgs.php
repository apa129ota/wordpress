<?php
if(!defined('ABSPATH'))die('');
$msgs=array(
    'ajaxError'=>__("Network Error","my_support_theme"),
    'likePost'=>__("Like Post","my_support_theme"),
    'postComm'=>__("Saving comment","my_support_theme"),
    'emptyText'=>__("Comment is empty","my_support_theme"),
    'loadingComm'=>__("Loading comments","my_support_theme"),
);
return $msgs;