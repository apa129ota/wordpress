<?php
if(!defined('ABSPATH'))die('');
//$data['form']['show_list']=true;
$dataTimeline=$this->get_template_var("dataTimeline");
//print_r($dataTimeline);
$all_posts=$data['all_posts'];
$count_sorted=0;

if(!empty($data['sorted'])){
	$count_sorted=count($data['sorted']);
}


$my_added_points=array();
$timeline_id=$id;
?>

<div class="my_timiline_hor_div my_timeline_object" data-open="<?php echo esc_attr($dataTimeline['openDialog']);?>" data-id="<?php echo esc_attr($id);?>" data-type="horizontal" id="my_timeline_<?php echo esc_attr($id);?>">
	<?php if(!empty($data['form']['show_line'])){?>
	<div class="my_timeline_hor_list">
		<div class="my_line_nav my_timeline_hor_list_nav_right">
	<i class="fa fa-chevron-right"></i>
	</div>
	
	<div class="my_line_nav my_timeline_hor_list_nav_left">
	<i class="fa fa-chevron-left"></i>
	</div>
	
		<ul class="my_timeline_hor_list_ul" style="width:<?php $c=$count_sorted*100;echo $c.'%'?>">
		<?php 
			if(!empty($data['sorted'])){
				$c12=1;
				foreach($data['sorted'] as $key=>$val){
						//$stamp=$val['stamp'];
						$arrStr=explode("/",$key);
				        $year=$arrStr[0];
				        $month=$arrStr[1];
				        $date_str=wp_my_pro_timeline_date_line($year,$month,$strings,$data['dateLong']);
						//$date_str=$key;//$arrStr[0].'/'.$arrStr[1];////date('F Y',$stamp);
						$posts=$val;//$val['posts'];
						//print_r($posts);
						//$month=$arrStr[1];
						//$year=$arrStr[0];
						$c_days=cal_days_in_month(CAL_GREGORIAN,$month,$year);
						$c_item=100/$c_days;
						//echo $c_item;
						?>
					<li class="my_timeline_month" data-i="<?php echo $c12;$c12++;?>" style="" data-date="<?php echo esc_attr($key)?>" data-stamp="<?php echo $stamp;?>">
						<span class="my_timeline_hor_list_text"><?php echo $date_str;?></span>
						<div class="my_timeline_hor_list_line">
						<?php if(!empty($posts)){?>
						<?php foreach($posts as $key1=>$val1){
						$index=$key1;//$val1['index'];key is podt id
						$type='my_timeline';//$val1['type'];
						$post_all=$all_posts[$index];
						$postDate=$post_all->getPostMetaByKeyStored('postDate');
						$str=$postDate;
						$postDateArr=explode("/",$str);
						if(count($postDateArr)==3){
						  $i=(int)$postDateArr[2];
						}else $i=1;
						$c=count($data['sortedD'][$str]);
						$pos=($c_item)*($i-1);
						
							?>
						<div style="left:<?php echo $pos.'%';?>" class="my_post_item" data-date="<?php echo esc_attr($key);?>" data-i="<?php echo esc_attr($key1)?>" data-c="<?php echo esc_attr($c);?>">
						<div class="my_post_item_inner">
						<i class="fa fa-circle"></i><?php /*<br/>*/ ?>
						<span><?php echo $i;?></span>
							<div class="my_timeline_tooltip">
								<div class="my_timeline_tooltip_inner">
									
									
									<div class="my_timeline_tooltip_item">
									<?php foreach($data['sortedD'][$str] as $key2=>$val2){?>
									<?php
									//print_r($val2);
										$post_type='my_timeline';//$val2['type']; 
										$post_index=$key2;//$val2['index'];
										$post=$all_posts[$post_index];
										$post_title=$post->getPostTitle();
										
									?>
									<a href="#javascript" title="<?php echo __("Go to this Post","my_related_posts_domain")?>" data-id="<?php echo esc_attr($post->getVar('ID'));?>" data-type="<?php echo esc_attr($post_type);?>"><span><?php echo $post_title;?></span></a>
									<?php }?>
									
									</div>
									
								</div>
							</div>
							</div>
						</div>
						
						
						<?php
					} 
					}?>
						</div>
					</li>
					<?php 
				}
			}
		?>
		</ul>
		</div>
	<?php 
	}
	$layout_cols=$data['layout']['cols'];
	$w123=ceil((100/$layout_cols)*(count($all_posts)))+100;
	$my_c_12_123=1;
	?>
	<div class="my_timeline_hor_out_div">
		<?php if(!empty($data['show_navigation'])){?>
		<?php if($dataTimeline['sliderCursor']=='images'){?>
		<div class="my_line_nav  my_nav my_nav_left my_timeline_slider_nav_1" data-type="left">
			
			<span class="my_nav_arrow"><i class="fa fa-angle-left"></i></span>
			<span class="my_nav_item"></span>
		</div>
		<div class="my_testimonial_next my_testimonial_next_left">
			<div>
				<div>
				</div>
			</div>
		</div>
		<div class="my_testimonial_next my_testimonial_next_rigth">
			<div>
			<div></div>
			</div>
		</div>
		
			<div class="my_line_nav my_nav my_nav_right my_timeline_slider_nav_1" data-type="right">
				<span class="my_nav_arrow"><i class="fa fa-angle-right"></i></span>
				<span class="my_nav_item"></span>
			</div>
		<?php }else if($dataTimeline['sliderCursor']=='default'){?>
		<div class="my_timeline_slider_nav my_timeline_slider_nav_left" data-type="left">
			<i class="fa fa-chevron-left"></i>
		</div>
		<div class="my_timeline_slider_nav my_timeline_slider_nav_right" data-type="right">
			<i class="fa fa-chevron-right"></i>
		</div>
		<?php }
	}
		?>
	<ul class="my_timeline_hor_ul" data-id="<?php echo esc_attr($id)?>" data-c="<?php $c_p_12=count($all_posts);echo $c_p_12;?>" style="width:<?php echo $w123.'%'?>">
		<?php
		$my_start_12_123=1;
		$layout_class=$data['layout']['layout_class']; 
		foreach($data['all_posts'] as $key=>$value){
			$post_id=$value->getVar("ID");//['post_id'];
			$type='my_timeline';
			$post_url=$value->getVar('permalink');
			$postDate=$value->getPostMetaByKeyStored('postDate');
			$postDateArr=explode("/",$postDate);
			$year=$postDateArr[0];
			$month=$postDateArr[1];
			$day=$postDateArr[2];
			$html=$classTmpl->renderTemplate($value,$dataTimeline['postTemplate'],$dataTimeline);
			$my_id='my_post_'.$type.'_'.$post_id;
			?>
			<li data-pos="<?php echo esc_attr($my_start_12_123);$my_start_12_123++;?>" data-i="<?php echo(esc_attr($year));?>" data-date="<?php echo esc_attr($year.'/'.$month);?>" data-post-id="<?php echo esc_attr($post_id)?>" data-type="<?php echo esc_attr($type);?>" data-i="<?php echo $my_c_12_123++;?>" class="my_post_class  my_timeline_li_class my_horizontal_timeline" data-open="<?php echo esc_attr($dataTimeline['openDialog']); ?>" data-link="<?php echo esc_attr($post_url); ?>" id="<?php echo $my_id;?>" data-type="<?php echo esc_attr($type);?>">
			<?php echo $html;?>
			</li>
			<?php 
			
		}
		
		?>
	</ul>
	</div>
</div>
<?php
