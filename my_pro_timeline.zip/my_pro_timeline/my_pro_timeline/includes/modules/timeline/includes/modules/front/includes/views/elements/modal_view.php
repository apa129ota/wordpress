<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_timeline_modal">
	<div class="my_timeline_modal_header">
		<div class="my_timeline_modal_title">
		<span class="my_view_span"><?php echo __("View post","my_related_posts_domain")?></span>
		<span style="display:none" class="my_view_comment"><?php echo __("Comment Post","my_related_posts_domain")?></span>
		<span style="display:none" class="my_share_post"><?php echo __("Share Post","my_related_posts_domain")?></span>
		
		</div>
		<div class="my_timeline_modal_close">
			<i class="fa fa-close"></i>
		</div>
		
	</div>
	<div class="my_timeline_modal_content">
		<div class="my_timeline_modal_loading">
			<span><?php echo __("Loading","my_related_posts_domain").' ... ';?><i class="fa fa-spin fa-spinner"></i></span>
		</div>
		<div class="my_timeline_modal_load">
			<iframe src=""></iframe>
		</div>
	</div>
</div>