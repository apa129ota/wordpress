<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_post_comments_div" data-post-id="<?php echo esc_attr($post_id);?>">
<h4><?php echo __("Post comments","my_support_theme")?> : <?php echo $commCount;?></h4>
<?php if(!empty($comments)){?>
	<?php foreach($comments as $key=>$val){
	    $comm=$val->text;
	    $stars=$val->stars;
	    $date=$val->created;
	    $timestamp=strtotime($date);
	    $date=date('Y,F d H:i:s',$timestamp);
	    $user_id=$val->userID;
	    require $commFile;
	}?>
	
	
</div>
<?php if($pages>1){?>
	<div class="my_add_button_12">
			<input data-pages="<?php echo esc_attr($pages);?>"  data-page="1" type="button" value="<?php echo __("Load More Comments","my_support_theme");?>" class="myLoadMoreComments"/>
		</div>
	<?php }?>
<?php }?>