<?php
if(!defined('ABSPATH'))die('');
?>
<div class="myPreviewTimeline">
	<h2><?php echo __("Preview Timeline","my_support_theme");?></h2>
	<div class="mySelectView">
		<span><?php echo __("Select View","my_support_theme");?></span>
		<select name="mySelectView" id="mySelectViewId">
		<?php if(!empty($data['layouts'])){
		    foreach($data['layouts'] as $k=>$v){
		        ?>
		        <option value="<?php echo $k;?>"><?php echo $v;?></option>
		        <?php 
		    }
		}?>
		</select>
	</div>
	<div class="my_timeline_inner">
	<?php $dataTimeline=$this->get_template_var("dataTimeline");?>
	<?php require $viewFileTimeline;?>
	</div>
</div> 