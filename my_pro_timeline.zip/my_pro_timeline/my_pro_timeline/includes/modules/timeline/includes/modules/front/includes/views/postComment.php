<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_post_comment my_clear_post">
<div class="my_post_user">
<?php if(empty($user_id)){
echo  get_avatar($user_id,64);
}else {?>
<img alt="" src="<?php echo $this->getUrl('images').'gravatar.png';?>"  class="avatar avatar-64 photo" height="64" width="64">
<?php }?>
</div>
<div class="my_post_comm">
<h4><?php echo __("Stars","my_support_theme");?></h4>
	<div class="my_post_row my_meta_stars_row" data-key="meta_stars">
		<div class="my_meta_stars">
			<ul class="my_stars">
			<?php 
			$diffC=floor($stars);
			$diff=($stars-$diffC)*100;
			self::debug("diff",$diff);
			//echo "Stars".$stars;
			for($i=1;$i<6;$i++){?>
			<li class="<?php if($i<=$stars)echo "my_active";?>">
				<i class="fa fa-star"></i>
			</li>
			<?php }
			/*if($diff>0){
			 if(!isset($my_added_diff)&&$i>$stars){
			     $my_added_diff=1;
			     ?>
			     <li data-diff="<?php echo esc_attr($diff)?>" class="my_stars_diff my_active" style="">
			     	<i class="fa fa-star"></i>
			     </li>
			     <?php 
			 }
			}*/
			?>
			
		
			</ul>

		</div>
	</div>	
<h4><?php echo __("Date","my_support_theme");?></h4>
<span class="myCommText"><?php echo $date;?></span>
<p class="myCommText"><?php echo $comm;?></p>	
</div>
</div>