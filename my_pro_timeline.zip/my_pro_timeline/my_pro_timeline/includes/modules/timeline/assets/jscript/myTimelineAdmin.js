/**
 * New builder class for adjusting post template properties
 */
(function($) { 
	myAdminTimeline=function(o){
		var self;
		
		this.pre_options={
				formErrorHtml:'<div class="my_module_error my_margin_top_10"><i class="fa fa-exclamation-circle"></i>{msg}</div>',
					};
		this.debug=true;
		this.myLoadPage="";
		this.myCurrPage="dashboard";
		this.myCurrSubpage="dashboard";
		this.myFormErrorEl="";
		this.working=false;
		this.dialog='';
		this.dialogInfo='';
		this.isSearchPosts="";
		this.searchPostsData="";
		this.searchPage=1;
		this.orderCol="";
		this.orderSel="";
		self=this;
		
		this.init=function(o){
			var gesture = window.navigator && window.navigator.msPointerEnabled && window.MSGesture;
			var  touch = (( "ontouchstart" in window ) || gesture || window.DocumentTouch && document instanceof DocumentTouch);
			self.touch=touch;  
			if(typeof o.my_debug!='undefined'){
				if(!o.my_debug){
					self.debug=false;
				}
			}
			
			var o2={
					modal:true,
					key:'preview',
					debug:self.debug,
					dw:'100%',
					dh:'100%',
					diff:0,
					initScroll:false,
					hideOverflow:true
			};
			self.preview_dialog=new myVusualBuilderDialog(o2);
			self.options=$.extend( self.pre_options,o);
			self.my_debug("Options",self.options);
			self.initActions();
			$("#title_html_form_id").attr('data-required','1');
			$("body").on("my_close_dialog",function(e,obj,key){
				if(key=="preview"){
					self.my_debug("Close windoww");
					self.working=false;
				}
			});
		};
		
		
		this.checkForm=function(form){
			var has=false;
			self.myFormErrorEl="";
			$(form).find(".my_module_error").remove();
			$(form).find("input").each(function(i,v){
				var max=$(v).attr('data-max-length');
				self.my_debug("Max length",max);
				var name=$(v).attr('name');
				var title=$(form).find('label[for="'+name+'"]').text();
				
				if(typeof max!="undefined"){
					var val=$(v).val();
					
					if(val.length>max){
						var msg=self.options.msgs.maxLength;
						msg=msg.replace('{1}',max);
						var msgDiv=self.options.formErrorHtml;
						msgDiv=msgDiv.replace('{msg}',msg);
						$(v).focus();
						self.myFormErrorEl=v;
						$(v).after(msgDiv);
						has=true;
						return false;
					}
				}
			});
			$(form).find("input[data-required='1']").each(function(i,v){
				var name=$(v).attr('name');
				self.my_debug("Check form name",name);
				var title=$(form).find('label[for="'+name+'"]').text();
				var val=$(v).val();
				if(val==""){
					has=true;
					var msg=self.options.msgs.required;
					msg=msg.replace('{1}',title);
					var msgDiv=self.options.formErrorHtml;
					msgDiv=msgDiv.replace('{msg}',msg);
					$(v).focus();
					self.myFormErrorEl=v;
					$(v).keyup(function(e){
						if(self.myFormErrorEl!==""){
							$(self.myFormErrorEl).siblings(".my_module_error").fadeOut(function(){
								$(this).remove();
							})
						}
					})
					$(v).after(msgDiv);
					return false;
				}
			});
			return has;
		},
		this.getFormElementByName=function(name){
			return $(self.myFormObj).find('name="'+name+"'").val();
		};
		
		this.validateForm=function(rules,form){
			var ret=true;
			var myDo=true;
			$.each(rules,function(i,v){
				var name=i;
				if(!myDo)return false;
				$.each(v,function(i1,v1){
					if(!myDo)return false;
					var elType=$(form).find('[name="'+name+'"]').parents("#"+name+"_id_div").attr('data-type');
					var $elDiv=$(form).find('[name="'+name+'"]').parents("#"+name+"_id_div");
					var formValue=$(form).find('[name="'+name+'"]').val();
					var $formEl=$(form).find('[name="'+name+'"]');
					self.my_debug("Check rule",{elType:elType,name:name,v1:v1,formValue:formValue});
					var type=v1.type;
					//var msg=self.options.msgs.required;
					//msg=msg.replace('{1}',title);
					var msgDiv=self.options.formErrorHtml;
					switch(type){
						case 'required':
							if(formValue==""){
								ret=false;
								msgDiv=msgDiv.replace('{msg}',v1.msg);
								$($elDiv).append(msgDiv);
								
							}
						break;
						case 'min_val':
							var min=v1.min;
							self.my_debug("Check min val",{min:min})
							if(formValue<min){
								ret=false;
								msgDiv=msgDiv.replace('{msg}',v1.msg);
								$($elDiv).append(msgDiv);
								
							}
						break;	
						case 'max_val':
							var max=v1.max;
							self.my_debug("Check max value",{max:max});
							if(formValue>max){
								ret=false;
								msgDiv=msgDiv.replace('{msg}',v1.msg);
								$($elDiv).append(msgDiv);
								
							}
						break;	
						case 'pattern':
							var pattern=v1.value;
							 var re= new RegExp(pattern,'ig');
							self.my_debug("Check pattern",{patt:pattern});
							if(!re.test(formValue)){
								ret=false;
								msgDiv=msgDiv.replace('{msg}',v1.msg);
								$($elDiv).append(msgDiv);
								
							}
						break;	
					}
					if(ret===false){
						if(elType=='text'){
							$($formEl).focus();
							//$(form).find('name="'+name+"'").keyup(self)
						}
						myDo=false;
						return false;
					}
				})
			});
			return ret;
		};
			this.initTooltip=function(sel){
			$(sel+" .my_tooltip").tooltip({
				//$(document).tooltip({	
				items:"*",
					
					content:function(){
						var html=$(this).find(".my_content").html();
						if(typeof html=='undefined'){
							html=$(this).attr('data-title');
						}
						//console.log('Html '+html);
						return html;
					}
					});
		};
		/**
		 * Preview timeline
		 */
		this.previewTimeline=function(e){
			$(".my_dialog_preview_loading").show();
			var url=self.options.previewUrl;
			url=url.replace('{id}',self.options.id);
			$(".my_dialog_form iframe").attr('src',url);
			self.preview_dialog.my_open();
			$("iframe").css({opacity:0});
			$(".my_dialog_form iframe").load(function(e){
				$("iframe").animate({opacity:1});
				$(".my_dialog_preview_loading").hide();
			});
			/*
			if(self.options.id==""){
				self.working=false;
				myAdminMsgs_inst.show_remove(self.options.msgs.saveTimeline,1);
				return;
			}*/
		};
		this.isSwipe=function(value){
			if(value==1){
				
				self.my_debug("Swipe is on turn off pretty photo");
				var $scr=$("#prettyPhoto_html_form_id_div").data('my-script');
				var valP=$scr.get_value();
				self.my_debug("Prettyval",valP);
				if(valP==1){
					myAdminMsgs_inst.show_remove(self.options.msgs.swipeIsOnPrettyOff,1);
					$scr.set_value("");
				}//else $scr.set_value("");
			}
		}
		this.showHideLayout=function(){
			var val=self.myIsFullWidth;
			self.my_debug("Show val",val);
			if(val){
				
				$("#gap_html_form_id_div").parents(".my_form_element_outer").fadeIn();
				$("#height_html_form_id_div").parents(".my_form_element_outer").fadeIn();
				
			}else {
				$("#gap_html_form_id_div").parents(".my_form_element_outer").fadeOut();
				$("#height_html_form_id_div").parents(".my_form_element_outer").fadeOut();
				
			}
			$(".my_form_element_outer").each(function(i,v){
				$(v).find(".my_new_module_element").each(function(i1,v1){
					var elId=$(v1).attr("id");
					if(elId.indexOf("layout")===0){
						self.my_debug("Found el",elId);
						if(val){
							$(v).fadeOut();
						}else $(v).fadeIn();
					}
				});
			});
		};
		this.initActions=function(){
			if(self.options.subPage=="horizontal"){
				
				self.myIsSwipe=0;//$("#swipeOn_html_form_id_div").data('my-script').get_value();
				if($("#swipeOn_html_form_id").is(":checked")){
					self.myIsSwipe=1;
				}
				self.myIsFullWidth=0;
				if($("#full_width_html_form_id").is(":checked")){
					self.myIsFullWidth=1;
				}
				self.my_debug("is full width",self.myIsFullWidth);
				self.showHideLayout();
				$("#full_width_html_form_id_div").on('my_change',function(e,obj,value,name){
					self.my_debug("Full Width Value",value);
					self.myIsFullWidth=value;
					if(value){
						$("#postTemplate_html_form_id_div").data('my-script').set_value("template_11");
						
					}
					self.showHideLayout();
				});
				self.my_debug("Is swipe",self.myIsSwipe);
				$("#swipeOn_html_form_id_div").on("my_change",function(e,obj,value,name){
					self.my_debug("Swipe",value);
					self.myIsSwipe=value;
					self.isSwipe(value);
				});
				$("#prettyPhoto_html_form_id_div").on("my_change",function(e,obj,value,name){
					self.my_debug("pretty",value);
					if(self.myIsSwipe){
						//self.isSwipe(self.myIsSwipe);
						myAdminMsgs_inst.show_remove(self.options.msgs.swipeIsOnPrettyOff1,1);
						
						$("#swipeOn_html_form_id_div").data('my-script').set_value('');
					}
				});
			}
			
			
			
			$(document).on('click',".myFormSubmit",function(e){
				e.preventDefault();
				if(self.working){
					self.my_debug("Working return");
					return;
				}
				self.working=true;
				var form=$(this).parents('form');
				
				var n=$(form).data('network');
				var f=$(form).data('key');
				var msg=self.options.msgs.getting_ids;
				if(typeof $(this).data('msg')!='undefined'){
					msg=$(this).data('msg');
				}
				self.my_debug("Network key",{network:n,key:f});
				var err=self.checkForm(form);
				var formData=form.serialize();
				self.my_debug("Form data",formData);
				self.$thisObj=$(this);
				self.myNetwork=n;
				if(err===false){
					
					switch(f){
					
					case 'saveTimeline':
						var err=self.checkForm($("#my_form_html_form"));
						if(err===true){
							self.working=false;
							return;
						}
						self.my_debug("Preview timeline");
						formData1=$("#my_form_html_form").serialize();
						var o1={};
						o1.show_msg=1;
						
						o1.data={
								action:self.options.ajax_action,
								form:formData1,
								id:self.options.id,
								type:self.options.subPage,
								my_action:'saveTimeline',
								formData:formData,
								my_nonce:self.options.my_nonce
						};
						self.my_debug("SaveTimeline",o1);
						o1.error=function(data){
							self.working=false;
							
						};
						o1.success=function(data){
							self.my_debug("Return", data);
							self.working=false;
							if(data.error==0){
								myAdminMsgs_inst.show_remove(data.msg,0);
								if(typeof data.id!="undefined"){
									self.options.id=data.id;
								}
							}else {
								myAdminMsgs_inst.show_remove(data.msg,1);
							}
							
						};
						myGlobalAjaxClass_inst.call_ajax(o1,msg);
					break;	
					case 'previewTimeline':
						self.my_debug("Preview timeline");
						self.previewTimeline(e);
					break;					
					
					}
					
				}
			});
			/*
			$(".my_social_menus a").click(function(e){
				e.preventDefault();
				if(self.myLoadPage!=""){
					myAdminMsgs_inst.show_remove(self.options.msgs.page_is_loading,1);
					return;
				}
				var key=$(this).attr('data-key');
				self.my_debug("Click Menu",key);
				var cssClass=".my_"+key;
				var l=$(cssClass).attr('data-loaded');
				self.myLoadPage=key;
				if(l==0){
					var o1={};
					o1.show_msg=1;
					o1.data={
							network:key,
							action:self.options.ajax_action,
							my_action:' load_network_page',
							
					};
					self.my_debug("Load page",o1);
					o1.error=function(data){
						//myAdminMsgs_inst.show_remove(self.options.msgs.page_is_loading,1);
						self.myLoadPage="";
					};
					o1.success=function(data){
						self.my_debug("Return", data);
						
						if(data.error==0){
							/*if(typeof data.added!='undefined'){
								$(".my_radio_inline").append('<li data-id="'+data.added.id+'" class="my_action" data-key="load_template">'+data.added.title+'</li>');
								$("input[name='id_my_templates']").val(data.added.id);
								$("input[name='title_my_templates']").val(data.title);
							}
							var cssClass=".my_"+key;
							$(cssClass).html(data.html);
							self.myShowPage(self.myLoadPage);
							myAdminMsgs_inst.show_remove(data.msg,0);
						}else {
							myAdminMsgs_inst.show_remove(data.msg,1);
						}
						self.myLoadPage="";
						
					};
					myGlobalAjaxClass_inst.call_ajax(o1,self.options.msgs.saving_shortcode);
					
				}else {
					self.myShowPage(key);
				}
				
			});
			*/
		};
		this.myAction=function(action){
			
		};
		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log("myAdminTimeline\n"+t,o);
				}
			}
		};
		//}
		console.log("options",o);
		this.init(o);
		
	}})(jQuery);		
