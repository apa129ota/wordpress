/**
 * 
 */
(function($) { 
	myAdminPostTimeline=function(o){
		var self;
		
		this.pre_options={
				formErrorHtml:'<div class="my_module_error my_margin_top_10"><i class="fa fa-exclamation-circle"></i>{msg}</div>',
					};
		this.debug=true;
		this.myLoadPage="";
		this.myCurrPage="dashboard";
		this.myCurrSubpage="dashboard";
		this.myFormErrorEl="";
		this.working=false;
		this.videoType='wordpress';
		this.currVideoTab;
		this.showForm={
				wordpress:{
					video_type_timeline_form_id_div:1,
					wordpress_video_timeline_form_id:1,
					video_poster_timeline_form_id_div:1
				},
				youtube:{
					video_type_timeline_form_id_div:1,
					video_poster_timeline_form_id_div:1,
					video_id_timeline_form_id:1
									},
				vimeo:{
					
					video_id_timeline_form_id:1,
					video_type_timeline_form_id_div:1,
					video_poster_timeline_form_id_div:1
					
				},
		}
		self=this;
		
		this.init=function(o){
			var gesture = window.navigator && window.navigator.msPointerEnabled && window.MSGesture;
			var  touch = (( "ontouchstart" in window ) || gesture || window.DocumentTouch && document instanceof DocumentTouch);
			self.touch=touch;  
			if(typeof o.my_debug!='undefined'){
				if(!o.my_debug){
					self.debug=false;
				}
			}
			
			//self.debug=false;
			self.options=$.extend( self.pre_options,o);
			self.my_debug("Options",self.options);
			/*$(".my_cont_inner").mCustomScrollbar({advanced:{
				updateOnContentResize:true
					}});
			*/
			self.initActions();
			if($("#isVideoPost_timeline_form_id").is(":checked")){
				self.my_debug("Viddeo Post");
				$(".my_timeline_video").fadeIn();
				
			}
			$("#includeTime_timeline_form_id_div").on("my_change",function(e,obj,val,v1){
				self.showTime(val);
			});
			if(!$("#includeTime_timeline_form_id").is(":checked")){
				$(".my_form_element_outer[data-id='hour_timeline_form_id']").fadeOut();
				$(".my_form_element_outer[data-id='min_timeline_form_id']").fadeOut();
				$(".my_form_element_outer[data-id='sec_timeline_form_id']").fadeOut();
				
			}
			
		};
		this.showTime=function(val){
			$("#my_video_type_id").val(self.currVideoTab);
			if(val==0){
				self.my_debug("Hide");
				$(".my_form_element_outer[data-id='hour_timeline_form_id']").fadeOut();
				$(".my_form_element_outer[data-id='min_timeline_form_id']").fadeOut();
				$(".my_form_element_outer[data-id='sec_timeline_form_id']").fadeOut();
				
			}else {
				self.my_debug("Show");
				$(".my_form_element_outer[data-id='hour_timeline_form_id']").fadeIn();
				$(".my_form_element_outer[data-id='min_timeline_form_id']").fadeIn();
				$(".my_form_element_outer[data-id='sec_timeline_form_id']").fadeIn();
				
			}
		}
		this.initActions=function(){
			$('body').on('my_init_form',function(e,id){
			//self.videoType=$("#video_type_timeline_form_id_div").data('my-script').get_value();
			//self.my_debug("Video type",self.videoType);
			
			$("#isVideoPost_timeline_form_id_div").on("my_change",function(e,obj,val,v1){
				self.my_debug("val",val);
				if(val==1){
					$(".my_timeline_video").fadeIn();
				}else {
					$(".my_timeline_video").fadeOut();
				}
			});
			self.currVideoTab=$(".my_blue_active a").attr('data-key');
			self.my_debug("Curr video",self.currVideoTab);
			$(document).on('click',".my_tab_a",function(e){
				e.preventDefault();
				if(self.working)return;
				if($(this).parents('li').hasClass("my_blue_active"))return;
				self.working=true;
				var prevTab="my_tab_"+self.currVideoTab;
				$(".my_tab_a[data-key='"+self.currVideoTab+"']").parents('li').removeClass("my_blue_active");
				
				self.currVideoTab=$(this).attr('data-key');
				$("."+prevTab).fadeOut(function(){
					var newTab="my_tab_"+self.currVideoTab;
					$("."+newTab).fadeIn();
					self.working=false;
				});
				self.my_debug("currVideoTab",self.currVideoTab);
				$(this).parents('li').addClass("my_blue_active");
				$("#my_video_type_id").val(self.currVideoTab);
			});
			/*$("#video_type_timeline_form_id_div").on("my_change",function(e,obj,val,v1){
				self.my_debug("val",val);
				self.videoType=val;
				self.myShowForm();
			});*/
			});
			
		};
		this.myShowForm=function(){
			switch(self.videoType){
				case 'wordpress':
					var show=self.showForm.wordpress;
					$(".my_timeline_video .my_form_element_outer").fadeOut();
					$.each(show,function(i,v){
						self.my_debug("Show",i);
						$("."+i).parents(".my_form_element_outer").animate({opacity:1});
					});
				case 'youtube':
					var show=self.showForm.youtube;
					$(".my_timeline_video .my_form_element_outer").fadeOut();
					$.each(show,function(i,v){
						self.my_debug("Show",i);
						$("#"+i).parents(".my_form_element_outer").fadeIn();
					});
				break;
				case 'vimeo':
					var show=self.showForm.vimeo;
					$(".my_timeline_video .my_form_element_outer").fadeOut();
					$.each(show,function(i,v){
						self.my_debug("Show",i);
						$("#"+i).parents(".my_form_element_outer").fadeIn();
					});
				break;
				case 'url':
					$(".my_timeline_video .my_form_element_outer").fadeOut();
					$("#video_type_timeline_form_id_div").fadeIn();
					$(".my_timeline_video input[type='text']").each(function(i,v){
						var id=$(v).attr('id');
						if(id!='video_id_timeline_form_id'){
							self.my_debug("Show",id);
							$(v).parents(".my_form_element_outer").fadeIn();
						}
					});
					
				break;	
			}
			
		};
		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log('myAdminPostTimeline\n'+t,o);
				}
			}
		};
			this.init(o);
			
	};
})(jQuery);		
