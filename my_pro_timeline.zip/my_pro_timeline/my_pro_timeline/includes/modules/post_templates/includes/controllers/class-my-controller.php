<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Post_Templates_Backend_Controller')){
	class Class_My_Post_Templates_Backend_Controller extends Class_My_General_Controller{
		//use MyDebug;
		protected $use_case='my_framework';
		private $module_class;
		function __construct($options=array()){
			/*if(!empty($options['debug'])){
				self::setDebugOptions($this->use_case);
			}*/
		    $options['debug']=1;
			$this->module_class=$options['module_class'];
			unset($options['module_class']);
			self::debug('testimonials_front_controller', $options,false);
			parent::__construct($options);
			//$this->ret['my_debug']=Class_My_Module_Debug::get_debug_source($this->use_case);
		}
		public function route_ajax(){
			parent::route_ajax();
			if($this->debug){
				if(!empty($this->ajax_errors)){
					self::debug("errors", $this->ajax_errors,false);
				}
			}
			if($this->debug){
			    if(class_exists('Class_My_Module_Debug')){
				$this->ret['debug']=Class_My_Module_Debug::get_debug_source($this->use_case);
			    }
			    }
			echo json_encode($this->ret);

			die('');
		}
		protected function my_get_link(){
		    $term=@$_POST['term'];
		    $term=preg_replace('/%/ims', '', $term);
		    self::debug("term", $term);
		    global $wpdb;
		    $wpdb->show_errors();
		    $search_term = $wpdb->esc_like($term);
		    $search_term = "'".$search_term . "%'";
		    $query="SELECT ID,post_title FROM ".$wpdb->posts." WHERE post_title LIKE ".$search_term;
		    $query.=" AND post_status='publish' ";
		    $query.=" limit 0,20 ";
		    $results=$wpdb->get_results($query);
		    $this->ret['data']=array();
		    $this->ret['count']=count($results);
		    if(!empty($results)){
		        foreach($results as $key=>$val){
		                $id=$val->ID;
		                $link=get_permalink($id);
		                $this->ret['data'][]=array('id'=>$val->ID,'label'=>$val->post_title,'value'=>$link,'obj'=>$val);
		            }
		        }
		    
		    
		    self::debug("query", $query);
		}
		protected function load_video(){
		    $type=@$_POST['type'];
		    $this->ret['error']=0;
		    $this->ret['msg']=__("Success","my_support_theme");

		    if(!in_array($type,array('media','url'))){
		        $this->ret['error']=1;
		        $this->ret['msg']=__("Error","my_support_theme");

		    }else{
		        if($type=='media'){
		            $poster=@$_POST['thumb'];
		            if(empty($poster)||!isset($poster))$poster='';
		            $w=@$_POST['width'];
		            $h=@$_POST['height'];
		            $url=@$_POST['url'];
		            $sub=@$_POST['subtype'];
		            $shortcode='[video '.$sub.'="'.$url.'" width="'.$w.'" height="'.$h.'" preload="none"';
		            //$shortcode='[video '.$sub.'="'.$url.'" preload="none"';

		            if(!empty($poster)){
		                $shortcode.=' poster="'.$poster.'"] ';
		            }else $shortcode.=']';
		            $this->ret['shortcode']=$shortcode;
		            ob_start();
		            echo '<div class="my_video_container">';
		            echo do_shortcode($shortcode);
		            echo '</div>';
		            $this->ret['html']=ob_get_clean();

		            //$this->ret['obj']=$obj;



		        }
		    }

		}
		protected function save_template(){
		    $this->module_class->loadFunctions("functions.php");
		    $f12=$this->plugin_object->getDir('modules').'new_form/includes/functions.php';
		    require_once $f12;
		    $form_data=@$_POST['form_data'];
		    $id=@$_POST['id'];
		    $css=@$_POST['css'];
		    $tmpl_data=@$_POST['tmpl_data'];
		    $title=@$_POST['title'];
		    self::debug('form_post', $_POST);
		 //   $form_arr=array();
		   parse_str($tmpl_data  ,$tmpl_arr);
		   self::debug('form_data', $form_data);
		    $this->plugin_object->loadModuleClass('meta');
		    $options=$this->plugin_object->loadOptions('meta_options.php');
		    $class_meta=new Class_My_Module_Meta($options);
		    $meta_key='template_style';
		    $form_all=$this->module_class->loadOptions('templates.php');
		    $elements=$form_all['form'];
		    self::debug("styles_elements", $elements);
		    self::debug("tmpl_data", $tmpl_arr);
		    $tmpl_arr=my_new_form_clean_data($tmpl_arr,$elements,array(
		        'id',
		        'my_nonce'
		    ));
		   self::debug("tmplArr", $tmpl_arr);
		    //wp_my_general_load_module_function(MY_IMAGE_MAPPER_LOCAL_MODULES_DIRNAME,'new_form','functions.php');
		    $this->ret['title']=$title;
		    $nonce=$tmpl_arr['my_nonce'];
		    if(!wp_verify_nonce($nonce,'templates_form')){
		        $this->ret['error']=1;
		        $this->ret['msg']=__("Error","my_support_theme");
		        self::debug("error_nonce", $nonce);
		        $this->ret['error_nonce_str']=$nonce;

		    }
		    else {
		        unset($tmpl_arr['my_nonce']);
		        $save_arr=array(
		            'tmpl_arr'=>$tmpl_arr,
		            'css'=>$css,
		            'rules'=>$form_data
		        );
		        self::debug("saveArr", $save_arr);
		        self::debug("id", $id);

		        if(empty($id)){
		            $cssCache=$this->module_class->generateCssCache($tmpl_arr['template'],$form_data);

		            $id=$class_meta->insert_update_object($title, 'template_style');
		            if(!empty($form_data['sort'])){
		                $class_meta->add_update_object_meta($id, 'sort',$tmpl_arr['template']);
		                
		            }
		            $class_meta->add_update_object_meta($id, 'template',$tmpl_arr['template']);
		            $class_meta->add_update_object_meta($id, 'post_type',$tmpl_arr['post_type']);
		            $class_meta->add_update_object_meta($id, 'tmpl_arr', $tmpl_arr);
		            $class_meta->add_update_object_meta($id, 'css', $css);
		            $class_meta->add_update_object_meta($id, 'rules', $form_data);
		            $class_meta->add_update_object_meta($id, 'cssCache', $cssCache);

		            $this->ret['added']=array(
		                'id'=>$id,
		                'title'=>$title
		            );
		            $this->ret['error']=0;
		            $this->ret['msg']=__("Template style has been saved !","my_support_theme");


		       }else {
		           $is=$class_meta->is_exists_object_by_type($id, 'template_style');
		           if(!empty($is)){
		               $tmpl=$class_meta->get_object_meta($id, 'template');
		               $cssCache=$this->module_class->generateCssCache($tmpl,$form_data);
		               
		               //$cssCache=wp_my_post_templates_gen_css($tmpl_arr['template'],$form_data);$this->ret['msg']=__("Template style has been updated !","my_support_theme");
		               //$class_meta->insert_update_object($title, 'style',$id);
		               $class_meta->add_update_object_meta($id, 'css', $css);
		               $class_meta->add_update_object_meta($id, 'cssCache', $cssCache);

		               $class_meta->add_update_object_meta($id, 'rules', $form_data);
		               $class_meta->add_update_object_meta($id, 'tmpl_arr', $tmpl_arr);
		               $this->ret['error']=0;
		               $this->ret['msg']=__("Template style has been updated !","my_support_theme");

		           }else {
		               $this->ret['error']=1;
		               $this->ret['msg']=__("Error","my_support_theme");
		           }

		      }
		    }



		}
	}
}
