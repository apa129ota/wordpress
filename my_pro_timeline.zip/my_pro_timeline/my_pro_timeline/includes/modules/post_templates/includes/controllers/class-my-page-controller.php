<?php
if(!defined('ABSPATH'))die('');
if(!class_exists("Class_My_Module_Post_Templates_Page_Controller")){
    class Class_My_Module_Post_Templates_Page_Controller extends Class_My_General_Controller{
        function __construct($options=array()){
            $options['isPageContr']=1;
            parent::__construct($options);
            
        }
        function init(){
           
        }
      /* protected function my_pro_grid_new_templates(){
            wp_my_general_load_module_function($this->plugin_object->getDir('modules'),'google_font','functions.php');
            global $wp_my_google_fonts_fonts;
            $wp_my_google_fonts_fonts=wp_my_google_fonts_get_fonts_arr();
            $templates=$this->plugin_object->getModule('post_templates');
            $templates->includeModalVisualBuilder(true,false);
            $html=$templates->builder->getBuilderForm();
            $this->add_template_var('html', $html);
            $file=$this->plugin_object->getDir('views');
            $id=@$_GET['my_id'];
            $file.='pages/template_new_custom.php';
            $this->loadFile($file);
        }*/
        protected function my_pro_timeline_templates(){
            wp_my_general_load_module_function($this->plugin_object->getDir('modules'),'icons','functions/functions.php');
            $from=$this->plugin_object->getDir('modules').'icons/includes/options/';
            $to=$this->plugin_object->getDir('modules').'icons/includes/options/';
            $icons=wp_my_module_icons_get_icons($to);
            $templates=$this->plugin_object->getModule('post_templates');
            $templates->setAdminIncludes();
            $uT=$templates->getUserTemplates();
            $this->add_template_var('userTemplates', $uT);
            $tId=$templates->getTmplId();
            $this->add_template_var('userTemplateID', $tId);
            
            $templates->loadClass('class-post-tags.php');
            wp_my_general_load_module_function($this->plugin_object->getDir('modules'),'google_font','functions.php');
            
            global $wp_my_google_fonts_fonts;
            $wp_my_google_fonts_fonts=wp_my_google_fonts_get_fonts_arr();
            $template_html='';
            $tFile=$templates->getAdminPageTemplate();
            $style_form_html=$templates->getStyleFormHtml();
            $this->add_template_var('style_form_html', $style_form_html);
            $tmpl_html=$templates->tmpl_html;
            ob_start();
            require $tFile;
            $template_html=ob_get_clean();
            $this->add_template_var('template_html', $template_html);
            $this->add_template_var('shortcodes_html', $templates->getAdminPageOptions());
            $id=@$_GET['my_id'];
            $file=$this->plugin_object->getDir('views');
            $file.='pages/templates.php';
            $this->loadFile($file);
            
            
            
        }
    }
}