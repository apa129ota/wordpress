<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Module_Post_Templates_Product_Model')){
	class Class_My_Module_Post_Templates_Product_Model extends Class_My_Module_Post_Templates_Post_Model{
		protected $filter_taxs=array(
			'product_cat','product_tag'
		);
		function __construct($options=array()){
			parent::__construct($options);

		}
		public function init(){
			parent::init();

			$this->getTaxonomies($this->filter_taxs);

			$this->getPostTerms();

		}
	}
}