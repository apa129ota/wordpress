<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Module_Post_Templates_Class_Custom_Templates')){
    class Class_My_Module_Post_Templates_Class_Custom_Templates{
        use MyDebug,MyArrayOptions;
        static public $templates;
        static public $imagesUrl;
        static function renderCustomTemplate($tmpl,$templates){
            ob_start();
           // echo self::$imagesUrl;
            //print_r(self::$templates);
            ?>
            <div class="my_post_template my_<?php echo $tmpl?> my_post_clear" data-key="<?php echo esc_attr($tmpl)?>" <?php echo self::renderTmplData($templates['templates'][$tmpl]['template'])?>>
            <?php 
            if(!empty($templates['templates'][$tmpl]['post_tags'])){
                
                foreach($templates['templates'][$tmpl]['post_tags'] as $key=>$val){
                    self::renderDiv($key, $val);
                    
                }
            }
            ?>
            </div>
            <?php 
            $html=ob_get_clean();
            return $html;
        }
        static function renderTmplData($valR){
            $data="";
            if(!empty($valR["data"])){
                $values=array();
                foreach($valR['data'] as $dataKey=>$dataVal){
                    $values[]='data-'.$dataKey.'="'.esc_attr($dataVal).'" ';
                }
                    $data=implode(" ",$values);
            }
            return $data;
        }
        static function renderAttrs($val){
            $data="";
            $values=array();
            if(!empty($val['attrs'])){
                foreach ($val['attrs'] as $keyA=>$valA){
                    $values[]=$keyA.'="'.esc_attr($valA).'" ';
                }
                $data=implode(" ",$values);
            }
            return $data;
            
        }
        static function renderChildren($k1,$v1){
          
            foreach($v1 as $keyC=>$valC){
                if(!empty($valC['ignore_html'])){
                    
                    return "";
                }
                
                $tag='div';
                if(!empty($valC['tag']))$tag=$valC['tag'];
                $cssClass=self::getCssClass($valC);
                if($tag=='a>i'){
                ?>
                <a href="#">
                <?php
                $isA='a';
                $tag='i';
                }
                
                ?>
            <<?php echo $tag; ?> <?php echo self::renderAttrs($valC)?> class="my_<?php echo $keyC;?>  <?php echo $cssClass?>" <?php echo self::renderTmplData($valC);?>>
            	<?php  echo self::getValue($keyC, $valC);
            	       if(!empty($valC['children'])){
            	           self::renderChildren($keyC, $valC['children']);
				            }
				 ?>
            </<?php echo $tag;?>>
           
            <?php 
            if(isset($isA)){
             ?>
             </<?php echo $isA?>>
             <?php    
            }
        }
        }
        static function getCssClass($val){
            if(!empty($val['class'])){
                $str=implode(" ", $val['class']);
                return $str;
            }
            return "";
        }
        static function renderDiv($key,$val,$child=false){
            $cssClass=self::getCssClass($val);
            $showRow=true;
            if(!empty($val['row']['hide']))$showRow=false;
            if($showRow){
            ?>
            <div class="my_post_row my_<?php echo $key;?>_row" data-key="<?php echo esc_attr($key)?>" <?php if(!empty($val['row']['data']))echo self::renderTmplData($val["row"]);?>>
			<?php }?>		
					<div class="my_<?php echo $key?> <?php echo $cssClass;?>" <?php echo self::renderTmplData($val);?>>
					<?php echo self::getValue($key, $val);?>
					<?php if(!empty($val['children'])){
					   self::renderChildren($key, $val['children']);
					}?>
					</div>
					
			<?php if($showRow){?>		
			</div>		 
			<?php }?>
	
            <?php 
            
            
        }
        static function renderShortcodeActions($key,$val){
            ?>
            <div class="my_template_shortcode_actions" data-key="<?php echo esc_attr($key);?>">
            	<ul>
            		<?php foreach($val as $key=>$val){?>
            		<li>
            		<i class="<?php echo implode(" ",$val['class'])?> my_tooltip">
            			<div class="my_content"><?php echo $val['tooltip'];?></div>
            		</i>
            		</li>
            		<?php }?>
            	</ul>
            </div>
            <?php 
        }
        static function getValue($key,$val){
            if(!empty($val['no_content']))return "";
            switch($key){
                case 'post_thumb':
                    $v=self::getRandomValue(self::$templates['defaults']['thumbs'][$val['source']]);
                    $value=self::$imagesUrl.$val['source']."/".$v;
                    //$html='<img src="'.$value.'"/>';
                    ob_start();
                    ?>
                    <div class="my_post_bg" data-title="<?php echo __("Thumb image","my_support_theme")?>" style="background-image:url('<?php echo $value;?>')">
                    
                    </div>
                    <?php 
                    $html=ob_get_clean();
                    return $html;
                break; 
                case 'name':
                    $val=self::getRandomValue(self::$templates['defaults']['names']);
                    return $val;    
                break;   
                case 'post_content':
                    $val=self::$templates['defaults']['post_content'];
                    return $val;
                break;    
                default:
                    if(!empty($val['html']))return $val['html'];
                    if(!empty(self::$templates['defaults'][$key])){
                        $val=self::getRandomValue(self::$templates['defaults'][$key]);
                        return $val;
                        
                    }
                    else return "";
                break;    
            }
        }
        static function getRandomValue($source){
           $c=count($source)-1;
           $t=rand(0,$c);
           $v=$source[$t];
           return $v;
        }
    }
}
        