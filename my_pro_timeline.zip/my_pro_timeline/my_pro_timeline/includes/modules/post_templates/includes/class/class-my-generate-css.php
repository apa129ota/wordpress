<?php
if (! defined('ABSPATH'))
    die('');
if (! class_exists('Class_My_Module_Post_Templates_Generate_Css')) {

    class Class_My_Module_Post_Templates_Generate_Css
    {
        use MyArrayOptions,MyDebug;

        protected $tmpl;

        protected $template;

        protected $debug = 0;

        protected $use_case = 'generate_css';

        protected $css;

        protected $cssRules = array();

        protected $cssGeneratedRules = array();

        protected $lastCssClass = '';

        protected $jscriptOptions = array();

        protected $isRow = false;

        protected $isRule = false;

        protected $isTemplate = false;

        protected $key = "";

        protected $cssKeys;

        protected $important = true;

        protected $cssRulesGeneratedArray = array();

        protected $cssChildKeys = array();

        protected $cssRulesArray = array();

        protected $cssIds = 1;

        protected $ignoreKeysCss = array(
            "data",
            "template_form",
            "styles",
            "parent_grid",
            "sort",
            "sort_arr",
            "fonts",
            "my_strict",
            "ignore_html",
            "no_content",
            "show_pretty",
            "tag",
            "source",
            "bg",
            "w",
            "h",
            "class"
        );

        protected $cssStyles = array();

        protected $rules = array();

        private $isChildren = false;

        private $d = '';

        protected $currentStyle = '';

        function __construct($options = array())
        {
            $this->setOptions($options);
            if ($this->debug) {
                self::setDebugOptions($this->use_case);
            }
            // self::debug("create_gen_css", $options);
        }

        static function genereateCssEffect($parentClass, $childClass, $effect = array())
        {}

        public function getCssRules($style = "")
        {
            if (empty($style)) {
                return $this->cssRulesArray;
            } else {
                if (! empty($this->cssStyles[$style])) {
                    return $this->cssStyles[$style];
                }
            }
        }

        /**
         * Get all stylse array
         * 
         * @return array|unknown
         */
        public function getAllCssRules()
        {
            $styles['default'] = $this->cssRulesArray;
            foreach ($this->cssStyles as $key => $val) {
                if($key=='default')continue;
                $styles[$key] = $val;
            }
            return $styles;
        }

        public function getCssStyles()
        {
            return $this->cssStyles;
        }

        public function getCss()
        {
            $this->css = '';
            $nRules = array();
            if (! empty($this->cssRules['styles'])) {
                foreach ($this->cssRules['styles'] as $k => $v) {
                    $this->cssStyles[$k] = $v;
                    $this->cssStyles[$k]['css'] = "";
                }
            }
            if (! empty($this->cssRules['template'])) {
                $nRules['template'] = $this->cssRules['template'];
            }
            foreach ($this->cssRules['post_tags'] as $k => $v) {
                $nRules[$k] = $this->cssRules['post_tags'][$k];
            }
            $this->cssRules = $nRules;
            // self::debug("newRules", $nRules);
            $this->generateCss($this->cssRules);
            self::debug("cssGeneratedRules", $this->cssGeneratedRules);
            self::debug("cssRulesArray", $this->cssRulesArray);
            self::debug("css", $this->css);
            // self::debug("d", $this->d,false);
            return $this->css;
        }

        protected function getStylesRules($rules = array(), $key, $c = 1)
        {
            $stylesArr = array();
            $stylesKeys = array_keys($this->cssStyles);
            foreach ($this->cssStyles as $keyS => $valS) {
                if ($keyS == 'default')
                    continue;
                /*
                 * if (! empty($valS[$keyS])) {
                 * $stylesArr[$keyS] = $valS[$keyS];
                 * } else {
                 * $stylesArr[$keyS] = array();
                 * }
                 */
                if (! empty($rules[$keyS])) {
                    $stylesArr[$keyS] = $rules[$keyS];
                } else {
                    $stylesArr[$keyS] = array();
                }
            }
            foreach ($rules as $keySR => $valSR) {
                if (! in_array($keySR, $stylesKeys)) {
                    foreach ($stylesKeys as $k1234 => $v1234) {
                        if (! isset($stylesArr[$v1234][$keySR])) {
                            $stylesArr[$v1234][$keySR] = $valSR;
                        }
                    }
                }
            }
            self::debug("stylesChildArray", $stylesArr);
            foreach ($stylesArr as $keyS => $valS) {
                $this->currentStyle = $keyS;
                $this->generateCssRaw($valS, $key, $c, true);
            }
        }

        protected function generateCssRaw($rules, $keyRT = '', $c = 1, $style = false, $isRow = false)
        {
            if (empty($style))
                $this->getStylesRules($rules, $keyRT, $c);
                
            foreach ($rules as $keyT => $valT) {
                if (array_key_exists($keyT, $this->cssKeys)) {
                    $this->isRule = true;
                    $this->key = $keyT;
                    if ($keyRT == 'template') {
                        if (! isset($class)) {
                            array_push($this->cssChildKeys, array(
                                'isRow' => 0,
                                'isTmpl' => 1,
                                'key' => $keyRT
                            ));
                        }
                        $class = '.my_' . $this->tmpl;
                        
                        $selector = $class;
                    } else {
                        $this->lastCssClass = $this->getElementClass($this->key, $this->isRow, $this->isTemplate);
                        
                        $class = $this->lastCssClass; // $this->getElementClass($this->key, $this->isRow, $this->isTemplate);
                        $selector = $this->getSelectorOfElement();
                    }
                    if ($isRow) {
                        $lastKey = array_pop($this->cssChildKeys);
                        array_push($this->cssChildKeys, $lastKey);
                        $selector = ".my_" . $this->tmpl . " .my_" . $lastKey['key'] . "_row";
                    }
                    $css = $this->genCssRule($selector, $keyT, $valT, $style);
                    if ($style === false) {
                        $valTAdjusted = $valT;
                        if (! isset($this->cssRulesArray[$selector])) {
                            $this->cssRulesArray[$selector] = array();
                        }
                        if (! isset($this->cssRules[$selector][$keyT])) {
                            $this->cssRules[$selector][$keyT] = array();
                        }
                        $this->cssRulesArray[$selector][$keyT]['keys'] = $this->cssChildKeys;
                        $this->cssRulesArray[$selector][$keyT]['value'] = $valTAdjusted;
                        $this->cssRulesArray[$selector][$keyT]['css'] = $css;
                        $this->cssRulesArray[$selector][$keyT]['id'] = $this->getIdSelectorOfElement();
                    } else {
                        $valTAdjusted = $valT;
                        if (! isset($this->cssStyles[$this->currentStyle][$selector])) {
                            $this->cssStyles[$this->currentStyle][$selector] = array();
                        }
                        if (! isset($this->cssStyles[$this->currentStyle][$selector][$keyT])) {
                            $this->cssStyles[$this->currentStyle][$selector][$keyT] = array();
                        }
                        $this->cssStyles[$this->currentStyle][$selector][$keyT]['keys'] = $this->cssChildKeys;
                        $this->cssStyles[$this->currentStyle][$selector][$keyT]['value'] = $valTAdjusted;
                        $this->cssStyles[$this->currentStyle][$selector][$keyT]['css'] = $css;
                        $this->cssStyles[$this->currentStyle][$selector][$keyT]['id'] = $this->getIdSelectorOfElement($this->currentStyle);
                    }
                    
                    $row = 0;
                    if ($this->isRow)
                        $row = 1;
                } else
                    trigger_error(__("Css key dont exists", "my_support_theme") . " = " . $keyT);
            }
            if ($keyRT == 'template') {
                array_pop($this->cssChildKeys);
            }
            // self::debug($key, $val)
        }

        protected function generateCssRules($css_rules, $key, &$c = 1)
        {
            if (! empty($css_rules['row']['css_rules'])) {
                $lastKey = array_pop($this->cssChildKeys);
                $lastKey['isRow'] = 1;
                array_push($lastKey);
                $arr = $css_rules['row']['css_rules'];
                $this->isRow = true;
                $this->isTemplate = false;
                $this->isRule = false;
                $this->generateCssRaw($arr, "", $c, false, true);
                $this->isRow = false;
                // array_pop($this->cssChildKeys);
            }
            if (! empty($css_rules['css_rules'])) {
                $arr = $css_rules['css_rules'];
                $this->isRow = false;
                $this->isTemplate = false;
                $this->isRule = false;
                $this->generateCssRaw($arr);
                $this->isRow = false;
                // array_pop($this->cssChildKeys);
            }
        }

        protected function getSelectorOfElement()
        {
            $class = ".my_" . $this->tmpl;
            foreach ($this->cssChildKeys as $k1 => $v1) {
                // $class.=" ".$this->getElementClass($v1['key'],$v1['isRow'],$v1['isTmpl']);
                extract($v1);
                $class .= " .my_" . $key;
                if ($isRow == 1) {
                    $class .= "_row";
                }
            }
            return $class;
        }

        protected function getIdSelectorOfElement($style = '')
        {
            $id = 'my_css_generated_' . $this->cssIds;
            $this->cssIds ++;
            
            return $id;
        }

        protected function specialCssRaw($css_rules, $key, $c)
        {
            
            // if(in_array($key,array("source","bg","sort","sort_arr","fonts","my_strict","ignore_html","no_content","show_pretty","tag")))return;
            self::debug('specialCssRawTop_' . $key, array(
                'key' => $key,
                'rules' => $css_rules,
                'keys' => $this->cssChildKeys
            ));
            self::debug("generateCss", array(
                'function' => 'specialCssRaw',
                'rules' => $css_rules,
                'key' => $key,
                'c' => $c,
                'keys' => $this->cssChildKeys
            ));
            
            $keyR = $key;
            $valR = $css_rules;
            switch ($keyR) {
                case 'css_rules':
                    if ($this->isChildren) {
                        /*
                         * ob_start();
                         * echo 'Children rules <pre>';
                         * print_r($valR);
                         * echo '</pre><pre>';
                         * print_r($this->cssChildKeys);
                         * echo '</pre>';
                         *
                         * $this->d.=ob_get_clean();
                         */
                    }
                    if (! empty($valR)) {
                        $this->isRow = false;
                        $this->isRule = false;
                        $this->isTemplate = false;
                        // $c ++;
                        // self::debug("hasChildrens", $valR);
                        $this->generateCssRaw($valR, $keyR, $c);
                    }
                    break;
                case "predefined_classes":
                    $stylesArr = array();
                    $stylesKeys = array_keys($this->cssStyles);
                    foreach ($valR as $k1 => $v1) {
                        if (in_array($k1, $stylesKeys)) {
                            $stylesArr[$k1] = $v1;
                            continue;
                        }
                        foreach ($v1 as $k2 => $v2) {
                            $classP = '.my_' . $this->tmpl . ' .' . $k1; // ".my_" . $this->tmpl . " ." . $this->getSelectorOfElement() . " ." . $k1;
                            $selector = $classP;
                            $css1 = $this->genCssRule($classP, $k2, $v2);
                            self::debug("predefined_classes", array(
                                'class' => $classP,
                                'key' => $key,
                                'val' => $val,
                                'css' => $css1
                            ));
                            if (! isset($this->cssRulesArray[$selector])) {
                                $this->cssRulesArray[$selector] = array();
                            }
                            if (! isset($this->cssRules[$selector][$k2])) {
                                $this->cssRules[$selector][$k2] = array();
                            }
                            $this->cssRulesArray[$selector][$k2]['keys'] = $this->cssChildKeys;
                            $this->cssRulesArray[$selector][$k2]['value'] = $v2;
                            $this->cssRulesArray[$selector][$k2]['css'] = $css1;
                            $this->cssRulesArray[$selector][$k2]['id'] = $this->getIdSelectorOfElement();
                            
                            $this->css .= $css1;
                        }
                        if (! empty($stylesArr)) {
                            foreach ($stylesArr as $keyS => $valS) {
                                foreach ($v1 as $k2 => $v2) {
                                    $classP = ".my_" . $this->tmpl . " ." . $k1;
                                    $selector = $classP;
                                    $css1 = $this->genCssRule($classP, $k2, $v2);
                                    $this->cssStyles[$keyS]['css'] . $css1;
                                }
                            }
                        }
                    }
                    break;
                case "added_css":
                    $this->generateAddedCssAll($valR, $keyR);
                    break;
                case "row":
                    if (! empty($valR['css_rules'])) {
                        $this->isRow = true;
                        $this->isRule = false;
                        $this->isTemplate = false;
                        // $c ++;
                        $lasKey = array_pop($this->cssChildKeys);
                        $keyT123 = $lasKey['key'];
                        array_push($this->cssChildKeys, $lasKey);
                        $this->generateCssRaw($valR['css_rules'], $keyT123, $c, false, true);
                        
                        $this->isRow = false;
                    }
                    break;
                case "children":
                    if (! empty($valR)) {
                        $this->isRow = false;
                        $this->isRule = false;
                        $this->isTemplate = false;
                        $c ++;
                        
                        $this->generateCss($valR, $c);
                    }
                    break;
                default:
                        /*self::debug("checkDefault", $keyR);
                        if (array_key_exists($keyR, $this->cssKeys)) {
                            $this->isRule = true;
                            self::debug("foundRule", $keyR);
                        } else {
                            array_push($this->cssChildKeys,array('key'=>$keyR,'isTmpl'=>0,'isRow'=>0));
                            self::debug('specialCssRawTop_'.$key,$this->cssChildKeys,false);
                        } */
                    break;
            }
        }

        protected function generateCss($rules, &$c = 1)
        {
            self::debug("childKeysTop_" . $c, array(
                'keys' => $this->cssChildKeys,
                'rules' => $rules
            ));
            self::debug("generateCss", array(
                'function' => 'generateCss',
                'rules' => $rules,
                'c' => $c,
                'keys' => $this->cssChildKeys
            ));
            
            foreach ($rules as $keyR => $valR) {
                if (in_array($keyR, $this->ignoreKeysCss))
                    continue;
                
                if (! in_array($keyR, array(
                    'template',
                    'css_rules',
                    'row',
                    'added_css',
                    'predefined_classes'
                ))) {
                    $c ++;
                    if (! in_array($keyR, array(
                        'children'
                    ))) {
                        $this->isChildren = false;
                        array_push($this->cssChildKeys, array(
                            'key' => $keyR,
                            'isTmpl' => 0,
                            'isR0w' => 0
                        ));
                    } else {
                        $this->isChildren = true;
                        /*
                         * ob_start();
                         * echo 'Children<pre>';
                         * print_r($valR);
                         * echo '</pre><pre>';
                         * echo 'Child keys';
                         * print_r($this->cssChildKeys);
                         * echo '</pre>';
                         */
                        self::debug("childrenKeys", array(
                            'key' => $keyR,
                            'keys' => $this->cssChildKeys,
                            'value' => $valR
                        ));
                        // $this->d .= ob_get_clean();
                    }
                    $this->generateCss($valR, $c);
                } else {
                    $this->isChildren = false;
                    
                    if ($keyR == 'template') {
                        $this->generateCssRaw($valR['css_rules'], $keyR, $c);
                    } else
                        $this->specialCssRaw($valR, $keyR, $c);
                }
            }
            if ($c > 1) {
                
                array_pop($this->cssChildKeys);
                self::debug("childKeysTop_" . $c, $this->cssChildKeys);
                $c --;
            }
            if (false) {
                if (! empty($rules['template']['css_rules'])) {
                    $this->lastCssClass = ".my_" . $this->tmpl;
                    $this->isTemplate = true;
                    $this->isRow = false;
                    $this->isRule = false;
                    $c ++;
                    $this->generateCssRaw($rules['template']['css_rules'], 'template', $c);
                    $this->isTemplate = false;
                }
                // self::debug("rules_" . $c, $rules);
                foreach ($rules as $keyR1 => $valR1) {
                    $this->generateCssRules($valR1, $keyR1, $c);
                    $this->specialCssRaw($valR1, $keyR1);
                    foreach ($valR1 as $keyR => $valR) {
                        self::debug("preCheckKey", $keyR . "_" . $c . "_" . $this->key);
                        $this->specialCssRaw($valR1, $keyR1);
                    }
                }
                // self::debug("checkKey", $keyR);
                if ($c > 1) {
                    $c --;
                    array_pop($this->cssChildKeys);
                }
            }
        }

        protected function generateAddedCssAll($val, $key)
        {
            foreach ($val['added_css'] as $k1 => $v1) {
                if (strpos($k1, ",") !== false) {
                    $ind = explode(",", $k1);
                    foreach ($ind as $kI => $vI) {
                        if (! empty($val[$kI])) {
                            $value = $val[$kI];
                            $css1 = $this->generateAddedCss($vI, $key, $value);
                            if (class_exists('Class_My_Module_Debug')) {
                                Class_My_Module_Debug::add_section($key . '_added_css_' . $kI, array(
                                    'val' => $value,
                                    'css' => $css1
                                ));
                            }
                        }
                    }
                } else {
                    
                    $ind = $k1;
                    $kI = $k1;
                    if (! empty($val[$kI])) {
                        $value = $val[$kI];
                        $css1 = $this->generateAddedCss($vI, $key, $value);
                        if (class_exists('Class_My_Module_Debug')) {
                            Class_My_Module_Debug::add_section($key . '_added_css_' . $kI, array(
                                'val' => $value,
                                'css' => $css1
                            ));
                        }
                    }
                }
                $this->css .= $css1;
            }
        }

        protected function generateAddedCss($rule, $key, $value)
        {
            $css = $rule;
            $value1 = $value;
            if (strpos($value1, ",") !== false) {
                $ex = explode(",", $value);
                $value1 = wp_my_general_rgba_color($ex[0], $ex[1]);
            }
            if (strpos($rule, '{val}') !== false) {
                $css = str_replace('{val}', $value1, $rule);
            } else {
                $varKey = $key;
                ob_start();
                switch ($varKey) {
                    case 'onHover':
                        echo $rule;
                        break;
                    case 'filter':
                    case 'padding':
                    case 'margin':
                    case 'width':
                    case 'height':
                    case 'float':
                    case 'border_bottom':
                    case 'border_top':
                    case 'border':
                    case 'border_left':
                    case 'border_right':
                        $my_check_border = array(
                            'top',
                            'left',
                            'right',
                            'bottom'
                        );
                        
                        if ($varKey == 'border') {
                            
                            foreach ($my_check_border as $k12 => $v12) {
                                unset($$v12);
                                if (! empty($value[$v12])) {
                                    $$v12 = $value[$v12];
                                }
                            }
                            if (! empty($value['border'])) {
                                
                                foreach ($my_check_border as $k12 => $v12) {
                                    if (! isset($$v12)) {
                                        $$v12 = $value['border'];
                                    }
                                }
                            }
                            foreach ($my_check_border as $k12 => $v12) {
                                if (isset($$v12)) {
                                    // echo $class."{border-".$v12.":".$$v12." !important;}";
                                    echo "{\nborder-" . $v12 . ":" . $$v12 . " !important;}\n";
                                }
                            }
                        } else
                            echo "{\n" . $varKey . ":" . $value . " !important;}\n";
                        
                        break;
                    case 'bg_image':
                        echo "{background-image:" . $value . " !important}\n";
                        break;
                    case 'bg_repeat':
                        echo "{background-repeat:" . $value . " !important}\n";
                        break;
                    case 'bg_color':
                    case 'bg_hover_color':
                        $value1 = $value;
                        if (strpos($value1, ",") !== false) {
                            $ex = explode(",", $value);
                            $value1 = wp_my_general_rgba_color($ex[0], $ex[1]);
                        }
                        if ($varKey == 'bg_hover_color') {
                            echo "{background-color:" . $value1 . " !important;}\n";
                        } else {
                            echo "{background-color:" . $value1 . " !important;}\n";
                        }
                        break;
                    
                    case 'font_size':
                    case 'line_height':
                    case 'font_weight':
                    case 'font_style':
                    case 'color':
                    case 'hover_color':
                    case 'align':
                    case 'text_decoration':
                    case 'letter_spacing':
                        $realKey = $varKey;
                        if ($realKey == 'align') {
                            $realKey = 'text-align';
                        }
                        if ($realKey == 'color' || $realKey == 'hover_color') {
                            if (strpos($value, ",") !== false) {
                                $ex = explode(",", $value);
                                $value = wp_my_general_rgba_color($ex[0], $ex[1]);
                            }
                        }
                        if ($varKey != 'hover_color') {
                            if (strpos($realKey, "_") !== false) {
                                $ex = explode("_", $realKey);
                                $realKey = $ex[0] . '-' . $ex[1];
                            }
                            echo "{\n" . $realKey . ":" . $value . " !important;}\n";
                        } else {
                            $realKey = 'color';
                            
                            echo "{\n" . $realKey . ":" . $value . " !important;}\n";
                        }
                        
                        break;
                }
                $css1 = ob_get_clean();
                $rule = str_replace('{css}', $css1, $rule);
                return $rule;
            }
        }

        protected function genCssRule($class, $key, $val, $style = false)
        {
            if (empty($val))
                return false;
            $css = '';
            ob_start();
            echo "\n" . $class . "";
            if ($key == 'box_shadow' && ! empty($val['type'])) {
                echo ":" . $val['type'];
            }
            if ($key != "bg_hover_color" && $key != "hover_color")
                echo " {";
            switch ($key) {
                case 'vertical_align':
                    echo 'vertical-align:'.$val." !important;\n";
                break;    
                case 'list_style_image':
                    echo 'list-style-image:'.$val." !important;\n";
                break;    
                case 'list_style_position':
                    echo 'list-style-position:'.$val." !importantl;\n";
                break;    
                case 'list_style_type':
                    echo 'list-style-type:'.$val." !important;\n";
                break;    
                case 'bg_hover_color_transition':
                case 'hover_color_transition':
                    $myKeyType = 'color';
                    if ($key == 'bg_hover_color_transition')
                        $myKeyType = 'background-color';
                    $myTypes = array(
                        '',
                        '-webkit-',
                        '-moz-',
                        '-o-'
                    );
                    foreach ($myTypes as $keyMyTypes => $valMyTypes) {
                        echo $valMyTypes;
                        echo "transition:" . $myKeyType . " " . $val . " !important;\n";
                    }
                    break;
                case 'bg_image':
                    echo "background-image:" . $val . " !important";
                    break;
                case 'bg_repeat':
                    echo "background-repeat:" . $val . " !important;\n";
                    break;
                case 'bg_color':
                case 'bg_hover_color':
                    $varKey = $key;
                    $value1 = $val;
                    if (strpos($value1, ",") !== false) {
                        $ex = explode(",", $value1);
                        $value1 = wp_my_general_rgba_color($ex[0], $ex[1]);
                    }
                    if ($varKey == 'bg_hover_color') {
                        echo ":hover{background-color:" . $value1 . " !important;\n";
                    } else {
                        echo "background-color:" . $value1 . " !important;\n";
                    }
                    break;
                case 'list_style':
                case 'font_size':
                case 'line_height':
                case 'font_weight':
                case 'font_style':
                case 'color':
                case 'hover_color':
                case 'align':
                case 'text_decoration':
                case 'letter_spacing':
                case 'word_wrap':
                    $value = $val;
                    $varKey = $key;
                    $realKey = $varKey;
                    if ($realKey == 'align') {
                        $realKey = 'text-align';
                    }
                    if ($realKey == 'color' || $realKey == 'hover_color') {
                        if (strpos($value, ",") !== false) {
                            $ex = explode(",", $value);
                            $value = wp_my_general_rgba_color($ex[0], $ex[1]);
                        }
                    }
                    if ($varKey != 'hover_color') {
                        if (strpos($realKey, "_") !== false) {
                            $ex = explode("_", $realKey);
                            $realKey = $ex[0] . '-' . $ex[1];
                        }
                        
                        echo $realKey . ":" . $value . " !important;\n";
                    } else {
                        $realKey = 'color';
                        echo ":hover{\n" . $realKey . ":" . $value . " !important;";
                    }
                    
                    break;
                
                case "border_radius":
                    //$this->border_radius($val);
                    
                break;
                case 'box_shadow':
                    $this->box_shadow($val);
                    break;
                case 'border_bottom':
                case 'border_top':
                case 'border':
                case 'border_left':
                case 'border_right':
                    $this->border($key, $val);
                    if(!empty($val['border_radius'])){
                        $this->border_radius($val['border_radius']);
                    }
                    break;
                case 'width':
                case 'height':
                case 'overflow':
                case 'float':
                case 'filter':
                case 'display':
                case 'position':
                case 'left':
                case 'right':
                case 'bottom':
                case 'top':
                case 'padding':
                case 'margin':
                    echo $key . ":" . $val . " !important;";
                    break;
                case 'font_family':
                    echo "font-family:" . $val . " , serif !important;\n";
                    break;
            }
            echo "\n}\n";
            $css = ob_get_clean();
            if (! $style)
                $this->css .= $css;
            else
                $this->cssStyles[$this->currentStyle]['css'] .= $css;
            /*
             * if ($this->debug) {
             * $this->cssGeneratedRules[$this->key . "_" . $key] = array(
             * 'class' => $class,
             * 'key' => $this->key,
             * 'isRow' => $this->isRow,
             * 'css' => $css
             * );
             * } else
             * $this->cssGeneratedRules[$this->key . "_" . $key] = $css;
             */
            return $css;
        }

        protected function border_radius($value)
        {
            $tmpCss = '';
            $cssProperties = array(
                '',
                '-webkit-',
                '-moz-'
            );
            $valuesTop = array();
            $valuesBottom=array();
            /*$valueTop=$valueBottom=$value;
            if(strpos("/",$value)!==false){
                $arr=explode("/",$value);
                $va
            }*/
            //echo $value;
            /*
            if (! empty($value['all'])) {
                $values[] = "" . $value['all'] . "!important;\n";
            } else {
                $check = array(
                    "top_left",
                    "top_right",
                    "bottom_right",
                    "bottom_left"
                );
                foreach ($check as $key => $val) {
                    if (isset($value[$val])) {
                        $keyNew12 = str_replace("_", "-", $val);
                        $values[] = "border-" . $keyNew12 . "-radius:" . $val . "!important;\n";
                    }
                }
            }*/
            foreach ($cssProperties as $key => $val) {
                //$cssAll = implode("\n", $values);
                echo $val . "border-radius:" . $value." !important;";
            }
             echo "\n}";
        }

        protected function border($key, $value)
        {
            $my_check_border = array(
                'top',
                'left',
                'right',
                'bottom'
            );
            if (is_array($value)) {
                
                foreach ($my_check_border as $k12 => $v12) {
                    unset($$v12);
                    if (! empty($value[$v12])) {
                        $$v12 = $value[$v12];
                    }
                }
                if (! empty($value['border'])) {
                    
                    foreach ($my_check_border as $k12 => $v12) {
                        if (! isset($$v12)) {
                            $$v12 = $value['border'];
                        }
                    }
                }
                foreach ($my_check_border as $k12 => $v12) {
                    if (isset($$v12)) {
                        echo "border-" . $v12 . ":" . $$v12 . " !important;";
                    }
                }
            } else
                echo $key . ":" . $value . " !important;\n";
        }

        protected function box_shadow($value)
        {
            $tmpCss = '';
            $templateCss = "{h_shadow} {v_shadow} {blur} {spread} {color}";
            $cssProperties = array(
                '',
                '-webkit-',
                '-moz-'
            );
            $checkCss = array(
                'blur',
                'spread',
                'color'
            );
            if (! is_array($value) && $value == 'none') {
                // echo $class." .my_".$key."{";
                foreach ($cssProperties as $k => $v) {
                    $str = 'box-shadow';
                    if (! empty($v))
                        $str = $v . "box-shadow:none !importat;\n";
                }
                // echo "\n}";
            } else {
                $values = array();
                foreach ($value as $key1 => $val) {
                    if (is_array($val)) {
                        if (class_exists('Class_My_Module_Debug')) {
                            Class_My_Module_Debug::add_section('tokenCssArr', $val);
                        }
                        $tokenCss = $templateCss;
                        $v_shadow = $val['v_shadow'];
                        $h_shadow = $val['h_shadow'];
                        $tokenCss = str_replace("{h_shadow}", $h_shadow, $tokenCss);
                        $tokenCss = str_replace("{v_shadow}", $v_shadow, $tokenCss);
                        if (class_exists('Class_My_Module_Debug')) {
                            Class_My_Module_Debug::add_section('tokenCss', $tokenCss);
                        }
                        foreach ($checkCss as $k1 => $v1) {
                            if (isset($val[$v1])) {
                                $vCss = $val[$v1];
                                if ($v1 == 'color') {
                                    if (strpos($vCss, ",") !== false) {
                                        $ex = explode(",", $vCss);
                                        $vCss = wp_my_general_rgba_color($ex[0], $ex[1]);
                                    }
                                }
                                if (class_exists('Class_My_Module_Debug')) {
                                    Class_My_Module_Debug::add_section('tokenCss', $tokenCss);
                                }
                                
                                $tokenCss = str_replace("{" . $v1 . "}", $vCss, $tokenCss);
                            } else
                                $tokenCss = str_replace("{" . $v1 . "}", "", $tokenCss);
                        }
                        $values[] = $tokenCss;
                    }
                }
                $cssAll = implode(",", $values);
                
                foreach ($cssProperties as $key => $val) {
                    echo $val . "box-shadow:" . $cssAll . " !important;\n";
                }
            }
        }

        protected function getElementClass($key, $row = false, $templ = false)
        {
            if ($templ) {
                $class = ".my_" . $this->tmpl;
            } else
                $class = ".my_" . $this->tmpl . " .my_" . $key;
            if ($row)
                $class .= "_row";
            return $class;
        }
    }
}