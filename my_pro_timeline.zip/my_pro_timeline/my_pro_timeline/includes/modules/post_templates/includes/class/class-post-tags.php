<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Module_Post_Templates_Class_Post_Tags')){
	class Class_My_Module_Post_Templates_Class_Post_Tags{
		use MyDebug,MyArrayOptions;
		protected $dir;
		protected $tmpl;
		protected $tmplKey;
		protected $module;
		protected $global_plugin;
		protected $post_id;
		protected $post_model;
		protected $post_meta_tags;
		protected $post_type;
		protected $debug;
		protected $templates;
		protected $tmpl_html;
		protected $use_case='my_framework';
		protected $post_meta_key;
		protected $show;
		protected $show_limit;
		protected $date_format;
		protected $post_thumb;
		protected $is_woo;
		protected $sort;
		protected $module_object;
		protected $use_slider=false;
		protected $slider_tmpl;
		protected $slider_options=array();
		protected $isPostTemplate=true;
		protected $isFront=0;
		protected $slider_options_default=array(
		    
		);
		protected $prefix;
		static $isIncludedCss=false;
		protected $enableStars=true;
		function __construct($options=array()){
		    $option['use_case']='post_tags';
			$this->setOptions($options);
			//$this->debug=0;
			if($this->debug){
				$this->setDebugOptions($this->use_case);
			}
			foreach($this->slider_options_default as $key=>$val){
			    if(!isset($this->slider_options[$key])){
			        $this->slider_options[$key]=$val;
			    }
			}
			if(is_admin()){
			    add_action("admin_head",array(&$this,"head"));
			}else {
			    add_action("wp_head", array(&$this,"head"));
			}
		}
		public function head(){
		    if(!self::$isIncludedCss){
		        self::$isIncludedCss=true;
		        if(!$this->enableStars){
		        ?>
		        	<style type="text/css">
                        .my_meta_stars_row{
                        	display:none;
                        	
                        }
                    </style>
		        <?php
		        }
		    }
		}
		public function init(){
		    
		    if(!empty($this->sort)){
		        $sort=$this->sort;
		        
		        $short_view=$this->module_object->getDir('views').'templates/shortcodes/';
		        $tmpl=$this->tmplKey;
		        $this->tmpl_html=require $short_view.'tmpl.php';
		    }
			else $this->tmpl_html=file_get_contents($this->tmpl);
			//echo $this->tmpl_html;
		}	
		private function formatNumber($num){
		   if($num>1000000000){
		       $s=floor($num/1000000000);
		       $s1=floor(($num-$s*1000000000)/100000000);
		       return $s.'.'.$s1.__("G","my_support_theme");
		   }
		    if($num>1000000){
		        $s=floor($num/1000000);
		        $s1=floor(($num-$s*1000000)/100000);
		        return $s.'.'.$s1.__("M","my_support_theme");
		    }else if($num>1000){
		        $s=floor($num/1000);
		        $s1=floor(($num-$s*1000)/100);
		        return $s.'.'.$s1.__("K","my_support_theme");
		        
		    }else return $num;
		}
		public function render(){
			$is_woo=$this->is_woo;
			preg_match_all('/\{([a-z_]+)\}/ims', $this->tmpl_html,$matches);
			//self::debug("matches",$matches);
			if(!empty($matches[1])){
				foreach($matches[1] as $k=>$v){
					if(strpos($v,'template')===0){
						$tArr=explode("_",$v);
						if(!empty($tArr[1])){
							$tVal=$tArr[1];
							$tagC='post_'.$tVal;
							switch($tVal){
								case 'stars':
								    $tP=$this->post_model->getPostMetaByKeyStored($tVal);//getPostMetaByKey($tVal);
									if($tP===false)$stars=4;
									else $stars=$tP;
								break;	
								case 'hearts':
									$tP=$this->post_model->getPostMetaByKeyStored($tVal);
								//	print_r($tP);
									if($tP!==false)$html=$tP;
									else $html=15;
									$html=$this->formatNumber($html);
									 
								break;
								case 'comments':
								    /*$has_comments=$this->post_model->getVar('has_commnets');
								    if(!$has_comments){
								        $html=0;
								    }
									else $html=$this->post_model->getVar('comment_num');
									*/
								    $html=$this->post_model->getPostMetaByKeyStored('starsCount');
									if($html===false)$html=0;
								    $html=$this->formatNumber($html);
									self::debug("post_tags_commnets", $html);
									//echo 'Commnets '.$html;
								break;			
								case 'share':
									$html='';
								break;	
							}
						$tag=$matches[0][$k];
						$tTmpl=$this->dir.$tVal.'.php';
						if($tVal=='share' || $tVal=='woo' ||$tVal=='wooprice'){
						    if($tVal=='share'){
						        $mediaOld=$this->post_model->getVar('post_thumbs');
						        $media='';
						        if(!empty($mediaOld)){
						            $media=$mediaOld['full'][0];
						        }
						        $post_id=$this->post_model->getVar('post_id');
						        $title=$this->post_model->getVar('post_title');
						        $content=$this->post_model->getContentText();
						        $facebook_url=wp_my_post_templates_share_post($post_id, $title, $content,$media,'facebook');
						        $twitter_url=wp_my_post_templates_share_post($post_id, $title, $content,$media,'twitter');
						        $g_plus=wp_my_post_templates_share_post($post_id, $title, $content,$media,'google');
						        $p=wp_my_post_templates_share_post($post_id, $title, $content,$media,'pinterest');
						    }
							if($tVal=='woo'){
								if(!$this->is_woo){
								    $is_woo=false;
									$fTmpl='';
									$post_id=$this->post_model->getVar('ID');
									$post_url=$this->post_model->getVar('permalink');
									ob_start();
									//echo 'Postr url'.$post_url;
									if(file_exists($tTmpl)){
									    require $tTmpl;
									}
									$fTmpl=ob_get_clean();
								}else {
								    $is_woo=true;
									$post_id=$this->post_model->getVar('ID');
									$post_url=$this->post_model->getVar('permalink');
									ob_start();
									if(file_exists($tTmpl)){
										require $tTmpl;
									}
									$fTmpl=ob_get_clean();
										
								}
							}else if($tVal=='wooprice'){
								if(!$this->is_woo){
									$fTmpl='';
								}else {
									$sale_price=$this->post_model->getVar('sale_price');
									$regular_price=$this->post_model->getVar('regular_price');
									$currency=$this->post_model->getVar('currency_simbol');
									ob_start();
									if(file_exists($tTmpl)){
										require $tTmpl;
									}
									$fTmpl=ob_get_clean();
								}
							}
							else {
							if($tTmpl=="stars.php"&&!$this->enableStars){
							    $fTmpl="";
							}else {
							     ob_start();
							     if(file_exists($tTmpl)){
								    require $tTmpl;
							     }
							     $fTmpl=ob_get_clean();
							}
							}
						}
						else if($tVal=='stars'){
							ob_start();
							$fa_icon=$this->templates[$this->tmplKey]['meta_stars']['i_icon'];
							if(file_exists($tTmpl)){
								require $tTmpl;
							}
							$fTmpl=ob_get_clean();
						}
						else if(file_exists($tTmpl)&&($html!==false)){
							$fTmpl=file_get_contents($tTmpl);
							$fTmpl=preg_replace('/\{'.$tagC.'\}/', $html, $fTmpl);
						}else{
							$fTmpl='';
						}
							//if($html!='')
							$this->tmpl_html=str_replace($tag, $fTmpl, $this->tmpl_html);
						}	
					}else {
					switch($v){
						case 'post_title':
							$html=$this->post_model->getPostVar('post_title');
						break;
						case 'post_date':
                            /*
							$post_date=$this->post_model->getPostVar('post_date');
							$t=strtotime($post_date);
							$date_format=$this->templates[$this->tmplKey]['post_tags']['post_date']['date_format'];
							if(!empty($this->date_format)){
								$date_format=$this->date_format;
							}
							else 
							$html=date('F d,Y',$t);
							*/
							$postDate=$this->post_model->getPostMetaByKeyStored("postDate");
							$arr=explode("/",$postDate);
							if(count($arr)==3){
							    $year=$arr[0];
							    $month=$arr[1];
							    $day=$arr[2];
							}else{
							    $year=date('Y');
							    $mongt=date('m');
							    $day=date('d');
							    $postDate=date('Y/m/d');
							}
							$html=$postDate;
						break;	
						case 'post_id':
						  $html=$this->post_id;
					    break;  
						case 'post_thumb':
						    if($this->use_slider){
						       
						        $my_set_debug=1;
						        ob_start();
						        $arr=$this->templates[$this->tmplKey]['post_tags']['post_thumb'];
						        if(!empty($this->post_thumb)){
						            $arr=$this->post_thumb;
						        }
						        $w=$arr['w'];
						        $h=$arr['h'];
						       
						       
						        $itemsOld=$this->post_model->getGalleryThumbsFront();
						        
						        $items=array();
						        $thumb='';
						        $itemsThumbs=array();
						       // print_r($itemsOld);
						        if(!empty($itemsOld['thumbs'])){
						            foreach($itemsOld['thumbs'] as $itemsK=>$itemsV){
						                $thumb='';
						                foreach($itemsV as $k21=>$v21){
						                    if($v21[1]>$w && $v21[2]>$h){
						                        $thumb=$v21;
						                        break;
						                    }
						                }
						                if(empty($thumb)){
						                    $thumb=$itemsV['full'];
						                }
						                $itemsThumbs[]=$itemsV['thumbnail'];
						                $thumb['my_id']=$itemsV['my_id'];
						                
						                $items[]=$thumb;
						                //return $this->post_thumbs['full'];
						                
						            }
						            //print_r($itemsOld);
						         //   print_r($items);
						            
						            $viewDirTmpl=$this->module_object->getDir('views').'templates/shortcodes/';
						            $template_file=$this->slider_tmpl;
						            if(!file_exists($viewDirTmpl.$template_file)){
						                $template_file='slider_1.php';
						            }
						            $id=$this->post_model->getVar('post_id');
						            $settings=$this->slider_options;   
						            require $viewDirTmpl.'slider.php';
						            $html=ob_get_clean();
						            
						        }
						    }else {
						        $my_do_thumb_1234=true;
						        if($this->isFront){
						            $my_do_thumb_1234=false;
						            $thumbs=$this->post_model->getVar("post_thumbs");
						            if(!empty($thumbs['full'])){
						                $myUrl=$thumbs['full'][0];
						            }
						            $isVideoPost=$this->post_model->getPostMetaByKeyStored('isVideoPost');
						            ob_start();
						            ?>
						     <?php /*<a class="" href="<?php echo esc_attr($myUrl);?>" rel="my_images">*/ ?>       
						     <div class="my_post_bg my_no_post_img">
							 	<?php if(!empty($isVideoPost)){?>
							 	<div class="my_video_tag my_tooltip">
							 		<span>
							 		<i class="fa fa-video-camera"></i>&nbsp;&nbsp;<?php echo __("Play Video","my_support_theme");?>
							 		</span>
							 	</div>
							 	<?php }?>
							 	
							 	<i class="fa fa-spin fa-spinner"></i>
							 	
							 </div>
							 <?php /*</a>*/ ?>
							 <?php 
							 $html=ob_get_clean();
						        }
						    if($my_do_thumb_1234){    
							$arr=$this->templates[$this->tmplKey]['post_tags']['post_thumb'];
							if(!empty($this->post_thumb)){
								$arr=$this->post_thumb;
							}
							$w=$arr['w'];
							$h=$arr['h'];
							$bg=$arr['bg'];
							$pretty=$arr['show_pretty'];
							self::debug("thumb_arr", $arr);
							//$thumb=$this->post_model->getThumbWidthHeight($w,$h);
							$thumbs=$this->post_model->getVar('post_thumbs');
							if(!empty($thumbs['full']))$thumb=$thumbs['full'][0];
							$pre_html='';
							if(!empty($thumb)){
								ob_start();
								if(!empty($bg)){?>
									<div class="my_post_bg" style="background-image:url('<?php echo $thumb;?>')">
									
									</div>
									<?php }else {
										?>
									<img class="my_post_img" src="<?php echo $thumb;?>"/>	
									<?php }
									$pre_html=ob_get_clean();
							if($pretty){
								$full=$this->post_model->getFullThumb();
								ob_start();
								?>
								<a rel="my_pretty_photo" href="<?php echo $full;?>">
								<?php echo $pre_html;?>
								</a>
								<?php 
								$html=ob_get_clean();
							}else {
								$html=$pre_html;
							}
							}else {
							 ob_start();
							 ?>
							 <div class="my_post_bg my_no_post_img">
							 	<h4>
							 	<i class="fa fa-image"></i>
							 	<?php echo __("No Image","my_support_theme")?></h4>
							 
							 </div>
							 <?php 
							 $html=ob_get_clean();
							}
						    }
						    }
						break;
						case 'post_content':
							//self::debug("templates", $this->templates);
							$post=$this->post_model->getPost();
						    $excerpt=$post->post_excerpt;//$this->post_model->getVar('post_excerpt');
							if(!empty($excerpt)){
								$post_content=$excerpt;
							}else {
								$post_content=$post->post_content;//$this->post_model->getVar('post_content');
								$post_content=wp_strip_all_tags($post_content);
								$post_content=strip_shortcodes($post_content);
							}
							$show=$this->templates[$this->tmplKey]['post_tags']['post_content']['show'];
							$show_limit=$this->templates[$this->tmplKey]['post_tags']['post_content']['show_limit'];
							if(($this->tmplKey!='template_6')&&($this->tmplKey!='template_8')){
							     $html=$post_content;
						  	     $html=mb_substr($html, 0,50).'..';
							}else $html=$post_content;
							/*if(isset($this->show)){
								$show=$this->show;
							}
							if(isset($this->show_limit)){
								$show_limit=$this->show_limit;
							}*/
							
							if($show=='all'){
								$html=$post_content;
							}else if($show=='limit'){
								switch($show_limit['type']){
									case 'length':
										$l=$show_limit['val'];
										$html=substr($post_content,0,$l).'...';
									break;	
								}
								
							}
							//self::debug("show", $show);
							//self::debug("show_limit", $show_limit);
							//self::debug("html",$html);
						break;		 	
					}
					$tag=$matches[0][$k];
					$this->tmpl_html=str_replace($tag, $html, $this->tmpl_html);
					}
				}
			}
			return $this->tmpl_html;
		
			
			
		}	
	}
}
