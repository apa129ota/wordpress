<?php
if(!defined('ABSPATH'))die('');
function wp_my_post_templates_adjust_array($templates,&$arr){
    foreach($templates as $key=>$val){
        $arr[$key]=$val;
        if(!empty($val['children'])){
            wp_my_post_templates_adjust_array($templates['children'], $arr);
        }
    }
}
/**
 *
 * @param unknown $post_id
 * @param unknown $post_title
 * @param unknown $post_content
 * @param string $image
 * @param string $type
 * @return string
 */
function wp_my_post_templates_share_post($post_id,$post_title,$post_content,$image='',$type='twitter'){
    if(!empty($post_id)){
        $url=get_permalink($post_id);
    }else $url=get_site_url();
    $myPost=get_post($post_id);
    if(empty($post_title)){
       $post_title=$myPost->post_title;
    }
    ob_start();
    switch($type){
        case 'twitter':
            $text=$post_title;
            if(strlen($text)<140){
                $left=140-strlen($text);
                if($left>40){
                    $text.=' '.substr($post_content,0,$left);
                }
            }
            ?>
		https://twitter.com/intent/tweet?url=<?php echo urlencode($url);?>&text=<?php echo urlencode($text);?>
		<?php
		break;
		case 'facebook':
			$text=substr($post_content,0,200);
			$appID=wp_my_pro_timeline_get_option("facebookAPPID");
		?>
		https://www.facebook.com/dialog/feed?app_id=<?php echo urlencode($appID)?>&caption=<?php echo urlencode($post_title)?>&link=<?php echo urlencode($url)?>&picture=<?php echo urlencode($image);?>&description=<?php echo urlencode($text);?>
		<?php
		break;
		case 'google':
			?>
			https://plus.google.com/share?url=<?php echo urlencode($url);?>
			<?php
		break;
		case 'pinterest':
			?>
			http://pinterest.com/pin/create/button/?url=<?php echo urlencode($url);?>&media=<?php echo urlencode($image);?>
			<?php
		break;
	}
	$url=ob_get_clean();
	return trim($url);
}

function wp_my_post_templates_filter_vars(&$arr){
	foreach($arr as $key=>$v){
		if(!empty($v['padding'])){
			wp_my_post_template_padd_margin($v['padding'],$key,$arr,'padding');
		}
		if(!empty($v['margin'])){
			wp_my_post_template_padd_margin($v['margin'],$key,$arr,'margin');
		}
		if(!empty($v['predefined_classes'])){
		    foreach($v['predefined_classes'] as $k1=>$v1){
		        if(!empty($v1['padding'])){
		            wp_my_post_template_padd_margin($v1['padding'],$k1,$arr[$key]['predefined_classes'],'padding');
		        }
		        if(!empty($v1['margin'])){
		            wp_my_post_template_padd_margin($v1['margin'],$k1,$arr[$key]['predefined_classes'],'margin');
		        }
		    }
		}

	}
}
function wp_my_post_template_padd_margin($val,$key,&$arr,$prop){
	$a=explode(" ",$val);
	$ret=array('top','right','bottom','left');
	$add=array();
	if(count($a)==1){
		foreach($ret as $k=>$v){
			$add[$prop.'-'.$v]=$val;
		}
	}else if(count($a)==4){
		foreach ($a as $k=>$v){
			$add[$prop.'-'.$ret[$k]]=$v;
		}
	}
	foreach($add as $k=>$v){
		$arr[$key][$k]=$v;
	}
}
/**
 * 
 * @param unknown $rule
 * @param unknown $key
 * @param unknown $value
 * @return mixed
 */
function wp_my_post_templates_gen_added_css($rule,$key,$value){
    $css=$rule;
    $value1=$value;
    if(strpos($value1,",")!==false){
        $ex=explode(",",$value);
        $value1=wp_my_general_rgba_color($ex[0],$ex[1]);
    }
    if(strpos($rule,'{val}')!==false){
        $css=str_replace('{val}',$value1, $rule);
    }else {
        $varKey=$key;
        ob_start();
        switch($varKey){
            case 'onHover':
                echo $rule;
            break;    
            case 'filter':
            case 'padding':
            case 'margin':
            case 'width':
            case 'height':
            case 'float':
            case 'border_bottom':
            case 'border_top':
            case 'border':
            case 'border_left':
            case 'border_right':
                $my_check_border=array('top','left','right','bottom');

                    if($varKey=='border'){

                        foreach($my_check_border as $k12=>$v12){
                            unset($$v12);
                            if(!empty($value[$v12])){
                                $$v12=$value[$v12];
                            }
                        }
                        if(!empty($value['border'])){

                            foreach($my_check_border as $k12=>$v12){
                                if(!isset($$v12)){
                                    $$v12=$value['border'];
                                }
                            }
                        }
                        foreach($my_check_border as $k12=>$v12){
                            if(isset($$v12)){
                                //echo $class."{border-".$v12.":".$$v12." !important;}";
                                echo "{\nborder-".$v12.":".$$v12." !important;}\n";
                            }
                        }


                    }else echo "{\n".$varKey.":".$value." !important;}\n";

                break;
            case 'bg_image':
                echo "{background-image:".$value." !important}\n";
                break;
            case 'bg_repeat':
                echo "{background-repeat:".$value." !important}\n";
                break;
            case 'bg_color':
            case 'bg_hover_color':
                $value1=$value;
                /*if(strpos($value1,",")!==false){
                    $ex=explode(",",$value);
                    $value1=wp_my_general_rgba_color($ex[0],$ex[1]);
                }*/
                $value1=wp_my_post_templates_get_color($value);
                if($varKey=='bg_hover_color'){
                     echo "{background-color:".$value1." !important;}\n";

                }else {
                     echo "{background-color:".$value1." !important;}\n";
                }
                break;

            case 'font_size':
            case 'line_height':
            case 'font_weight':
            case 'font_style':
            case 'color':
            case 'hover_color':
            case 'align':
            case 'i_font_size':    
            case 'text_decoration':
            case 'letter_spacing':
                $realKey=$varKey;
                if($realKey=='align'){
                    $realKey='text-align';
                }
                if($realKey=='color' || $realKey=='hover_color'){
                    /*if(strpos($value,",")!==false){
                        $ex=explode(",",$value);
                        $value=wp_my_general_rgba_color($ex[0],$ex[1]);
                    }*/
                    $value=wp_my_post_templates_get_color($value);

                }
                     if($varKey!='hover_color'){
                        if(strpos($realKey,"_")!==false){
                            $ex=explode("_",$realKey);
                            $realKey=$ex[0].'-'.$ex[1];
                        }
                       echo "{\n".$realKey.":".$value." !important;}\n";

                    }else {
                        $realKey='color';

                        echo "{\n".$realKey.":".$value." !important;}\n";

                    }

                break;
        }
        $css1=ob_get_clean();
        $rule=str_replace('{css}', $css1, $rule);
        return $rule;
        }


}
/**
 * 
 * @param unknown $tmpl
 * @param unknown $templates
 * @param string $fake
 * @param string $rec
 * @param string $classNew
 * @return string|unknown
 */
function wp_my_post_templates_gen_css($tmpl,$templates,$fake='',$rec=false,$classNew=''){
    $css='';
	$class='.my_'.$tmpl;
    if($rec){
        $rules=$templates;
        if(class_exists('Class_My_Module_Debug')){
            Class_My_Module_Debug::add_section('recursion', array('val'=>$tmpl,'rules'=>$rules));
            
        }
    }
	else if(!empty($fake)){
	    if(isset($templates[$fake]['post_tags'])){
	        $rules['predefined_classes']=$templates[$fake]['post_tags']['predefined_classes'];
	    }else {
	        $rules['predefined_classes']=$templates[$fake]['predefined_classes'];
	    }

	}else {
	if(!empty($templates[$tmpl])){
	    if(isset($templates[$tmpl]['post_tags'])){
		  $rules=$templates[$tmpl]['post_tags'];
            
	    }else {
	        $rules=$templates[$tmpl];
	    }
	}
	}
	$myStrict=false;
	if(isset($templates[$tmpl]['template'])){
	    
	    foreach($templates[$tmpl]['template'] as $key=>$val){
	        if(!empty($val['predefined_classes'])){
	            
	            if(class_exists('Class_My_Module_Debug')){
	                Class_My_Module_Debug::add_section($key.'_predefined', array('val'=>$val['predefined_classes']));
	            }
	            foreach($val['predefined_classes'] as $k1=>$v1){
	                foreach($v1 as $k2=>$v2){
	                    $class1=$class." .$k1";
	                    $css1=wp_my_post_templates_gen_rule($class1, 'predefined_classes', $k2, $v2);
	                    
	                    if(class_exists('Class_My_Module_Debug')){
	                        Class_My_Module_Debug::add_section($key.'_'.$k1.'_'.$k2, array('val'=>$v2,'css'=>$css1));
	                    }
	                    $css.=$css1;
	                }
	            }
	        }
	        if(!empty($val['added_css'])){
	            foreach($val['added_css'] as $k1=>$v1){
	                if(strpos($k1,",")!==false){
	                    $ind=explode(",", $k1);
	                    foreach($ind as $kI=>$vI){
	                        if(!empty($val[$kI])){
	                            $value=$val[$kI];
	                            $css1=wp_my_post_templates_gen_added_css($vI, $key, $value);
	                            if(class_exists('Class_My_Module_Debug')){
	                                Class_My_Module_Debug::add_section($key.'_added_css_'.$kI, array('val'=>$value,'css'=>$css1));
	                            }
	                        }
	                    }
	                }else {
	                    $ind=$k1;
	                    $kI=$k1;
	                    if(!empty($val[$kI])){
	                        $value=$val[$kI];
	                        $css1=wp_my_post_templates_gen_added_css($vI, $key, $value);
	                        if(class_exists('Class_My_Module_Debug')){
	                            Class_My_Module_Debug::add_section($key.'_added_css_'.$kI, array('val'=>$value,'css'=>$css1));
	                        }
	                    }
	                }
	            }
	        }
	       if($key!='predefined_classes' && $key!='added_css'){
	            $css1=wp_my_post_templates_gen_rule($class, 'template', $key, $val);
	            if(class_exists('Class_My_Module_Debug')){
	                Class_My_Module_Debug::add_section($key, array('val'=>$css,'css'=>$css1));
	            }
	            $css.=$css1;
	       }
	        
	    }
	}
	if(class_exists('Class_My_Module_Debug')){
	    Class_My_Module_Debug::add_section('call_css', array('val'=>$tmpl,'fake'=>$fake,'rules'=>$rules));

	}
	/**
	 * Gen css rules
	 */
	if(!empty($rules['meta_stars'])){
	    foreach ($rules['meta_stars'] as $key=>$val){
	        if(strpos($key,"i")!==false){
	            switch ($key){
	               case 'i_font_size':
	                   $int=(int)$val+8;
	                  ob_start();
	                  ?>
	                  <?php echo $class?> .my_stars_diff{left:-<?php echo $int;?>px !important}
	                  <?php 
	                  $css.=ob_get_clean();
	                  
	               break;    
	            }
	        }
	    }
	}
	    if(!empty($rules['my_strict']))$myStrict=true;   
		foreach($rules as $key=>$val){
		    //if($key=='sort' || $key=='sort_arr' ||$key=='fonts' || )continue;
		    if(in_array($key,array("sort","sort_arr","fonts","my_strict","ignore_html")))continue;
			switch($key){
			      
			    case 'child':
			        
			    break;    
			    case 'children':
			        if(class_exists('Class_My_Module_Debug')){
			            Class_My_Module_Debug::add_section('children1', array('val'=>$tmpl,'fake'=>$fake,'rules'=>$val));
			            
			        }
			        $css.=wp_my_post_templates_gen_css($tmpl, $val,'',true);
			    break;    
			    case 'predefined_classes':
			        if(class_exists('Class_My_Module_Debug')){
			            Class_My_Module_Debug::add_section($key.'_predefined', array('val'=>$val['predefined_classes']));
			        }
			        foreach($val as $k1=>$v1){
			            foreach($v1 as $k2=>$v2){
			                $class1=$class." .$k1";
			                $css1=wp_my_post_templates_gen_rule($class1, 'predefined_classes', $k2, $v2);

			                if(class_exists('Class_My_Module_Debug')){
			                    Class_My_Module_Debug::add_section($key.'_'.$k1.'_'.$k2, array('val'=>$v2,'css'=>$css1));
			                }
			                $css.=$css1;
			            }
			        }
			      break;
				case 'woo_data':
					foreach($val as $k2=>$v2){
						if($k2=='bg_hover_color' || $k2=='hover_color'){
					if($k2=='bg_hover_color'){
						$bg_color=$v2;//['bg_hover_color'];
						$ex=explode(",",$bg_color);
						$bg_value=wp_my_general_rgba_color($ex[0],$ex[1]);
						ob_start();
						?>
						.my_woo_data li:hover{
							background-color:<?php echo $bg_value;?>; !important;
							}
						<?php
						$css1=ob_get_clean();
						$css.=$css1;
					}else if($k2=='hover_color'){
						$color=$v2;//['hover_color'];
						$ex=explode(",",$bg_color);
						$color_value=wp_my_general_rgba_color($ex[0],$ex[1]);
						ob_start();
						?>
						.my_woo_data li:hover a{
							color:<?php echo $color_value;?>; !important;
						}
						<?php
						$css1=ob_get_clean();
						$css.=$css1;

					}

					}else {
					    if($key!='show'){

						$css1=wp_my_post_templates_gen_rule($class, $key, $k2, $v2);

						if(class_exists('Class_My_Module_Debug')){
							Class_My_Module_Debug::add_section($key.'_'.$k1, array('val'=>$v1,'css'=>$css1));
						}
						$css.=$css1;
					    }
					}
					}
				break;
				case 'post_meta':
					//print_r($val);
					if(class_exists('Class_My_Module_Debug')){
						Class_My_Module_Debug::add_section("post_meta",array('key'=>$key,'val'=>$val));
					}

					foreach($val as $k2=>$v2){
					    if($k2=='predefined_classes'){
					        foreach($v2 as $k12=>$v12){
					            foreach($v12 as $k22=>$v22){
					                $class1=$class." .$k12";
					                $css1=wp_my_post_templates_gen_rule($class1, 'predefined_classes', $k22, $v22);
					                
					                if(class_exists('Class_My_Module_Debug')){
					                    Class_My_Module_Debug::add_section($key.'_'.$k12.'_'.$k22, array('val'=>$v2,'css'=>$css1));
					                }
					                $css.=$css1;
					            }
					        }
					    }
					    else if(is_array($v2)){
							foreach($v2 as $k1=>$v1){
							    if($k1=='font_size' || $k1=='line_height')continue;
								$css1=wp_my_post_templates_gen_rule($class, $key, $k1, $v1,".my_".$k2);
								if(class_exists('Class_My_Module_Debug')){
									Class_My_Module_Debug::add_section('post_meta'.$k1, array('val'=>$v1,'css'=>$css1));
								}

								$css.=$css1;
							}
						}else {
							if($key!='show'){
							    if($k2!='font_size'&&$k2!='line_height'){
							    
						      $css1=wp_my_post_templates_gen_rule($class, $key, $k2, $v2);

							 if(class_exists('Class_My_Module_Debug')){
								Class_My_Module_Debug::add_section($key.'_'.$k1, array('val'=>$v1,'css'=>$css1));
							 }
							 $css.=$css1;
							    }
							}
						}
					}

				break;
				default:
					if(!empty($val['predefined_classes'])){

						if(class_exists('Class_My_Module_Debug')){
							Class_My_Module_Debug::add_section($key.'_predefined', array('val'=>$val['predefined_classes']));
						}
							foreach($val['predefined_classes'] as $k1=>$v1){
								foreach($v1 as $k2=>$v2){
									$class1=$class." .$k1";
									$css1=wp_my_post_templates_gen_rule($class1, 'predefined_classes', $k2, $v2);

									if(class_exists('Class_My_Module_Debug')){
										Class_My_Module_Debug::add_section($key.'_'.$k1.'_'.$k2, array('val'=>$v2,'css'=>$css1));
									}
									$css.=$css1;
								}
							}
					}
					if(!empty($val['added_css'])){
					   foreach($val['added_css'] as $k1=>$v1){
					       if(strpos($k1,",")!==false){
					           $ind=explode(",", $k1);
					           foreach($ind as $kI=>$vI){
					               if(!empty($val[$kI])){
					                   $value=$val[$kI];
					                   $css1=wp_my_post_templates_gen_added_css($vI, $key, $value);
					                   if(class_exists('Class_My_Module_Debug')){
					                       Class_My_Module_Debug::add_section($key.'_added_css_'.$kI, array('val'=>$value,'css'=>$css1));
					                   }
					               }
					           }
					       }else {
					           $ind=$k1;
					           $kI=$k1;
					           if(!empty($val[$kI])){
					               $value=$val[$kI];
					               $css1=wp_my_post_templates_gen_added_css($kI, $key, $value);
					               if(class_exists('Class_My_Module_Debug')){
					                   Class_My_Module_Debug::add_section($key.'_added_css_'.$kI, array('val'=>$value,'css'=>$css1));
					               }
					           }
					       }
					       //$css.=$css1;
					   }
					   
					}
					if(is_array($val)){
					foreach($val as $k1=>$v1){
						if($key=='predefined_classes')continue;
						if($key=='added_css')continue;
						if($k1=='children'){
						    
						    if(class_exists('Class_My_Module_Debug')){
						        Class_My_Module_Debug::add_section('children2', array('val'=>$tmpl,'k1'=>$k1,'rules'=>$v1));
						        
						    }
						    $css.=wp_my_post_templates_gen_css($tmpl, $v1,'',true);
						        }else {
						$key1=$k1;
						$css1=wp_my_post_templates_gen_rule($class, $key, $key1, $v1);
						if(class_exists('Class_My_Module_Debug')){
							Class_My_Module_Debug::add_section($key.'_'.$k1, array('val'=>$v1,'css'=>$css1));
						}
						        
						$css.=$css1;
                            
					       }
					}
					}else {
					    $css1=wp_my_post_templates_gen_rule($class, $key, $val, '',false,$myStrict);
					    if(class_exists('Class_My_Module_Debug')){
					        Class_My_Module_Debug::add_section($key.'_'.$k1, array('val'=>$v1,'css'=>$css1));
					    }
					    $css.=$css1;
					    
					}
				break;
			}
		}
	//}
	//$css=ob_get_clean();
	return $css;
}
/**
 * 
 * @param unknown $color
 * @return unknown|string
 */
function wp_my_post_templates_get_color($color){
    if(strpos($color,"rgba")!==false){
        return $color;
    }else if(strpos($color,"rgb")!==false){
        return $color;
    }else {
        if(strpos($color,",")!==false){
            $ex=explode(",",$color);
            $c=wp_my_general_rgba_color($ex[0],$ex[1]);
            return $c;
        }else {
            
        }
        
    }
}
/**
 * Generate rule
 * @param unknown $class
 * @param unknown $key
 * @param unknown $varKey
 * @param unknown $value
 * @param string $meta
 * @param string $strict
 * @return string
 */
function wp_my_post_templates_gen_rule($class,$key,$varKey,$value,$meta=false,$strict=false){
	/*if($meta){

	}*/
	if($value=='')return '';
	ob_start();
	switch($varKey){
	    
	    case "border_radius":
	        
	        $tmpCss='';
	        $cssProperties=array('','-webkit-','-moz-');
	        
	        $values=array();
	        $myDo=true;
	        if(!is_array($value)&&strpos($value,"/")!==false){
	            if($key=='template' || $key=='predefined_classes' || $strict){
	                echo $class."{\n";
	                
	            }
	            else echo $class." .my_".$key."_row{\n";
	            foreach ($cssProperties as $key=>$val){
	                echo $val."border-radius:".$value." !important;";
	            }
	            $myDo=false;
	        }
	        else if(!empty($value['all'])){
	            $values[]="border:".$value['all']."!important;\n";
	        }else {
	            $check=array("top_left","top_right","bottom_right","bottom_left");
	            foreach($check as $key=>$val){
	                if(isset($value[$val])){
	                    $keyNew12=str_replace("_", "-", $val);
	                    $values[]="border-".$keyNew12."-radius:".$val."!important;\n";
	                }
	            }
	        }
	        if($myDo){
	           if($key=='template' || $key=='predefined_classes' || $strict){
	                echo $class."{\n";
	            
	           }
	           else echo $class." .my_".$key."_row{\n";
	           foreach ($cssProperties as $key=>$val){
	               $cssAll=implode("\n",$values);
	                echo $val."border-radius:".$cssAll;
	           }
	        }
	        echo "\n}";
	    break;    
	    case 'box_shadow':
	        $tmpCss='';
	        $templateCss="{h_shadow} {v_shadow} {blur} {spread} {color}";
            $cssProperties=array(
              '','-webkit-','-moz-'  
            );
            $checkCss=array('blur','spread','color');
            if(!is_array($value)&&$value=='none'){
	            echo $class." .my_".$key."{";
	            foreach($cssProperties as $k=>$v){
	                $str='box-shadow';
	                if(!empty($v))$str=$v."box-shadow:none !importat;\n";
	            }
	            echo "\n}";
	            
	        }else {
	            $values=array();
	           foreach($value as $key1=>$val){
	               if(is_array($val)){
	                   if(class_exists('Class_My_Module_Debug')){
	                       Class_My_Module_Debug::add_section('tokenCssArr', $val);
	                       
	                   }
	                 $tokenCss=$templateCss;
	                   $v_shadow=$val['v_shadow'];
	                   $h_shadow=$val['h_shadow'];
	                   $tokenCss=str_replace("{h_shadow}", $h_shadow, $tokenCss);
	                   $tokenCss=str_replace("{v_shadow}", $v_shadow, $tokenCss);
	                   if(class_exists('Class_My_Module_Debug')){
	                       Class_My_Module_Debug::add_section('tokenCss', $tokenCss);

	                   }
	                   foreach($checkCss as $k1=>$v1){
	                       if(isset($val[$v1])){
	                           $vCss=$val[$v1];
	                           if($v1=='color'){
	                               /*if(strpos($vCss,",")!==false){
	                                   $ex=explode(",",$vCss);
	                                   $vCss=wp_my_general_rgba_color($ex[0],$ex[1]);
	                               }*/
	                               $vCss=wp_my_post_templates_get_color($vCss);
	                           }
	                           if(class_exists('Class_My_Module_Debug')){
	                               Class_My_Module_Debug::add_section('tokenCss', $tokenCss);
	                               
	                           }
	                           
	                           $tokenCss=str_replace("{".$v1."}", $vCss, $tokenCss);
	                       }else $tokenCss=str_replace("{".$v1."}", "", $tokenCss);
	                   }
	                   $values[]=$tokenCss;
	                   
	                }
	           }
	           $cssAll=implode(",", $values);
	           if($key=='template' || $key=='predefined_classes' ||$strict){
	               if((!empty($value['type'])&&($value['type']=="hover"))){
	                   echo $class.":hover {\n";
	               }
	               else 
	               echo $class."{\n";
	               
	           }
	           else echo $class." .my_".$key."{\n";
	           foreach($cssProperties as $key=>$val){
	               echo $val."box-shadow:".$cssAll." !important;\n";
	           }
	           echo "}";
	        }
	    break;    
	    case 'bg_gradient_css':
	        if($key=='template' || $key=='predefined_classes' || $strict){
	            echo $class;
	        }else echo $class." .my_".$key;
	        echo "{\n".$value."\n}";
	    break; 
	    case 'display':
	    case 'position':
	    case 'left':
	    case 'right':
	    case 'bottom':
	    case 'top':
	        if($key=='template' || $key=='predefined_classes' ||$strict){
	            echo $class."{\n";
	            
	        }
	        else echo $class." .my_".$key."{\n";
	        
	        echo $varKey.":".$value."\n}";
	    break;    
	    case 'filter':
	        if($key=='template' || $key=='predefined_classes' ||$strict){
	            echo $class."{\n";
	            
	        }
	        else echo $class." .my_".$key."{\n";
	        
	        echo "filter:",$value."\n}";
	    break;    
	    case 'onHover':
	        if($key=='template' || $key=='predefined_classes' ||$strict){
	            echo $class."{\n";
	            
	        }
	        else echo $class." .my_".$key."{\n";
	        
	        echo ":hover{filter:".$value."\n}";
	    break;    
	    case 'font_family':
	       if($value!='default'){
	           if($key=='predefined_classes' || $key=='predefined_classes' ||$strict){
	               echo $class."{font-family:".$value." , serif !important\n}";
	           }
	           else echo $class." .my_".$key."{font-family:".$value." , serif !important\n}";
	        }
	    break;
		case 'i_font_size':
		case 'i_line_height':
		case 'i_color':
		case 'i_color_hover':
			if($key=='meta_stars'){
				$key='stars';
			}
			$realKey=substr($varKey,2);
			if($realKey=='align'){
				$realKey='text-align';
			}
			if($realKey=='color' || $realKey=='color_hover'){

				/*if(strpos($value,",")!==false){
					$ex=explode(",",$value);
					$value=wp_my_general_rgba_color($ex[0],$ex[1]);
				}*/
			    $value=wp_my_post_templates_get_color($value);

			}

			if($realKey!='color_hover'){
				if(strpos($realKey,"_")!==false){
					$ex=explode("_",$realKey);
					$realKey=$ex[0].'-'.$ex[1];
				}
				echo $class." .my_".$key." ".$meta." i , ".$class." .my_".$key." ".$meta." a i{\n".$realKey.":".$value." !important;}\n";

			}else {
				$realKey='color';
				if($key=='stars'){

					echo $class." .my_stars .my_active i , ".$class." .my_stars .my_active a i{\n".$realKey.":".$value." !important;}\n";
					//echo $class." .my_stars:hover i , ".$class." .my_stars:hover a i{\n".$realKey.":".$value." !important}\n";

				}
				else echo $class." .my_".$key." ".$meta.":hover i , ".$class." .my_".$key." ".$meta.":hover a i{\n".$realKey.":".$value." !important;}\n";
			}
		break;
		case 'padding':
		case 'margin':
		case 'width':
		case 'height':
		case 'float':
		case 'border_bottom':
		case 'border_top':
		case 'border':
		case 'border_left':
		case 'border_right':
		    $my_check_border=array('top','left','right','bottom');
		    if($key=='predefined_classes' ||$key=='template' || $strict){
		          if($varKey=='border'){

		              foreach($my_check_border as $k12=>$v12){
		                  unset($$v12);
		                  if(!empty($value[$v12])){
		                      $$v12=$value[$v12];
		                  }
		              }
		              if(!empty($value['border'])){

		                  foreach($my_check_border as $k12=>$v12){
		                     if(!isset($$v12)){
		                       $$v12=$value['border'];
		                     }
		                  }
		              }
		                  foreach($my_check_border as $k12=>$v12){
		                      if(isset($$v12)){
		                          echo $class."{border-".$v12.":".$$v12." !important;}";
		                      }
		                  }

		          }else {
		              echo $class."{\n".$varKey.":".$value." !important;}\n";
		          }

		    }
			else {
			    if($varKey=='border'){

			        foreach($my_check_border as $k12=>$v12){
			            unset($$v12);
			            if(!empty($value[$v12])){
			                $$v12=$value[$v12];
			            }
			        }
			        if(!empty($value['border'])){

			            foreach($my_check_border as $k12=>$v12){
			                if(!isset($$v12)){
			                    $$v12=$value['border'];
			                }
			            }
			        }
			        foreach($my_check_border as $k12=>$v12){
			            if(isset($$v12)){
			                //echo $class."{border-".$v12.":".$$v12." !important;}";
			                echo $class." .my_".$key."_row{\nborder-".$v12.":".$$v12." !important;}\n";
			            }
			        }

			    }/*else {
			        echo $class."{\n".$varKey.":".$value." !important;}\n";
			    }*/
			    else echo $class." .my_".$key."_row{\n".$varKey.":".$value." !important;}\n";
			}
		break;
		case 'bg_image':
		    if($key=='predefined_classes' ||$key=='template' || $strict)
		        echo $class." {background-image:".$value." !important}\n";
			else echo $class." .my_".$key."_row {background-image:".$value." !important}\n";
		break;
		case 'bg_repeat':
		    if($key=='predefined_classes' ||$key=='template' || $strict)
		        echo $class." {background-repeat:".$value." !important}\n";
			else echo $class." .my_".$key."_row {background-repeat:".$value." !important}\n";
		break;
		case 'bg_color':
		case 'bg_hover_color':
		    $value1=$value;
			/*if(strpos($value1,",")!==false){
				$ex=explode(",",$value);
				$value1=wp_my_general_rgba_color($ex[0],$ex[1]);
			}*/
		    $value1=wp_my_post_templates_get_color($value);
			if($varKey=='bg_hover_color'){
			    if($key=='predefined_classes' || $key=='template' || $strict){
			        echo $class.":hover{background-color:".$value1." !important;}\n";
			    }
			    else echo $class." .my_".$key."_row:hover {background-color:".$value1." !important;}\n";

			}else {
			if($key=='predefined_classes' || $key=='template' || $strict){
			    echo $class."{background-color:".$value1." !important;}\n";
			}
			else echo $class." .my_".$key."_row {background-color:".$value1." !important;}\n";
			}
		break;
		case 'list_style':
		case 'font_size':
		case 'line_height':
		case 'font_weight':
		case 'font_style':
		case 'color':
		case 'hover_color':
		case 'align':
		case 'text_decoration':
		case 'letter_spacing':
		case 'word_wrap':    
			$realKey=$varKey;
			if($realKey=='align'){
				$realKey='text-align';
			}
			if($realKey=='color' || $realKey=='hover_color'){
				/*if(strpos($value,",")!==false){
					$ex=explode(",",$value);
					$value=wp_my_general_rgba_color($ex[0],$ex[1]);
				}*/
			    $value=wp_my_post_templates_get_color($value);
			    
			}
			if($key=='predefined_classes' || $key=='template' || $strict){
					if($varKey!='hover_color'){

						if(strpos($realKey,"_")!==false){
						$ex=explode("_",$realKey);
						$realKey=$ex[0].'-'.$ex[1];
						}
						echo  $class.", ".$class." a{\n".$realKey.":".$value." !important;}\n";

		}else {
		    $realKey='color';

		echo $class." :hover , ".$class."  a:hover{\n".$realKey.":".$value." !important;}\n";

			}
		}
			else {
			if($varKey!='hover_color'){
				if(strpos($realKey,"_")!==false){
					$ex=explode("_",$realKey);
					$realKey=$ex[0].'-'.$ex[1];
				}
				if($key=='post_meta' &&in_array($varKey,array('line_height','font_size','color'))){
					echo $class." .my_".$key." span , ".$class." .my_".$key." i , ".$class." .my_".$key." a i{\n".$realKey.":".$value." !important;}\n";

				}

				echo $class." .my_".$key.", ".$class." .my_".$key." a{\n".$realKey.":".$value." !important;}\n";

			}else {
			    $realKey='color';

				echo $class." .my_".$key.":hover , ".$class." .my_".$key." a:hover{\n".$realKey.":".$value." !important;}\n";

				}
			}
		break;
		 
		default:
		break;    
	}
	$css=ob_get_clean();
	return $css;
}