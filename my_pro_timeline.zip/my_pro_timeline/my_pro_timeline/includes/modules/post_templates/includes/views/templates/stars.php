<?php
if(!defined('ABSPATH'))die('');
$diffC=floor($stars);
$diff=($stars-$diffC)*100;
?>
<ul class="my_stars">
	<?php for($i=1;$i<=5;$i++){?>
	<li class="<?php if($i<=$stars)echo 'my_active'?>">
		<i class="fa fa-star"></i>
	</li>
	<?php }?>
	<?php 
	if($diff>0){
			 //if(!isset($my_added_diff)&&$i>$stars){
			     $my_added_diff=1;
			     ?>
			     <li data-diff="<?php echo esc_attr($diff)?>" class="my_stars_diff my_active" style="">
			     	<i class="fa fa-star"></i>
			     </li>
			     <?php 
			 }
			 ?>
</ul>
