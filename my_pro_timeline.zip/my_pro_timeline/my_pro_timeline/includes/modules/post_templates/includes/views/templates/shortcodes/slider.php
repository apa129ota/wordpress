<?php
if(!defined('ABSPATH'))die('');
$layout_cols=$settings['layout_cols'];
$w123=ceil((100/$layout_cols)*(count($items)))+100;
$show_nav=$settings['show_nav'];
?>
<div class="my_testimonial_shortcode my_timiline_hor_div my_testimonial_card" id="my_timeline_<?php echo esc_attr($id);?>">
	<?php if($show_nav){?>
		<?php //if($show_left_right){?>
		<div class="my_line_nav my_timeline_hor_list_nav_left my_nav my_nav_left my_timeline_slider_nav_1" data-type="left">
			
			<span class="my_nav_arrow"><i class="fa fa-angle-left"></i></span>
			<span class="my_nav_item"></span>
		</div>
		<div class="my_testimonial_next my_testimonial_next_left">
			<div>
				<div>
				</div>
			</div>
		</div>
		<?php //}?>
		<div class="my_testimonial_next my_testimonial_next_rigth">
			<div>
			<div></div>
			</div>
		</div>
		
			<div class="my_line_nav my_timeline_hor_list_nav_right my_nav my_nav_right my_timeline_slider_nav_1" data-type="right">
				<span class="my_nav_arrow"><i class="fa fa-angle-right"></i></span>
				<span class="my_nav_item"></span>
			</div>
		
			
	<?php }?>	
	<div class="my_timeline_hor_out_div">
	<ul class="my_timeline_hor_ul" data-id="<?php echo esc_attr($id)?>" data-c="<?php $c_p_12=count($items);echo $c_p_12;?>" style="width:<?php echo $w123.'%'?>">
		<?php 
		$my_start_12_123=1;
		$my_c_12_123=1;
		foreach($items as $itemKey=>$item){
	//if(!isset($itemVal['post_id']))$post_id=$my_start_12_123;
	//else $post_id=$itemVal['post_id'];	
	$post_id=trim($item['my_id']);
		    ?>
	<li data-full="<?php echo esc_attr($itemsOld[$itemKey][0])?>" data-text="<?php echo esc_attr($item['small']);?>" data-thumb="<?php echo $itemsThumbs[$itemKey][0];?>" data-pos="<?php echo esc_attr($my_start_12_123);$my_start_12_123++;?>" data-post-id="<?php echo esc_attr($post_id);?>" data-i="<?php echo $my_c_12_123++;?>" class="my_timeline_li_class"   id="<?php echo 'my_timeline_id_'.$post_id;?>">
	<?php require $template_file;?>
	</li>
	<?php }?>
	</ul>
			
</div>
<?php $a_page_12=@$_GET['my_image_mapper_templates'];
$my_set_debug=0;
?>
<script type="text/javascript">
jQuery(document).ready(function($){
	$(window).load(function(e){
								my_timeline_o_<?php echo $id?>={};
								my_timeline_o_<?php echo $id?>.edit_styles=1;								
								my_timeline_o_<?php echo $id?>.template="";
								my_timeline_o_<?php echo $id?>.debug=<?php echo $my_set_debug;?>;
								my_timeline_o_<?php echo $id?>.preview=<?php echo '0'?>;
								my_timeline_o_<?php echo $id?>.mobile=<?php $f=wp_is_mobile();if(!empty($f))echo '1';else echo '0';?>;
								my_timeline_o_<?php echo $id?>.ajax_timeout=30000;
								my_timeline_o_<?php echo $id?>.id="<?php echo $id;?>";
								my_timeline_o_<?php echo $id?>.ajax_url="<?php echo admin_url('admin-ajax.php');?>";
								my_timeline_o_<?php echo $id?>.ajax_action="<?php echo 'my_timeline_load_post'?>";
								my_timeline_o_<?php echo $id?>.ajax_nonce="<?php echo wp_create_nonce('my_timeline_load_post_'.$id);?>";								
								my_timeline_o_<?php echo $id?>.form={};
								my_timeline_o_<?php echo $id?>.form=<?php echo json_encode($settings['form']);?>;
								my_timeline_o_<?php echo $id?>.start_item=1;								
								my_timeline_o_<?php echo $id?>.layout=<?php echo json_encode($settings['layout']);?>;
								$("#my_timeline_<?php echo $id;?>").myproslider(my_timeline_o_<?php echo $id?>);
	});
								});
						</script>
</div>
