<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_post_row my_meta_stars_row" data-key="meta_stars">
<div class="my_meta_stars">
{template_stars}
</div>
</div>