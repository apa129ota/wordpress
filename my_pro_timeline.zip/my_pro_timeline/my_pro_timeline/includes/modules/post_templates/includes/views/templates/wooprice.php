<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_post_row my_post_woo_price_row" data-key="post_woo_price">
	<div class="my_post_woo_price">
	<?php if(isset($regular_price)&&!empty($regular_price)){?>
	<span class="woo_price_regular"><?php echo $currency;?><?php ?><?php echo $regular_price?></span>&nbsp;
	<span class="woo_price_sale"><?php echo $currency;?><?php echo $sale_price?></span>	
	<?php }else {?>
	<span class="woo_price_sale"><?php echo $currency;?><?php echo $sale_price?></span>	
	<?php }?>
	</div>
</div>