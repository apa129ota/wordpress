<?php
?>
<div class="my_post_template my_template_7 my_post_clear" data-key="template_7">


<div class="my_post_row my_post_title_row" data-key="post_title">
<div class="my_post_title">
{post_title}
</div>
</div>
{template_wooprice}


<div class="my_post_row my_post_thumb_row" data-key="post_thumb">
<div class="my_post_thumb">
{post_thumb}
</div>
</div>
<div class="my_post_row my_post_content_row" data-key="post_content">
<div class="my_post_content">
{post_content}
</div>
</div>

{template_woo}

</div>