<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_post_row my_post_meta_row" data-key="post_meta">
<div class="my_post_meta">
<ul>
{template_hearts}
{template_comments}
{template_share}
</ul>
</div>
</div>