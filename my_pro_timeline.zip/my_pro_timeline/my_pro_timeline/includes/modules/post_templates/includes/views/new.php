<?php
if(!defined('ABSPATH'))die('');
return;
?>
<div class="my_dialog_new">
<div class="my_header_dialog">
<h4 class="my_no_margin"><?php echo __("New user defined Template","my_support_theme");?></h4>
			<div class="my_timeline_modal_close_1">
				<i class="fa fa-close"></i>
			</div>
	</div>
	<div class="my_shortcode_content my_post_clear">
		<div class="">
			<div id="my_templates_style_css_new">
			
			</div>
				<div class="my_form_options_div">
		<div class="my_options_form">
			<div class="my_slide_in_out">
				<i class="fa fa-angle-double-left" style="display:none"></i>
				<i class="fa fa-angle-double-right"></i> 
			</div>
			<div class="my_options_form_inner">
				<div class="my_selected_elem_12"><h4></h4></div>
			<?php echo $this->template_vars_html_new;?>
			</div>
			</div>
			</div>
		</div>
		<div class="my_shortcode_editor">
			<div class="my_module_post_templates_editor_div_out">
				<div class="my_module_post_templates_editor_div" data-type="" data-id="">
					<div class="my_module_post_templates_editor_div_inner">
						<div class="my_post_template my_post_clear" data-key="">
						</div>
					</div>
				</div>
			</div>			
		</div>
	</div>
</div>	