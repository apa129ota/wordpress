<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_dialog_save">
	<div class="my_header_dialog">
		<h4 class="my_no_margin"><?php echo __("Add Object","my_support_theme");?></h4>
			<div class="my_timeline_modal_close_1">
				<i class="fa fa-close"></i>
			</div>
	</div>
	<div class="my_shortcode_content">
	</div>
</div>	