<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_post_share_popup my_post_share_arrow my_post_template my_<?php echo $tmpl?>" >
	<div class="my_post_row my_share_div_row my_post_share_div" data-key="share_div" data-type="dialog">
		
	</div>
</div>