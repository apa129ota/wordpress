<?php
if(!defined('ABSPATH'))die('');
?>



<div class="my_module_poost_templates_title">
<h4><?php echo __("Preview Template","my_support_theme")?></h4>
</div>			
<div class="my_module_post_templates_editor_div_out">
	<div class="my_module_post_templates_editor_div" data-type="" data-id="">
	
		<div class="my_module_post_templates_editor_div_inner">
		
			<?php echo $tmpl_html;?>
		</div>	
	</div>
</div>	