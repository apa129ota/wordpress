<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_dialog_stars">
<div class="my_stars_popup my_post_template my_<?php echo $tmpl;?> my_post_clear">
	<div class="my_post_row my_stars_popup_row" data-key="stars_popup"  data-type="dialog">
		<div class="my_header_dialog" data-class="my_header_dialog">
			<h4 class="my_no_margin my_stars_popip_title" data-class="my_stars_popup_title"> <?php echo  __("Add stars to post","my_support_theme")?></h4>
				<div class="my_timeline_modal_close">
				<i class="fa fa-close my_stars_close_dialog " data-class="my_stars_close_dialog"></i>
		</div>
		</div>
		<div class="my_stars_popup_stars">
			<div class="my_post_title_stars"></div>
			<?php 
			$default=5;
			$key='my_stars_input';
			$element_id='my_stars_input_id';
			$element_name='my_stars_input_name';
			$element_value=5;
			$element=array(
			    'min'=>1,
			    'max'=>5,
			    
			)
			?>
			<form id="my_stars_form_id" method="post">
				<input type="hidden" name="my_nonce" value="<?php echo wp_create_nonce('my_stars_stars');?>"/>
			<div data-default="<?php echo esc_attr($default);?>" data-base-name="<?php echo $key;?>" id="<?php echo $element_id.'_div';?>" data-type="<?php echo $type;?>" data-open="<?php if(!empty($element['open']))echo $element['open']; ?>" data-id="<?php echo $element_id?>" data-name="<?php echo $element_name;?>" <?php if(!empty($element_validate))echo $element_validate;?> class="my_meta_stars my_new_module_element my_jscript_stars <?php if(!empty($element['div_classes'])){$str=implode(" ",$element['div_classes']);echo $str;}?>">
				<input type="hidden" id="<?php echo esc_attr($element_id);?>" name="<?php echo esc_attr($element_name);?>" value="<?php if(!empty($element_value))echo esc_attr($element_value)?>"/>
				<?php 
	               $i=$element['min'];
	               $c=$element['max'];
	               ?>
				<ul class="my_stars">
				<?php for($f=$i;$f<=$c;$f++){?>
					<li data-i="<?php echo $f;?>">
					<i  class="fa fa-star <?php if($f<=$value)echo 'my_stars_active'?>"></i>
					</li>
				<?php }?>
				</ul>
			</div>
			<input type="button" class="my_add_stars_button" data-class="my_add_stars_button" value="<?php echo __("Add stars","my_support_theme")?>"/>
				
			</form>
		
		</div>
		
	</div>
</div>
</div>