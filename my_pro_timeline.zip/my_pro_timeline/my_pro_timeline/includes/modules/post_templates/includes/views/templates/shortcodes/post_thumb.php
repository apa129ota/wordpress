<?php 
if(!defined('ABSPATH'))die('');
?>
<div class="my_post_row my_post_thumb_row" data-key="post_thumb">
<div class="my_post_thumb">
{post_thumb}
</div>
</div>