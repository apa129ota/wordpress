<?php
if(!defined('ABSPATH'))die('');
?>
<li class="my_post_comments" data-i="{post_comments}">
<i class="fa fa-comment" ></i>
<span class="my_post_templates_comments">{post_comments}</span>
</li>

