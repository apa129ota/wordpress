<div class="my_post_template my_template_custom_new my_post_clear" data-key="template_custom_new" data-post-id=="{post_id}">
</div>