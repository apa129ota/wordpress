<div class="my_post_template my_template_8 my_post_clear" data-key="template_8">



{template_wooprice}
<div class="my_post_row my_post_thumb_row" data-key="post_thumb">
<div class="my_post_thumb">
{post_thumb}
</div>
</div>
<div class="my_post_row my_post_content_row" data-key="post_content">
<div class="my_post_content">
{post_content}
</div>
</div>

{template_woo}

</div>