<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_timeline_modal">
	<div class=" my_header my_no_margin" style="margin-bottom: 10px;">
		<h4 class="my_no_margin"><?php echo __("Slide Options","my_support_theme")?></h4>
		<div class="my_timeline_modal_close">
			<i class="fa fa-close"></i>
		</div>
		
	</div>
	<div class="my_timeline_modal_content">
		<div class="my_options_form">
			<div class="my_slide_in_out">
				<i class="fa fa-angle-double-left" style="display:none"></i>
				<i class="fa fa-angle-double-right"></i> 
			</div>
			<div class="my_post_templates_object_expolorer">
				<h4><?php ?></h4>
			</div>
			<div class="my_options_form_inner">
			<?php global $wp_my_module_forms;
			$c12=0;
			foreach($wp_my_module_forms as $key=>$val){
				?>
				<div class="my_module_shortcodes_form" data-key="<?php echo esc_attr($key)?>" style="<?php if($c12>0)echo 'display:none';?>">
					<?php echo $val;?>
				</div>
				<?php 
				$c12++;
			}	
			?>
			</div>
		</div>
		<?php /*
		<div class="my_timeline_modal_loading">
			<span><?php echo __("Loading","my_related_posts_domain").' ... ';?><img src="<?php echo MY_RELATED_POSTS_IMAGES_URL.'wpspin.gif';?>"/></span>
		</div>
		*/ ?>
		<div class="my_timeline_modal_load my_flex_display">
			<div class="my_flex_display my_slide_image" style="">
				
				<?php /*<div class="my_slide_image_overlay my_transition">
					<ul>
						<li><a href="#javascript" class="my_transition"><i class="fa fa-plus"></i></a>
					</ul>
				</div>
				*/ ?>
			</div>
			<div class="my_flex_display my_sidebar my_border_one my_h_100 my_bg">
				
				<?php /*<ul class="my_window_actions">
						<li class="my_transition"><a href="#javascript" class="my_transition my_add_element"><i class="fa fa-plus"></i><span><?php echo __("Add Element","my_support_theme") ?></span></a></li>
						
				</ul>
				*/?>
				<div class="my_elemenet_section">
					<h4><a href="#javascript" class="my_transition my_open_section"><i class="fa fa-plus"></i><span><?php echo __("Add Element","my_support_theme") ?></span></a></h4>
				
				<div class="my_section_inside">
				<ul class="my_window_actions">
							<li style="text-align:center"><span><?php echo __("Select Element","my_support_theme")?></span></li>
							<?php 
							global $my_shortcodes;
							if(!empty($my_shortcodes)){
								foreach($my_shortcodes as $key=>$val){
								?>
								<li class="my_transition"><a href="#javascript" title="<?php echo esc_attr($val['tooltip'])?>" class="my_transition my_add_shortcode" data-key="<?php echo esc_attr($key)?>"><i class="fa <?php echo $val['icon']?>"></i><span><?php echo $val['title'];?></span></a></li>
								<?php 
								}
							}
							?>
				</ul>
				</div>
				</div>		
				<ul class="my_element_actions">
					
				</ul>
			</div>
			<?php my_new_form_footer();?>
		</div>
	</div>
</div>	