<?php
?>
<div class="my_post_template my_template_5 my_post_clear" data-key="template_5">


<div class="my_post_row my_post_title_row" data-key="post_title">
<div class="my_post_title">
{post_title}
</div>
</div>
<div class="my_post_row my_meta_stars_row" data-key="meta_stars">
<div class="my_meta_stars">
{template_stars}
</div>
</div>
<div class="my_post_row my_post_meta_row" data-key="post_meta">
		<div class="my_post_meta">
			<ul>
				{template_hearts}
				{template_comments}
				{template_share} 
			</ul>
		</div>
	</div>

{template_wooprice}
<div class="my_post_row my_post_content_row" data-key="post_content">
<div class="my_post_content">
{post_content}
</div>
</div>

<div class="my_post_row my_post_thumb_row" data-key="post_thumb">
<div class="my_post_thumb">
{post_thumb}
</div>
</div>
{template_woo}

</div>