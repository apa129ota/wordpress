<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_dialog_save">
	<div class="my_header_dialog">
		<h4 class="my_no_margin"><?php echo __("Save template","my_support_theme");?></h4>
			<div class="my_timeline_modal_close_1">
				<i class="fa fa-close"></i>
			</div>
	</div>
	<div class="my_shortcode_content">
	<ul>
		<li><label for="my_name_tmpl_12"><?php echo __("Template Name","my_support_theme") ?></label></li>
		<li>
			<input type="text"  value="" name="my_name_tmpl_12" id="my_name_tmpl_id_12"/>
	
		</li>
		<li>
		<input type="button" class="button button-primary button-large my_action" data-key="my_save_tmpl" value="<?php echo __("Save","my_support_theme")?>"/>
		</li>
	
	</ul>
	</div>
</div>	
