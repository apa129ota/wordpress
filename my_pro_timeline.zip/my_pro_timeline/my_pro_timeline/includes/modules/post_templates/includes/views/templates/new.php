<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_post_template my_template_new my_post_clear" data-key="template_new">
</div>