<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_module_templates_options_form">
		<?php /*
		<div class="my_section_inside_new">
				<ul class="my_window_actions">
							<li style="text-align:center"><span><?php echo __("Select Element","my_support_theme")?></span></li>
							<?php 
							global $my_shortcodes;
							if(!empty($my_shortcodes)){
								foreach($my_shortcodes as $key=>$val){
								?>
								<li class="my_transition"><a href="#javascript" title="<?php echo esc_attr($val['tooltip'])?>" class="my_transition my_add_shortcode" data-key="<?php echo esc_attr($key)?>"><i class="fa <?php echo $val['icon']?>"></i><span><?php echo $val['title'];?></span></a></li>
								<?php 
								}
							}
							?>
				</ul>
				</div>
		*/ ?>		
	<ul class="my_actions">
		
		<?php /*<li>
			<input type="button" class="button button-primary button-large my_action" data-key="new_template" value="<?php echo __("New Custom Template","my_support_theme")?>"/>
			<div class="my_help my_tooltip" style="display:inline-block;">
				<div class="my_content"><?php echo __("This type of template is not connected with post type it's used to rendfer custom post input with predefined fields like title,content,video,image gallery etc..","my_support_theme")?></div>
			</div>
		</li>
		*/ ?>
		<li>
			<input type="button" class="button button-primary button-large my_action" data-key="save_template" value="<?php echo __("Save Template","my_support_theme")?>"/>
		</li>
	</ul>
	
		<?php echo $options_form;?>
	
		
				
</div>