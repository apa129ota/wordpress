<?php
if(!defined('ABSPATH'))die('');
ob_start();
//print_r($sort);
?>
<div class="my_post_template my_<?php echo $tmpl?> my_post_clear" data-key="<?php echo $tmpl;?>" data-post-id=="{post_id}">
<?php foreach($sort as $kS=>$vS){?>
	<?php $f=$short_view.$vS.'.php';?>
	<?php if(file_exists($f))require $f;?>
<?php }?>
</div>
<?php $tmpHtml=ob_get_clean();
return $tmpHtml;
?>
