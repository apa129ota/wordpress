<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_post_row my_post_date_row" data-key="post_date">
<div class="my_post_date">
{post_date}
</div>
</div>