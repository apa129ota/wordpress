<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_dialog_view_a">
	<div class="my_view_a_popup my_post_template my_<?php echo $tmpl;?> my_post_clear">
	<div class="my_post_row my_view_a_row" data-key="view_a" data-type="dialog">
		<div class="my_header_dialog1" data-class="my_header_dialog1">
			<h4 class="my_no_margin my_view_a_title" data-class="my_view_a_title"> <?php echo  __("View post","my_support_theme")?></h4>
				<div class="my_timeline_modal_close">
				<i class="fa fa-close my_view_a_close_dialog " data-class="my_view_a_close_dialog"></i>
		</div>
		</div>
		<div class="my_view_a_div">
			<div class="my_view_a_loading">
			<?php echo  __("Loading","my_support_theme") ?>&nbsp;&nbsp;
				<i class="fa fa-spinner fa-spin my_view_a_loading_i" data-class="my_view_a_loading_i"></i>
			</div>
			
		
		<iframe src=""></iframe>
		</div>
	</div>	
		
</div>
	<?php if(is_admin()){?>
	<div class="my_post_tmpl_close_dialog my_action" data-key="close_dialog">
				<?php echo __("Close open dialog","my_support_theme") ?>
			</div>
	<?php }?>
</div>