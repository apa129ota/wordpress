<?php
if(!defined('ABSPATH'))die('');
$thumb=$item[0];

?>
<div class="my_post_bg" style="background-image:url('<?php echo $thumb;?>')">
									
</div>