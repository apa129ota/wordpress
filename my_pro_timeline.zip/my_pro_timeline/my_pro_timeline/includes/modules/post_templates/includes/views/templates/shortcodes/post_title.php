<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_post_row my_post_title_row" data-key="post_title">
		<div class="my_post_title">
		{post_title}
		</div>
</div>