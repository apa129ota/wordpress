<?php
if(!defined('ABSPATH'))die('');
$my_header_msg=__("Add new/Edit Image Mapper Templates","my_support_theme");
?>
<?php 
	$file=$my_views_dirname.'elements/my_header.php';
	require $file;
	?>
<div class="my_container_inner">
	<div class="my_image_mapper_add_new_div my_clearfix">
		<div class="my_image_mapper_image_div my_border_none">
		<?php //echo $s; ?>
		</div>
		
		<div class="my_image_mapper_styles_div">
			<h4><?php echo __("Edit Template Styles","my_support_theme")?></h4>
			<?php echo $shortcodes_html;?>
		</div>
	</div>
</div>	