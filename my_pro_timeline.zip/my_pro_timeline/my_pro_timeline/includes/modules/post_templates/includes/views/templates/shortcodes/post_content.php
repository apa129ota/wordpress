<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_post_row my_post_content_row" data-key="post_content">
<div class="my_post_content">
{post_content}
</div>
</div>