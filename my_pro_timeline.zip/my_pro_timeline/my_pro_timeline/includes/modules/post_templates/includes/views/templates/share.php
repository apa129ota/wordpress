<?php
if(!defined('ABSPATH'))die('');
?>
<li class="my_post_share" data-i="">
	<div class="my_post_share_div" style="display:none">
		
<div class="my_post_share_div_12">
	<ul data-id="<?php echo $post_id?>">
		<li>
		<a href="<?php echo $facebook_url?>"><i class="fa fa-facebook fa_facebook_share" data-class="fa_facebook_share"> </i></a>
		</li>
		<li>
		<a href="<?php echo $twitter_url?>"><i class="fa fa-twitter fa_twitter_share" data-class="fa_twitter_share"></i></a>
		</li>
		<li>
		<a href="<?php echo $p?>"><i class="fa fa-pinterest-p fa_pinterest_share" data-class="fa_pinterest_share"></i></a>
		</li>
		<li>
		<a href="<?php echo $g_plus?>"><i class="fa fa-google-plus fa_google_plus_share" data-class="fa_google_plus_share"></i></a>
		</li>	
	</ul>
	<div class="my_post_share_arrow"></div>
    
</div>
	</div>
<i class="fa fa-share" ></i>
<span class="my_post_templates_share_text"><?php echo __("Share","my_support_theme")?></span>
</li>