<?php
if(!defined('ABSPATH'))die('');
?>
<li class="my_post_hearts" data-i="{post_hearts}" data-is="0">
	<i class="fa fa-heart"></i>
	<span class="my_post_templates_hearts">{post_hearts}</span>
</li>