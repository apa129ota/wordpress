<?php
if(!defined('ABSPATH'))die('');
if(!isset($link_target)){
    $link_target="_blank";
}
if($is_woo){
    if(!isset($my_woo_add_cart_text)){
	   $my_woo_add_cart_text=__("Add to cart","my_support_theme");
    }
    if(!isset($my_woo_view_text)){
	   $my_woo_view_text=__("View Product","my_support_theme");    
    }
}else {
    if(!isset($my_woo_view_text)){
        $my_woo_view_text=__("View Post","my_support_theme");
    }   
}
?>
<div data-id="<?php echo $post_id?>" class="my_post_row my_woo_data_row" data-key="woo_data">
	<ul class="my_woo_data  my_post_clear">
		<?php if(!$is_woo){?>
		<li class="my_woo_view_post my_transition">
			<a class="my_woo_view_a" href="<?php echo $post_url;?>" target="<?php echo $link_target;?>" title="<?php echo __("View Post","my_support_theme")?>"><?php echo $my_woo_view_text;?></a>
		</li>
		<?php }else {?>	
		<li class="my_woo_view my_transition">
			<a class="my_woo_view_a" href="<?php echo $post_url;?>" target="<?php echo $link_target;?>" title="<?php echo __("View Product","my_support_theme")?>"><?php echo $my_woo_view_text;?></a>
		</li>
			<li class="my_woo_add_to_cart my_transition">
			<a class="my_woo_add_to_cart_a" href="#javascript" title="<?php echo __("Add product to cart","my_support_theme")?>" data-id="<?php echo $post_id?>"><i class="fa fa-cart-plus"></i>&nbsp;&nbsp;<?php echo $my_woo_add_cart_text;?></a>
		</li>		
		<?php }?>
	</ul>
</div>
