<?php
if (! defined('ABSPATH'))
    die('');
$cssProperties['added'] = array(
    'width' => array(),
    'height' => array(),
    'bg_color' => array(
        'tag' => 'background-color'
    ),
    'list_style_type'=>array(),
    'list_style_image'=>array(),
    'list_style_position'=>array(),
    'bg_hover_color_transition'=>array(),
    'color_hover_transition'=>array(),
    'display' => array(),
    'position' => array(),
    'left' => array(),
    'right' => array(),
    'bottom' => array(),
    'top' => array(),
    'filter' => array(),
    'font_family' => array(),
    '' => array(),
    'padding' => array(),
    'margin' => array(),
    'width' => array(),
    'height' => array(),
    'float' => array(),
    'border_bottom' => array(),
    'border_top' => array(),
    'border' => array(),
    'border_left' => array(),
    'border_right' => array(),
    'border_radius' => array(
        'prefix' => array(
            '',
            '-webkit-',
            '-moz-'
        )
    ),
    'box_shadow' => array(
        
    ),
    'bg_image'=>array(
        'tag'=>'background-image'
    ),
    'bg_repeat'=>array(
        'tag'=>'backgorund-repeat'
    ),
    'bg_hover_color'=>array(
        'tag'=>'background-color'
    ),
    'list_style'=>array(),
    'font_size'=>array(),
    'line_height'=>array(),
    'font_weight'=>array(),
    'font_style'=>array(),
    'color'=>array(),
    'hover_color'=>array(),
    'align'=>array(),
    'text_decoration'=>array(),
    'vertical_align'=>array(),
    'letter_spacing'=>array(),
    'word_wrap'=>array(),
    'overflow'=>array(),
    'overflow-x'=>array(),
    'overflow-y'=>array(),
    'background_position'=>array(),
    'background_size'=>array(),
    'backgorund_origin'=>array(),
    'vertical_align'=>array(),
    'z_index'=>array(),
    'text_shadow'=>array()
);

return $cssProperties;