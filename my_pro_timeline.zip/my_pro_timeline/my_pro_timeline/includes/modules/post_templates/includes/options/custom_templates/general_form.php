<?php
if (! defined('ABSPATH'))
    die('');
$template_form=array(
  /*  'builder_work'=>array(
        'layout_class'=>'my_col_50',
        'title'=>__("Builder Expert mode","my_support_theme"),
        'tooltip'=>__("If you enable expert mode you will have all options to define template"),
        'default'=>0,
        'type'=>'checkbox',
        'label' => __("Expert mode", "my_support_theme"),
    ),*/
    'thumb_effect'=>array(
            'layout_class'=>'my_col_50',
            'title'=>__("Thumb Effect","my_support_theme"),
            'tooltip'=>__("This effect is supported starting from browsers versions :<br/> chrome 18 ,edge 13,Firefox 35, Safari 6.0 "),
            'type'=>'jscript_radio_list',
            'jscript'=>array(
                'max_c'=>1,
                'max_sel'=>__("Maximum elements are selected","my_support_theme"),
                'duration'=>500,
                'animation'=>'fadein',
                'choose_value'=>__("Plese Select value","my_support_theme"),
             ),
            'show_filter'=>0,
            'multiple'=>false,
            'choose_value'=>__("Plese Select value","my_support_theme"),
            'default'=>'none',
            'values'=>array(
                'gray'=>__("From gray to color","my_support_theme"),
                'color'=>__("From color to gray","my_support_theme"),
                'none'=>__("None","my_suport_theme")
            )
        )
    );
return $template_form;