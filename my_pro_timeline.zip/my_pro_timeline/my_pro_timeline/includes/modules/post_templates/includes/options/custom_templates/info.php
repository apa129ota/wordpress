<?php
if(!defined('ABSPATH'))die('');
$info=array(
    'team_1'=>array(
        'title'=>__("Team template 1","my_support_theme"),
        'descr'=>__("Post Title","my_support_theme"),
        'cat'=>__("Team Template","my_support_theme")
    ),
    
);
return $info;