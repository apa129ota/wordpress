<?php
if(!defined('ABSPATH'))die('');
$arr['backend']=array(
	'controller_file'=>'class-my-controller.php',
	'controller_name'=>'Class_My_Post_Templates_Backend_Controller',
	'my_actions'=>array(
		'save_template'=>array(
	        'is_logged'=>1,
	        'capability'=>'manage_options'

	    ),
	    'load_video'=>array(
	        'is_logged'=>1,
	        'capability'=>'manage_options'
	    ),
	    'my_get_link'=>array(
	        'is_logged'=>1,
	        'capability'=>'manage_options',
	        'nonce_str'=>'my_list_autocomplete'
	    )
	)
);
return $arr;