<?php
if (! defined('ABSPATH'))
    die('');
/*
 * $templates['defaults']=array(
 * 'names'=>array('John Doe','John Smith','Mary Doe','Mary Smith'),
 * 'thumbs'=>array(
 * 'people'=>array('man-1.jpg','man-2.jpg','woman.jpg')
 * ),
 * 'position'=>array('director','designer','web developer'),
 * 'post_content'=>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
 *
 * Pri quas audiam virtute ut, case utamur fuisset eam ut, iisque accommodare an eam. Reque blandit qui eu, cu vix nonumy volumus. Legendos intellegam id usu, vide oporteat vix eu, id illud principes has. Nam tempor utamur gubergren no.
 *
 * Ex soleat habemus usu, te nec eligendi deserunt vituperata. Natum consulatu vel ea, duo cetero repudiare efficiendi cu. Has at quas nonumy facilisis, enim percipitur mei ad. Mazim possim adipisci sea ei, omnium aeterno platonem mei no.
 *
 * Consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
 *
 * Nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
 * "
 * );
 */
$template = array(
    'parent_grid' => array(
        'padding' => "20px 20px 20px 45px"
    ),
    'styles' => array(
        'default' => array(
            'title' => __("Default Style", "my_support_theme"),
            'img' => ''
        ),
        'style_1' => array(
            'title' => __("White", "my_support_theme"),
            'img' => ''
        )
    
    ),
    'groups'=>array(
      'social_icons'=>array(
          'title'=>__("Social Icons", "my_support_theme"),
          'elements'=>array(
              'div'=>array(
                'title'=>__("Social Div", "my_support_theme"),
                'selector'=>'.my_webs >div',
                'css_rules'=>array(
                      'style_1' => array(   
                       'bg_hover_color' => '#e74b3c,1'
                      ),
                  'display' => 'inline-block',
                  'margin' => '0px 10px 0px 0px',
                  'padding' => '5px',
                  'bg_hover_color' => '#559fc8,0.8'
              )
             ),
             'i'=>array(
                 'title'=>__("Social Icon", "my_support_theme"),
                 'selector'=>'.my_webs > div i.fa',
                 'css_rules' => array(
                     'style_1' => array(
                         'color' => '#818181,1',
                         'hover_color' => '#ffffff,1'
                         
                     ),
                     
                     'color' => '#ffffff,1',
                     'hover_color' => '#ffffff,0.8',
                     'font_size' => '22px',
                     'line_height' => '22px'
                 )
             ) 
          )
      )  
    ),
    'template_form' => array(
        'builder_work','thumb_effect'
    ),
    'template' => array(
        'w' => 320,
        'h' => 450,
        'data' => array(
            'm_custom_scroll' => 1,
            'title' => __("Template", "my_support_theme")
        ),
        'css_rules' => array(
            
            'style_1' => array(
                'bg_color' => '#ffffff,1',
                'border' => "1px solid #818181",
                    'box_shadow' => array(
                        'type' => 'hover',
                        array(
                            'h_shadow' => '0px',
                            'v_shadow' => '14px',
                            'blur' => '45px',
                            'spread' => '',
                            'color' => '#818181,0.247059'
                        
                        ),
                        array(
                            'h_shadow' => '0px',
                            'v_shadow' => '10px',
                            'blur' => '18px',
                            'spread' => '',
                            'color' => '#818181,0.219608'
                        )
                    )
                
            ),
            'position' => 'relative',
            'width' => '100%',
            'height' => '',
            'bg_color' => '#476c82,1',
            /*'bg_hover_color'=>'#476c82,0.9',
            'bg_hover_color_transition'=>'0.5s ease',
            */
            
            'box_shadow' => array(
                'type' => 'hover',
                array(
                    'h_shadow' => '0px',
                    'v_shadow' => '14px',
                    'blur' => '45px',
                    'spread' => '',
                    'color' => '#000000,0.247059'
                
                ),
                array(
                    'h_shadow' => '0px',
                    'v_shadow' => '10px',
                    'blur' => '18px',
                    'spread' => '',
                    'color' => '#000000,0.219608'
                )
            )
        )
    ),
    'post_tags' => array(
        'post_thumb' => array(
            'data' => array(
                'title' => __("Post thumb", "my_support_theme")
            ),
            'row' => array(
                'css_rules' => array(
                    
                    'w' => '400px',
                    'h' => '150px',
                    'width' => '100%',
                    'height' => '160px',
                    'padding' => '0px 0px 0px 0px',
                    'margin' => '0px',
                    'float' => 'none',
                    'bg_image' => '',
                    'bg_repeat' => '',
                    'bg_color' => '',
                    
                    'align' => 'center'
                )
            ),
            'css_rules' => array(
                'padding' => "5px 0px 5px 5px",
                'width' => '100%',
                'height' => '100%'
            ),
            'source' => 'people',
            
            'bg' => 1,
            
            'show_pretty' => 1,
            
            'children' => array(
                'post_bg' => array(
                    'data' => array(
                        'title' => __("Thumb", "my_support_theme")
                    ),
                    'ignore_html' => 1,
                    'css_rules' => array(
                        'style_1' => array(
                            'border' => array(
                                "border" => "2px solid #c4c4c4"
                            
                            )
                        ),
                        
                        /*'filter' => 'grayscale(100%)',*/
                        'ignore_html' => 1,
                        'width' => '150px',
                        'height' => '150px',
                        'display' => 'inline-block',
                        'border' => array(
                            "border" => "2px solid #ffffff",
                            'border_radius' =>'50%'
                        ),
                        
                    )
                )
            )
        
        ),
        'user_data' => array(
            'data' => array(
                'title' => __("Team member data", "my_support_theme")
            ),
            'row' => array(
                'css_rules' => array(
                    'padding' => '0px 0px 10px 0px',
                    'margin' => '0px',
                    'width' => '100%',
                    'height' => ''
                
                ),
               
            ),
            'css_rules' => array(
                'margin'=>'0px'
            ),
            'children' => array(
                'div' => array(
                    'data' => array(
                        'title' => __("Team member data Div", "my_support_theme")
                    ),
                    'css_rules' => array(
                        'padding' => '0px 0px 0px 0px',
                        'margin' => '0px',
                        'width' => '100%',
                        'height' => '100%',
                        'align' => 'center'
                    ),
                    'no_content' => '',
                    'children' => array(
                        /*'icon' => array(
                            'tag' => 'i',
                            'class' => array(
                                'fa',
                                'fa-hand-o-top'
                            ),
                            'css_rules' => array(
                                'color' => '#ffffff,1',
                                'hover_color' => '#ffffff,0.8',
                                'font_size' => '22px',
                                'line_height' => '22px'
                            )
                        ),*/
                        'name' => array(
                            'tag' => 'div',
                            'data' => array(
                                'title' => __("Team Name", "my_support_theme")
                            ),
                            'css_rules' => array(
                                'style_1' => array(
                                    'color' => '#818181,1',
                                    'hover_color' => '#818181,0.8',
                                    'hover_color_transition' => '0.5s ease'
                                
                                ),
                                'color' => '#ffffff,1',
                                'hover_color' => '#ffffff,0.8',
                                'hover_color_transition' => '0.5s ease',
                                'font_weight' => '600',
                                'padding' => "0px 0px 10px 0px",
                                
                                // 'color' => '#559fca,1',
                                // 'hover_color' => '#559fca,0.8',
                                'font_size' => '18px',
                                'line_height' => '22px'
                            
                            )
                        
                        ),
                        
                        'position' => array(
                            'tag' => 'div',
                            'data' => array(
                                'title' => __("Team member position", "my_support_theme")
                            ),
                            'css_rules' => array(
                                'style_1' => array(
                                    'color' => '#c4c4c4,1',
                                    'hover_color' => '#c4c4c4,0.8'
                                ),
                                'color' => '#57a6d4,1',
                                'hover_color' => '#57a6d4,0.8',
                                'hover_color_transition' => '0.5s ease',
                                'font_size' => '18px',
                                'line_height' => '22px',
                                'word_wrap' => 'break-word'
                            )
                        ),
                        'my_hr' => array(
                            'tag' => 'div',
                            'data' => array(
                                'title' => __("Line", "my_support_theme")
                            ),
                            'no_content' => 1,
                            'css_rules' => array(
                                'style_1' => array(
                                    'border' => array(
                                        'bottom' => "2px solid #818181"
                                    )
                                ),
                                'border' => array(
                                    'bottom' => "2px solid #ffffff"
                                ),
                                'display' => 'inline-block',
                                'width' => '15%'
                            )
                        ),
                        'my_projects' => array(
                            'tag' => 'div',
                            'children' => array(
                                'my_projects_a' => array(
                                    'tag' => 'a',
                                    'data' => array(
                                        'title' => __("Link to portfolio items", "my_support_theme")
                                    ),
                                    'attrs' => array(
                                        'href' => '#'
                                    ),
                                    'html' => __("Portfolio", "my_support_theme"),
                                    'css_rules' => array(
                                        'style_1' => array(
                                            'color' => '#c4c4c4,1',
                                            'hover_color' => '#c4c4c4,0.8'
                                        ),
                                        'text_decoration'=>'none',
                                        'color' => '#ffffff,1',
                                        'hover_color' => '#fffff,0.8',
                                        'hover_color_transition' => '0.5s ease',
                                        'font_size' => '18px',
                                        'line_height' => '22px',
                                        'word_wrap' => 'break-word'
                                    )
                                )
                            )
                        )
                    )
                )
            
            )
        ),
        'webs' => array(
            'shortcode_actions'=>array(
              'my_add_icon'=>array(
                  'tooltip'=>__("Add new Social Icon","my_support_theme"),
                  'class'=>array(
                      'fa','fa-plus'
                  )
              ),
              'group'=>array(
                  'selector'=>'.my_webs i.fa',
                  
                  'tooltip'=>__("Group","my_support_theme"),
                  'class'=>array(
                      'fa','fa-object-group'
                  )
              ),  
              'reorder'=>array(
                  'tooltip'=>__("Sort icons","my_support_theme"),
                  //'tag'=>'i',
                  'class'=>array(
                      'fa','fa-sort'
                  ),
                  
              ),
              
            ),
            'row' => array(
                'css_rules' => array(
                    'style_1' => array(
                        'color' => '#e4e4e4,1',
                        'hover_color' => '#e4e4e4,0.8'
                    ),
                    'width' => '100%',
                    'padding' => '9px 0px 9px 0px',
                    'bg_color' => '',
                /*'border'=>array(
                 'top'=>'2px solid #ffffff'
                 ),*/
                'align' => 'center',
                    'color' => '#ffffff,1',
                    'hover_color' => '#ffffff,0.8',
                    'font_size' => '22px',
                    'line_height' => '22px',
                    'height' => '40px',
                    'overflow' => 'hidden'
                )
            ),
            'data' => array(
                'title' => __("Social icons", "my_support_theme")
            ),
            'children' => array(
                'web' => array(
                    'tag' => 'div',
                    'data' => array(
                        'title' => __("Web", "my_support_theme")
                    ),
                    'css_rules' => array(
                        'style_1' => array(
                            
                            'bg_hover_color' => '#e74b3c,1'
                        
                        ),
                        'display' => 'inline-block',
                        'margin' => '0px 10px 0px 0px',
                        'padding' => '5px',
                        'bg_hover_color' => '#559fc8,0.8'
                    ),
                    'children' => array(
                        'a' => array(
                            'tag' => 'a',
                            'attrs' => array(
                                'href' => '#'
                            ),
                            'no_content' => 1,
                            'children' => array(
                                'web_i' => array(
                                    'data' => array(
                                        'title' => __("Web icon", "my_support_theme")
                                    ),
                                    'tag' => 'i',
                                    'class' => array(
                                        'fa',
                                        'fa-globe'
                                    ),
                                    'css_rules' => array(
                                        'style_1' => array(
                                            'color' => '#818181,1',
                                            'hover_color' => '#ffffff,1'
                                        
                                        ),
                                        
                                        'color' => '#ffffff,1',
                                        'hover_color' => '#ffffff,0.8',
                                        'font_size' => '22px',
                                        'line_height' => '22px'
                                    )
                                )
                            )
                        )
                    )
                
                ),
                'email' => array(
                    'tag' => 'div',
                    'data' => array(
                        'title' => __("Email", "my_support_theme")
                    ),
                    'css_rules' => array(
                        'style_1' => array(
                            
                            'bg_hover_color' => '#e74b3c,1'
                        
                        ),
                        'display' => 'inline-block',
                        'margin' => '0px 10px 0px 0px',
                        'padding' => '5px',
                        'bg_hover_color' => '#559fc8,0.8'
                    ),
                    'children' => array(
                        'a' => array(
                            'tag' => 'a',
                            'attrs' => array(
                                'href' => '#'
                            ),
                            'no_content' => 1,
                            'children' => array(
                                
                                'web_i' => array(
                                    'tag' => 'i',
                                    'class' => array(
                                        'fa',
                                        'fa-envelope'
                                    ),
                                    'data' => array(
                                        'title' => __("Email icon ", "my_support_theme")
                                    ),
                                    'css_rules' => array(
                                        'style_1' => array(
                                            'color' => '#818181,1',
                                            'hover_color' => '#ffffff,1'
                                        
                                        ),
                                        
                                        'color' => '#ffffff,1',
                                        'hover_color' => '#ffffff,0.8',
                                        'font_size' => '22px',
                                        'line_height' => '22px'
                                    )
                                )
                            )
                        )
                    )
                ),
                'facebook' => array(
                    'tag' => 'div',
                    'css_rules' => array(
                        'style_1' => array(
                            
                            'bg_hover_color' => '#e74b3c,1'
                        
                        ),
                        'data' => array(
                            'title' => __("Facebook ", "my_support_theme")
                        ),
                        'padding' => '5px',
                        'bg_hover_color' => '#559fc8,0.8',
                        'display' => 'inline-block',
                        'margin' => '0px 10px 0px 0px'
                    ),
                    'children' => array(
                        'a' => array(
                            'tag' => 'a',
                            'attrs' => array(
                                'href' => '#'
                            ),
                            'no_content' => 1,
                            'children' => array(
                                'web_i' => array(
                                    'data' => array(
                                        'title' => __("Facebook icon ", "my_support_theme")
                                    ),
                                    'tag' => 'i',
                                    'class' => array(
                                        'fa',
                                        'fa-facebook'
                                    ),
                                    'css_rules' => array(
                                        'style_1' => array(
                                            'color' => '#818181,1',
                                            'hover_color' => '#ffffff,1'
                                        
                                        ),
                                        
                                        'color' => '#ffffff,1',
                                        'hover_color' => '#ffffff,0.8',
                                        'font_size' => '22px',
                                        'line_height' => '22px'
                                    )
                                )
                            )
                        )
                    )
                ),
                'twitter' => array(
                    'tag' => 'div',
                    'data' => array(
                        'title' => __("Twitter", "my_support_theme")
                    ),
                    'css_rules' => array(
                        'style_1' => array(
                            
                            'bg_hover_color' => '#e74b3c,1'
                        
                        ),
                        'padding' => '5px',
                        'bg_hover_color' => '#559fc8,0.8',
                        'display' => 'inline-block',
                        'margin' => '0px 10px 0px 0px'
                    ),
                    'children' => array(
                        'a' => array(
                            'tag' => 'a',
                            'attrs' => array(
                                'href' => '#'
                            ),
                            'no_content' => 1,
                            'children' => array(
                                'web_i' => array(
                                    'data' => array(
                                        'title' => __("Twitter icon ", "my_support_theme")
                                    ),
                                    'tag' => 'i',
                                    'class' => array(
                                        'fa',
                                        'fa-twitter'
                                    ),
                                    'css_rules' => array(
                                        'style_1' => array(
                                            'color' => '#818181,1',
                                            'hover_color' => '#ffffff,1'
                                        
                                        ),
                                        
                                        'color' => '#ffffff,1',
                                        'hover_color' => '#ffffff,0.8',
                                        'font_size' => '22px',
                                        'line_height' => '22px'
                                    )
                                )
                            )
                        )
                    )
                ),
                'linkedin' => array(
                    'tag' => 'div',
                    'data' => array(
                        'title' => __("Linkedin", "my_support_theme")
                    ),
                    'css_rules' => array(
                        'style_1' => array(
                            
                            'bg_hover_color' => '#e74b3c,1'
                        
                        ),
                        'display' => 'inline-block',
                        'margin' => '0px 10px 0px 0px',
                        'padding' => '5px',
                        'bg_hover_color' => '#559fc8,0.8'
                    ),
                    'children' => array(
                        'a' => array(
                            'tag' => 'a',
                            'attrs' => array(
                                'href' => '#'
                            ),
                            'no_content' => 1,
                            'children' => array(
                                'web_i' => array(
                                    'tag' => 'i',
                                    'data' => array(
                                        'title' => __("Linkedin icon", "my_support_theme")
                                    ),
                                    'class' => array(
                                        'fa',
                                        'fa-linkedin'
                                    ),
                                    'css_rules' => array(
                                        'style_1' => array(
                                            'color' => '#818181,1',
                                            'hover_color' => '#ffffff,1'
                                        
                                        ),
                                        
                                        'color' => '#ffffff,1',
                                        'hover_color' => '#ffffff,0.8',
                                        'font_size' => '22px',
                                        'line_height' => '22px'
                                    )
                                )
                            )
                        )
                    )
                )
            
            )
        ),
        'post_content' => array(
            'data' => array(
                'title' => __("About data", "my_support_theme")
            ),
            'row' => array(
                'css_rules' => array(
                    'float'=>'none',
                    'padding' => '10px',
                    'margin' => '0px',
                    'width' => '100%',
                    'height' => '',
                    'bg_image' => '',
                    'bg_repeat' => '',
                    'bg_color' => ''
                )
            ),
            'css_rules' => array(
                'style_1' => array(
                    'color' => '#818181,1'
                ),
                'color' => '#ffffff,1',
                'font_size' => '16px',
                'line_height' => '20px'
            ),
            'predefined_classes' => array(
                'style_1' => array(
                    'mCSB_draggerRail' => array(
                        // 'bg_color' => '#212121,0.4'
                        'bg_color' => '#e74b3c,0.4'
                    ),
                    'mCSB_dragger_bar' => array(
                        // 'bg_color' => '#212121,0.8'
                        'bg_color' => '#e74b3c,0.8'
                    
                    )
                ),
                'mCSB_draggerRail' => array(
                    
                    // 'bg_color' => '#212121,0.4'
                    'bg_color' => '#559fca,0.4'
                ),
                'mCSB_dragger_bar' => array(
                    // 'bg_color' => '#212121,0.8'
                    'bg_color' => '#559fca,0.8'
                
                )
            )
        )
    )

);
return $template;