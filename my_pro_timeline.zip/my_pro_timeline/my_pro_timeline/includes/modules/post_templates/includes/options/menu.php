<?php
if(!defined('ABSPATH'))die('');

$menu=array(
    'admin_pages'=>array(
        'controller'=>array(
            'file'=>'class-my-page-controller.php',
            'class'=>'Class_My_Module_Post_Templates_Page_Controller'
        ),
        'my_pro_timeline_templates'=>array(
            'page_title'=>__("Templates","my_support_theme"),
            'menu_title'=>__("Templates","my_support_theme"),
            'capability'=>'manage_options',
            'is_logged'=>true,
            'template'=>'',
            'parent'=>'my_pro_timeline',//specify parent menu if you want
            'styles'=>array(
                'my_table_view_css'=>'{modules_url}tableview/assets/css/admin.css',
                'my_admin_css'=>'{css_url)admin.css',
                'my_admin_menu_css'=>'{css_url}admin_menu.css',
                'my_jquery_ui'=>'{css_url}jquery-ui.css'
            ),
            'scripts'=>array(
                'my_general_js'=>'{jscript_url}admin/my_general.js',
                'my_easing'=>'{jscript_url}jquery.easing.1.3.js'
            ),
            
        ),
        /*
        'my_pro_grid_new_templates'=>array(
            'page_title'=>__("Templates","my_support_theme"),
            'menu_title'=>__("Templates","my_support_theme"),
            'capability'=>'manage_options',
            'is_logged'=>true,
            'template'=>'',
            'parent'=>'my_pro_social_stream',//specify parent menu if you want
            'styles'=>array(
                'my_table_view_css'=>'{modules_url}tableview/assets/css/admin.css',
                'my_admin_css'=>'{css_url)admin.css',
                'my_admin_menu_css'=>'{css_url}admin_menu.css',
                'my_jquery_ui'=>'{css_url}jquery-ui.css'
            ),
            'scripts'=>array(
                'my_general_js'=>'{jscript_url}admin/my_general.js',
                'my_easing'=>'{jscript_url}jquery.easing.1.3.js'
            ),
            
        ),*/
       
));
return $menu;
