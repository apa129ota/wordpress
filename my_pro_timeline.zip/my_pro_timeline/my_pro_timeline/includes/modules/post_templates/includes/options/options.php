<?php
if(!defined('ABSPATH'))die('');
$o=array(
    'page_url'=>admin_url('admin.php?page=my_pro_grid_templates'),
);
return $o;