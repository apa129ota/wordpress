<?php
if (! defined('ABSPATH'))
    die('');
$units = array(
    'px' => 'px',
    '%' => '%',
    'px' => 'px',
    'cm' => 'cm',
    'mm' => 'mm',
    'in' => 'in',
    'pt' => 'pt',
    'pc' => 'pc',
    'ch' => 'ch',
    'em' => 'em'
);
$units1 = array(
    'px' => 'px',
    '%' => '%'
);
$templates['shortcodes'] = array();
$templates['shortcodes'] = array(
    'post_title' => array(
        'type' => 'post',
        'title' => __("Post Title", "my_support_theme")
    ),
    'post_date' => array(
        'type' => 'post',
        'title' => __("Post Date", "my_support_theme")
    ),
    'post_woo_price' => array(
        'type' => 'woo',
        'title' => __("Product price", "my_support_theme")
    ),
    'post_thumb' => array(
        'type' => 'post',
        'title' => __("Post thumbnail", "my_support_theme")
    ),
    'woo_data' => array(
        'type' => 'post',
        'title' => __("Post Link and woocommerce links", "my_support_theme")
    ),
    'post_content' => array(
        'type' => 'post',
        'title' => __("Post Content", "my_support_theme")
    ),
    'post_meta' => array(
        'type' => 'post',
        'title' => __("Post Meta", "my_support_theme")
    )

);
$templates['actions'] = array(
    'box' => array(
    )
);
$font_style = array(
    'normal' => __("Normal", "my_support_theme"),
    'italic' => __("Italic", "my_support_theme"),
    'oblique' => __("Oblique", "my_support_theme")

);
$text_decoration = array(
    'none' => __("None", "my_support_theme"),
    'underline' => __("Underline", "my_support_theme"),
    'overline' => __("Overline", "my_support_theme"),
    'line-through' => __("Line Through", "my_support_theme")

);
$templates['form'] = array(
    'width' => array(
        'title' => __("Dialog width", "my_support_theme"),
        'type' => 'text',
        'default' => '400',
        'layout_class' => 'my_col_50',
        'tooltip' => __("Post width in pixel units.", "my_support_theme")
    
    ),
    'height' => array(
        'tooltip' => __("Post height in pixel units.", "my_support_theme"),
        'title' => __("Dialog height", "my_support_theme"),
        'type' => 'text',
        'default' => '400',
        'layout_class' => 'my_col_50'
    ),
    'post_type' => array(
        'layout_class' => 'my_col_50',
        'type' => 'jscript_dropdown',
        'title' => __("Post type", "my_support_theme"),
        'tooltip' => __("Set template post type", "my_support_theme"),
        'jscript' => array(
            'max_c' => 1,
            'max_sel' => __("Maximum elements are selected", "my_support_theme"),
            'duration' => 500,
            'animation' => 'fadein',
            'choose_value' => __("Plese Select value", "my_support_theme")
        ),
        'show_filter' => 0,
        'multiple' => false,
        'choose_value' => __("Plese Select value", "my_support_theme"),
        'default' => 'post'
        /*
     * 'values'=>array(
     * 'left'=>__("Left","my_support_theme"),
     * 'right'=>__("Right","my_support_theme"),
     * 'center'=>__("Center","my_support_theme")
     * )
     */
    
    ),
    'template' => array(
        'layout_class' => 'my_col_50',
        'type' => 'jscript_dropdown',
        'title' => __("Templates", "my_support_theme"),
        'tooltip' => __("Load predefined template, and adjust styles", "my_support_theme"),
        'jscript' => array(
            'max_c' => 1,
            'max_sel' => __("Maximum elements are selected", "my_support_theme"),
            'duration' => 500,
            'animation' => 'fadein',
            'choose_value' => __("Plese Select value", "my_support_theme")
        ),
        'show_filter' => 0,
        'multiple' => false,
        'choose_value' => __("Plese Select value", "my_support_theme"),
        'default' => 'template_1',
        'values' => array(
            'template_11'=>__("Full image","my_support_theme"),
            'template_1' => __("Template 1", "my_support_theme"),
            'template_2' => __("Template 2", "my_support_theme"),
            //'template_3' => __("Template Three", "my_support_theme"),
            //'template_4' => __("Template Four", "my_support_theme"),
            //'template_5' => __("Template Five", "my_support_theme"),
            'template_6' => __("Template 3", "my_support_theme"),
            //'template_7' => __("Template Seven", "my_support_theme"),
            'template_8' => __("Template 4", "my_support_theme"),
            'template_10' => __("Blue Template", "my_support_theme")
        )
    
    ),
    /*
    'font_family' => array(
        'layout_class' => 'my_col_50',
        'type' => 'jscript_dropdown',
        'title' => __("Font", "my_support_theme"),
        'tooltip' => __("Choose default font or some google fonts", "my_support_theme"),
        'jscript' => array(
            'max_c' => 1,
            'max_sel' => __("Maximum elements are selected", "my_support_theme"),
            'duration' => 500,
            'animation' => 'fadein',
            'choose_value' => __("Plese Select value", "my_support_theme")
        ),
        'show_filter' => 1,
        'multiple' => false,
        'choose_value' => __("Plese Select value", "my_support_theme"),
        'default' => 'default',
        'translate' => array(
            'class' => '.my_testimonial_item *:not(i)',
            'property' => 'font-family'
        )
        
    ),
    */
    'use_expert' => array(
        'layout_class' => 'my_col_50',
        'type' => 'checkbox',
        'default' => 0,
        'title' => __("Use expert Builder", "my_support_theme"),
        'tooltip' => __("More options will be available for expert buider.", "my_support_theme"),
        
        'label' => __("Expert builder", "my_support_theme")
    
    )
    /*
 * 'slider_template'=>array(
 * 'layout_class'=>'my_col_50',
 * 'type'=>'jscript_dropdown',
 * 'title'=>__("Slider Templates","my_support_theme"),
 * 'tooltip'=>__("Load predefined slider template, and adjust styles","my_support_theme"),
 * 'jscript'=>array(
 * 'max_c'=>1,
 * 'max_sel'=>__("Maximum elements are selected","my_support_theme"),
 * 'duration'=>500,
 * 'animation'=>'fadein',
 * 'choose_value'=>__("Plese Select value","my_support_theme"),
 * ),
 * 'show_filter'=>0,
 * 'multiple'=>false,
 * 'choose_value'=>__("Plese Select value","my_support_theme"),
 * 'default'=>'slider_1',
 * 'values'=>array(
 * 'slider_1'=>__("Only image","my_support_theme"),
 * 'slider_2'=>__("Image and title","my_support_theme"),
 * 'slider_3'=>__("Image title and short description","my_support_theme"),
 * 'slider_4'=>__("Image title and full description","my_support_theme")
 *
 *
 * )
 * )
 */

);
$templates['sections'] = array(
    'elements' => array(
        
        'sections' => array(
            'box' => array(
                'title' => __("Box", "my_support_theme")
            
            ),
            /*'list'=>array(
                'title' => __("List", "my_support_theme")
                
            ),*/
            'border' => array(
                'title' => __("Border", "my_support_theme")
            
            ),
            'icon' => array(
                'title' => __("Icon", "my_support_theme")
            
            ),
            'text' => array(
                'title' => __("Text properties", "my_support_theme")
            ),
						/*'thumb'=>array(
								'title'=>__("Thumb properties","my_support_theme"),
						),*/
						'margin' => array(
                'title' => __("Margin", "my_support_theme")
            ),
            'padding' => array(
                'title' => __("Padding", "my_support_theme")
            ),
            /*'slider' => array(
                'title' => __("Slider styles", "my_support_theme")
            
            )*/
        
        )
    )
);
/*
$templates['predefined']['list']=array(
    'list_icon'=>array(
        'type' => 'jscript_dropdown',
        'jscript' => array(
            'max_c' => 1,
            'max_sel' => __("Maximum elements are selected", "my_support_theme"),
            'duration' => 500,
            'animation' => 'fadein',
            'choose_value' => __("Plese Select value", "my_support_theme")
        ),
        'show_filter' => 1,
        'multiple' => false,
        'choose_value' => __("Plese Select value", "my_support_theme"),
        
        'tooltip' => __("List style icon", "my_support_theme"),
        'title' => __("List style icon", "my_support_theme"),
        'default'=>'fa-plus'
    ),
    'list_style_position' => array(
        'type' => 'jscript_dropdown',
        'jscript' => array(
            'max_c' => 1,
            'max_sel' => __("Maximum elements are selected", "my_support_theme"),
            'duration' => 500,
            'animation' => 'fadein',
            'choose_value' => __("Plese Select value", "my_support_theme")
        ),
        'show_filter' => 0,
        'multiple' => false,
        'choose_value' => __("Plese Select value", "my_support_theme"),
        
        'tooltip' => __("List style type", "my_support_theme"),
        'title' => __("List style type", "my_support_theme"),
        'values' => array(
            'inherit' => __("Inherit", "my_support_theme"),
            'inside'=> __("Inside", "my_support_theme"),
            'outside'=> __("Outside", "my_support_theme"),
            
        ),
        'default' => 'none'
    ),
    
    'list_style_image'=>array(
        'type' => 'thumb',
        'tooltip' => __("Image", "my_support_theme"),
        'title' => __("Thumb", "my_support_theme"),
        'property' => array(
            'class' => '{class}',
            'property' => 'background'
        ),
        'choose_title' => __("Change Thumb", "my_related_posts_domain"),
        'no_image' => __("No Image", "my_related_posts_domain"),
        'choose_title' => __("Choose Media", "my_related_posts_domain"),
        'remove' => __("Remove Media", "my_related_posts_domain"),
        'jscript' => array(
            'can_remove' => true,
            'multiple' => 0,
            'show_values' => 1,
            'max_c' => 1,
            'choose_title' => __("Choose Media", "my_related_posts_domain"),
            'media_title' => __("Choose Image", "my_related_posts_domain"),
            'button_text' => __("Insert", "my_related_posts_domain"),
            'filter_type' => 'image' // audio video image
            
        )
    ),
    'list_style_type' => array(
        'type' => 'jscript_dropdown',
        'jscript' => array(
            'max_c' => 1,
            'max_sel' => __("Maximum elements are selected", "my_support_theme"),
            'duration' => 500,
            'animation' => 'fadein',
            'choose_value' => __("Plese Select value", "my_support_theme")
        ),
        'show_filter' => 0,
        'multiple' => false,
        'choose_value' => __("Plese Select value", "my_support_theme"),
        
        'tooltip' => __("List style type", "my_support_theme"),
        'title' => __("List style type", "my_support_theme"),
        'values' => array(
            'none' => __("None", "my_support_theme"),
            'disc' => __("Disc", "my_support_theme"),
            'armenian' => __("Armenian", "my_support_theme"),
            'circle' => __("Circle", "my_support_theme"),
            'cjk-ideographic' => __("Cjk ideographic", "my_support_theme"),
            'decimal' => __("Decimal", "my_support_theme"),
            'decimal-leading-zero' => __("Decimal leading zero", "my_support_theme"),
            'georgian' => __("Georgian", "my_support_theme"),
            'hebrew' => __("Hebrew", "my_support_theme"),
            'hiragana' => __("Hiragana", "my_support_theme"),
            'hiragana-iroha' => __("Hiragana iroha", "my_support_theme"),
            'katakana' => __("None", "my_support_theme"),
            'katakana-iroha' => __("Katakana iroha", "my_support_theme"),
            'lower-alpha' => __("Lower alpha", "my_support_theme"),
            'lower-greek' => __("Lower greek", "my_support_theme"),
            'lower-latin' => __("Lower latin", "my_support_theme"),
            'lower-roman' => __("Lower roman", "my_support_theme"),
            'square' => __("Square", "my_support_theme"),
            'upper-alpha' => __("Upper alpha", "my_support_theme"),
            'upper-greek' => __("Upper greek", "my_support_theme"),
            'upper-latin' => __("Upper latin", "my_support_theme"),
            'upper-roman' => __("Upper roman", "my_support_theme"),
            
            
        ),
        'default' => 'none'
    ),
    
);*/
$templates['predefined']['box'] = array(
    'width' => array(
        'title' => __("Width", "my_support_theme"),
        'type' => 'jscript_spinner',
        'property' => 'height',
        'default' => '100',
        'default_unit' => '%',
        'units' => $units1,
        'translate' => array(
            'class' => '.my_post_thumb',
            'property' => 'width'
        )
    ),
    'height' => array(
        'type' => 'multi',
        'title' => __("Height", "my_support_theme"),
        'elements' => array(
            'auto' => array(
                'css' => array(
                    'width' => '30px'
                ),
                'type' => 'checkbox',
                'default' => 1,
                'label' => __("Auto", "my_support_theme"),
                'translate' => array(
                    'class' => '{class}',
                    'property' => 'height'
                )
            ),
            'choose' => array(
                'css' => array(
                    'display:none'
                ),
                
                'type' => 'jscript_spinner',
                'property' => 'height',
                'default' => '100',
                'default_unit' => 'px',
                'units' => $units1,
                'translate' => array(
                    'class' => '{class}',
                    'property' => 'height'
                )
            )
        
        )
    ),
    'display'=>array(
     'type'=>'jscript_dropdown',
     'jscript'=>array(
     'max_c'=>1,
     'max_sel'=>__("Maximum elements are selected","my_support_theme"),
     'duration'=>500,
     'animation'=>'fadein',
     'choose_value'=>__("Plese Select value","my_support_theme"),
     ),
     'show_filter'=>0,
     'multiple'=>false,
     'choose_value'=>__("Plese Select value","my_support_theme"),
     'default'=>'block',
     'tooltip'=>__("Display","my_support_theme"),
     'title'=>__("Display","my_support_theme"),
     'values'=>array(
     'none'=>__("None","my_support_theme"),
     'block'=>__("Block","my_support_theme"),
     'inline'=>__("Inline","my_support_theme"),
     'inline-block'=>__("Inline Block","my_support_theme"),

     //'repeat-y'=>__("Repat Y","my_support_theme"),
     ),
        
     ),
		/*'float'=>array(
				'type'=>'jscript_dropdown',
				'jscript'=>array(
						'max_c'=>1,
						'max_sel'=>__("Maximum elements are selected","my_support_theme"),
						'duration'=>500,
						'animation'=>'fadein',
						'choose_value'=>__("Plese Select value","my_support_theme"),
				),
				'show_filter'=>0,
				'multiple'=>false,
				'choose_value'=>__("Plese Select value","my_support_theme"),
				'default'=>'static',
				'tooltip'=>__("Float element","my_support_theme"),
				'title'=>__("Float","my_support_theme"),
				'values'=>array(
					'none'=>__("None","my_support_theme"),
					'left'=>__("Left","my_support_theme"),
					'right'=>__("Right","my_support_theme"),
					//'repeat-y'=>__("Repat Y","my_support_theme"),
				),
				'defaault'=>'left'
			),
			*/
		'bg_image' => array(
        'type' => 'thumb',
        'tooltip' => __("Background image", "my_support_theme"),
        'title' => __("Background Image", "my_support_theme"),
        'property' => array(
            'class' => '{class}',
            'property' => 'background'
        ),
        'choose_title' => __("Change Thumb", "my_related_posts_domain"),
        'no_image' => __("No Image", "my_related_posts_domain"),
        'choose_title' => __("Choose Media", "my_related_posts_domain"),
        'remove' => __("Remove Media", "my_related_posts_domain"),
        'jscript' => array(
            'can_remove' => true,
            'multiple' => 0,
            'show_values' => 1,
            'max_c' => 1,
            'choose_title' => __("Choose Media", "my_related_posts_domain"),
            'media_title' => __("Choose Image", "my_related_posts_domain"),
            'button_text' => __("Insert", "my_related_posts_domain"),
            'filter_type' => 'image' // audio video image
        
        )
    ),
    
    'bg_repeat' => array(
        'type' => 'jscript_dropdown',
        'jscript' => array(
            'max_c' => 1,
            'max_sel' => __("Maximum elements are selected", "my_support_theme"),
            'duration' => 500,
            'animation' => 'fadein',
            'choose_value' => __("Plese Select value", "my_support_theme")
        ),
        'show_filter' => 0,
        'multiple' => false,
        'choose_value' => __("Plese Select value", "my_support_theme"),
        
        'tooltip' => __("Repat background", "my_support_theme"),
        'title' => __("Repeat background", "my_support_theme"),
        'label' => __("Repeat", "my_support_theme"),
        'values' => array(
            'no-repeat' => __("No repeat", "my_support_theme"),
            'repeat' => __("Repeat", "my_support_theme"),
            'repeat-x' => __("Repeat X", "my_support_theme"),
            'repeat-y' => __("Repeat Y", "my_support_theme")
        ),
        'default' => 'no-repeat'
    ),
    
    'bg_color' => array(
        'type' => 'jscript_color_picker',
        'tooltip' => __("Background Color", "my_support_theme"),
        'title' => __("Bg Color", "my_support_theme"),
        'pick_title' => __("Pick a Color", "my_support_theme"),
        'close_title' => __("Close", "my_support_theme"),
        'default' => array(
            'color' => '#000000',
            'transp' => 0
        ),
        'jscript' => array(
            'pick_title' => __("Pick a Color", "my_support_theme"),
            'close_title' => __("Close", "my_support_theme"),
            'hex_title' => __("Hex value", "my_support_theme"),
            'transp_title' => __("Transparency", "my_support_theme")
        ),
        'property' => array(
            'class' => '{class}',
            'property' => 'background'
        ),
        'transparency' => true
    ),
    'bg_hover_color' => array(
        'type' => 'jscript_color_picker',
        'tooltip' => __("Background Hover Color", "my_support_theme"),
        'title' => __("Hover Color", "my_support_theme"),
        'pick_title' => __("Pick a Color", "my_support_theme"),
        'close_title' => __("Close", "my_support_theme"),
        'default' => array(
            'color' => '#000000',
            'transp' => 0
        ),
        'jscript' => array(
            'pick_title' => __("Pick a Color", "my_support_theme"),
            'close_title' => __("Close", "my_support_theme"),
            'hex_title' => __("Hex value", "my_support_theme"),
            'transp_title' => __("Transparency", "my_support_theme")
        ),
        'property' => array(
            'class' => '{class}',
            'property' => 'background'
        ),
        'transparency' => true
    ),
    /*'bg_hover_transition'=>array(
        
    ),*/
    'box_shadow' => array(
        'tooltip' => __("Element box shadow", "my_support_theme"),
        'title' => __("Box Shadow", "my_support_theme"),
        'type' => 'jscript_box_shadow',
        'jscript' => array(
            'shadowText' => __("Shadow", "my_support_theme"),
            'myEdit'=> __("Edit", "my_support_theme"),
        ),
        'default' =>'none', /*array(
            'type'=>'hover',
            array(
                'h_shadow' => '0px',
                'v_shadow' => '14px',
                'blur' => '45px',
                'spread' => '',
                'color' => '#818181,0.247059',
                'inset'=>0
            ),
            array(
                'h_shadow' => '0px',
                'v_shadow' => '10px',
                'blur' => '18px',
                'spread' => '',
                'color' => '#818181,0.219608',
                'inset'=>0
            )
        ),*/
        'elements' => array(
            'myOnHover' => array(
                'css' => array(
                    'width' => '30px'
                ),
                'type' => 'checkbox',
                'default' => 0,
                'label' => __("On Hover show", "my_support_theme"),
                'translate' => array(
                    'class' => '{class}',
                    'property' => 'height'
                )
            ),
            'inset' => array(
                'css' => array(
                    'width' => '30px'
                ),
                'type' => 'checkbox',
                'default' => 0,
                'label' => __("inset", "my_support_theme"),
                'translate' => array(
                    'class' => '{class}',
                    'property' => 'height'
                )
            ),
            
            'h_shadow' => array(
                'title' => __("Horizontal", "my_support_theme"),
                'tooltip' => __("Horizontal position of shadow", "my_support_theme"),
                'type' => 'jscript_spinner',
                'property' => 'height',
                'default' => '0',
                'default_unit' => 'px',
                'units' => $units
            ),
            'v_shadow' => array(
                'title' => __("Vertical", "my_support_theme"),
                'tooltip' => __("Vertical Position of shadow", "my_support_theme"),
                
                'type' => 'jscript_spinner',
                'property' => 'height',
                'default' => '0',
                'default_unit' => 'px',
                'units' => $units
            ),
            'blur' => array(
                'title' => __("Blur", "my_support_theme"),
                'tooltip' => __("Blur position", "my_support_theme"),
                
                'type' => 'jscript_spinner',
                'property' => 'height',
                'default' => '0',
                'default_unit' => 'px',
                'units' => $units
            ),
            'spread' => array(
                'title' => __("Spread", "my_support_theme"),
                'tooltip' => __("Spread position of shadow", "my_support_theme"),
                
                'type' => 'jscript_spinner',
                'property' => 'height',
                'default' => '0',
                'default_unit' => 'px',
                'units' => $units
            ),
            'color' => array(
                'type' => 'jscript_color_picker',
                'tooltip' => __("Box Color", "my_support_theme"),
                'title' => __("Shadow Color", "my_support_theme"),
                'pick_title' => __("Pick a Color", "my_support_theme"),
                'close_title' => __("Close", "my_support_theme"),
                'default' => array(
                    'color' => '#000000',
                    'transp' => 0.1
                ),
                'jscript' => array(
                    'pick_title' => __("Pick a Color", "my_support_theme"),
                    'close_title' => __("Close", "my_support_theme"),
                    'hex_title' => __("Hex value", "my_support_theme"),
                    'transp_title' => __("Transparency", "my_support_theme")
                ),
                'property' => array(
                    'class' => '{class}',
                    'property' => 'background'
                ),
                'transparency' => true
            )
        
        )
    
    )
    /*
 * 'left'=>array(
 * 'title'=>__("Left position","my_support_theme"),
 * 'type'=>'jscript_spinner',
 * 'property'=>'height',
 * 'default'=>'0',
 * 'default_unit'=>'px',
 * 'units'=>$units1,
 * 'translate'=>array(
 * 'class'=>'.my_post_thumb',
 * 'property'=>'width'
 * )
 * ),
 * 'right'=>array(
 * 'title'=>__("Right position","my_support_theme"),
 * 'type'=>'jscript_spinner',
 * 'property'=>'height',
 * 'default'=>'0',
 * 'default_unit'=>'px',
 * 'units'=>$units1,
 * 'translate'=>array(
 * 'class'=>'.my_post_thumb',
 * 'property'=>'width'
 * )
 * ),
 * 'position'=>array(
 * 'type'=>'jscript_dropdown',
 * 'jscript'=>array(
 * 'max_c'=>1,
 * 'max_sel'=>__("Maximum elements are selected","my_support_theme"),
 * 'duration'=>500,
 * 'animation'=>'fadein',
 * 'choose_value'=>__("Plese Select value","my_support_theme"),
 * ),
 * 'show_filter'=>0,
 * 'multiple'=>false,
 * 'choose_value'=>__("Plese Select value","my_support_theme"),
 *
 * 'tooltip'=>__("Position","my_support_theme"),
 * 'title'=>__("Position","my_support_theme"),
 * 'label'=>__("Repeat","my_support_theme"),
 * 'values'=>array(
 * 'static'=>__("Static","my_support_theme"),
 * 'fixed'=>__("Fixed","my_support_theme"),
 * 'absolute'=>__("Absolute","my_support_theme"),
 * 'relative'=>__("Relative","my_support_theme"),
 * 'initial'=>__("Initial","my_support_theme"),
 * 'ihnerit'=>__("Relative","my_support_theme"),
 *
 *
 * ),
 * 'default'=>'no-repeat'
 * )
 */
);
$templates['predefined']['border'] = array(
    'border' => array(
        'type' => 'jscript_border',
        'title' => __('Border', "my_support_theme"),
        'tooltip' => __("Specify border clicking on rectangle and selecting some top left or right border", "support_theme"),
        'default' => array(
            'width' => '1px',
            'color' => '#000000',
            'style' => 'solid',
            'border_radius'=>'50%/25%'
        ),
        'elements' => array(
            /*'border_same_value'=>array(
                'title'=>__("Set all border values same", "my_support_theme"),
                'tooltip'=>__("If you uncheck this options you will have ability to specify different values for each border.", "my_support_theme"),
                'default'=>1,
                'type'=>'checkbox'
                
            ),*/
            'border_select'=>array(
                /*'css'=>array(
                  'display:none'  
                ),*/
                'outer_classes'=>array(
                  'my_new_form_select_border'  
                ),
                'title'=>__("Set values for", "my_support_theme"),
                'tooltip'=>__("Set value for top bottom right left border.If you check all all borders will have the same value.", "my_support_theme"),
                'type'=>'select',
               
                'default'=>'all',
                'multiple'=>false,
                'values'=>array(
                    'all'=>__("All borders", "my_support_theme"),
                    'top'=>__("Top Border", "my_support_theme"),
                    'right'=>__("Right Border", "my_support_theme"),
                    'bottom'=>__("Bottom Border", "my_support_theme"),
                    'left'=>__("Left Border", "my_support_theme"),
                    
                )
            ),
            
            'border_width' => array(
                'outer_classes'=>array(
                    'my_new_form_select_border_width'
                ),
                'title'=>__("Width", "my_support_theme"),
                'type' => 'jscript_spinner',
                'property' => 'height',
                'default' => '1',
                'default_unit' => 'px',
                'units' => $units
            ),
            
            'border_color' => array(
                'outer_classes'=>array(
                    'my_new_form_select_border_color'
                ),
                'title'=>__("Color", "my_support_theme"),
                'type' => 'jscript_color_picker',
                'pick_title' => __("Pick a Color", "my_support_theme"),
                'close_title' => __("Close", "my_support_theme"),
                'default' => '#000000',
                
                'jscript' => array(
                    'pick_title' => __("Pick a Color", "my_support_theme"),
                    'close_title' => __("Close", "my_support_theme"),
                    'hex_title' => __("Hex value", "my_support_theme"),
                    'transp_title' => __("Transparency", "my_support_theme")
                ),
                'property' => array(
                    'class' => '{class}',
                    'property' => 'background'
                ),
                'transparency' => false
            ),
            'border_type' => array(
                'outer_classes'=>array(
                    'my_new_form_select_border_type'
                ),
                'title'=>__("Type", "my_support_theme"),
                'type' => 'select',
                'default' => 'solid',
                'values' => array(
                    'dotted' => __("Dotted", "my_support_theme"),
                    'dashed' => __("Dashed", "my_support_theme"),
                    'solid' => __("Solid", "my_support_theme"),
                    'double' => __("Double", "my_support_theme"),
                    'groove' => __("Groove", "my_support_theme"),
                    'ridge' => __("Ridge", "my_support_theme"),
                    'inset' => __("Inset", "my_support_theme"),
                    'outset' => __("Outset", "my_support_theme"),
                    'none' => __("None", "my_support_theme"),
                    'hidden' => __("Hidden", "my_support_theme")
                
                )
            ),
            /*'border_radius_same_value'=>array(
                'title'=>__("All border radius will have same value", "my_support_theme"),
                'tooltip'=>__("If you uncheck this options you will have ability to specify different values for each border radius.", "my_support_theme"),
                'default'=>1,
                'type'=>'checkbox'
                
            ),*/
            
            'border_radius_select'=>array(
                /*'css'=>array(
                  'display:none'  
                ),*/
                'outer_classes'=>array(
                    'my_new_form_select_border_radius'
                ),
                'title'=>__("Set values for", "my_support_theme"),
                'tooltip'=>__("Set value for top-left top-right bottom-right or bottom-left border radius.Set values for all to set only one value.", "my_support_theme"),
                'type'=>'select',
                'default'=>'all',
                'multiple'=>false,
                
                'values'=>array(
                    'all'=>__("All border radius", "my_support_theme"),
                    'top_left'=>__("Top Left Border Radius", "my_support_theme"),
                    'top_right'=>__("Top Right Border Radius", "my_support_theme"),
                    'bottom_right'=>__("Bottom Right Border Radius", "my_support_theme"),
                    'bottom_left'=>__("Bottom Left Border Radius", "my_support_theme"),
                    
                )
            ),
            
            'border_radius_1'=>array(
                'outer_classes'=>array(
                    'my_new_form_select_border_radius_1'
                ),
                'title'=>__("Border radius top", "my_support_theme"),
                'tooltip'=>__("If you want symetric radius left second spinner empty or set same value as first spinner.", "my_support_theme"),
                'type' => 'jscript_spinner',
                'property' => 'height',
                'default' => '5',
                'default_unit' => 'px',
                'units' => $units
            ),
            
            'border_bottom_same_value'=>array(
                'outer_classes'=>array(
                    'my_new_form_select_border_bottom_same'
                ),
                'style'=>array('display:none'),
                'title'=>__("Same value for top bottom radius", "my_support_theme"),
                'tooltip'=>__("If you want to specify different values for bottom radius uncheck this checkbox .", "my_support_theme"),
                'type'=>'checkbox',
                'default'=>1,
            ),
            'border_radius_2'=>array(
                'outer_classes'=>array(
                    'my_new_form_select_border_radius_2'
                ),
                'css'=>array(
                  'display:none'  
                ),
                'title'=>__("Border radius bottom", "my_support_theme"),
                'type' => 'jscript_spinner',
                'property' => 'height',
                'default' => '0',
                'default_unit' => 'px',
                'units' => $units
            ),
        )
    )
    /*
 * 'outline'=>array(
 * 'type'=>'jscript_border',
 * 'title'=>__('Outline',"my_support_theme"),
 * 'tooltip'=>__("Specify element outline clicking on rectangle and selecting some top left or right border","support_theme"),
 * 'default'=>array(
 * 'width'=>'1px',
 * 'color'=>'#000000',
 * 'style'=>'solid'
 * ),
 * 'elements'=>array(
 * 'border_width'=>array(
 * 'type'=>'jscript_spinner',
 * 'property'=>'height',
 * 'default'=>'1',
 * 'default_unit'=>'px',
 * 'units'=>$units,
 * ),
 * 'border_color'=>array(
 * 'type'=>'jscript_color_picker',
 * 'pick_title'=>__("Pick a Color","my_support_theme"),
 * 'close_title'=>__("Close","my_support_theme"),
 * 'default'=>array(
 * 'color'=>'#000000',
 * 'transp'=>1
 * ),
 * 'jscript'=>array(
 * 'pick_title'=>__("Pick a Color","my_support_theme"),
 * 'close_title'=>__("Close","my_support_theme"),
 * 'hex_title'=>__("Hex value","my_support_theme"),
 * 'transp_title'=>__("Transparency","my_support_theme")
 * ),
 * 'property'=>array(
 * 'class'=>'{class}',
 * 'property'=>'background'
 * ),
 * 'transparency'=>true,
 * ),
 * 'border_type'=>array(
 * 'type'=>'select',
 * 'default'=>'solid',
 * 'values'=>array(
 * 'dotted'=>__("Dotted","my_support_theme"),
 * 'dashed'=>__("Dashed","my_support_theme"),
 * 'solid'=>__("Solid","my_support_theme"),
 * 'double'=>__("Double","my_support_theme"),
 * 'groove'=>__("Groove","my_support_theme"),
 * 'ridge'=>__("Ridge","my_support_theme"),
 * 'inset'=>__("Inset","my_support_theme"),
 * 'outset'=>__("Outset","my_support_theme"),
 * 'none'=>__("None","my_support_theme"),
 * 'hidden'=>__("Hidden","my_support_theme"),
 *
 * )
 * )
 * )
 * )
 */

);
/*
 * $templates['predefined']['thumb']['border']=array(
 *
 * 'show_border'=>array(
 * 'type'=>'multi',
 *
 * 'title'=>__('Border',"my_support_theme"),
 * 'tooltip'=>__("If you want all border specify only border top and check show border all","my_support_theme"),
 * 'elements'=>array(
 * 'show'=>array(
 * 'type'=>'checkbox',
 * 'default'=>0,
 * 'label'=>__("Show border","my_support_theme"),
 * 'translate'=>array(
 * 'class'=>'{class}',
 * 'property'=>'height'
 * )
 * ),
 * 'all'=>array(
 * 'type'=>'checkbox',
 * 'default'=>0,
 * 'label'=>__("All border are same","my_support_theme"),
 *
 * ),
 * )
 *
 * ),
 * 'border_top'=>array(
 * 'type'=>'multi',
 * 'title'=>__("Height","my_support_theme"),
 * 'elements'=>array(
 * 'border_width'=>array(
 * 'type'=>'jscript_spinner',
 * 'property'=>'height',
 * 'default'=>'1',
 * 'default_unit'=>'px',
 * 'units'=>$units,
 * ),
 * 'border_color'=>array(
 * 'type'=>'jscript_color_picker',
 * 'pick_title'=>__("Pick a Color","my_support_theme"),
 * 'close_title'=>__("Close","my_support_theme"),
 * 'default'=>array(
 * 'color'=>'#000000',
 * 'transp'=>1
 * ),
 * 'jscript'=>array(
 * 'pick_title'=>__("Pick a Color","my_support_theme"),
 * 'close_title'=>__("Close","my_support_theme"),
 * 'hex_title'=>__("Hex value","my_support_theme"),
 * 'transp_title'=>__("Transparency","my_support_theme")
 * ),
 * 'property'=>array(
 * 'class'=>'{class}',
 * 'property'=>'background'
 * ),
 * 'transparency'=>true,
 * ),
 * 'border_type'=>array(
 * 'type'=>'select',
 * 'default'=>'solid',
 * 'values'=>array(
 * 'dotted'=>__("Dotted","my_support_theme"),
 * 'dashed'=>__("Dashed","my_support_theme"),
 * 'solid'=>__("Solid","my_support_theme"),
 * 'double'=>__("Double","my_support_theme"),
 * 'groove'=>__("Groove","my_support_theme"),
 * 'ridge'=>__("Ridge","my_support_theme"),
 * 'inset'=>__("Inset","my_support_theme"),
 * 'outset'=>__("Outset","my_support_theme"),
 * 'none'=>__("None","my_support_theme"),
 * 'hidden'=>__("Hidden","my_support_theme"),
 *
 * )
 * )
 *
 * )
 * ),
 * 'border_bottom'=>array(
 * 'type'=>'multi',
 * 'title'=>__("Border Bottom","my_support_theme"),
 * 'elements'=>array(
 * 'border_width'=>array(
 * 'type'=>'jscript_spinner',
 * 'property'=>'height',
 * 'default'=>'1',
 * 'default_unit'=>'px',
 * 'units'=>$units,
 * ),
 * 'border_color'=>array(
 * 'type'=>'jscript_color_picker',
 * 'pick_title'=>__("Pick a Color","my_support_theme"),
 * 'close_title'=>__("Close","my_support_theme"),
 * 'default'=>array(
 * 'color'=>'#000000',
 * 'transp'=>1
 * ),
 * 'jscript'=>array(
 * 'pick_title'=>__("Pick a Color","my_support_theme"),
 * 'close_title'=>__("Close","my_support_theme"),
 * 'hex_title'=>__("Hex value","my_support_theme"),
 * 'transp_title'=>__("Transparency","my_support_theme")
 * ),
 * 'property'=>array(
 * 'class'=>'{class}',
 * 'property'=>'background'
 * ),
 * 'transparency'=>true,
 * ),
 * 'border_type'=>array(
 * 'type'=>'select',
 * 'default'=>'solid',
 * 'values'=>array(
 * 'dotted'=>__("Dotted","my_support_theme"),
 * 'dashed'=>__("Dashed","my_support_theme"),
 * 'solid'=>__("Solid","my_support_theme"),
 * 'double'=>__("Double","my_support_theme"),
 * 'groove'=>__("Groove","my_support_theme"),
 * 'ridge'=>__("Ridge","my_support_theme"),
 * 'inset'=>__("Inset","my_support_theme"),
 * 'outset'=>__("Outset","my_support_theme"),
 * 'none'=>__("None","my_support_theme"),
 * 'hidden'=>__("Hidden","my_support_theme"),
 *
 * )
 * )
 *
 * )
 * ),
 * 'border_left'=>array(
 * 'type'=>'multi',
 * 'title'=>__("Border Left","my_support_theme"),
 * 'elements'=>array(
 * 'border_width'=>array(
 * 'type'=>'jscript_spinner',
 * 'property'=>'height',
 * 'default'=>'1',
 * 'default_unit'=>'px',
 * 'units'=>$units,
 * ),
 * 'border_color'=>array(
 * 'type'=>'jscript_color_picker',
 * 'pick_title'=>__("Pick a Color","my_support_theme"),
 * 'close_title'=>__("Close","my_support_theme"),
 * 'default'=>array(
 * 'color'=>'#000000',
 * 'transp'=>1
 * ),
 * 'jscript'=>array(
 * 'pick_title'=>__("Pick a Color","my_support_theme"),
 * 'close_title'=>__("Close","my_support_theme"),
 * 'hex_title'=>__("Hex value","my_support_theme"),
 * 'transp_title'=>__("Transparency","my_support_theme")
 * ),
 * 'property'=>array(
 * 'class'=>'{class}',
 * 'property'=>'background'
 * ),
 * 'transparency'=>true,
 * ),
 * 'border_type'=>array(
 * 'type'=>'select',
 * 'default'=>'solid',
 * 'values'=>array(
 * 'dotted'=>__("Dotted","my_support_theme"),
 * 'dashed'=>__("Dashed","my_support_theme"),
 * 'solid'=>__("Solid","my_support_theme"),
 * 'double'=>__("Double","my_support_theme"),
 * 'groove'=>__("Groove","my_support_theme"),
 * 'ridge'=>__("Ridge","my_support_theme"),
 * 'inset'=>__("Inset","my_support_theme"),
 * 'outset'=>__("Outset","my_support_theme"),
 * 'none'=>__("None","my_support_theme"),
 * 'hidden'=>__("Hidden","my_support_theme"),
 *
 * )
 * )
 *
 * )
 * ),
 * 'border_right'=>array(
 * 'type'=>'multi',
 * 'title'=>__("Border Right","my_support_theme"),
 * 'elements'=>array(
 * 'border_width'=>array(
 * 'type'=>'jscript_spinner',
 * 'property'=>'height',
 * 'default'=>'1',
 * 'default_unit'=>'px',
 * 'units'=>$units,
 * ),
 * 'border_color'=>array(
 * 'type'=>'jscript_color_picker',
 * 'pick_title'=>__("Pick a Color","my_support_theme"),
 * 'close_title'=>__("Close","my_support_theme"),
 * 'default'=>array(
 * 'color'=>'#000000',
 * 'transp'=>1
 * ),
 * 'jscript'=>array(
 * 'pick_title'=>__("Pick a Color","my_support_theme"),
 * 'close_title'=>__("Close","my_support_theme"),
 * 'hex_title'=>__("Hex value","my_support_theme"),
 * 'transp_title'=>__("Transparency","my_support_theme")
 * ),
 * 'property'=>array(
 * 'class'=>'{class}',
 * 'property'=>'background'
 * ),
 * 'transparency'=>true,
 * ),
 * 'border_type'=>array(
 * 'type'=>'select',
 * 'default'=>'solid',
 * 'values'=>array(
 * 'dotted'=>__("Dotted","my_support_theme"),
 * 'dashed'=>__("Dashed","my_support_theme"),
 * 'solid'=>__("Solid","my_support_theme"),
 * 'double'=>__("Double","my_support_theme"),
 * 'groove'=>__("Groove","my_support_theme"),
 * 'ridge'=>__("Ridge","my_support_theme"),
 * 'inset'=>__("Inset","my_support_theme"),
 * 'outset'=>__("Outset","my_support_theme"),
 * 'none'=>__("None","my_support_theme"),
 * 'hidden'=>__("Hidden","my_support_theme"),
 *
 * )
 * )
 *
 * )
 * ),
 * 'show_outline'=>array(
 * 'type'=>'multi',
 *
 * 'title'=>__('Outline',"my_support_theme"),
 * 'tooltip'=>__("If you want all border specify only border top and check show border all","my_support_theme"),
 * 'elements'=>array(
 * 'show'=>array(
 * 'type'=>'checkbox',
 * 'default'=>0,
 * 'label'=>__("Show border","my_support_theme"),
 * 'translate'=>array(
 * 'class'=>'{class}',
 * 'property'=>'height'
 * )
 * ),
 * 'all'=>array(
 * 'type'=>'checkbox',
 * 'default'=>0,
 * 'label'=>__("All border are same","my_support_theme"),
 *
 * ),
 * )
 *
 * ),
 * 'outline_top'=>array(
 * 'type'=>'multi',
 * 'title'=>__("Outline top","my_support_theme"),
 * 'elements'=>array(
 * 'outline_width'=>array(
 * 'type'=>'jscript_spinner',
 * 'property'=>'height',
 * 'default'=>'1',
 * 'default_unit'=>'px',
 * 'units'=>$units,
 * ),
 * 'outline_space'=>array(
 * 'type'=>'jscript_spinner',
 * 'property'=>'height',
 * 'default'=>'1',
 * 'default_unit'=>'px',
 * 'units'=>$units,
 * ),
 * 'outline_color'=>array(
 * 'type'=>'jscript_color_picker',
 * 'pick_title'=>__("Pick a Color","my_support_theme"),
 * 'close_title'=>__("Close","my_support_theme"),
 * 'default'=>array(
 * 'color'=>'#000000',
 * 'transp'=>1
 * ),
 * 'jscript'=>array(
 * 'pick_title'=>__("Pick a Color","my_support_theme"),
 * 'close_title'=>__("Close","my_support_theme"),
 * 'hex_title'=>__("Hex value","my_support_theme"),
 * 'transp_title'=>__("Transparency","my_support_theme")
 * ),
 * 'property'=>array(
 * 'class'=>'{class}',
 * 'property'=>'background'
 * ),
 * 'transparency'=>true,
 * ),
 * 'outline_type'=>array(
 * 'type'=>'select',
 * 'default'=>'solid',
 * 'values'=>array(
 * 'dotted'=>__("Dotted","my_support_theme"),
 * 'dashed'=>__("Dashed","my_support_theme"),
 * 'solid'=>__("Solid","my_support_theme"),
 * 'double'=>__("Double","my_support_theme"),
 * 'groove'=>__("Groove","my_support_theme"),
 * 'ridge'=>__("Ridge","my_support_theme"),
 * 'inset'=>__("Inset","my_support_theme"),
 * 'outset'=>__("Outset","my_support_theme"),
 * 'none'=>__("None","my_support_theme"),
 * 'hidden'=>__("Hidden","my_support_theme"),
 *
 * )
 * )
 *
 * )
 * ),
 * 'outline_bottom'=>array(
 * 'type'=>'multi',
 * 'title'=>__("Outline Bottom","my_support_theme"),
 * 'elements'=>array(
 * 'outline_width'=>array(
 * 'type'=>'jscript_spinner',
 * 'property'=>'height',
 * 'default'=>'1',
 * 'default_unit'=>'px',
 * 'units'=>$units,
 * ),
 * 'outline_space'=>array(
 * 'type'=>'jscript_spinner',
 * 'property'=>'height',
 * 'default'=>'1',
 * 'default_unit'=>'px',
 * 'units'=>$units,
 * ),
 * 'outline_color'=>array(
 * 'type'=>'jscript_color_picker',
 * 'pick_title'=>__("Pick a Color","my_support_theme"),
 * 'close_title'=>__("Close","my_support_theme"),
 * 'default'=>array(
 * 'color'=>'#000000',
 * 'transp'=>1
 * ),
 * 'jscript'=>array(
 * 'pick_title'=>__("Pick a Color","my_support_theme"),
 * 'close_title'=>__("Close","my_support_theme"),
 * 'hex_title'=>__("Hex value","my_support_theme"),
 * 'transp_title'=>__("Transparency","my_support_theme")
 * ),
 * 'property'=>array(
 * 'class'=>'{class}',
 * 'property'=>'background'
 * ),
 * 'transparency'=>true,
 * ),
 * 'outline_type'=>array(
 * 'type'=>'select',
 * 'default'=>'solid',
 * 'values'=>array(
 * 'dotted'=>__("Dotted","my_support_theme"),
 * 'dashed'=>__("Dashed","my_support_theme"),
 * 'solid'=>__("Solid","my_support_theme"),
 * 'double'=>__("Double","my_support_theme"),
 * 'groove'=>__("Groove","my_support_theme"),
 * 'ridge'=>__("Ridge","my_support_theme"),
 * 'inset'=>__("Inset","my_support_theme"),
 * 'outset'=>__("Outset","my_support_theme"),
 * 'none'=>__("None","my_support_theme"),
 * 'hidden'=>__("Hidden","my_support_theme"),
 *
 * )
 * )
 *
 * )
 * ),
 * 'outline_left'=>array(
 * 'type'=>'multi',
 * 'title'=>__("Outline Left","my_support_theme"),
 * 'elements'=>array(
 * 'outline_width'=>array(
 * 'type'=>'jscript_spinner',
 * 'property'=>'height',
 * 'default'=>'1',
 * 'default_unit'=>'px',
 * 'units'=>$units,
 * ),
 * 'outline_space'=>array(
 * 'type'=>'jscript_spinner',
 * 'property'=>'height',
 * 'default'=>'1',
 * 'default_unit'=>'px',
 * 'units'=>$units,
 * ),
 * 'outline_color'=>array(
 * 'type'=>'jscript_color_picker',
 * 'pick_title'=>__("Pick a Color","my_support_theme"),
 * 'close_title'=>__("Close","my_support_theme"),
 * 'default'=>array(
 * 'color'=>'#000000',
 * 'transp'=>1
 * ),
 * 'jscript'=>array(
 * 'pick_title'=>__("Pick a Color","my_support_theme"),
 * 'close_title'=>__("Close","my_support_theme"),
 * 'hex_title'=>__("Hex value","my_support_theme"),
 * 'transp_title'=>__("Transparency","my_support_theme")
 * ),
 * 'property'=>array(
 * 'class'=>'{class}',
 * 'property'=>'background'
 * ),
 * 'transparency'=>true,
 * ),
 * 'outline_type'=>array(
 * 'type'=>'select',
 * 'default'=>'solid',
 * 'values'=>array(
 * 'dotted'=>__("Dotted","my_support_theme"),
 * 'dashed'=>__("Dashed","my_support_theme"),
 * 'solid'=>__("Solid","my_support_theme"),
 * 'double'=>__("Double","my_support_theme"),
 * 'groove'=>__("Groove","my_support_theme"),
 * 'ridge'=>__("Ridge","my_support_theme"),
 * 'inset'=>__("Inset","my_support_theme"),
 * 'outset'=>__("Outset","my_support_theme"),
 * 'none'=>__("None","my_support_theme"),
 * 'hidden'=>__("Hidden","my_support_theme"),
 *
 * )
 * )
 *
 * )
 * ),
 * 'outline_right'=>array(
 * 'type'=>'multi',
 * 'title'=>__("Outlin Right","my_support_theme"),
 * 'elements'=>array(
 * 'outline_width'=>array(
 * 'type'=>'jscript_spinner',
 * 'property'=>'height',
 * 'default'=>'1',
 * 'default_unit'=>'px',
 * 'units'=>$units,
 * ),
 * 'outline_space'=>array(
 * 'type'=>'jscript_spinner',
 * 'property'=>'height',
 * 'default'=>'1',
 * 'default_unit'=>'px',
 * 'units'=>$units,
 * ),
 * 'outline_color'=>array(
 * 'type'=>'jscript_color_picker',
 * 'pick_title'=>__("Pick a Color","my_support_theme"),
 * 'close_title'=>__("Close","my_support_theme"),
 * 'default'=>array(
 * 'color'=>'#000000',
 * 'transp'=>1
 * ),
 * 'jscript'=>array(
 * 'pick_title'=>__("Pick a Color","my_support_theme"),
 * 'close_title'=>__("Close","my_support_theme"),
 * 'hex_title'=>__("Hex value","my_support_theme"),
 * 'transp_title'=>__("Transparency","my_support_theme")
 * ),
 * 'property'=>array(
 * 'class'=>'{class}',
 * 'property'=>'background'
 * ),
 * 'transparency'=>true,
 * ),
 * 'outline_type'=>array(
 * 'type'=>'select',
 * 'default'=>'solid',
 * 'values'=>array(
 * 'dotted'=>__("Dotted","my_support_theme"),
 * 'dashed'=>__("Dashed","my_support_theme"),
 * 'solid'=>__("Solid","my_support_theme"),
 * 'double'=>__("Double","my_support_theme"),
 * 'groove'=>__("Groove","my_support_theme"),
 * 'ridge'=>__("Ridge","my_support_theme"),
 * 'inset'=>__("Inset","my_support_theme"),
 * 'outset'=>__("Outset","my_support_theme"),
 * 'none'=>__("None","my_support_theme"),
 * 'hidden'=>__("Hidden","my_support_theme"),
 *
 * )
 * )
 *
 * )
 * ),
 * );
 */
$templates['predefined']['thumb'] = array(
    'w' => array(
        'title' => __("Width", "my_support_theme"),
        'type' => 'jscript_spinner',
        'property' => 'height',
        'default' => '400',
        'default_unit' => 'px',
        'units' => $units,
        'translate' => array(
            'class' => '.my_post_thumb',
            'property' => 'width'
        )
    ),
    'h' => array(
        'title' => __("Height", "my_support_theme"),
        'type' => 'jscript_spinner',
        'property' => 'height',
        'default' => '200',
        'default_unit' => 'px',
        'units' => $units,
        'translate' => array(
            'class' => '.my_post_thumb',
            'property' => 'width'
        )
    )
);
$templates['predefined']['padding'] = array(
    'padding-top' => array(
        'title' => __("Padding top", "my_support_theme"),
        'type' => 'jscript_spinner',
        'property' => 'height',
        'default' => '0',
        'default_unit' => 'px',
        'units' => $units,
        'translate' => array(
            'class' => '{class}',
            'property' => 'padding-top'
        )
    ),
    'padding-left' => array(
        'title' => __("Padding left", "my_support_theme"),
        'type' => 'jscript_spinner',
        'property' => 'height',
        'default' => '0',
        'default_unit' => 'px',
        'units' => $units,
        'translate' => array(
            'class' => '{class}',
            'property' => 'padding-left'
        )
    ),
    'padding-right' => array(
        'title' => __("Padding right", "my_support_theme"),
        'type' => 'jscript_spinner',
        'property' => 'height',
        'default' => '0',
        'default_unit' => 'px',
        'units' => $units,
        'translate' => array(
            'class' => '{class}',
            'property' => 'padding-right'
        )
    ),
    'padding-bottom' => array(
        'title' => __("Padding bottom", "my_support_theme"),
        'type' => 'jscript_spinner',
        'property' => 'height',
        'default' => '0',
        'default_unit' => 'px',
        'units' => $units,
        'translate' => array(
            'class' => '{class}',
            'property' => 'padding-bottom'
        )
    )
);
$templates['predefined']['margin'] = array(
    'margin-top' => array(
        'title' => __("Margin top", "my_support_theme"),
        'type' => 'jscript_spinner',
        'property' => 'height',
        'default' => '0',
        'default_unit' => 'px',
        'units' => $units,
        'translate' => array(
            'class' => '{class}',
            'property' => 'margin-top'
        )
    ),
    'margin-left' => array(
        'title' => __("Margin left", "my_support_theme"),
        'type' => 'jscript_spinner',
        'property' => 'height',
        'default' => '0',
        'default_unit' => 'px',
        'units' => $units,
        'translate' => array(
            'class' => '{class}',
            'property' => 'margin-left'
        )
    ),
    'margin-right' => array(
        'title' => __("Margin Right", "my_support_theme"),
        'type' => 'jscript_spinner',
        'property' => 'height',
        'default' => '0',
        'default_unit' => 'px',
        'units' => $units,
        'translate' => array(
            'class' => '{class}',
            'property' => 'margin-right'
        )
    ),
    'margin-bottom' => array(
        'title' => __("Margin bottom", "my_support_theme"),
        'type' => 'jscript_spinner',
        'property' => 'height',
        'default' => '0',
        'default_unit' => 'px',
        'units' => $units,
        'translate' => array(
            'class' => '{class}',
            'property' => 'margin-bottom'
        )
    )
);
$templates['predefined']['icon'] = array(
    'i_color' => array(
        'type' => 'jscript_color_picker',
        'tooltip' => __("Color", "my_support_theme"),
        'title' => __("Color", "my_support_theme"),
        'pick_title' => __("Pick a Color", "my_support_theme"),
        'close_title' => __("Close", "my_support_theme"),
        'default' => array(
            'color' => '#ffffff',
            'transp' => 1
        ),
        'jscript' => array(
            'pick_title' => __("Pick a Color", "my_support_theme"),
            'close_title' => __("Close", "my_support_theme"),
            'hex_title' => __("Hex value", "my_support_theme"),
            'transp_title' => __("Transparency", "my_support_theme")
        ),
        'transparency' => true,
        'translate' => array(
            'class' => '.my_line_nav span i, .my_line_nav span',
            'property' => 'color'
        )
    ),
    'i_color_hover' => array(
        'type' => 'jscript_color_picker',
        'tooltip' => __("Hover Color", "my_support_theme"),
        'title' => __("Hover Color", "my_support_theme"),
        'pick_title' => __("Pick a Color", "my_support_theme"),
        'close_title' => __("Close", "my_support_theme"),
        'default' => array(
            'color' => '#ffffff',
            'transp' => 1
        ),
        'jscript' => array(
            'pick_title' => __("Pick a Color", "my_support_theme"),
            'close_title' => __("Close", "my_support_theme"),
            'hex_title' => __("Hex value", "my_support_theme"),
            'transp_title' => __("Transparency", "my_support_theme")
        ),
        'transparency' => true,
        'translate' => array(
            'class' => '.my_line_nav span i, .my_line_nav span',
            'property' => 'color'
        )
    ),
    'i_font_size' => array(
        '
		    title' => __("Font size", "my_support_theme"),
        'type' => 'jscript_spinner',
        'default' => '14',
        'default_unit' => 'px',
        'units' => $units,
        'translate' => array(
            'class' => '{class}',
            'property' => 'font-size'
        )
    ),
    'i_line_height' => array(
        'title' => __("Line height", "my_support_theme"),
        'type' => 'jscript_spinner',
        'default' => '14',
        'default_unit' => 'px',
        'units' => $units,
        'translate' => array(
            'class' => '{class}',
            'property' => 'font-size'
        )
    )
    /*
 * 'i_icon'=>array(
 * 'type'=>'jscript_dropdown',
 * 'title'=>__("Icon","my_support_theme"),
 * 'tooltip'=>__("Icon","my_support_theme"),
 * 'jscript'=>array(
 * 'icon'=>1,
 * 'max_c'=>1,
 * 'max_sel'=>__("Maximum elements are selected","my_support_theme"),
 * 'duration'=>500,
 * 'animation'=>'fadein',
 * 'choose_value'=>__("Plese Select value","my_support_theme"),
 * ),
 * 'show_filter'=>1,
 * 'multiple'=>false,
 * 'choose_value'=>__("Plese Select value","my_support_theme"),
 * 'default'=>'fa-star',
 * )
 */
);
$templates['predefined']['text'] = array(
    /*'font_family' => array(
        'type' => 'jscript_dropdown',
        'title' => __("Font", "my_support_theme"),
        'tooltip' => __("Choose default font or some google fonts", "my_support_theme"),
        'jscript' => array(
            'max_c' => 1,
            'max_sel' => __("Maximum elements are selected", "my_support_theme"),
            'duration' => 500,
            'animation' => 'fadein',
            'choose_value' => __("Plese Select value", "my_support_theme")
        ),
        'show_filter' => 1,
        'multiple' => false,
        'choose_value' => __("Plese Select value", "my_support_theme"),
        'default' => 'default',
        'translate' => array(
            'class' => '.my_testimonial_item *:not(i)',
            'property' => 'font-family'
        )
    
    ),*/
    'font_weight' => array(
        'title' => __("Font Weight", "my_support_theme"),
        'type' => 'jscript_dropdown',
        'tooltip' => __("Font weight", "my_support_theme"),
        'jscript' => array(
            'max_c' => 1,
            'max_sel' => __("Maximum elements are selected", "my_support_theme"),
            'duration' => 500,
            'animation' => 'fadein',
            'choose_value' => __("Plese Select value", "my_support_theme")
        ),
        'show_filter' => 0,
        'multiple' => false,
        'choose_value' => __("Plese Select value", "my_support_theme"),
        'default' => '100',
        'values' => array(
        )
    
    ),
    'font_style' => array(
        'title' => __("Font Style", "my_support_theme"),
        'type' => 'jscript_dropdown',
        'tooltip' => __("Font style italic or normal", "my_support_theme"),
        'jscript' => array(
            'max_c' => 1,
            'max_sel' => __("Maximum elements are selected", "my_support_theme"),
            'duration' => 500,
            'animation' => 'fadein',
            'choose_value' => __("Plese Select value", "my_support_theme")
        ),
        'show_filter' => 0,
        'multiple' => false,
        'choose_value' => __("Plese Select value", "my_support_theme"),
        'default' => 'normal',
        'values' => $font_style
    
    ),
    'text_decoration' => array(
        'title' => __("Decoration", "my_support_theme"),
        'type' => 'jscript_dropdown',
        'tooltip' => __("Text decoration", "my_support_theme"),
        'jscript' => array(
            'max_c' => 1,
            'max_sel' => __("Maximum elements are selected", "my_support_theme"),
            'duration' => 500,
            'animation' => 'fadein',
            'choose_value' => __("Plese Select value", "my_support_theme")
        ),
        'show_filter' => 0,
        'multiple' => false,
        'choose_value' => __("Plese Select value", "my_support_theme"),
        'default' => 'none',
        'values' => $text_decoration
    ),
    'font_size' => array(
        'title' => __("Font size", "my_support_theme"),
        'type' => 'jscript_spinner',
        'default' => '14',
        'default_unit' => 'px',
        'units' => $units,
        'translate' => array(
            'class' => '{class}',
            'property' => 'font-size'
        )
        // 'layout_class'=>'my_col_25',
    ),
    'letter_spacing' => array(
        'title' => __("Letter space", "my_support_theme"),
        'type' => 'jscript_spinner',
        'default' => '0',
        'default_unit' => 'px',
        'units' => $units,
        'translate' => array(
            'class' => '{class}',
            'property' => 'line-height'
        )
    ),
    
    'line_height' => array(
        'title' => __("Line height", "my_support_theme"),
        'type' => 'jscript_spinner',
        'default' => '14',
        'default_unit' => 'px',
        'units' => $units,
        'translate' => array(
            'class' => '{class}',
            'property' => 'line-height'
        )
    ),
    'color' => array(
        'type' => 'jscript_color_picker',
        'tooltip' => __("Color", "my_support_theme"),
        'title' => __("Color", "my_support_theme"),
        'pick_title' => __("Pick a Color", "my_support_theme"),
        'close_title' => __("Close", "my_support_theme"),
        'default' => array(
            'color' => '#ffffff',
            'transp' => 1
        ),
        'jscript' => array(
            'pick_title' => __("Pick a Color", "my_support_theme"),
            'close_title' => __("Close", "my_support_theme"),
            'hex_title' => __("Hex value", "my_support_theme"),
            'transp_title' => __("Transparency", "my_support_theme")
        ),
        'transparency' => true,
        'translate' => array(
            'class' => '.my_line_nav span i, .my_line_nav span',
            'property' => 'color'
        )
    ),
    'hover_color' => array(
        'type' => 'jscript_color_picker',
        'tooltip' => __("Hover Color", "my_support_theme"),
        'title' => __("Hover Color", "my_support_theme"),
        'pick_title' => __("Pick a Color", "my_support_theme"),
        'close_title' => __("Close", "my_support_theme"),
        'default' => array(
            'color' => '#ffffff',
            'transp' => 1
        ),
        'jscript' => array(
            'pick_title' => __("Pick a Color", "my_support_theme"),
            'close_title' => __("Close", "my_support_theme"),
            'hex_title' => __("Hex value", "my_support_theme"),
            'transp_title' => __("Transparency", "my_support_theme")
        ),
        'transparency' => true,
        'translate' => array(
            'class' => '.my_line_nav span i, .my_line_nav span',
            'property' => 'color'
        )
    ),
	/*'a'=>array(
			'type'=>'on_off',
			'title'=>__("Link text","my_support_theme"),
			'tooltip'=>__("If you check this option text will be linked to post link.","my_support_theme"),

			'default'=>'',
	),*/
    'align' => array(
        'type' => 'jscript_dropdown',
        'title' => __("Align", "my_support_theme"),
        'tooltip' => __("Text align", "my_support_theme"),
        'jscript' => array(
            'max_c' => 1,
            'max_sel' => __("Maximum elements are selected", "my_support_theme"),
            'duration' => 500,
            'animation' => 'fadein',
            'choose_value' => __("Plese Select value", "my_support_theme")
        ),
        'show_filter' => 0,
        'multiple' => false,
        'choose_value' => __("Plese Select value", "my_support_theme"),
        'default' => 'center',
        'values' => array(
            'left' => __("Left", "my_support_theme"),
            'right' => __("Right", "my_support_theme"),
            'center' => __("Center", "my_support_theme"),
            'justify' => __("Justify", "my_support_theme")
        )
    
    )
    /*
 * 'date_format'=>array(
 * 'type'=>'text',
 * 'title'=>__("Date Format","my_support_theme"),
 * 'tooltip'=>__("Adjust date format.Use for day d Day of the month, 2 digits with leading zeros 01 to 31
 * D A textual representation of a day, three letters Mon through Sun
 * j Day of the month without leading zeros 1 to 31
 * l (lowercase 'L') A full textual representation of the day of the week Sunday through Saturday
 * ,F A full textual representation of a month, such as January or March January through December
 * m Numeric representation of a month, with leading zeros 01 through 12
 * M A short textual representation of a month, three letters Jan through Dec
 * Usew for year Y A full numeric representation of a year, 4 digits Examples: 1999 or 2003
 * y A two digit representation of a year Examples: 99 or 03
 *
 * ","my_support_theme"),
 * 'default'=>'F d,Y',
 *
 *
 *
 * ),
 */
);
/*
 * $templates['predefined']=array(
 * 'post_title'=>array(
 * 'translate'=>array(
 * 'class'=>".my_post_title, .my_post_title a"
 * ),
 * 'elements'=>array(
 * 'font_size',
 * 'line_height',
 * 'color',
 * 'align',
 * 'a',
 * 'hover_color')
 * ),
 * 'post_date'=>array(
 * 'translate'=>array(
 * 'class'=>".my_post_date"
 * ),
 * 'elements'=>array('font_size','line_height','color','align','date_format')
 * ),
 * 'hearts'=>array(
 * 'elements'=>array('color','hover_color','animate')
 * )
 * );
 */
$templates['tags'] = array(
    ".my_post_title" => array()
);
$templates['template_6'] = array(
    'title' => __("General Post Template Five", "my_support_theme"),
    'width' => 500,
    'height' => 590,
    'post_tags' => array(
        'template' => array(
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => '#ffffff,1',
            'bg_hover_color' => '#ffffff,1',
            'margin'=>'15px 15px 45px 15px',
            'border'=>array(
                "border"=>"1px solid #818181"
            ),
            'box_shadow' => array(
                'type' => 'hover',
                array(
                    'h_shadow' => '0px',
                    'v_shadow' => '14px',
                    'blur' => '45px',
                    'spread' => '',
                    'color' => '#000000,0.247059'
                    
                ),
                array(
                    'h_shadow' => '0px',
                    'v_shadow' => '10px',
                    'blur' => '18px',
                    'spread' => '',
                    'color' => '#000000,0.219608'
                )
            )
            
        ),
        'post_title' => array(
            'font_weight' => 400,
            'text_decoration' => 'none',
            'font_style' => 'normal',
            
            'padding' => '0px 0px 0px 0px',
            'margin' => '10px 0px 0px 0px',
            'font_size' => '18px',
            'line_height' => '30px',
            'color' => '#212121,1',
            'hover_color' => '#212121,1',
            'align' => 'none',
            'width' => '100%',
            'float' => 'left',
            'height' => 'auto',
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => ''
        
        ),
        'post_date' => array(
            'font_weight' => 400,
            'text_decoration' => 'none',
            'font_style' => 'normal',
            
            'padding' => '0px 0px 0px 0px',
            'margin' => '0px 0px 10px 0px',
            'font_size' => '16px',
            'line_height' => '20px',
            'color' => '#212121,1',
            'hover_color' => '#212121,1',
            'align' => 'center',
            'date_format' => 'F d,Y',
            'align' => 'center',
            'width' => '100%',
            'float' => 'none',
            'height' => 'auto',
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => ''
        ),
        'post_thumb' => array(
            'padding' => '0px 0px 0px 0px',
            'margin' => '0px 0px 0px 0px',
            'bg' => 1,
            'w' => '500px',
            'h' => '300px',
            'width' => '100%',
            'height' => '',
            'show_pretty' => 1,
            'float' => 'nobe',
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => '',
            'border' => array(
                'border' => '1px solid #cccccc'
            )
        
        ),
        'post_content' => array(
            'padding' => '8px 15px 8px 15px',
            'margin' => '0px 0px 0px 0px',
            'font_weight' => 400,
            'text_decoration' => 'none',
            'font_style' => 'normal',
            'show' => 'all',
            'font_size' => '14px',
            'line_height' => '18px',
            'color' => '#212121,1',
            'show_limit' => array(
                'type' => 'length',
                'val' => 100
            ),
            'align' => 'justify',
            'width' => '100%',
            
            'float' => 'none',
            'height' => '150px',
            'center' => 1,
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => '#f5f5f5,1',
            'border' => array(
                'border' => '1px solid #cccccc'
            ),
            'predefined_classes' => array(
                'mCSB_draggerRail' => array(
                    'bg_color' => '#212121,0.4'
                ),
                'mCSB_dragger_bar' => array(
                    'bg_color' => '#212121,0.8'
                )
            )
        ),
        'post_meta' => array(
            'padding' => '0px 0px 0px 0px',
            'margin' => '10px 0px 10px 0px',
            'width' => '50%',
            'float' => 'left',
            'height' => 'auto',
            'align' => 'center',
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => '',
            'font_size' => '14px',
            'line_height' => '18px',
            'post_hearts' => array(
                'i_color' => '#e64c28,1',
                'i_color_hover' => '#e64c00,1',
                'i_icon' => 'fa-heart'
            ),
            'post_comments' => array(
                'i_color' => '#000000,1',
                'i_color_hover' => '#212121,1',
                'i_icon' => 'fa-comment'
            ),
            'post_share' => array(
                'i_color' => '#000000,1',
                'i_color_hover' => '#212121,1',
                'i_icon' => 'fa-share'
            )
        ),
        'meta_stars' => array(
            'padding' => '0px 0px 0px 0px',
            'margin' => '10px 0px 10px 0px',
            'align' => 'left',
            'width' => '50%',
            'float' => 'left',
            'height' => 'auto',
            'i_color' => '#EEAA00,1',
            'i_color_hover' => '#f70,1',
            'i_font_size' => '14px',
            'i_line_height' => '18px',
            'i_icon' => 'fa-star',
            'i_align' => 'center'
        
        ),
        'woo_data' => array(
            'padding' => '0px 0px 0px 0px',
            'margin' => '0px 0px 0px 0px',
            'width' => '100%',
            'float' => 'none',
            'height' => 'auto',
            'align' => 'center',
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => '#212121,1',
            'color' => '#ffffff,1',
            'font_size' => '18px',
            'line_height' => '50px',
            'bg_hover_color' => '#d45729,1',
            'hover_color' => '#ffffff,1'
        
        ),
        'predefined_classes' => array(
            'my_post_all_1' => array(
                'width' => '100%',
                'padding' => '0px 0px 0px 0px',
                'margin' => '10px 0px 10px 0px',
                'border' => array(
                    'bottom' => '2px solid #212121'
                ),
                'width' => '100%',
                'float' => 'none',
                'height' => 'auto',
                'align' => 'center',
                'bg_image' => '',
                'bg_repeat' => '',
                'bg_color' => '#212121,0',
                'color' => '#ffffff,1',
                'font_size' => '18px',
                'line_height' => '22px',
                'bg_hover_color' => '#d45729,0'
            
            ),
            'my_post_all_2' => array(
                'width' => '100%',
                'padding' => '0px 0px 0px 0px',
                'margin' => '10px 0px 10px 0px',
                'width' => '100%',
                'float' => 'none',
                'height' => 'auto',
                'align' => 'center',
                'bg_image' => '',
                'bg_repeat' => '',
                'bg_color' => '#212121,0',
                'color' => '#ffffff,1',
                'font_size' => '18px',
                'line_height' => '22px',
                'bg_hover_color' => '#d45729,0'
            
            )
        
        )
    )
);
$templates['template_7'] = $templates['template_6'];
$templates['template_7']['height'] = 540;
$templates['template_7']['post_tags']['post_title']['width'] = '100%';
$templates['template_7']['post_tags']['post_title']['float'] = 'nove';
$templates['template_7']['post_tags']['post_title']['align'] = 'center';

$templates['template_8'] = $templates['template_7'];
$templates['template_8']['height'] = 490;
//$templates['template_new'] = $templates['template_1'];
//$templates['template_custom_new'] = $templates['template_1'];

$templates['template_5'] = array(
    'title' => __("General Post Template Five", "my_support_theme"),
    'width' => 500,
    'height' => 340,
    'post_tags' => array(
        'post_title' => array(
            'font_weight' => 400,
            'text_decoration' => 'none',
            'font_style' => 'normal',
            
            'padding' => '0px 0px 0px 0px',
            'margin' => '10px 0px 0px 0px',
            'font_size' => '18px',
            'line_height' => '30px',
            'color' => '#212121,1',
            'hover_color' => '#212121,1',
            'align' => 'none',
            'width' => '100%',
            'float' => 'left',
            'height' => 'auto',
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => ''
        
        ),
        'post_date' => array(
            'font_weight' => 400,
            'text_decoration' => 'none',
            'font_style' => 'normal',
            
            'padding' => '0px 0px 0px 0px',
            'margin' => '0px 0px 10px 0px',
            'font_size' => '16px',
            'line_height' => '20px',
            'color' => '#212121,1',
            'hover_color' => '#212121,1',
            'align' => 'center',
            'date_format' => 'F d,Y',
            'align' => 'center',
            'width' => '100%',
            'float' => 'none',
            'height' => 'auto',
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => ''
        ),
        'post_thumb' => array(
            'padding' => '0px 0px 0px 0px',
            'margin' => '0px 0px 0px 0px',
            'bg' => 1,
            'w' => '250px',
            'h' => '200px',
            'width' => '50%',
            'height' => '200px',
            'show_pretty' => 1,
            'float' => 'left',
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => '',
            'border' => array(
                'border' => '1px solid #cccccc'
            )
        
        ),
        'post_content' => array(
            'padding' => '8px 15px 8px 15px',
            'margin' => '0px 0px 0px 0px',
            'font_weight' => 400,
            'text_decoration' => 'none',
            'font_style' => 'normal',
            'show' => 'all',
            'font_size' => '14px',
            'line_height' => '18px',
            'color' => '#212121,1',
            'show_limit' => array(
                'type' => 'length',
                'val' => 100
            ),
            'align' => 'left',
            'width' => '50%',
            'float' => 'left',
            'height' => '200px',
            'center' => 1,
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => '#f5f5f5,1',
            'border' => array(
                'border' => '1px solid #cccccc'
            ),
            'predefined_classes' => array(
                'mCSB_draggerRail' => array(
                    'bg_color' => '#212121,0.4'
                ),
                'mCSB_dragger_bar' => array(
                    'bg_color' => '#212121,0.8'
                )
            )
        ),
        'post_meta' => array(
            'padding' => '0px 0px 0px 0px',
            'margin' => '12px 0px 0px 0px',
            'width' => '50%',
            'float' => 'left',
            'height' => 'auto',
            'align' => 'center',
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => '',
            'font_size' => '14px',
            'line_height' => '18px',
            'post_hearts' => array(
                'i_color' => '#e64c28,1',
                'i_color_hover' => '#e64c00,1',
                'i_icon' => 'fa-heart'
            ),
            'post_comments' => array(
                'i_color' => '#000000,1',
                'i_color_hover' => '#212121,1',
                'i_icon' => 'fa-comment'
            ),
            'post_share' => array(
                'i_color' => '#000000,1',
                'i_color_hover' => '#212121,1',
                'i_icon' => 'fa-share'
            )
        ),
        'meta_stars' => array(
            'padding' => '0px 0px 0px 0px',
            'margin' => '10px 0px 10px 0px',
            'align' => 'left',
            'width' => '50%',
            'float' => 'left',
            'height' => 'auto',
            'i_color' => '#EEAA00,1',
            'i_color_hover' => '#f70,1',
            'i_font_size' => '14px',
            'i_line_height' => '18px',
            'i_icon' => 'fa-star',
            'i_align' => 'center'
        
        ),
        'woo_data' => array(
            'padding' => '0px 0px 0px 0px',
            'margin' => '0px 0px 0px 0px',
            'width' => '100%',
            'float' => 'none',
            'height' => 'auto',
            'align' => 'center',
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => '#212121,1',
            'color' => '#ffffff,1',
            'font_size' => '18px',
            'line_height' => '50px',
            'bg_hover_color' => '#d45729,1',
            'hover_color' => '#ffffff,1'
        
        ),
        'predefined_classes' => array(
            'my_post_all_1' => array(
                'width' => '100%',
                'padding' => '0px 0px 0px 0px',
                'margin' => '10px 0px 10px 0px',
                'border' => array(
                    'bottom' => '2px solid #212121'
                ),
                'width' => '100%',
                'float' => 'none',
                'height' => 'auto',
                'align' => 'center',
                'bg_image' => '',
                'bg_repeat' => '',
                'bg_color' => '#212121,0',
                'color' => '#ffffff,1',
                'font_size' => '18px',
                'line_height' => '22px',
                'bg_hover_color' => '#d45729,0'
            
            ),
            'my_post_all_2' => array(
                'width' => '100%',
                'padding' => '0px 0px 0px 0px',
                'margin' => '10px 0px 10px 0px',
                'width' => '100%',
                'float' => 'none',
                'height' => 'auto',
                'align' => 'center',
                'bg_image' => '',
                'bg_repeat' => '',
                'bg_color' => '#212121,0',
                'color' => '#ffffff,1',
                'font_size' => '18px',
                'line_height' => '22px',
                'bg_hover_color' => '#d45729,0'
            
            )
        
        )
    )
);
$templates['template_3'] = array(
    'title' => __("General Post Template Three", "my_support_theme"),
    'width' => 500,
    'height' => 310,
    'post_tags' => array(
        'post_title' => array(
            'font_weight' => 400,
            'text_decoration' => 'none',
            'font_style' => 'normal',
            
            'padding' => '0px 0px 0px 0px',
            'margin' => '10px 0px 10px 0px',
            'font_size' => '18px',
            'line_height' => '30px',
            'color' => '#212121,1',
            'hover_color' => '#212121,1',
            'align' => 'left',
            'width' => '50%',
            'float' => 'left',
            'height' => 'auto',
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => ''
        
        ),
        'post_date' => array(
            'font_weight' => 400,
            'text_decoration' => 'none',
            'font_style' => 'normal',
            
            'padding' => '0px 0px 0px 0px',
            'margin' => '0px 0px 10px 0px',
            'font_size' => '16px',
            'line_height' => '20px',
            'color' => '#212121,1',
            'hover_color' => '#212121,1',
            'align' => 'center',
            'date_format' => 'F d,Y',
            'align' => 'center',
            'width' => '100%',
            'float' => 'none',
            'height' => 'auto',
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => ''
        ),
        'post_thumb' => array(
            'padding' => '0px 0px 0px 0px',
            'margin' => '0px 0px 10px 0px',
            'bg' => 1,
            'w' => '250px',
            'h' => '200px',
            'width' => '50%',
            'height' => '200px',
            'show_pretty' => 1,
            'float' => 'left',
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => ''
        
        ),
        'post_content' => array(
            'padding' => '0px 15px 0px 15px',
            'margin' => '0px 0px 10px 0px',
            'font_weight' => 400,
            'text_decoration' => 'none',
            'font_style' => 'normal',
            'show' => 'all',
            'font_size' => '14px',
            'line_height' => '18px',
            'color' => '#212121,1',
            'show_limit' => array(
                'type' => 'length',
                'val' => 100
            ),
            'align' => 'left',
            'width' => '50%',
            'float' => 'left',
            'height' => '200px',
            'center' => 1,
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => ''
        ),
        'post_meta' => array(
            'padding' => '0px 0px 0px 0px',
            'margin' => '12px 0px 0px 0px',
            'width' => '100%',
            'float' => 'none',
            'height' => 'auto',
            'align' => 'center',
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => '',
            'font_size' => '14px',
            'line_height' => '18px',
            'post_hearts' => array(
                'i_color' => '#e64c28,1',
                'i_color_hover' => '#e64c00,1',
                'i_icon' => 'fa-heart'
            ),
            'post_comments' => array(
                'i_color' => '#000000,1',
                'i_color_hover' => '#212121,1',
                'i_icon' => 'fa-comment'
            ),
            'post_share' => array(
                'i_color' => '#000000,1',
                'i_color_hover' => '#212121,1',
                'i_icon' => 'fa-share'
            )
        ),
        'meta_stars' => array(
            'padding' => '0px 0px 0px 0px',
            'margin' => '10px 0px 10px 0px',
            'align' => 'left',
            'width' => '50%',
            'float' => 'left',
            'height' => 'auto',
            'i_color' => '#EEAA00,1',
            'i_color_hover' => '#f70,1',
            'i_font_size' => '14px',
            'i_line_height' => '18px',
            'i_icon' => 'fa-star',
            'i_align' => 'center'
        
        ),
        'woo_data' => array(
            'padding' => '0px 0px 0px 0px',
            'margin' => '0px 0px 0px 0px',
            'width' => '100%',
            'float' => 'none',
            'height' => 'auto',
            'align' => 'center',
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => '#212121,1',
            'color' => '#ffffff,1',
            'font_size' => '18px',
            'line_height' => '50px',
            'bg_hover_color' => '#d45729,1',
            'hover_color' => '#ffffff,1'
        
        ),
        'predefined_classes' => array(
            'my_post_all_1' => array(
                'width' => '100%',
                'padding' => '0px 0px 0px 0px',
                'margin' => '10px 0px 10px 0px',
                'border' => array(
                    'bottom' => '2px solid #212121'
                ),
                'width' => '100%',
                'float' => 'none',
                'height' => 'auto',
                'align' => 'center',
                'bg_image' => '',
                'bg_repeat' => '',
                'bg_color' => '#212121,0',
                'color' => '#ffffff,1',
                'font_size' => '18px',
                'line_height' => '22px',
                'bg_hover_color' => '#d45729,0'
            
            ),
            'my_post_all_2' => array(
                'width' => '100%',
                'padding' => '0px 0px 0px 0px',
                'margin' => '10px 0px 10px 0px',
                'width' => '100%',
                'float' => 'none',
                'height' => 'auto',
                'align' => 'center',
                'bg_image' => '',
                'bg_repeat' => '',
                'bg_color' => '#212121,0',
                'color' => '#ffffff,1',
                'font_size' => '18px',
                'line_height' => '22px',
                'bg_hover_color' => '#d45729,0'
            
            )
        
        )
    )
);
$templates['template_2'] = array(
    'title' => __("General Post Template Two", "my_support_theme"),
    'width' => 400,
    'height' => 392,
    'post_tags' => array(
        'template' => array(
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => '#ffffff,1',
            'bg_hover_color' => '#ffffff,1',
            'margin'=>'15px 15px 45px 15px',
            'border'=>array(
                "border"=>"1px solid #818181"
            ),
            'box_shadow' => array(
                'type' => 'hover',
                array(
                    'h_shadow' => '0px',
                    'v_shadow' => '14px',
                    'blur' => '45px',
                    'spread' => '',
                    'color' => '#000000,0.247059'
                    
                ),
                array(
                    'h_shadow' => '0px',
                    'v_shadow' => '10px',
                    'blur' => '18px',
                    'spread' => '',
                    'color' => '#000000,0.219608'
                )
            )
            
        ),
        'post_title' => array(
            'font_weight' => 400,
            'text_decoration' => 'none',
            'font_style' => 'normal',
            
            'padding' => '0px 0px 0px 0px',
            'margin' => '12px 0px 12px 0px',
            'font_size' => '18px',
            'line_height' => '30px',
            'color' => '#212121,1',
            'hover_color' => '#212121,1',
            'align' => 'left',
            'width' => '50%',
            'float' => 'left',
            'height' => 'auto',
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => ''
        
        ),
        'post_date' => array(
            'font_weight' => 400,
            'text_decoration' => 'none',
            'font_style' => 'normal',
            
            'padding' => '0px 0px 0px 0px',
            'margin' => '0px 0px 10px 0px',
            'font_size' => '16px',
            'line_height' => '20px',
            'color' => '#212121,1',
            'hover_color' => '#212121,1',
            'align' => 'center',
            'date_format' => 'F d,Y',
            'align' => 'center',
            'width' => '100%',
            'float' => 'none',
            'height' => 'auto',
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => ''
        ),
        'post_thumb' => array(
            'padding' => '0px 0px 0px 0px',
            'margin' => '0px',
            'bg' => 1,
            'w' => '400px',
            'h' => '200px',
            'width' => '100%',
            'height' => '',
            'show_pretty' => 1,
            'float' => 'none',
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => ''
        
        ),
        'post_content' => array(
            'padding' => '5px 15px 5px 15px',
            'margin' => '12px 0px 12px 0px',
            'font_weight' => 400,
            'text_decoration' => 'none',
            'font_style' => 'normal',
            'show' => 'limit',
            'font_size' => '14px',
            'line_height' => '18px',
            'color' => '#212121,1',
            'show_limit' => array(
                'type' => 'length',
                'val' => 100
            ),
            'align' => 'center',
            'width' => '100%',
            'float' => 'none',
            'height' => 'auto',
            'center' => 1,
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => ''
        ),
        'post_meta' => array(
            'padding' => '0px 0px 0px 0px',
            'margin' => '0px 0px 0px 0px',
            'width' => '100%',
            'float' => 'none',
            'height' => 'auto',
            'align' => 'center',
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => '',
            'font_size' => '14px',
            'line_height' => '18px',
            'post_hearts' => array(
                'i_color' => '#e64c28,1',
                'i_color_hover' => '#e64c00,1',
                'i_icon' => 'fa-heart'
            ),
            'post_comments' => array(
                'i_color' => '#000000,1',
                'i_color_hover' => '#212121,1',
                'i_icon' => 'fa-comment'
            ),
            'post_share' => array(
                'i_color' => '#000000,1',
                'i_color_hover' => '#212121,1',
                'i_icon' => 'fa-share'
            )
        ),
        'meta_stars' => array(
            'padding' => '0px 0px 0px 0px',
            'margin' => '12px 0px 0px 0px',
            'align' => 'left',
            'width' => '50%',
            'float' => 'left',
            'height' => 'auto',
            'i_color' => '#EEAA00,1',
            'i_color_hover' => '#f70,1',
            'i_font_size' => '14px',
            'i_line_height' => '18px',
            'i_icon' => 'fa-star',
            'i_align' => 'center'
        
        ),
        'woo_data' => array(
            'padding' => '0px 0px 0px 0px',
            'margin' => '0px 0px 0px 0px',
            'width' => '100%',
            'float' => 'none',
            'height' => 'auto',
            'align' => 'center',
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => '#212121,1',
            'color' => '#ffffff,1',
            'font_size' => '18px',
            'line_height' => '50px',
            'bg_hover_color' => '#d45729,1',
            'hover_color' => '#ffffff,1'
        
        )
    )
);
$templates['template_4'] = $templates['template_3'];
$templates['template_10'] = array(
    'title' => __("Blue template", "my_support_theme"),
    'width' => 400,
    'height' => 410,
    'post_tags' => array(
        'template' => array(
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => '#ffffff,1',
            'bg_hover_color' => '#ffffff,1',
            'margin'=>'15px 15px 45px 15px',
            'border'=>array(
                "border"=>"1px solid #818181"
            ),
            'box_shadow' => array(
                'type' => 'hover',
                array(
                    'h_shadow' => '0px',
                    'v_shadow' => '14px',
                    'blur' => '45px',
                    'spread' => '',
                    'color' => '#000000,0.247059'
                    
                ),
                array(
                    'h_shadow' => '0px',
                    'v_shadow' => '10px',
                    'blur' => '18px',
                    'spread' => '',
                    'color' => '#000000,0.219608'
                )
            )
            
        ),
        'post_thumb' => array(
            'padding' => '0px 0px 0px 0px',
            'margin' => '0px 0px 0px 0px',
            'bg' => 1,
            'w' => '400px',
            'h' => '200px',
            'width' => '100%',
            'height' => '',
            'show_pretty' => 1,
            'float' => 'none',
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => ''
        
        ),
        'post_title' => array(
            'font_weight' => 400,
            'text_decoration' => 'none',
            'font_style' => 'normal',
            
            'padding' => '0px 0px 0px 0px',
            'margin' => '10px 0px 10px 0px',
            'font_size' => '18px',
            'line_height' => '22px',
            'color' => '#3c5993,1',
            'hover_color' => '#3c5993 ,0.9',
            'align' => 'center',
            'width' => '100%',
            'float' => 'none',
            'height' => 'auto',
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => ''
        
        ),
        'post_date' => array(
            'font_weight' => 400,
            'text_decoration' => 'none',
            'font_style' => 'normal',
            
            'padding' => '0px 0px 0px 0px',
            'margin' => '10px 0px 10px 0px',
            'font_size' => '18px',
            'line_height' => '22px',
            'color' => '#3c5993,1',
            'hover_color' => '#3c5993,0.9',
            'align' => 'center',
            'date_format' => 'F d,Y',
            'align' => 'center',
            'width' => '100%',
            'float' => 'none',
            'height' => 'auto',
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => ''
        ),
        'share_div' => array(
            'added_css' => array(
                'font_weight,text_decoration,font_size,line_height' => '.my_post_share_div_12 i{css}',
                'bg_color' => ".my_post_share_arrow{border-top-color:{val}!important}",
                'bg_hover_color' => ".my_share_div_row:hover .my_post_share_arrow{border-top-color:{val}!important}"
            
            ),
            'font_weight' => 400,
            'text_decoration' => 'none',
            'font_style' => 'normal',
            
            'padding' => '10px 0px 10px 0px',
            'margin' => '0px 0px 0px 0px',
            'font_size' => '18px',
            'line_height' => '22px',
            'color' => '#ffffff,1',
            'hover_color' => '#ffffff,1',
            'align' => 'center',
            'width' => '150px',
            'float' => 'none',
            'height' => 'auto',
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => '#3c5993,1',
            'predefined_classes' => array(
                'fa_facebook_share' => array(
                    'color' => '#ffffff,1',
                    'hover_color' => '#d45729,1',
                    'font_size' => '14px',
                    'line_height' => '18px'
                ),
                'fa_twitter_share' => array(
                    'color' => '#ffffff,1',
                    'hover_color' => '#d45729,1'
                
                ),
                'fa_pinterest_share' => array(
                    'color' => '#ffffff,1',
                    'hover_color' => '#d45729,1'
                
                ),
                'fa_google_plus_share' => array(
                    'color' => '#ffffff,1',
                    'hover_color' => '#d45729,1'
                
                )
            
            )
        ),
        'post_content' => array(
            'padding' => '12px 15px 12px 15px',
            'margin' => '0px 0px 0px 0px',
            'font_weight' => 400,
            'text_decoration' => 'none',
            'font_style' => 'normal',
            'show' => 'limit',
            'font_size' => '14px',
            'line_height' => '18px',
            'color' => '#222222,1',
            'show_limit' => array(
                'type' => 'length',
                'val' => 100
            ),
            'align' => 'center',
            'width' => '100%',
            'float' => 'none',
            'height' => 'auto',
            'center' => 1,
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => ''
        ),
        'post_meta' => array(
            'padding' => '15px',
            'margin' => '0px 0px 0px 0px',
            'width' => '100%',
            'float' => 'left',
            'height' => 'auto',
            'align' => 'center',
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => '#3c5993,1',
            'font_size' => '14px',
            'line_height' => '18px',
            'post_hearts' => array(
                'i_font_size' => '14px',
                'i_line_height' => '18px',
                'i_color' => '#ffffff,1',
                'i_color_hover' => '#ffffff,0.8',
                'i_icon' => 'fa-heart'
            ),
            'post_comments' => array(
                'i_font_size' => '14px',
                'i_line_height' => '18px',
                'i_color' => '#ffffff,1',
                'i_color_hover' => '#ffffff,0.8',
                'i_icon' => 'fa-comment'
            ),
            'post_share' => array(
                'i_font_size' => '14px',
                'i_line_height' => '18px',
                'i_color' => '#ffffff,1',
                'i_color_hover' => '#ffffff,0.8',
                'i_icon' => 'fa-share'
            ),
            'predefined_classes' => array(
                'my_post_templates_hearts' => array(
                    'font_size' => '14px',
                    'line_height' => '18px',
                    'color' => '#ffffff,1',
                    'hover_color' => '#ffffff,0.8',
                    'align' => 'left',
                    'font_weight' => 400,
                    'text_decoration' => 'none',
                    'font_style' => 'normal'
                
                ),
                'my_post_templates_comments' => array(
                    'font_size' => '14px',
                    'line_height' => '18px',
                    'color' => '#ffffff,1',
                    'hover_color' => '#ffffff,0.8',
                    'align' => 'left',
                    'font_weight' => 400,
                    'text_decoration' => 'none',
                    'font_style' => 'normal'
                
                ),
                'my_post_templates_share_text' => array(
                    'font_size' => '14px',
                    'line_height' => '18px',
                    'color' => '#ffffff,1',
                    'hover_color' => '#ffffff,0.8',
                    'align' => 'left',
                    'font_weight' => 400,
                    'text_decoration' => 'none',
                    'font_style' => 'normal'
                
                )
            
            )
        )
    )
);
$templates['template_11'] = array(
    'title' => __("Full Image", "my_support_theme"),
    'width' => 400,
    'height' => 400,
    'post_tags'=>array(
        
    )
    
);
foreach ($templates['template_10']['post_tags'] as $k=>$v){
    $templates['template_11']['post_tags'][$k]=$v;
}
//$templates['template_11']['post_tags']['post_content']['width']='100%';
$templates['template_11']['post_tags']['post_thumb']=array(
        'padding' => '0px 0px 0px 0px',
        'margin' => '0px 0px 0px 0px',
        'bg' => 1,
        'w' => '400px',
        'h' => '400px',
        'position'=>'absolute',
        'top'=>'0px',
        'left'=>'0px',
        'width' => '100%',
        'height' => '100%',
        'show_pretty' => 1,
        'float' => 'none',
        'bg_image' => '',
        'bg_repeat' => '',
        'bg_color' => ''
);
$templates['template_11']['post_tags']['post_title']['color']='#ffffff,1';
$templates['template_11']['post_tags']['post_title']['hover_color']='#ffffff,0.8';
$templates['template_11']['post_tags']['post_date']['color']='#ffffff,1';
$templates['template_11']['post_tags']['post_date']['hover_color']='#ffffff,0.8';
$templates['template_11']['post_tags']['post_content']['color']='#ffffff,1';
$templates['template_11']['post_tags']['post_meta']['bg_color']='';





$templates['template_1'] = array(
    'title' => __("General Post Template One", "my_support_theme"),
    'width' => 400,
    'height' => 'auto',
    'post_tags' => array(
        'template' => array(
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => '#ffffff,1',
            'bg_hover_color' => '#ffffff,1',
            'margin'=>'15px 15px 45px 15px',
            'border'=>array(
                "border"=>"1px solid #818181"
            ), 
            'box_shadow' => array(
                'type' => 'hover',
                array(
                    'h_shadow' => '0px',
                    'v_shadow' => '14px',
                    'blur' => '45px',
                    'spread' => '',
                    'color' => '#000000,0.247059'
                    
                ),
                array(
                    'h_shadow' => '0px',
                    'v_shadow' => '10px',
                    'blur' => '18px',
                    'spread' => '',
                    'color' => '#000000,0.219608'
                )
            )
            
        ),
        
        'view_a' => array(
            'font_weight' => 400,
            'text_decoration' => 'none',
            'font_style' => 'normal',
            
            'padding' => '0px 0px 0px 0px',
            'margin' => '0px 0px 0px 0xp',
            'font_size' => '18px',
            'line_height' => '22px',
            'color' => '#212121,1',
            'hover_color' => '#212121,1',
            'align' => 'center',
            'width' => '100%',
            'float' => 'none',
            'height' => '100%',
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => '#ffffff,1',
            'added_css' => array(
                'bg_color' => array(
                    ".my_dialog_view_a_ui{background-color:{val} !important}",
                    ".my_dialog_view_a{background-color:{val} !important}"
                ),
                'bg_hover_color' => array(
                    ".my_dialog_view_a_ui:hover{background-color:{val} !important}",
                    ".my_dialog_view_a:hover{background-color:{val} !important}"
                )
            ),
            'predefined_classes' => array(
                
                'my_header_dialog1' => array(
                    'bg_color' => '#222222,1',
                    'color' => '#ffffff,1',
                    'padding' => '10px',
                    'border' => array(
                        'bottom' => '5px solid #0074A2'
                    )
                ),
                'my_view_a_title' => array(
                    'padding' => '15px',
                    'font_size' => '20px',
                    'line_height' => '26px',
                    'text_decoration' => 'none',
                    'text_style' => 'normal',
                    'color' => '#ffffff,1',
                    'hover_color' => '#fffff,1'
                ),
                'my_view_a_loading' => array(
                    'padding' => '10px',
                    'font_size' => '20px',
                    'line_height' => '26px',
                    'text_decoration' => 'none',
                    'text_style' => 'normal',
                    'color' => '#212121,1',
                    'hover_color' => '#212121,1',
                    'align' => 'center',
                    'width' => '100%'
                ),
		                /*'my_view_a_dialog'=>array(
		                    'font_size'=>'20px',
		                    'line_height'=>'26px',

		                    'color'=>'#ffffff,1',
		                    'hover_color'=>'#d45729,1'
		                ),*/
		                'my_view_a_loading_i' => array(
                    'font_size' => '20px',
                    'line_height' => '26px',
                    'color' => '#212121,1',
                    'hover_color' => '#212121,1'
                ),
                'my_view_a_close_dialog' => array(
                    'font_size' => '20px',
                    'line_height' => '26px',
                    
                    'color' => '#ffffff,1',
                    'hover_color' => '#d45729,1'
                )
            
            )
        ),
        'stars_popup' => array(
            'added_css' => array(
                'bg_color' => array(
                    ".my_dialog_stars_ui{background-color:{val} !important}",
                    ".my_dialog_stars{background-color:{val} !important}"
                ),
                'bg_hover_color' => array(
                    ".my_dialog_stars_ui:hover{background-color:{val} !important}",
                    ".my_dialog_stars:hover{background-color:{val} !important}"
                )
            ),
            'font_weight' => 400,
            'text_decoration' => 'none',
            'font_style' => 'normal',
            
            'padding' => '0px 0px 0px 0px',
            'margin' => '0px 0px 0px 0xp',
            'font_size' => '18px',
            'line_height' => '22px',
            'color' => '#212121,1',
            'hover_color' => '#212121,1',
            'align' => 'center',
            'width' => '395px',
            'float' => 'none',
            'height' => '190px',
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => '#ffffff,1',
            'predefined_classes' => array(
                'my_header_dialog' => array(
                    'bg_color' => '#222222,1',
                    'color' => '#ffffff,1',
                    'padding' => '10px',
                    'border' => array(
                        'bottom' => '5px solid #0074A2'
                    )
                ),
                'my_stars_popup_title' => array(
                    'font_size' => '20px',
                    'line_height' => '26px',
                    'text_decoration' => 'none',
                    'text_style' => 'normal',
                    'color' => '#ffffff,1',
                    'hover_color' => '#ffffff,1'
                ),
                'my_stars_close_dialog' => array(
                    'font_size' => '20px',
                    'line_height' => '26px',
                    
                    'color' => '#ffffff,1',
                    'hover_color' => '#d45729,1'
                ),
                'my_stars_popup_stars' => array(
                    'padding' => '10px',
                    'align' => 'center'
                    // 'bg_color'=>'#ffffff,1',
                    // 'color'=>'#212121,1',
                ),
                'my_stars_popup_title' => array(
                    'padding' => '10px',
                    'font_size' => '20px',
                    'line_height' => '26px',
                    'text_decoration' => 'none',
                    'text_style' => 'normal',
                    'color' => '#212121,1',
                    'hover_color' => '#212121,1'
                ),
                'my_add_stars_button' => array(
                    'padding' => '10px',
                    'align' => 'center',
                    'font_size' => '14px',
                    'line_height' => '20px',
                    'bg_color' => '#212121,1',
                    'bg_hover_color' => '#d45729,1',
                    'color' => '#ffffff,1',
                    'hover_color' => '#fffff,1'
                
                ),
                'my_jscript_stars' => array(
                    'margin' => '0px 0px 20px 0px'
                )
            )
        ),
        'share_div' => array(
            'added_css' => array(
                'font_weight,text_decoration,font_size,line_height' => '.my_post_share_div_12 i{css}',
                'bg_color' => ".my_post_share_arrow{border-top-color:{val}!important}",
                'bg_hover_color' => ".my_share_div_row:hover .my_post_share_arrow{border-top-color:{val}!important}"
            
            ),
            'font_weight' => 400,
            'text_decoration' => 'none',
            'font_style' => 'normal',
            
            'padding' => '10px 0px 10px 0px',
            'margin' => '0px 0px 0px 0px',
            'font_size' => '18px',
            'line_height' => '22px',
            'color' => '#212121,1',
            'hover_color' => '#212121,1',
            'align' => 'center',
            'width' => '150px',
            'float' => 'none',
            'height' => 'auto',
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => '#222222,1',
            'predefined_classes' => array(
                'fa_facebook_share' => array(
                    'color' => '#ffffff,1',
                    'hover_color' => '#d45729,1',
                    'font_size' => '14px',
                    'line_height' => '18px'
                ),
                'fa_twitter_share' => array(
                    'color' => '#ffffff,1',
                    'hover_color' => '#d45729,1'
                
                ),
                'fa_pinterest_share' => array(
                    'color' => '#ffffff,1',
                    'hover_color' => '#d45729,1'
                
                ),
                'fa_google_plus_share' => array(
                    'color' => '#ffffff,1',
                    'hover_color' => '#d45729,1'
                
                )
            
            )
        ),
        'post_title' => array(
            'font_weight' => 400,
            'text_decoration' => 'none',
            'font_style' => 'normal',
            
            'padding' => '0px 0px 0px 0px',
            'margin' => '10px 0px 10px 0px',
            'font_size' => '18px',
            'line_height' => '22px',
            'color' => '#212121,1',
            'hover_color' => '#212121,1',
            'align' => 'center',
            'width' => '100%',
            'float' => 'none',
            'height' => 'auto',
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => ''
        
        ),
        'post_woo_price' => array(
            'font_weight' => 400,
            'text_decoration' => 'none',
            'font_style' => 'normal',
            
            'padding' => '0px 0px 0px 0px',
            'margin' => '10px 0px 0px 0px',
            'font_size' => '16px',
            'line_height' => '20px',
            'color' => '#212121,1',
            'hover_color' => '#212121,1',
            'align' => 'center',
            'width' => '100%',
            'float' => 'none',
            'height' => 'auto',
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => '',
            'predefined_classes' => array(
                'woo_price_regular' => array(
                    'text_decoration' => 'line-through',
                    'color' => '#d45729,1',
                    'font_style' => 'normal',
                    'font_weight' => 600,
                    'font_size' => '16px',
                    'line_height' => '20px',
                    'hover_color' => '#212121,1'
                ),
                'woo_price_sale' => array(
                    'text_decoration' => 'none',
                    'color' => '#d45729,1',
                    'font_style' => 'normal',
                    'font_weight' => 600,
                    'font_size' => '16px',
                    'line_height' => '20px',
                    'hover_color' => '#212121,1'
                
                )
            )
        ),
        'post_date' => array(
            'font_weight' => 400,
            'text_decoration' => 'none',
            'font_style' => 'normal',
            
            'padding' => '0px 0px 0px 0px',
            'margin' => '0px 0px 10px 0px',
            'font_size' => '16px',
            'line_height' => '20px',
            'color' => '#212121,1',
            'hover_color' => '#212121,1',
            'align' => 'center',
            'date_format' => 'F d,Y',
            'align' => 'center',
            'width' => '100%',
            'float' => 'none',
            'height' => 'auto',
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => ''
        ),
        'post_thumb' => array(
            'padding' => '0px 0px 0px 0px',
            'margin' => '0px',
            'bg' => 1,
            'w' => '400px',
            'h' => '200px',
            'width' => '100%',
            'height' => '',
            'show_pretty' => 1,
            'float' => 'none',
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => ''
        
        ),
        'post_content' => array(
            //'padding' => '0px 15px 0px 15px',
            'padding'=>'0px',
            'margin' => '0px 0px 0px 0px',
            'font_weight' => 400,
            'text_decoration' => 'none',
            'font_style' => 'normal',
            'show' => 'limit',
            'font_size' => '14px',
            'line_height' => '18px',
            'color' => '#212121,1',
            'show_limit' => array(
                'type' => 'length',
                'val' => 100
            ),
            'align' => 'center',
            'width' => '100%',
            'float' => 'none',
            'height' => 'auto',
            'center' => 1,
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => '',
            'predefined_classes' => array(
                'my_post_content'=>array(
                    'padding' => '12px 15px 12px 15px',
                    
                )
                
            )
        ),
        'post_meta' => array(
            'padding' => '0px 0px 0px 0px',
            'margin' => '10px 0px 0px 0px',
            'width' => '50%',
            'float' => 'left',
            'height' => 'auto',
            'align' => 'center',
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => '',
           // 'font_size' => '14px',
           // 'line_height' => '18px',
            'post_hearts' => array(
                'i_font_size' => '14px',
                'i_line_height' => '18px',
                'i_color' => '#e64c28,1',
                'i_color_hover' => '#e64c00,1',
                'i_icon' => 'fa-heart'
            ),
            'post_comments' => array(
                'i_font_size' => '14px',
                'i_line_height' => '18px',
                'i_color' => '#000000,1',
                'i_color_hover' => '#212121,1',
                'i_icon' => 'fa-comment'
            ),
            'post_share' => array(
                'i_font_size' => '14px',
                'i_line_height' => '18px',
                'i_color' => '#000000,1',
                'i_color_hover' => '#212121,1',
                'i_icon' => 'fa-share'
            ),
            'predefined_classes' => array(
                'my_post_templates_hearts' => array(
                    'font_size' => '14px',
                    'line_height' => '18px',
                    'color' => '#212121,1',
                    'hover_color' => '#212121,1',
                    'align' => 'left',
                    'font_weight' => 400,
                    'text_decoration' => 'none',
                    'font_style' => 'normal'
                
                ),
                'my_post_templates_comments' => array(
                    'font_size' => '14px',
                    'line_height' => '18px',
                    'color' => '#212121,1',
                    'hover_color' => '#212121,1',
                    'align' => 'left',
                    'font_weight' => 400,
                    'text_decoration' => 'none',
                    'font_style' => 'normal'
                
                ),
                'my_post_templates_share_text' => array(
                    'font_size' => '14px',
                    'line_height' => '18px',
                    'color' => '#212121,1',
                    'hover_color' => '#212121,1',
                    'align' => 'left',
                    'font_weight' => 400,
                    'text_decoration' => 'none',
                    'font_style' => 'normal'
                
                )
            
            )
        ),
        'meta_stars' => array(
            'added_css' => array(
                //'i_font_size'=>".my_stars_diff{left:-{exp}={val}+8 !important}",
                
                ),
            'padding' => '0px 0px 0px 0px',
            'margin' => '10px 0px 00px 0px',
            'align' => 'center',
            'width' => '50%',
            'float' => 'left',
            'height' => 'auto',
            'i_color' => '#EEAA00,1',
            'i_color_hover' => '#f70,1',
            'i_font_size' => '14px',
            'i_line_height' => '18px',
            'i_icon' => 'fa-star',
            'i_align' => 'center',
            'i_icon' => 'fa-star'
        
        ),
        'woo_data' => array(
            'padding' => '0px 0px 0px 0px',
            'margin' => '0px 0px 0px 0px',
            'width' => '100%',
            'float' => 'none',
            'height' => 'auto',
            'align' => 'center',
            'bg_image' => '',
            'bg_repeat' => '',
            'bg_color' => '#212121,1',
            'color' => '#ffffff,1',
            'font_size' => '18px',
            'line_height' => '50px',
            'bg_hover_color' => '#d45729,1',
            'hover_color' => '#ffffff,1'
        
        ),
        'predefined_classes' => array(
            'my_shortcode_list_ul' => array(
                'bg_color' => '',
                'width' => '100%',
                'list_style' => 'none'
            ),
            'my_shortcode_list_li' => array(
                'padding' => '10px 0px',
                'margin' => '0px'
            
            ),
            'my_shortcode_list_li_icon' => array(
                'font_size' => '14px',
                'line_height' => '18px',
                'text_decoration' => 'none',
                'color' => '#1484c9,1',
                'hover_color' => '#1484c9,1',
                'padding' => '0px 6px 0px 6px'
            
            ),
            'my_shortcode_list_li_span' => array(
                'font_family' => 'default',
                'font_size' => '14px',
                'line_height' => '18px',
                'letter_spacing' => '1px',
                'text_decoration' => 'none',
                'text_style' => 'normal',
                'color' => '#444444,1',
                'hover_color' => '#444444,1'
            )
        )
    
    )
);
for ($i = 2; $i < 10; $i ++) {
    $templates['template_' . $i]['post_tags']['post_meta']['predefined_classes'] = $templates['template_1']['post_tags']['post_meta']['predefined_classes'];
    $templates['template_' . $i]['post_tags']['post_woo_price'] = $templates['template_1']['post_tags']['post_woo_price'];
    $templates['template_' . $i]['post_tags']['share_div'] = $templates['template_1']['post_tags']['share_div'];
    $templates['template_' . $i]['post_tags']['view_a'] = $templates['template_1']['post_tags']['view_a'];
    $templates['template_' . $i]['post_tags']['stars_popup'] = $templates['template_1']['post_tags']['stars_popup'];
    if ($i == 7) {
        
        foreach ($templates['template_' . $i]['post_tags']['post_woo_price']['predefined_classes'] as $k1 => $v1) {
            $templates['template_' . $i]['post_tags']['post_woo_price']['predefined_classes'][$k1]['line_height'] = '30px';
            $templates['template_' . $i]['post_tags']['post_woo_price']['predefined_classes'][$k1]['font_size'] = '18px';
        }
    }
}

for ($i = 1; $i < 10; $i ++) {
    $val = $i * 100;
    $templates['predefined']['text']['font_weight']['values'][$val] = $val;
}
return $templates;