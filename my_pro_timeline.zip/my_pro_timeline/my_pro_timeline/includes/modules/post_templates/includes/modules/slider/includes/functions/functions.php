<?php
if(!defined('ABSPATH'))die('');
function wp_my_front_testimonials_get_styles(){
	
}
/**
 * Add front styles
 * @param unknown $type
 * @param unknown $settings
 */
function wp_my_front_testimonials_styles($type,$settings){
	$css='';
	switch($type){
		case 'card':
			if( $settings['shadow']=='on-hover' || $settings['shadow']=='show'){
				$my_show_shadow=true;
			
			}
			if(!empty($my_show_shadow)){
			$css.='.my_timeline_hor_out_div > ul >li {
					padding-bottom:52px !important;
				}';
			}
		break;	
	}
	return $css;
}
/**
 * 
 * @param unknown $val
 * @param string $url
 * @return string|Ambigous <>
 */
function wp_my_front_testimonials_render_image($val,$url=''){
	if(isset($val['thumb_name'])){
		$file=$url.'people/'.$val['thumb_name'];
		return $file;
	}else if(isset($val['thumb_id'])){
		$src=wp_get_attachment_image_src($val['thumb_id']);
		return $src[0];
	}else {
		$src='http://2.gravatar.com/avatar/?s=80&d=mm&r=g';
		if(is_ssl()){
			$src=str_replace('http://', 'https://', $src);
			
		}
		return $src;
	}
}

function wp_my_front_testimonials_render_metadata($item,$show=array()){
	$show_all=false;
	if(empty($show))$show_all=true;
	if($show_all){
		$show=array(
			'name'=>'{name} / {position}',
			'stars'=>'{stars}',
			'company'=>'{company_name} / {company_url}'		
		);
	}
	?>
	<ul class="my_testimonials_metadata">
		<?php 
		foreach($show as $key_1=>$val_1){
			$str=$val_1;
			preg_match_all('/({[a-z_]+\})/ims', $val_1,$matches);
			//print_r($matches);
			foreach($matches[1] as $k1=>$v1){
				$v2=str_replace('{', '', $v1);
				$v2=str_replace('}', '', $v2);
				///echo 'v2'.$v2;
				$val_2='';
				if(isset($item[$v2])){
					$val_2=$item[$v2];
				}
				//echo 'val_2'.$val_2.'<BR/>';
				if($v2!=='stars'){
				if($v2=='company_url'){
					if(!empty($val_2)){
						$val_2='<a href="'.$val_2.'" target="_blank" class="my_transition">'.__("Company url","my_support_theme").'</a>';
					}
				}	
				$str=str_replace($v1, $val_2, $str);
				}
			}
		?>
		<li>
			<?php if($key_1!='stars'){
				?>
				<span class="my_testimonials_metadata_<?php echo $key_1?>">
				<?php 
				echo $str;
				?>
				</span>
				<?php 
			}else {?>
				
					<div class="my_jscript_stars">
					<ul>
			<?php for($f=1;$f<=5;$f++){?>
				<li data-i="<?php echo $f;?>">
					<i  class="fa fa-star <?php if($f<=$val_2)echo 'my_stars_active'?>"></i>
				</li>
					<?php }?>
				</ul>
				</div>
			<?php }?>
			
		</li>
		<?php 	
		}
		?>
	</ul>
	<?php 
	
}
