<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Module_Shortcodes_Row')){
	class Class_My_Module_Shortcodes_Row extends Class_My_Module_Shortcodes_General{
	    protected $noNewLayouts=true;
		function Class_My_Module_Shortcodes_Row($options=array()){
			parent::Class_My_Module_Shortcodes_General($options);
		}
		public function display_element(){

			$layouts=$this->options['layouts'];
			if($this->noNewLayouts){
			    $file=plugin_dir_path(__FILE__).'views/display_only.php';
			}
			else $file=plugin_dir_path(__FILE__).'views/display.php';
			require $file;
			/*$this->render_buttons(array(
					'my_insert'=>array(
							'title'=>__("Insert","my_support_theme")
					)
			));*/
		}
		public function display_content(){
			$file=plugin_dir_path(__FILE__).'views/columns.php';
			$html=require $file;
			$file=plugin_dir_path(__FILE__).'views/row.php';
			$row=require $file;
			?>
					<script type="text/html" class="my_shortcode_row">
						<?php echo $row;?>
					</script>
					<script type="text/html" class="my_shortcode_row_default">
						<?php echo $html ;?>
					</script>
					<?php
				}
		static function display_rows($rows,$echo=true){
			$file=plugin_dir_path(__FILE__).'views/columns.php';
			$html=require $file;
			//echo 'Html '.$html;
			$file=plugin_dir_path(__FILE__).'views/row.php';
			$row=require $file;
			$i=1;
			$all_html='';
			foreach($rows as $key=>$val){
				$id="my_shortcode_row_row_".$i;
				$row_html="";
				foreach($val['columns'] as $k1=>$v1){
					$width=$v1['width'];
					$i_html=$html;
					$id_1=$id."_".$k1;
					$i_html=str_replace("{id}", $id_1, $i_html);
					$i_html=str_replace("{width}", $width,$i_html);
					$i_html=str_replace("{i}", $k1, $i_html);
					//echo 'I html '.$i_html;
					$row_html.=$i_html;
				}
				//echo 'Row html '.$row_html;
				$row_ht=$row;
				$row_ht=str_replace("{id}", $id, $row_ht);
				$row_ht=str_replace("{i}", $i, $row_ht);
				$row_ht=str_replace("{content}", $row_html, $row_ht);
				$all_html.=$row_ht;
				$i++;
			}
			if($echo)echo $all_html;
			return $all_html;

		}
	}
}
