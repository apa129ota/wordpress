<?php
if (! defined ( 'ABSPATH' ))
	die ( '' );
?>
<div class="my_shortcode_heading_div">
	<?php echo $formHtml;?>
	<input type="button" class="my_heading_action button button-primary button-large" "data-key="insert" value="<?php echo __("Insert Heading","my_support_theme")?>"/>

</div>