<?php
if(!defined('ABSPATH'))die('');
$image=wp_my_front_testimonials_render_image($item,$my_url);
?>
<div class="my_timeline_item my_testimonial_item my_testimonial_bottom " data-float="<?php echo $float;?>">

	<div class="my_testimonial_text">
		
		<p class="my_testimonial_p">
		<?php echo $item['text'];?>
		</p>
		<?php if($float=='left'){?>
			<?php if(!empty($settings['show_text_border'])){?>
			<div class="my_arrow_border my_bottom_arrow_inner my_bottom_arrow_inner_left"> 
			</div>
			<?php }?>
			<div class="my_arrow my_bottom_arrow my_bottom_arrow_left">
			
			</div>
		<?php }else {?>
			<?php if(!empty($settings['show_text_border'])){?>
			<div class="my_arrow_border my_bottom_arrow_inner my_bottom_arrow_inner_right"> 
			</div>
			<?php }?>
			<div class="my_arrow my_bottom_arrow my_bottom_arrow_right">
			
			</div>
		<?php }?>
	</div>
	<div class="my_testimonial_meta_div my_clear_after">
	<div class="my_testimonial_meta my_clear_after <?php echo 'my_float_'.$float?>">
		<div class="my_float_<?php echo $float;?> <?php if($float=='left'){echo 'my_testimonials_thumb_left my_testimonial_thumb_div';}else echo 'my_testimonials_meta_data_right my_testimonial_meta_data_div'?>">
			<?php 
			//if($float=='left'){
				?>
				<img class="my_testimonial_thumb" src="<?php echo $image?>"/>
				<?php 
			//}else {
			//wp_my_front_testimonials_render_metadata($item);
			//}
			?>
		</div>
		<div class="my_float_<?php echo $float;?> <?php if($float=='right'){echo 'my_testimonials_thumb_right my_testimonial_thumb_div';}else echo 'my_testimonials_meta_data_left my_testimonial_meta_data_div'?>">
			<?php 
			/*if($float=='right'){
				?>
							<img class="my_testimonial_thumb" src="<?php echo $image?>"/>
							<?php 
						}else {
			*/
			wp_my_front_testimonials_render_metadata($item);
			//}
			?>
		</div>
	</div>
</div>