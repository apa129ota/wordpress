<?php 
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Module_Post_Templates_Templates')){
	class Class_My_Module_Post_Templates_Templates extends Class_My_General_Module{
		use MySingleton;
		
		function __construct($options=array()){
			$options['url']=plugin_dir_url(__FILE__);
			$options['dir']=plugin_dir_path(__FILE__);
			parent::__construct($options);
		
		}
		function init(){
			parent::init(array());
		}
		/**
		 * Call admin includes front controller
		 */
		public function setAdminIncludes(){
			add_action('admin_head', array($this,'admin_head'),PHP_INT_MAX);
			add_action('admin_enqueue_scripts',array($this,'admin_scripts'),PHP_INT_MAX);
			add_action('admin_footer',array($this,'admin_footer'),PHP_INT_MAX);
			add_action('wp_ajax_'.$this->ajax_action,array($this,'backend_ajax'));
		}
		private function renderOptionsForm(){
			$id=@$_GET['id'];
			if(!isset($id))$id='';
			$this->global_plugin->loadModuleClass('new_form');
			$elements=$this->templates['form'];
			if(!empty($elements['post_type'])){
				if(!empty($this->post_types)){
					foreach($this->post_types as $k=>$v){
						$name=$v;
						if(is_object($v)){
							$name=$v->label;
						}
						$elements['post_type']['values'][$k]=$name;
					}
				}
			}
			$key='my_templates';
			$my_set_debug=$this->debug;
			$my_set_debug=0;
			$options=array(
					'id'=>$key,
					'elements'=>$elements,
					'hidden'=>array(
							'my_nonce'=>wp_create_nonce(),
							'id'=>$id
					),
					'element_template'=>'my_li.php',
					'form_template'=>'my_form.php',
					'my_debug'=>$my_set_debug
			);
			$form_class=new Class_Wp_My_Module_New_Form($options);
			ob_start();
			$form_class->render_form();
			$this->options_form=ob_get_clean();
		}
		public function admin_head(){
			$my_set_debug=0;
			if($this->debug){
				$my_set_debug=1;
			}
			$msgs=$this->loadOptions('admin_msgs.php');
			$options=$this->global_plugin->loadOptions("ajax_options.php");
			?>
			<script type="text/javascript">
			jQuery(document).ready(function($){
				var o_ajax=<?php echo json_encode($options);?>;
				myGlobalAjaxClass_inst=new myGlobalAjaxClass(o_ajax);
				var o3={};
				myAdminMsgs_inst=new myAdminMsgs(o3);
				var o={};
				o.my_debug=<?php echo $my_set_debug;?>;
				myAdminMsgs_inst=new myAdminMsgs(o);
				var o4={};
				o4.my_debug=<?php echo $my_set_debug;?>;
				o4.msgs=<?php echo json_encode($msgs);?>;
				myAdminTemplatesAdmin_inst=new myAdminTemplatesAdmin(o4);
			});
			</script>
			<?php 
					
		}
		public function admin_footer(){
		}
		public function admin_scripts(){
			wp_enqueue_script('jquery');
			wp_enqueue_script("jquery-touch-pounch");
			wp_enqueue_script('jquery-ui-core');
			wp_enqueue_script("jquery-ui-widget");
			wp_enqueue_script("jquery-ui-dialog");
			wp_enqueue_script('jquery-effects-core');
			wp_enqueue_script("jquery-ui-tooltip");
			wp_enqueue_script("jquery-ui-resizable");
			wp_enqueue_script("jquery-ui-draggable");
			wp_enqueue_script("jquery-ui-droppable");
			wp_enqueue_media();
			$url=$this->global_plugin->getUrl('jscript').'admin/my_ajax.js';
			wp_enqueue_script('my_framework_ajax',$url);
			$url=$this->global_plugin->getUrl('jscript').'admin/admin_msgs.js';
			wp_enqueue_script("my_framework_msgs",$url);
			
			$url=$this->global_plugin->getUrl('css').'msgs.css';
			wp_enqueue_style("my_testimonials_msgs_form",$url);
			$url=$this->getUrl('jscript');
			wp_enqueue_script('my_mapper_admin_js',$url.'my_admin.js');
			$css_url=$this->getUrl('css');
			wp_enqueue_style('my_framework_templates_admin_css',$css_url.'admin.css');
			//wp_enqueue_script('my_mapper_main_js',$url.'main.js');
		}
		public function getAdminPageTemplate(){
			$dir=$this->getDir('views').'editor.php';
			return $dir;
		}
		public function getAdminPageOptions(){
			$dir=$this->getDir('views').'options.php';
			//return $dir;
			$options_form=$this->options_form;
			ob_start();
			require $dir;
			$html=ob_get_clean();
			return $html;
		}
		private function getPostTypes(){
			$this->post_types=array(
				'post'=>__("Post","my_support_theme")
			);
			$args = array(
					'public'   => true,
					'_builtin' => false
			);
			
			$output = 'objects'; // names or objects, note names is the default
			$operator = 'and'; // 'and' or 'or'
			
			$post_types = get_post_types( $args, $output, $operator );
			foreach($post_types as $k=>$v){
				$this->post_types[$k]=$v;
				
			}
			self::debug("post_types", $this->post_types);	
		}
	}
}
	