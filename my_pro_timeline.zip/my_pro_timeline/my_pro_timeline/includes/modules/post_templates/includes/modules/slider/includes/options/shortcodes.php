<?php
if(!defined('ABSPATH'))die('');
$shortcodes['layout']=array(
		'layout_1600_type'=>array(
				'display'=>'inline',
				'title'=>__("Set sizes in (layout>1600)","my_support_theme"),
				'type'=>'jscript_radio_list',
				'default'=>'%',
				'layout_class'=>'my_col_33',
				'values'=>array(
						'%'=>__("Percentage","my_support_theme"),
						'px'=>__("Pixels","my_support_theme")
				)
		),
		'layout_1600_height'=>array(
				'title'=>__("Container height (layout>1600)","my_support_theme"),
				'type'=>'text',
				'default'=>'80',
				'layout_class'=>'my_col_33',
		
		),
		'layout_1600_cols'=>array(
				'title'=>__("Columns in the slider (layout>1600)","my_support_theme"),
				'type'=>'text',
				'default'=>'5',
				'layout_class'=>'my_col_33',
					
		),
			
		'layout_1280_type'=>array(
				'display'=>'inline',
				'title'=>__("Set sizes in (layout>1280)","my_support_theme"),
				'type'=>'jscript_radio_list',
				'default'=>'%',
				'layout_class'=>'my_col_33',
				'values'=>array(
						'%'=>__("Percentage","my_support_theme"),
						'px'=>__("Pixels","my_support_theme")
				)
		),
		'layout_1280_height'=>array(
				'title'=>__("Container height (layout>1280)","my_support_theme"),
				'type'=>'text',
				'default'=>'80',
				'layout_class'=>'my_col_33',
					
		),
		'layout_1280_cols'=>array(
				'title'=>__("Columns in the slider (layout>1280)","my_support_theme"),
				'type'=>'text',
				'default'=>'4',
				'layout_class'=>'my_col_33',
		
		),
		'layout_980_type'=>array(
				'display'=>'inline',
				'title'=>__("Set sizes in (layout>980)","my_support_theme"),
				'type'=>'jscript_radio_list',
				'default'=>'%',
				'layout_class'=>'my_col_33',
				'values'=>array(
						'%'=>__("Percentage","my_support_theme"),
						'px'=>__("Pixels","my_support_theme")
				)
		),
		'layout_980_height'=>array(
				'title'=>__("Container height (layout>980)","my_support_theme"),
				'type'=>'text',
				'default'=>'80',
				'layout_class'=>'my_col_33',
		
		),
		'layout_980_cols'=>array(
				'display'=>'inline',
				'title'=>__("Columns in the slider (layout>980)","my_support_theme"),
				'type'=>'text',
				'default'=>'3',
				'layout_class'=>'my_col_33',
					
		),
		'layout_700_type'=>array(
				'display'=>'inline',
				'title'=>__("Set sizes in (layout>700)","my_support_theme"),
				'type'=>'jscript_radio_list',
				'default'=>'%',
				'layout_class'=>'my_col_33',
				'values'=>array(
						'%'=>__("Percentage","my_support_theme"),
						'px'=>__("Pixels","my_support_theme")
				)
		),
		'layout_700_height'=>array(
				'title'=>__("Container height (layout>700)","my_support_theme"),
				'type'=>'text',
				'default'=>'80',
				'layout_class'=>'my_col_33',
					
		),
		'layout_700_cols'=>array(
				'title'=>__("Columns in the slider (layout>700)","my_support_theme"),
				'type'=>'text',
				'default'=>'2',
				'layout_class'=>'my_col_33',
		
		),
		'layout_small_type'=>array(
				'display'=>'inline',
				'title'=>__("Set sizes in (layout<700px)","my_support_theme"),
				'type'=>'jscript_radio_list',
				'default'=>'%',
				'layout_class'=>'my_col_33',
				'values'=>array(
						'%'=>__("Percentage","my_support_theme"),
						'px'=>__("Pixels","my_support_theme")
				)
		),
		'layout_small_height'=>array(
				'title'=>__("Container height (layout<700)","my_support_theme"),
				'type'=>'text',
				'default'=>'80',
				'layout_class'=>'my_col_33',
		
		),
		'layout_small_cols'=>array(
				'title'=>__("Columns in the slider (layout<700)","my_support_theme"),
				'type'=>'text',
				'default'=>'1',
				'layout_class'=>'my_col_33',
					
		),
);
$shortcodes['default']=array(
'elements'=>array(
				'title'=>array(
						'type'=>'text',
						'title'=>__("Title","my_support_theme"),
						'tooltip'=>__("Shortcode title","my_support_theme"),
						'layout_class'=>'my_col_100',
						'placeholder'=>__("Shortcode Title","my_support_theme")	
				),
				'limit'=>array(
						'type'=>'text',
						'tooltip'=>__("Limit posts in this shortcode.","my_support_theme"),
						'title'=>__("Limit posts","my_support_theme"),
						'layout_class'=>'my_col_25',
						'default'=>50
						
				),
				'category'=>array(
						'type'=>'jscript_dropdown',
						'title'=>__("Testimonial Category","my_support_theme"),
						'tooltip'=>__("Filter posts by testimonial category","my_support_theme"),
						'widths'=>array(
								600=>'100%',
								1200=>'25%',
						
						),
						'layout_class'=>'my_col_25',
						'default'=>'all',
						'values'=>array(
							'all'=>__("All Categories","my_support_theme")
						),
						'jscript'=>array(
								'max_c'=>1,
								'max_sel'=>__("Maximum elements are selected","my_support_theme"),
								'duration'=>500,
								'animation'=>'fadein',
								'choose_value'=>__("Plese Select value","my_support_theme"),
						),
						'show_filter'=>1,
						'multiple'=>false,
						'choose_value'=>__("Plese Select value","my_support_theme"),
				),
				'order_by'=>array(
						'type'=>'jscript_dropdown',
						'title'=>__("Order by","my_support_theme"),
						'tooltip'=>__("Order posts by criteria, post_date stars ect","my_support_theme"),
						'default'=>'post_date',
						'layout_class'=>'my_col_25',
						'jscript'=>array(
								'max_c'=>1,
								'max_sel'=>__("Maximum elements are selected","my_support_theme"),
								'duration'=>500,
								'animation'=>'fadein',
								'choose_value'=>__("Plese Select value","my_support_theme"),
						),
						'values'=>array(
							'post_date'=>__("Post date","my_support_theme"),
							'stars'=>__("Stars","my_support_theme")	
						),
						'show_filter'=>0,
						'multiple'=>false,
							
						),
				'order'=>array(
						'type'=>'on_off',
						'title'=>__("Order","my_support_theme"),
						'tooltip'=>__("Order posts in ascending or descending order","my_support_theme"),
						'layout_class'=>'my_col_25',
						'on'=>__("Ascending","my_support_theme"),
						'off'=>__("Descending","my_support_theme"),
						'default'=>'',
						),
				'autoplay'=>array(
					'type'=>'on_off',
					'title'=>__("Autoplay","my_support_theme"),
					'tooltip'=>__("Set autoplay function","my_support_theme"),
					'layout_class'=>'my_col_25',
					//'on'=>__("Ascending","my_support_theme"),
					//'off'=>__("Descending","my_support_theme"),
					'default'=>'',
				),
				'autoplay_timeout'=>array(
					'type'=>'text',
					'title'=>__("Autoplay timeout","my_support_theme"),
					'tooltip'=>__("Set autoplay timeout in miliseconds","my_support_theme"),
					'layout_class'=>'my_col_25',
					'default'=>10000
		
				),
				'swipeOn'=>array(
						'type'=>'on_off',
						'title'=>__("Swipe On","my_support_theme"),
						'tooltip'=>__("Allow swipe on the slider","my_support_theme"),
						'layout_class'=>'my_col_25',
						'on'=>__("On","my_support_theme"),
						'off'=>__("Off","my_support_theme"),
						'default'=>1,
				),
				'show_nav'=>array(
						'type'=>'on_off',
						'title'=>__("Show navigation","my_support_theme"),
						'tooltip'=>__("Show navigation ","my_support_theme"),
						'layout_class'=>'my_col_25',
						'on'=>__("On","my_support_theme"),
						'off'=>__("Off","my_support_theme"),
						'default'=>1,
				),
			'show_thumbs'=>array(
						'type'=>'on_off',
						'title'=>__("Show navigation Thumbs","my_support_theme"),
						'tooltip'=>__("Show navigation Thumbs","my_support_theme"),
						'layout_class'=>'my_col_25',
						'on'=>__("On","my_support_theme"),
						'off'=>__("Off","my_support_theme"),
						'default'=>1,
				),
			'thumbs_pos'=>array(
					'type'=>'jscript_radio_list',
					'title'=>__("Show navigation Thumbs","my_support_theme"),
					'tooltip'=>__("Show navigation Thumbs","my_support_theme"),
					'layout_class'=>'my_col_25',
					'values'=>array(
						'below'=>__("Below Shortcode","my_support_theme"),
						'above'=>__("Above Shortcode","my_support_theme"),
					),
					'default'=>'below'
			),	
			'shadow'=>array(
					'type'=>'jscript_radio_list',
					'title'=>__("Show navigation Thumbs","my_support_theme"),
					'tooltip'=>__("Show navigation Thumbs","my_support_theme"),
					'layout_class'=>'my_col_25',
					'values'=>array(
							'show'=>__("Show","my_support_theme"),
							'on-hover'=>__("Show on hover","my_support_theme"),
							'hide'=>__("Hide","my_support_theme")
					),
					'default'=>'show'
					),
		'template'=>array(
				'type'=>'jscript_dropdown',
				'title'=>__("Template","my_support_theme"),
				'tooltip'=>__("Choose te4stimonial template","my_support_theme"),
				'widths'=>array(
						600=>'100%',
						1200=>'25%',
				
				),
				'layout_class'=>'my_col_25',
				'default'=>'center_bottom',
				'values'=>array(
						'center_top'=>__("Center Top","my_support_theme"),
						'center_bottom'=>__("Center Bottom","my_support_theme"),
						'bottom'=>__("Bottom","my_support_theme"),
						'top'=>__("Top","my_support_theme")
				),
				'jscript'=>array(
						'max_c'=>1,
						'max_sel'=>__("Maximum elements are selected","my_support_theme"),
						'duration'=>500,
						'animation'=>'fadein',
						'choose_value'=>__("Plese Select value","my_support_theme"),
				),
				'show_filter'=>1,
				'multiple'=>false,
				'choose_value'=>__("Plese Select value","my_support_theme"),
					),
			'float'=>array(
						'type'=>'jscript_dropdown',
						'title'=>__("Float meta Data","my_support_theme"),
						'tooltip'=>__("Float metabada","my_support_theme"),
						'default'=>'left',
						'layout_class'=>'my_col_25',
						'values'=>array(
							'left'=>__("Left","my_support_theme"),
							'right'=>__("Right","my_support_theme")	
						),
					'jscript'=>array(
							'max_c'=>1,
							'max_sel'=>__("Maximum elements are selected","my_support_theme"),
							'duration'=>500,
							'animation'=>'fadein',
							'choose_value'=>__("Plese Select value","my_support_theme"),
					),
						'show_filter'=>0,
						'multiple'=>false,
							
						),
			'per_page'=>array(
					'title'=>__("Testimonials Per Page","my_support_theme"),
					'type'=>'text',
					'default'=>'12',
					'layout_class'=>'my_col_25',
						),
			'style'=>array(
						'type'=>'jscript_dropdown',
						'title'=>__("Style","my_support_theme"),
						'tooltip'=>__("Select style","my_support_theme"),
						'default'=>'gray',
						'layout_class'=>'my_col_25',
						'values'=>array(
							'gray'=>__("Gray","my_support_theme"),	
							'dark'=>__("Dark","my_support_theme"),
							'light'=>__("Light","my_support_theme")	
						),
					'jscript'=>array(
							'max_c'=>1,
							'max_sel'=>__("Maximum elements are selected","my_support_theme"),
							'duration'=>500,
							'animation'=>'fadein',
							'choose_value'=>__("Plese Select value","my_support_theme"),
					),
						'show_filter'=>0,
						'multiple'=>false,
							
						),
		'layout_1600_type'=>array(
				'display'=>'inline',
				'title'=>__("Units fro height","my_support_theme"),
				'type'=>'jscript_radio_list',
				'default'=>'%',
				'layout_class'=>'my_col_25',
				'values'=>array(
						'%'=>__("Percentage","my_support_theme"),
						'px'=>__("Pixels","my_support_theme")
				)
		),
		'layout_1600_height'=>array(
				'title'=>__("Slider Height","my_support_theme"),
				'type'=>'text',
				'default'=>'80',
				'layout_class'=>'my_col_25',
		
		),
		)	
				
				);


$shortcodes['card']=array(
	'title'=>__("Card Slider","my_support_theme"),
	'default'=>array('title','limit','category','order_by','order','layout','autoplay','autoplay_timeout','style','swipeOn','show_nav','show_thumbs','thumbs_pos','shadow','template','float')
);
$shortcodes['slider']=array(
	'title'=>__("Slider","my_support_theme"),
	'default'=>array('title','limit','category','order_by','order','layout_1600_type','layout_1600_height','autoplay','autoplay_timeout','style','swipeOn','show_nav','show_thumbs','thumbs_pos','shadow','template','float')			
);
$shortcodes['grid']=array(
		'title'=>__("Grid","my_support_theme"),
		'default'=>array('title','layout','category','order_by','order','style','shadow','template','float','per_page')
);

return $shortcodes;