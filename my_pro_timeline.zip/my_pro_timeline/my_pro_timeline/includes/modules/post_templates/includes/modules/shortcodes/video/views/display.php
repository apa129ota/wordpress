<?php
if (! defined ( 'ABSPATH' ))
	die ( '' );
?>
<div class="my_shortcode_video_div">
<ul>
<li><?php echo __("You can add video from media library , just choose Add Video button.","my_support_theme")?></li>
<li><?php echo __("You can add video from youtube, choose type youtube and add video id.","my_support_theme")?><br/>
<?php echo __("In example youtube link is : ","my_support_theme")?>https://www.youtube.com/watch?v=<b>v5P4LsUyXV4</b><?php echo __(" id is boldded text.","my_support_theme")?></li>
</li>
<li><?php echo __("You can add video from Vimeo, choose type Vimeo and add video id.","my_support_theme")?><br/>
<?php echo __("In this example Vimeo link is : ","my_support_theme")?>https://vimeo.com/<b>189131291</b><?php __(" id is boldded text","my_support_theme")?></li>
<li><?php echo __("You can add video by adding url of video files form mp4 wmv etc.Choose Url video type","my_support_theme")?>
</li>
</ul>

<div class="my_choosed_video">
	<div class="my_choosed_media" style="display:none">
	<h4><?php echo __("Media library Video","my_support_theme")?></h4>
		<ul>
			<li class="my_video_title"></li>
			<li class="my_video_file"></li>
			<li class="my_video_length"></li>


		</ul>
	</div>
	<div class="my_choosed_url" style="display:none">
	<h4><?php echo __("Media Url Video","my_support_theme")?></h4>
		<ul>
			<li class="my_video_title1"></li>
			<li class="my_video_file1"></li>
			<li class="my_video_length1"></li>


		</ul>
	</div>
	<div class="my_choosed_youtube" style="display:none">
	<h4><?php echo __("Youtube Video","my_support_theme")?></h4>

	</div>
	<div class="my_choosed_vimeo" style="display:none">
	<h4><?php echo __("Vimeo Video","my_support_theme")?></h4>

	</div>


	<div class="my_preview"></div>
</div>
	<?php echo $formHtml;?>
	<input type="button" class="my_video_action button button-primary button-large" "data-key="insert" value="<?php echo __("Insert Video","my_support_theme")?>"/>
</div>