/**
 * New builder class for adjusting post template properties
 */
(function($) { 
	myAdminTemplatesBuilder=function(o){
		var self;
		this.my_working=false;
		this.debug=true;
		this.options=o;
		this.network='';
		this.network_ids='';
		this.my_pre_open_post_id='';
		this.search_ids={};
		this.my_get_all=false;
		this.my_save_all=false;
		this.included_fonts={};
		this.my_image_id='';
		this.pins=[];
		this.my_edit_id="";// my_post_title_row";
		this.sections={};
		this.name_sections={};
		this.my_edit_icon='';
		this.my_sub_section='';
		this.my_disable_change=false;
		this.default_values={};
		this.sub_sections={};
		this.w=400;
		this.h=400;
		this.my_globals={};
		this.my_is_global='';
		this.myPropHeight={};
		this.dialog_save;
		this.dialog_new;
		this.dialog_stars;
		this.my_dialog_open='';
		this.my_sort_option=false;
		this.my_add_clear=false;
		this.fonts={};
		this.fonts_objects={};
		this.included_fonts={};
		this.templateEffects={};
		this.setStyle="default";
		this.cssRules={};
		this.templateSelectors={};
		this.domObjects={};
		this.domObject={};
		this.domRows={};
		this.isGroup=false;
		this.groupKey="";
		this.groupSubKey="";
		this.groupSelector="";
		this.groupRules={};
		this.advancedEditor=false;
		this.pre_options={
				w:30,
				h:30,
				form_class:'.my_options_form',
				form_template_class:'#my_form_my_templates',
				form_element:".my_new_module_element",
				li_form:".my_form_element_outer",
				class_cont:".my_image_mapper_image_image_div_1",
				class_img:".my_image_mapper_image_image_div_1 img",
				editor_class:".my_slide_image_inner",
				element_inner:".my_shortcode_content_new",
				ul_button:".my_shotcode_actions_ul",
				outter_class:".my_outter_object",
				form_class:".my_options_form",
				form_element:".my_new_module_element",
				shortcode_content:".my_shortcode_content_new",
				item_add_class:".my_shortcode_added_html",
				item_class:".my_shortcode_item",
				row_class:".my_shortcode_row_row",
				object_children_sel_html:'<a href="#javascript" class="my_show_object_children" title="{title}"><i class="fa fa-caret-right"></i><i class="fa fa-caret-down" style="visibility:hidden"></i></a>',
				object_div:'<div class="my_object_item_i">{i}<div id="{myId}" class="my_object_item" data-key="{key}">{title}</div></div>'	
		};
		
		self=this;
		
		this.init=function(o){
			 var gesture = window.navigator && window.navigator.msPointerEnabled && window.MSGesture;
			var  touch = (( "ontouchstart" in window ) || gesture || window.DocumentTouch && document instanceof DocumentTouch);
			self.touch=touch;  
			if(typeof self.options.my_debug!='undefined'){
				if(!self.options.my_debug){
					self.debug=false;
				}
			}
				
			self.debug=false;
			self.options=$.extend( self.pre_options,self.options);
			self.my_debug("Options",self.options);
			if(typeof self.options.fonts!='undefined'){
				self.fonts=self.options.fonts;
			}else {
			
				self.options.fonts={};
				self.fonts={};
			}
			self.checkGlobalOptions();
			$(".my_options_form_inner").mCustomScrollbar({advanced:{
				updateOnContentResize:true
			}});
			self.my_debug('Templates keys',self.templateObjects);
			self.initDefault();
			self.formStylesEvents();
			self.getFormStylesSections();
			self.optionsFormActions();
			self.adjustCssRulesArray();
			self.calculateHeight();
			self.clickTemplate();
			$(self.options.form_class+" "+self.options.form_element).each(function(i,v){
				self.my_change_el(i,v);
			});
			
		},
		/**
		 * Edit dragg line color
		 */
		this.edit_dragg=function(t){
			self.debug=true;
			self.my_debug("Edit dragg line",t);
			self.my_disable_change=true;
			var objectStyle;
			var style=self.setStyle;
			
			if(self.my_edit_id!=""){
				$(self.my_edit_id).css('outline','');
			}
			if(t){
				self.my_edit_id=".my_"+self.options.tmpl+" .mCSB_draggerRail";
				
			}else {
				self.my_edit_id=".my_"+self.options.tmpl+" .mCSB_dragger_bar";
			}
			objectStyle=self.options.cssRules[style][self.my_edit_id];
			self.my_debug("Object style",objectStyle);
			$(self.my_edit_id).css('outline','4px dashed #000000');
			self.setFormRules(objectStyle,true);
			self.debug=false;
			
		},
		this.getSetValues=function(set){
			// self.my_disable_change=true;
			if(set==0){
				$(self.options.form_class+" "+self.options.form_element).each(function(i,v){
					var id=$(v).attr('id');
					var o=self.get_element_data(id);
					var name=o.name;
					if($('#'+id).parents('#my_form_section_slider').length==0){
					var s=$("#"+id).data('my-script');
					if(typeof s!='undefined'){
						
						var val=s.get_value();
						if(name=="box_shadow"){
							val="none";
						}
						self.my_debug("Get default values",{id:id,name:name,val:val});
						self.default_values[id]=val;
					}
					}
				});
				self.my_debug("Default values",self.default_values);
				
			}else {
				self.my_debug("Set Default values",self.default_values);
				$.each(self.default_values,function(i,v){
					var id=i;
					var o=self.get_element_data(id);
					self.my_debug("Set default values",{name:o.name,id:id,val:v});
					
					var s=$("#"+id).data('my-script');
					if(typeof s!='undefined'){
						s.set_value(v);
					}
				});
			}
			// self.my_disable_change=false;
			
		};
		this.initDefault=function(){
			if(typeof wpMyModuleNewFormMainScript_template_vars=='undefined'){
				setTimeout(self.initDefault,1000);
			}
			else if(wpMyModuleNewFormMainScript_template_vars.init_el){
				self.getSetValues(0);
				$("#my_form_section_icon").hide();
				$('#my_form_section_slider').hide();
				self.calculateHeight();
				$(".my_action[data-key='adjust_height']").trigger('click');
		
			}else {
				setTimeout(self.initDefault,1000);
					
			}
		},
		/**
		 * Function which adjust css style when element is changed
		 * all options form has this functionality
		 */
		this.my_change_el=function(i,v){
			
			var id=$(v).attr('id');
			var o=self.get_element_data(id);
			self.my_debug('Init chnage',o);
			
			switch(o.type){
				case 'jscript_box_shadow':
				case 'jscript_color_picker':
				case 'jscript_dropdown':
				case 'jscript_spinner':
				case 'thumb':	
				case 'jscript_border':	
					// return false;
											
					
					
					// var o=self.get_element_data(id);
					var type=o.type;
					self.my_debug('Init chnage 1',o);
					
					$(o.obj).on('my_change',function(e,obj,val,v1){
						self.debug=true;
						if(self.my_edit_id=='')return;
						if(self.my_disable_change)return;
						var id=$(this).attr('id');
						var o=self.get_element_data(id);
						var myScriptObj=$(o.obj).data('my-script');
						if(self.options.use_slider&&self.my_edit_id=='post_thumb'){
							if($('#'+id).parents('#my_form_section_slider').length>0){
								self.options.rules.post_thumb[o.name]=val;
								self.my_debug("Change slider",{name:o.name,val:val});
								return;
							}									
						
						}
						var css='';
						var backupVal=val;
						var oldSetValue='';
						var prevFont='';
						if(self.my_sub_section==''){
							if(self.isGroup){
								
							}else {
								if(typeof self.options.cssRules[self.setStyle][self.my_edit_id]!='undefined'){
									if(typeof self.options.cssRules[self.setStyle][self.my_edit_id].font_family!='undefined'){
										prevFont=self.options.cssRules[self.setStyle][self.my_edit_id].font_family;
									}
								}
								oldSetValue=prevFont;
							}
						}else {
							// var
							// prevFont=self.options.rules[self.my_edit_id][self.my_sub_section].font_family;
							// oldSetValue=prevFont;
						}
						
						self.my_debug("Change element",{id:id,o:o,val:val,v1:v1,edit_id:self.my_edit_id,icon:self.my_edit_icon});
						if(self.my_edit_id=='')return;
						if(self.my_edit_icon!=''){
							self.my_debug("Change icon",{o:o,id:id,name:v1,edit_icon:self.my_edit_icon});
							var rowClass='';// '.my_'+self.options.tmpl+'
											// .my_'+self.my_edit_id+"_row";
							var itemClass='';// '.my_'+self.options.tmpl+"
												// .my_"+self.my_edit_id;
							
							if(o.name=='i_icon'){
								
							}
							if(o.name=='i_color'){
								backupVal=v1;
								v1='color';
							}else if(o.name=='i_color_hover'){
								backupVal=v1;
								v1='hover_color';
							}
							var itemClass1='.my_'+self.options.tmpl;
							if(self.my_edit_icon=='meta_stars'){
								if(v1=='hover_color'){
									itemClass=itemClass1+" .my_stars .my_active i ,"+itemClass1+" .my_stars .my_active a i";
									// itemClass+=itemClass1+" my_stars:hover i
									// ,"+itemClass1+"my_stars:hover a i";
									
								}
								else itemClass=itemClass1+" .my_stars i ,"+itemClass1+" .my_stars a i";
								self.options.rules.meta_stars[o.name]=val;
							}else {
								if(v1=='hover_color'){
									itemClass=itemClass1+" .my_post_meta .my_"+self.my_edit_icon+":hover i, "+itemClass1+" .my_post_meta .my_"+self.my_edit_icon+":hover a i ";
								}	
								else itemClass=itemClass1+" .my_post_meta .my_"+self.my_edit_icon+" i, "+itemClass1+" .my_"+self.my_edit_icon+" i a";
							}					
							var realKey=v1;
							if(v1=='hover_color')realKey='color';
							if(v1=='i_font_size'){
								realKey='font-size';
								if(self.my_edit_id=='post_meta'){
									/*
									 * $.each(self.options.rules.post_meta,function(i,v){
									 * v[v1]=val; });
									 */
									self.options.rules.post_meta[self.my_edit_icon][o.name]=val;
									css=itemClass+"{"+realKey+" : "+val+" !important}";
								}else css=itemClass+"{"+realKey+" : "+val+"!important}";
							}else if(v1=="i_line_height"){
								realKey='line-height';
								if(self.my_edit_id=='post_meta'){
									/*
									 * $.each(self.options.rules.post_meta,function(i,v){
									 * v[v1]=val; });
									 */
									self.options.rules.post_meta[self.my_edit_icon][o.name]=val;
								}
								css=itemClass+" {"+realKey+" : "+val+" !important}";
								
							}
							else css=itemClass+"{"+realKey+" : "+val+"!important}";
							
						}else {
						if(o.name=='bg_hover_color'){
							backupVal=v1;
							v1='bg_hover_color';
						}	
						else if(o.name=='bg_color'){
							backupVal=v1;
							v1='bg_color';
						}
						else if(o.name=='color'){
							backupVal=v1;
							v1='color';
						}else if(o.name=='hover_color'){
							backupVal=v1;
							v1='hover_color';
						}else if(o.name=='i_color'){
							backupVal=v1;
							v1='i_color';
						}else if(o.name=='i_color_hover'){
							backupVal=v1;
							v1='i_color_hover';
						}
						
						// var rowClass='.my_'+self.options.tmpl+'
						// .my_'+self.my_edit_id+"_row";
						// var itemClass='.my_'+self.options.tmpl+"
						// .my_"+self.my_edit_id;
						var itemClass=self.my_edit_id;
						if(v1=='hover_color' || v1=="bg_hover_color"){
							if(self.isGroup){
								var splitArr=self.my_edit_id.split(",");
								itemClass="";
								$.each(splitArr,function(iG,vG){
									if(itemClass.length>0)itemClass+=" , ";
									itemClass+=vG+":hover ";
								});
							}
						}
						var rowClass=itemClass;
						if(self.my_sub_section!=''){
							// if($.inArray(self.my_sub_section,['fa-facebook','fa-google-plus','fa-twitter','fa-pinterest'])!=-1){
								itemClass='.my_'+self.options.tmpl+" ."+self.my_sub_section;
							// }
							// else itemClass='.my_'+self.options.tmpl+"
							// .my_"+self.my_edit_id+" ."+self.my_sub_section;
							// self.sub_sections[self.my_sub_section][o.name]=backupVal;
							
						}
						
						// if(v1=='')
						self.my_debug('Call change script',{v1:v1,val:val,edit_id:self.my_edit_id,rowClass:rowClass,itemClass:itemClass});
						if(typeof val!='undefined'){
						if(v1=='bg_image'){
							
						}
						else if(self.my_sub_section==''){
							if(self.isGroup){
								if(typeof self.groupRules[self.setStyle]=='undefined'){
									self.groupRules[self.setStyle]={};
								}
								if(typeof self.groupRules[self.setStyle][self.groupKey]=='undefined'){
									self.groupRules[self.setStyle][self.groupKey]={};
								}
								if(typeof self.groupRules[self.setStyle][self.groupKey][self.groupSubKey]=='undefined'){
									self.groupRules[self.setStyle][self.groupKey][self.groupSubKey]={};
								}
								self.groupRules[self.setStyle][self.groupKey][self.groupSubKey].selector=self.groupSelector;
								self.groupRules[self.setStyle][self.groupKey][self.groupSubKey][v1]=backupVal;
							}
							else self.options.cssRules[self.setStyle][self.my_edit_id][v1]=backupVal;
							}
						
						switch(v1){
							case 'list_style_type':
								css=itemClass+"\n{list-style-type:"+val+" !important\n}";
							break;	
							case 'list_style_position':
								css=itemClass+"\n{list-style-position:"+val+" !important;\n}";
							break;	
							case 'list_style_image':
								if(val==''){
									css='';
									
								}else {
									var myObj=$(o.obj).data('my-script');
									img=myObj.getSizesUrl('full').url;	
									thumb_id=$(o.obj).data('my-script').get_value();
									if(self.my_sub_section==''){
										self.options.rules[self.my_edit_id][v1]=thumb_id;
									}else {
										self.sub_sections[self.my_sub_section][o.name]=thumb_id;
									}
									$(o.obj).data('my-script').getObjectValue();
									css=itemClass+"{list-style-image:url('"+img+"') !important;}";
								}
							break;
							case 'list_style_icon':
							break;	
							case 'box_shadow':
								var cssProperties = [
						                '',
						                '-webkit-',
						                '-moz-'
						            ];
								var cssObj=myScriptObj.getCss();
								self.my_debug("Object css",cssObj);
								css=itemClass+"\n{"+cssObj+"\n}";
							break;
							case 'font_family':
								// itemClass;
								var idElem=self.my_edit_id;
								if(self.my_sub_section!=''){
									idElem+="_"+self.my_sub_section;
								}
								
								if(val=='default'){
								
									self.my_debug("Prev font",{font:prevFont,objects:self.fonts_objects});
									if(typeof prevFont!='undefined'){
										var objE=self.fonts_objects[prevFont];
										if(objE.length==1){
											self.my_debug("Remove font",prevFont);
											$("head link.my_image_mapper_fonts_css[data-key='"+prevFont+"']").remove();
											delete self.included_fonts[prevFont];
											delete self.options.rules.fonts[prevFont];
											delete self.fonts_objects[prevFont];
										}else {
											objE.length--;
											delete objE[prevFont].elems[idElem];
										}
										self.my_debug("Prev font",{font:prevFont,objects:self.fonts_objects});
										
										delete objE.elems[idElem];
									}
									css=itemClass+"{font-family:inherit !important};";
								}else {
								/*
								 * if(typeof
								 * self.options.cssRules.fonts[val]=='undefined'){
								 * self.options.rules.fonts[val]=1; }
								 */
								if(typeof self.options.cssRules[self.setStyle][self.my_edit_id][val]=='undefined'){
									self.options.fonts[val]=1;
								}
								
								if(typeof self.included_fonts[val]=='undefined'){
										self.my_debug("Inlcude new font",val);
										var value=val.replace(/ /g,'+');
										self.my_debug("Inlcude new font",value);
										$("head").append('<link class="my_image_mapper_fonts_css"  data-key="'+val+'" rel="stylesheet" href="https://fonts.googleapis.com/css?family='+value+'"/>');
										self.included_fonts[val]=1;
										self.options.cssRules[self.setStyle][self.my_edit_id][val]
								}
								var idElem=self.my_edit_id;
								if(self.my_sub_section!=''){
									idElem+="_"+self.my_sub_section;
								}
								css=itemClass+"{font-family:"+val+" , serif !important\n}";
								if(typeof self.fonts_objects[val]=='undefined'){
									var objF={};
									objF.elems={};
									objF.length=0;
									self.fonts_objects[val]=objF;
									
									
								}
								self.fonts_objects[val].length++;
								self.fonts_objects[val].elems[idElem]=1;
								
								}
							break;	
							case 'bg_hover_color':
								if(self.my_edit_id=='woo_data'){
								css=rowClass+" li:hover {background-color:"+val+" !important;}";	
								}
								
								else css=rowClass+":hover {background-color:"+val+" !important;}";
								
							break;	
							case 'bg_color':
								if(self.my_sub_section=='mCSB_draggerRail' || self.my_sub_section=='mCSB_dragger_bar'){
									// $(".my_form_element_outer").hide();
									// $(".my_form_element_outer[data-name='bg_color_template_vars']").show();
									css='.my_'+self.options.tmpl+" ."+self.my_sub_section+"{\n background-color:"+val+"!important;}";
									
								}
								else css=rowClass+"{background-color:"+val+" !important;}";
							break;
							case 'bg_image':
								if(val==''){
									css='';
									if(self.my_sub_section==''){self.options.rules[self.my_edit_id][v1]='';
									}
									else self.sub_sections[self.my_sub_section][o.name]=val;;
								}else {
									var myObj=$(o.obj).data('my-script');
									img=myObj.getSizesUrl('full').url;	
									thumb_id=$(o.obj).data('my-script').get_value();
									if(self.my_sub_section==''){
										self.options.rules[self.my_edit_id][v1]=thumb_id;
									}else {
										self.sub_sections[self.my_sub_section][o.name]=thumb_id;
									}
									$(o.obj).data('my-script').getObjectValue();
									css=rowClass+"{background-image:url('"+img+"') !important;}";
								}
							break;	
							case 'bg_repeat':
								css=rowClass+"{background-repeat:"+val+" !important}"
								
							break;	
							case 'align':
							case 'color':
							case 'hover_color':
							case 'font_size':
							case 'line_height':	
							case 'font_style':
							case 'font_weight':
							case 'text_decoration':
							case 'letter_spacing':	
								
								if(v1=='text_decoration'){
									css=itemClass+"{text-decoration:"+val+" !important;}";
								}
								else
								if(v1=='font_weight'){
									css=itemClass+"{font-weight:"+val+" !important;}";
								}
								else
								if(v1=='font_style'){
									css=itemClass+"{font-style:"+val+" !important;}";
								}
								else if(v1=='font_size'){
									css=itemClass+"{font-size:"+val+" !important;}";
								}
								else if(v1=='line_height'){
									css=itemClass+"{line-height:"+val+" !important;}";
								}
								else if(v1=='hover_color'){
									
									css=itemClass+":hover , "+itemClass+":hover a {color:"+val+" !important;}";
								}else if(v1=='color'){
									css=itemClass+" , "+itemClass+" a {color:"+val+" !important;}";
									
								}else if(v1=='align'){
									css=itemClass+" , "+itemClass+":hover a {text-align:"+val+" !important;}";
								}else if(v1=='letter_spacing'){
									css=itemClass+" {letter-spacing:"+val+" !important;}";
								}
								else css=itemClass+"{"+v1+":"+val+" !important;}";
								
							break;	
							case 'border':
							case 'outline':	
							case 'width':
							case 'height_choose':	
							case 'margin-left':
							case 'margin-right':
							case 'margin-top':
							case 'margin-bottom':
							case 'padding-left':
							case 'padding-right':
							case 'padding-top':
							case 'padding-bottom':
								if(v1=='height_choose'){
									v1='height';
									if(val.indexOf('%')!=-1){
										var vH=parseFloat(val)/100*self.h;
										self.my_debug('Height',vH);
										val=vH+'px';
									}
									if(self.my_edit_id=='post_thumb'){
										rowClass=".my_"+self.options.tmpl+" .my_post_thumb_row ";
										
									}
								}
								if(v1=='border'){
									css=='';
									$.each(val,function(i3,v3){
										css+=rowClass+" { border-"+i3+":"+v3+" !important;}\n";
										
									});
									var cssRadius=obj.getBorderRadiusCss();
									self.my_debug("Border radius",cssRadius);
									doCss=['','-moz-','-webkit-'];
									$.each(doCss,function(iR,vR){
										css+=rowClass+" {"+vR+"border-radius:"+cssRadius+" !important };"
									});
									//css+=rowClass+" {"+cssRadius+" !importnant };"
								}else if(v1=='outline'){
									css=='';
									$.each(val,function(i3,v3){
										css+=rowClass+" { outline-"+i3+":"+v3+" !important;}\n";
										
									});
								}
								else css=rowClass+" { "+v1+":"+val+" !important;}";
								
								if(v1=='width'&&self.my_edit_id!='share_div'){
									var dw=parseFloat(val);
									my_do=false;
									if(val.indexOf('%')!==-1&&dw<100){
									my_do=true;
									}else if(val.indexOf('px')!==-1&&dw<self.w){
										my_do=true;
									}
									if(my_do){
										css+=rowClass+"{ float:left !important;}";
									}
								}
								
							break;	
						}
						}
						}
						var elemName=v1.replace(/-/g,'_');
						var id=self.my_edit_id+"_"+elemName;
						if(self.isGroup){
							id='#'+self.groupKey+"_"+self.groupSubKey+"_"+elemName;
						}
						if(self.my_edit_icon!='')id+='_'+self.my_edit_icon;
						var has=$("#my_templates_style_css "+id).length;
						if(v1=='height'){
							if(typeof self.myPropHeight[id]!='undefined'){
								if(backupVal.indexOf('%')==-1){
									delete self.myPropHeight[id];
								}
							}
							if(backupVal.indexOf('%')==-1){
								var oVal={name:elemName,val:backupVal,rowClass:rowClass};
								self.myPropHeight[id]=oVal;
							}
						}
						if(has==0){
							$("#my_templates_style_css").append('<style type="text/css" class="'+id+'">'+css+'</style>');
							
						}else {
							$("#my_templates_style_css "+id).html(css);
						}
						var o=self.options.cssRules[self.setStyle][self.my_edit_id];// self.options.rules[self.my_edit_id];
						
						if(self.my_sub_section!=''){
							o=self.options.rules[self.my_edit_id][self.my_sub_section];
						}
							if(typeof o!='undefined'){
							if(typeof o.added_css!='undefined'){
								var find=self.findRuleAddedCss(o.added_css,v1);
								if(find.length>0){
									var added_css='';
									$.each(find,function(iF,vF){
										added_css+=self.genCssAddedCss(vF,v1,val);
									});
									self.my_debug("added  css from element",css);
									var id1=self.my_edit_id+"_added_css_"+elemName;
									var has1=$("#my_templates_style_css #"+id1).length;
									if(has1==0){
										$("#my_templates_style_css").append('<style type="text/css" id="'+id1+'">'+added_css+'</style>');
										
									}else {
										$("#my_templates_style_css #"+id1).html(added_css);
									}
								}
							}
							}
							setTimeout(function(){
								self.calculateHeight();
							},500);
						self.my_debug("add css",css);
						
						});
				break;	
				case 'text':
				case 'radio_list':
				case 'radio':
				case 'checkbox':
					self.my_debug('Call change script');
					
				break;
					}
			
		
				
			self.debug=false;
		},
		this.setEditIdOptions=function(obj){
			self.my_debug("Set rules",{id:self.my_edit_id,obj:obj});
			if(typeof self.options.cssRules[self.setStyle][self.my_edit_id]=='undefined'){
				self.options.cssRules[self.setStyle][self.my_edit_id]={};
			}
			$.each(obj,function(i,v){
				self.options.cssRules[self.setStyle][self.my_edit_id][i]=v;

			});
			self.setValuesNew();
		};
		this.setValuesNew=function(){
			if(typeof self.options.cssRules[self.setStyle][self.my_edit_id]!='undefined'){
				var key=self.my_edit_id;
				self.setValues(self.options.cssRules[self.setStyle][self.my_edit_id],key);

			}
		};
		this.show_sections=function(show){
			if(show==1){
				$(".my_form_section").each(function(i,v){
					var id=$(v).attr('id');
					self.my_debug('Show section',id);
					$(v).find(".my_form_section_inner").show();
					$(v).find(".fa-minus").css('display','inline-block');

					$(v).find(".fa-plus").hide();
				});
			}else {
				$(".my_form_section").each(function(i,v){
					var id=$(v).attr('id');
					self.my_debug('Hide section',id);
					$(v).find(".my_form_section_inner").hide();
					$(v).find(".fa-minus").hide();
					$(v).find(".fa-plus").css('display','inline-block');

				});
			}
		};
		this.setValues=function(values,key){
			var sections_incl={};
			self.my_debug("Set values",values);
			$(".my_form_section").show();
			var has_val={};
			// $(".my_form_section .fa-plus")..trigger('click');
			self.show_sections(1);
			var has_border=false;
			var has_height=false;
			$.each(values,function(i,val){
				if(i=='border'){
					has_border=true;
				}
				if(i=='height'){
					if(val=='auto'){
						$(".my_form_element_inline_height_choose_template_vars").hide();
						$("#height_auto_template_vars_id").prop("checked",true);
					}else {
						has_height=true;
						$(".my_form_element_inline_height_choose_template_vars").show();
						$("#height_auto_template_vars_id").prop("checked",false);
					}
				}
				var name=i;
				has_val[name]=1;
				var id=i+'_template_vars_id_div';
				if(i=='height' && has_height){
					id='height_choose_'+'template_vars_id_div';
				}
				var o=self.get_element_data(id);
				var name=o.name;
				var sec=self.name_sections[name];
				if(typeof sections_incl[sec]=='undefined')sections_incl[sec]=1;
				self.my_debug("Element",{id:id,name:name,sec:sec,val:val});
				var s=$("#"+id).data('my-script');
				if(typeof s!='undefined'){
					 s.set_value(val);
				}else{
						self.my_debug("object undefined");
				}

			});
			if(!has_border){
				self.my_debug('ha nbo border');
				var id='border_'+'template_vars_id_div';
				var s=$("#"+id).data('my-script');
				if(typeof s!='undefined'){
					s.set_value();
				}
			}
			self.my_debug('show section',sections_incl);

			$.each(self.section_names,function(i,v){
				if(typeof has_val[i]=='undefined'){
				var id=i+'_template_vars_id_div';
				$("#"+id).parents('li').hide();
				}
			});
			self.show_sections(0);
			$(".my_form_section_inner").hide();
			$.each(sections_incl,function(i,val){
				self.my_debug('show section',i);
				$("#my_form_section_"+i).show();

			});
			// $(".my_form_section .fa-minus").trigger('click');


		};
		this.getShorthandRule=function(key,str){
			var obj={};
			var splitArr=str.split(" ");
			var cCount=splitArr.length;
			if(cCount==4){
				obj[key+"_top"]=splitArr[0];
				obj[key+"_right"]=splitArr[1];
				obj[key+"_bottom"]=splitArr[2];
				obj[key+"_left"]=splitArr[3];
				
			}else if(cCount==3){
				obj[key+"_top"]=splitArr[0];
				obj[key+"_right"]=splitArr[1];
				obj[key+"_bottom"]=splitArr[1];
				obj[key+"_left"]=splitArr[2];
			}else if(cCount==2){
				obj[key+"_top"]=splitArr[0];
				obj[key+"_right"]=splitArr[1];
				obj[key+"_bottom"]=splitArr[0];
				obj[key+"_left"]=splitArr[1];
			}else {
				obj[key+"_top"]=splitArr[0];
				obj[key+"_right"]=splitArr[0];
				obj[key+"_bottom"]=splitArr[0];
				obj[key+"_left"]=splitArr[0];
			}
			self.my_debug("Show short values",{key:key,str:str,obj:obj});
			return obj;
		},
		this.adjustStylesArrayShorthand=function(obj){
			var d=self.debug;
			self.debug=false;
			self.my_debug("Adjust styles array",obj);
			var adjustShortRule={};
			var val;
			$.each(obj,function(i,v){
				 
				if(typeof v['padding']!='undefined'){
					val=v['padding'].value;
					adjustShortRule=self.getShorthandRule('padding',val);
					$.each(adjustShortRule,function(iR,vR){
						v[iR]=vR;
					});
				}
				if(typeof v['margin']!='undefined'){
					val=v['margin'].value;
					adjustShortRule=self.getShorthandRule('margin',val);
					$.each(adjustShortRule,function(iR,vR){
						v[iR]=vR;
					});
				}
			});
			self.debug=d;
		},
		this.clickTemplate=function(){
			return '';
			$.each(self.templateSelectors,function(i,v){
				
				$(i).attr('data-my-key',i);
				$(i).click(function(e){
					e.preventDefault();
					e.stopPropagation();
					var key=$(this).attr('data-my-key');
					self.my_debug("Click on",key);
					$(".my_object_item[data-key='"+key+"']").trigger('click');
					
				});
			});
			/*
			 * e.preventDefault(); var cl=$(this).attr('class');
			 * self.my_debug("Click Template",cl);
			 * cl=cl.replace('my_post_clear','');
			 * cl=cl.replace('ui-sortable',''); var clA=cl.split(" "); var
			 * clNew=''; $.each(clA,function(i,v){ if(v!=""){
			 * if(clNew.length>0)c;New+=" "; clNew+="."+v; } }); cl=clNew;
			 * self.my_debug("Click Template",cl);
			 * 
			 * var tmplCl=".my_"+self.options.tmpl; if(cl.indexOf(tmplCl)==-1){
			 * var cl1=cl; cl1=tmplCl+" "+cl; cl=cl1; } self.my_debug("Click
			 * Template Filter Class",cl);
			 * 
			 * if(typeof self.templateSelectors[cl]!='undefined'){
			 * $(".my_object_item[data-key='"+cl+"']").trigger('click'); }
			 */
		},
		this.setHeight=function(val){
			var newVal=val;
			self.my_debug("Set height",{val:val,tmpl:self.options.tmpl});
			$("#height_my_templates_id").val(newVal);
			$(".my_tmpl_h").text(newVal+'px');
			$(".my_"+self.options.tmpl).css('height',newVal+'px');
		},
		this.checkGlobalOptions=function(){
			var arr=["setStyle","advancedEditor"];
			$.each(arr,function(i,v){
				if(typeof self.options[v]!='undefined'){
					self.my_debug("Set global option",{i:i,v:v,val:self.options[v]});
					self[v]=self.options[v];
				}
			});
		},
		this.showAllSections=function(){
			var argL=arguments.length;
			$("#my_form_template_vars .my_form_element_outer").show();
			$("#my_form_template_vars .my_form_section").each(function(i,v){
				var key=$(v).attr('data-key');
				
				if(!$(v).find(".my_form_section_inner").is(":visible")){
					self.my_debug("show section",key);
					$(v).find(" h4").first().trigger('click');
				}
		});
		
		},
		/**
		 * set form rules with option to hide elements 
		 * which dont have value in css
		 */
		this.setFormRules=function(obj,hide){
			self.showAllSectionsElements();
			self.showAllSections();
			self.my_disable_change=true;
			var hasSectionsArr={};
			$("#my_form_template_vars .my_new_module_element").each(function(i,v){
				var base_name=$(v).attr('data-base-name');
				var script=$(v).data('my-script');
				var sec=$(v).parents(".my_form_section").attr('data-key');
				if(hide&&(typeof obj[base_name]=='undefined')){
					$(v).parents(".my_form_element_outer").hide();
				}
				if(typeof obj[base_name]!='undefined'){
					if($.inArray(sec,hasSectionsArr)==-1){
						hasSectionsArr[sec]=1;
					}
					if(typeof script!="undefined"){
						if(typeof obj[base_name].value!='undeifned'){
							script.set_value(obj[base_name].value);
						}
						else script.set_value(obj[base_name]);
					}
				}
			});
			self.my_debug("Sectons",hasSectionsArr);
			$("#my_form_template_vars .my_form_section").each(function(i,v){
				var key=$(v).attr('data-key');
				if(typeof hasSectionsArr[key]=='undefined'){
					self.my_debug("hide sec",key);
					$(v).hide();
				}
			});
			self.my_disable_change=false;
		},
		this.showAllSectionsElements=function(){
			$("#my_form_template_vars .my_form_element_outer").show();
			$("#my_form_template_vars .my_form_section").show();
			$("#my_form_template_vars .my_form_section").each(function(i,v){
				var key=$(v).attr('data-key');
				
				if($(v).find(".my_form_section_inner").is(":visible")){
					self.my_debug("show section",key);
					$(v).find(" h4").first().trigger('click');
				}
			});
		},
		/**
		 * Adjust options forrm ctions
		 */
		this.optionsFormActions=function(){
			$(document).on('click',".my_object_item",self.mySelectObject);
			$(".my_image_mapper_image_div .my_radio_inline .my_action").click(self.my_action);
			$(document).on('chnage',"#builder_work_my_templates_id",function(e){
				var is=1;
				if(!$(this).is("checked"))is=0;
				var type=$("#post_type_my_templates_id").val();
				var val=$("#template_my_templates_id").val();
				var url=self.options.admin_page+'&my_tmpl='+val+"&my_type="+type+'&my_adv='+is;
				var tmpl=$("#slider_template_my_templates_id").val();
				if($(this).is(":checked")){
					url+='&my_slider=1';
				}
				window.location.href=url;
			});
			/**
			 * Select group of the template
			 */
			$(document).on('click',".my_object_group_item",function(e){
				self.debug=true;
				self.my_disable_change=true;
				e.preventDefault();
				self.isGroup=true;
				var key=$(this).attr('data-key');
				var subKey=$(this).attr('data-sub-key');
				var sel=$(this).attr('data-selector');
				var style=self.setStyle;
				self.groupKey=key;
				self.groupSubKey=subKey;
				self.groupSelector=sel;
				
				self.my_debug("Select group",{key:key,subKey:subKey,sel:sel,style:style});
				if(self.my_edit_id!=""){
					$(self.my_edit_id).css('outline','');
				}
				var editId="";
				$(sel).each(function(i,v){
					var t=$(v).attr('data-title');
					var s=$(v).attr('data-selector');
					self.my_debug("Mini selector",{s:s,t:t});
					if(editId.length>0)editId+=" , ";
					editId+=s;
				});
				self.my_debug("Edit id",editId);
				self.my_edit_id=editId;
				$(sel).css('outline','4px dashed #000000');
				var objectStyle;
				var foundRules=false;
				if(typeof self.groupRules[style]!='undefined'){
					if(typeof self.groupRules[style][key]!='undefined'){
						if(typeof self.groupRules[style][key][subKey]!='undefined'){
							objectStyle=self.groupRules[style][key][subKey];
							foundRules=true;
						}
					}
				}
				if(!foundRules)objectStyle=self.options.cssGroups[key]['elements'][subKey]['css_rules'];
				self.my_debug("Object style",objectStyle);
				if(style!='default'){
					$.each(objectStyle[style],function(i,v){
						objectStyle[i]=v;
					});
				}
				self.my_debug("Object style parsed",objectStyle);
				self.adjustStylesArrayShorthand(objectStyle);
				self.setFormRules(objectStyle,true);
				self.my_disable_change=false;
				self.debug=false;
				
			});
			/*
			 * Show object item children 
			 */
			$(document).on('click','.my_show_object_children',function(e){
				self.debug=true;
				e.preventDefault();
				self.my_debug("Show children",$(this).siblings(".my_object_item").attr('data-key'));
				//var isH=$(this).find('.fa-caret-right').is(':visible');
				var idObject=$(this).siblings(".my_object_item").attr('id');
				var idChildren=idObject.replace("my_object_item_","my_object_children_");
				var isH=$("#"+idChildren).is(":visible");
				self.my_debug("Is hidden",isH);
				self.my_debug("object id",{objId:idObject,idChild:idChildren});
				if(!isH){
					$(this).find('.fa-caret-right').css('visibility','hidden');
					$(this).find('.fa-caret-down').css('visibility','visible');
					//$(this).parent(".my_object_item").siblings(".my_object_children").slideDown();
					$("#"+idChildren).slideToggle();
				}else {
					$(this).find('.fa-caret-down').css('visibility','hidden');
					$(this).find('.fa-caret-right').css('visibility','visible');
					//$(this).parents(".my_object_item_i").siblings(".my_object_children").slideUp();
					$("#"+idChildren).slideToggle();
				}
				self.debug=false;
			});
			var w=$(".my_image_mapper_add_new_div").width();
			w-=($(".my_image_mapper_styles_div").width()+20);
			$(".my_image_mapper_image_div").width(w);
			$(window).resize(function(e){
				var w=$(".my_image_mapper_add_new_div").width();
				w-=($(".my_image_mapper_styles_div")+20);
				$(".my_image_mapper_image_div").width(w);

			});

			if($("#width_my_templates_id").length>0){
				var dW=parseFloat($("#width_my_templates_id").val());
				self.w=dW;
				self.my_debug("Change dialog width",dW);
				$(".my_module_post_templates_editor_div").width(dW);
				$("#width_my_templates_id").change(function(e){
					var dW=parseFloat($("#width_my_templates_id").val());
					self.w=dW;
					self.my_debug("Change dialog width",dW);
					$(".my_module_post_templates_editor_div").width(dW);

				});

			}
			$("#height_auto_template_vars_id").change(function(e){
				var ch=false;
				if($(this).is(":checked")){
					$("[data-id='height_choose_template_vars_id']").hide();
					ch=true;
				}else {
					$("[data-id='height_choose_template_vars_id']").show();
					
				}
				var value="";
				// if(ch)value="auto";
				if(self.my_edit_id!=""){
					if(ch){
						value="auto";
						var v1='height';
						var elemName=v1.replace(/-/g,'_');
						var id=self.my_edit_id+"_"+elemName;
						var has=$("#my_templates_style_css "+id).length;
						var css=".my_"+self.options.tmpl+" "+self.my_edit_id+"\n{height:auto;!important}";
						if(has==0){
							$("#my_templates_style_css").append('<style type="text/css" class="'+id+'">'+css+'</style>');
							
						}else {
							$("#my_templates_style_css "+id).html(css);
						}
					}else {
						
					}
					
				}
				
			});
			if($("#height_my_templates_id").length>0){
				var dH=parseFloat($("#height_my_templates_id").val());
				self.h=dH;
				self.my_debug("Change dialog width",dH);
				$(".my_module_post_templates_editor_div").height(dH);
				
				$("#height_my_templates_id").change(function(e){
					var dH=parseFloat($("#height_my_templates_id").val());
					self.h=dH;
					self.my_debug("Change dialog width",dH);
					$(".my_module_post_templates_editor_div").height(dH);
					$.each(self.myPropHeight,function(i,v){
							var oVal=v;
							var id=i;
							if(oVal.val.indexOf('%')!=-1){

								var vH=parseFloat(val)/100*self.h;
								self.my_debug('Height',vH);
								val=vH+'px';

								var has=$("#my_templates_style_css #"+id).length;
								var css=oVal.rowClass+"{ height:"+val+"!important}";

								if(has==0){
										$("#my_templates_style_css").append('<style type="text/css" id="'+id+'">'+css+'</style>');

								}else {
										$("#my_templates_style_css #"+id).html(css);
								}								}
							self.my_debug("Prop heigjht",{id:id,css:css,val:val,oVal:oVal});

					})

				});
				

			}
			$("#use_slider_my_templates_id").on('change',function(e){
				var type=$("#post_type_my_templates_id").val();
				var val=$("#template_my_templates_id").val();
				var url=self.options.admin_page+'&my_tmpl='+val+"&my_type="+type;
				var tmpl=$("#slider_template_my_templates_id").val();
				if($(this).is(":checked")){
					url+='&my_slider=1';
				}
				window.location.href=url;
			});
			$("#template_my_templates_id_div").on("my_change",function(e){
				var type=$("#post_type_my_templates_id").val();// .data('my-script').get_value();
				var $o=$(this).data('my-script');
				var val=$o.get_value();
				self.my_debug("Change post type",{val:val,type:type});
				var url=self.options.admin_page+'&my_tmpl='+val+"&my_type="+type;
				window.location.href=url;
			});
			$("#post_type_my_templates_id_div").on("my_change",function(e){
				var tmpl=$("#template_my_templates_id").val();// $("#template_my_templates_id_div").data('my-script').get_value();

				var $o=$(this).data('my-script');
				var val=$o.get_value();
				self.my_debug("Change post type",{val:val,tmpl:tmpl});
				var url=self.options.admin_page+'&my_type='+val+"&my_tmpl="+tmpl;
				window.location.href=url;
			});
			if($("#tmpl_styles_my_templates_id_div").length>0){
				$("#tmpl_styles_my_templates_id_div").on('my_change',function(e,obj,val,v1){
					var preStyle=self.setStyle;
					self.my_debug("Change style",val);
					var styleClass=".my_"+self.options.tmpl+"_style"+"_"+val;
					var css=$(styleClass).text();
					// self.my_debug("New css",css);
					if(typeof css!='undefined'){
						self.setStyle=val;
						self.my_debug("Set style",val);
						
						$("#my_css_tmpl_"+self.options.tmpl).text(css);
					}else self.my_debug("css style is undefined");
				});
			}
			$("#thumb_effect_my_templates_id_div").on("my_change",function(e,obj,val,v1){
				// var
				// tmpl=$("#template_my_templates_id").val();//$("#template_my_templates_id_div").data('my-script').get_value();

				// var $o=$(obj).data('my-script');
				// var val=$o.get_value();
				self.my_debug("Change effects",{val:val,tmpl:self.options.tmpl});
				var preVal='';
				if(typeof self.templateEffects.thumb_effects!='undefined'){
					preVal=self.templateEffects.thumb_effects;
				}
				self.templateEffects.thumb_effect=val;
				if(preVal!='none'&&val=='none'){
					self.my_debug("Remove Effect",val);
					myPostEffects_inst.removeEffect(".my_"+self.options.tmpl,'grayscale');
					myPostEffects_inst.removeCss("filter",".my_post_bg");
				}else if(val!='none'){
					var d=$(".my_"+self.options.tmpl).attr('data-grayscale');
					if(typeof d !='undefined'){
						if(d==0){
							$(".my_"+self.options.tmpl).attr('data-grayscale',1);
						}
					}
					if(val=='gray'){
						myPostEffects_inst.filterGrayscale(".my_"+self.options.tmpl,"mouseenter","mouseleave",2000,".my_post_bg",'easeInQuad',1,0);
						
					}
					else myPostEffects_inst.filterGrayscale(".my_"+self.options.tmpl,"mouseenter","mouseleave",2000,".my_post_bg",'easeInQuad',0,1);
					
				}
				
			});
			
		},
		this.my_action=function(e){
			e.preventDefault();
			var t=$(this).attr('data-key');
			self.debug=true;
			self.my_debug('My Action',t);
			switch(t){
				case 'open_builder':
					if(typeof self.my_check_init_t=='undefined'){
						setTimeout(myAdminTemplatesBuilderAdmin_inst.checkInit,300);
						self.my_check_init_t=1;
					}
					setTimeout(function(){
					var w=window.innerWidth;
					self.my_debug("Div width",w);
					w-=480;
					$(".my_timeline_modal .my_image_mapper_image_div").width(w);
					},100);
					var w=$(this).parents(".my_img_1").data('w');
					var h=$(this).parents(".my_img_1").data('h');
					self.my_debug("Edit slide",{id:id,w:w,h:h});
					$(".my_module_debug").hide();
					//var img=$(this).parents(".my_img_1").data('image');
					//self.my_debug("Img",img);
					//$(".my_timeline_modal").find(".my_slide_image .my_img_slide_inner").remove();
					//$(".my_timeline_modal").find(".my_slide_image").append('<img class="my_img_slide_inner" src="'+img+'"/>');
					//$(".my_timeline_modal").find(".my_slide_image").append('<div class="my_slide_image_inner"><img class="my_img_slide_inner" data-w="'+w+'" data-h="'+h+'" src="'+img+'"/></div>');
					var is_mc=$(".my_timeline_modal").find(".my_slide_image").attr('is-mc');
					var width = window.innerWidth;
					var height = window.innerHeight;
					var h1=$(".my_timeline_modal").find(".my_header").outerHeight();
					var h2=height-h1;
					$(".my_timeline_modal").find(".my_slide_image").height(h2);
					$(".my_view_item").hide();
					$(".my_view_item[data-key='"+type+"']").show();
					$(".my_module_shortcodes_form").hide();
					$(".my_module_shortcodes_form[data-key='"+type+"']").show();
					if(typeof is_mc=='undefined'){
						$(".my_timeline_modal").find(".my_slide_image").mCustomScrollbar({advanced:{
							updateOnContentResize:true
						}});
						$(".my_timeline_modal").find(".my_slide_image").attr('is-mc',1);
					}

					var hh=h;
					$(".my_options_form").height((h2-150));
					$(".my_options_form_inner").height((h2-150));
					var is_mc_1=$(".my_options_form").data('is-mc');
					if(typeof is_mc_1=='undefined'){

						$(".my_options_form_inner").mCustomScrollbar({advanced:{
							updateOnContentResize:true
						}});
						$(".my_options_form").data('is-mc',1);

					}
					myAdminDialog_inst.open_dialog();
				break;
				case 'new_template':
					var type=$("#post_type_my_templates_id").val();
					var val=$("#template_my_templates_id").val();
					var url=self.options.admin_page+'&my_tmpl=template_custom_new&my_type='+type;
					window.location.href=url;
				break;
				case 'close_dialog':
					$(".my_post_tmpl_close_dialog").fadeOut();

					self.dialog_open.my_close();
				break;
				case  'edit_view_dialog':
					$(".my_post_tmpl_close_dialog").fadeIn();

					self.dialog_view.my_open();
					/*setTimeout(function(){
						$(".my_view_a_row").trigger('click');
					},1000);*/
					self.dialog_open=self.dialog_view;
				break;
				case 'edit_stars_dialog':
					$(".my_post_tmpl_close_dialog").fadeIn();

					$(".my_post_title_stars").text(self.options.post.post_title);
					self.dialog_stars.my_open();
					/*setTimeout(function(){
						$(".my_stars_popup_row").trigger('click');
					},1000);
					*/
					self.dialog_open=self.dialog_stars;
				break;
				case  'edit_share_box':
					$(".my_post_meta_row").trigger('click');
					$(".my_post_share").trigger('click');
					$(".my_share_div_row").trigger('click');
				break;
				case 'adjust_height':
					var hV=parseInt($(".my_tmpl_h").text());
					self.h=hV;
					$(".my_module_post_templates_editor_div").height(self.h);
					$("#height_my_templates_id").val(self.h);
				break;
				case 'save_template':
					var id=$("input[name='id_my_templates']").val();
					if(id!=''){
						var t=$("input[name='title_my_templates']").val();
						$("#my_name_tmpl_id_12").val(t);
						$(".my_action[data-key='my_save_tmpl']").trigger('click');
						return;
					}
					self.dialog_save.my_open();
				break;
				case 'my_save_tmpl':
					//Save template
					var title=$("#my_name_tmpl_id_12").val();
					if(title==''){
						$("#my_name_tmpl_id_12").focus();
						myAdminMsgs_inst.show_remove(self.options.msgs.title_is_required,1);
						return;
					}
					var o1={};
					o1.show_msg=1;
					var css='';
					$("#my_templates_style_css style").each(function(i,v){
						css+="\n"+$(v).text()+"\n";
					});
					var id=$("input[name='id_my_templates']").val();
					o1.data={
							id:id,
							tmpl_data:$("#my_form_my_templates").serialize(),
							action:self.options.ajax_action,
							my_action:'save_template',
							title:title,
							css:css,
							form_data:self.options.rules
					};
					self.my_debug("Save template daa ",o1);
					o1.success=function(data){
						self.my_debug("Return", data);
						if(data.error==0){
							if(typeof data.added!='undefined'){
								$(".my_radio_inline").append('<li data-id="'+data.added.id+'" class="my_action" data-key="load_template">'+data.added.title+'</li>');
								$("input[name='id_my_templates']").val(data.added.id);
								$("input[name='title_my_templates']").val(data.title);
							}
							myAdminMsgs_inst.show_remove(data.msg,0);
						}else {
							myAdminMsgs_inst.show_remove(data.msg,1);
						}

					};
					myGlobalAjaxClass_inst.call_ajax(o1,self.options.msgs.saving_shortcode);


				break;
				case 'edit_dragg1':
					var id=self.my_edit_id;
					if(id!=''){
						if($(id+" .mCSB_dragger_bar").length>0){
							$(id+" .mCSB_dragger_bar").trigger('click');
						}
					}
					//$(".my_post_content_row").trigger('click');
					//$(".my_module_post_templates_editor_div_inner").find(".mCSB_dragger_bar").trigger('click');

				break;
				case 'edit_dragg_line1':
					//$(".my_post_content_row").trigger('click');
					//$(".my_module_post_templates_editor_div_inner").find(".mCSB_draggerRail").trigger('click');
					var id=self.my_edit_id;
					if(id!=''){
						if($(id+" .mCSB_dragger_bar").length>0){
							$(id+" .mCSB_draggerRail").trigger('click');
						}
					}

				break;

				case 'edit_dragg':
					//console.log('Edit dragg');
					//$(".my_post_content_row").trigger('click');
					//$(".my_module_post_templates_editor_div_inner").find(".mCSB_dragger_bar").trigger('click');
					self.edit_dragg(true);	
				break;
				case 'edit_dragg_line':
					//console.log("Edit drag line");
					self.edit_dragg(false);
					//$(".my_post_content_row").trigger('click');
					//$(".my_module_post_templates_editor_div_inner").find(".mCSB_draggerRail").trigger('click');

				break;

				case 'load_template':
					var id=$(this).data('id');
					self.my_debug("load id",id);
					var url=self.options.admin_page+'&my_tmpl_id='+id;
					window.location.href=url;
				break;
				case 'new_template':
					var type=$("#post_type_my_templates_id").val();//.data('my-script').get_value();

					self.my_debug("Change post type",{val:val,type:type});
					var url=self.options.admin_page+"&my_tmpl=new&my_type="+type;
					window.location.href=url;

				break;
				case 'sort':
					self.my_sort_option=true;
					$($(".my_module_post_templates_editor_div .my_post_row")).find('*').each(function(){
					$(this).css({'-webkit-touch-callout': 'none',
									'-webkit-user-select': 'none',
									'-khtml-user-select': 'none',
									'-moz-user-select': 'none',
									'-ms-user-select': 'none',
									'user-select': 'none'});
					});
					$(".my_module_post_templates_editor_div").find(".my_post_row").each(function(i,v){
						var w=$(v).outerWidth(true);
						var h=$(v).outerHeight(true);
						$(v).attr('data-w',w);
						$(v).attr('data-h',h);
					});
					$(".my_module_post_templates_editor_div .my_"+self.options.tmpl).sortable({

						items:"  .my_post_row",
						sort:function(event,ui){
							var h=$(ui.item).attr('data-h');
						      var w=$(ui.item).attr('data-w');
						      //self.my_debug("Ui item",{w:w,h:h});
						      //var st=$(ui.item).attr('style');
						      //$(ui.item).attr('style',st+';width:'+w+'px;!important;height:'+h+'px !important');

						},
						stop:function(event,ui){
							self.my_debug("Stop");
							$("#my_added_css_sortable").remove();
						},
						 start: function( event, ui ) {
						      var h=$(ui.item).attr('data-h');
						      var w=$(ui.item).attr('data-w');
						      var st=$(ui.item).attr('style');
						      var k=$(ui.item).attr('data-key')
						      var css='<style type="text/css" id="my_added_css_sortable">.my_'+self.options.tmpl+' .my_'+k+'_row{width:'+w+'px !important;height:'+h+'px !important;}';

						      self.my_debug("Ui item",{w:w,h:h,k:k,css:css});
						      $("head").append(css);

						      //$(ui.item).attr('style',st+';width:'+w+'px;!important;height:'+h+'px !important');

						      //$(ui.item).css('height',h+'px');
						      //.addClass("yellow");
						    },
						change:function(e,ui){
							var arr=[];
							//$("#my_added_css_sortable").remove();
							$(".my_module_post_templates_editor_div .my_"+self.options.tmpl+" .my_post_row").each(function(i,v){
								var k=$(v).data('key');
								if(typeof k!='undefined'){
								arr[arr.length]=k;
								}

							});
							//$(ui.item).attr('style','');

							self.my_debug("New sort array",arr);
							self.options.sort=1;
							self.options.sort_arr=arr;
						}
					});
					$(".my_start_sort").hide();
					$(".my_stop_sort").show();
					break;
				case 'stop_sort':
					var arr=[];
					$(".my_module_post_templates_editor_div .my_"+self.options.tmpl+" .my_post_row").each(function(i,v){
								var k=$(v).data('key');
								if(typeof key!='undefined')
								arr[arr.length]=k;

							});
							self.my_debug("New sort array",arr);
							self.options.sort=1;
							self.options.sort_arr=arr;


					self.my_sort_option=false;
					$(".my_stop_sort").hide();
					$(".my_start_sort").show();
					$(".my_module_post_templates_editor_div my_"+self.options.tmpl).sortable("destroy");
					//$(".my_start_sort").hide();
					$($(".my_module_post_templates_editor_div .my_post_row")).find('*').each(function(){
						$(this).css({'-webkit-touch-callout': '',
										'-webkit-user-select': '',
										'-khtml-user-select': '',
										'-moz-user-select': '',
										'-ms-user-select': '',
										'user-select': ''});
						});
					setTimeout(function(){
						self.my_add_clear=true;
						self.calculateHeight();
						$(".my_action[data-key='adjust_height']").trigger('click');
						self.my_add_clear=false;
					},500);
				break;
			}
		};
		this.init_objects_display=function(){
			var $div=(".my_options_form_object_explorer");
			var $div1=$(".my_options_form_object_explorer1");
			// if(self.options.custom==1)return;
			self.templateObjects={};
			$(".my_"+self.options.tmpl+" .my_post_row").each(function(i,v){
				var key=$(v).data('key');
				var dialog=$(v).data('type');
				var title=self.options.msgs[key];
				if(typeof title=='undefined'){
					title=$(v).attr('data-title');
				}
				var has_child=false;
				var children=[];
				self.templateObjects[key]={};
				
				if(key=='post_meta'){
					has_child=true;
					var obj={};
					obj.sel=".my_post_hearts i";
					obj.title=self.options.msgs.post_hearts;
					children[children.length]=obj;
					var obj={};
					obj.sel=".my_post_comments i";
					obj.title=self.options.msgs.post_comments;
					children[children.length]=obj;
					var obj={};
					obj.sel=".my_post_share i";
					obj.title=self.options.msgs.post_share;
					children[children.length]=obj;
					var newArr=[]
					/*
					 * $.each(chldren,function(i,v){ var obj={};
					 * obj.sel=".my_post_meta" obj.title=self.options.msgs.span;
					 * }));
					 */
					
				}else if(key=='meta_stars'){
					has_child=true;
					var obj={};
					obj.sel=".my_meta_stars .my_active:eq(0) i";
					obj.title=self.options.msgs.stars_active;
					children[children.length]=obj;
					var obj={};
					obj.sel=".my_meta_stars .my_stars li:eq(4) i";
					obj.title=self.options.msgs.stars_inactive;
					children[children.length]=obj;
				
				}				
				if(typeof self.options.rules[key]!='undefined'){
				var hasPred=self.options.rules[key].predefined_classes;
				if(typeof hasPred!='undefined'){
					$.each(hasPred,function(i1,v1){
						
						
						var title=self.options.msgs[i1];
						var obj={};
						obj.title=title;
						obj.sel="."+i1;
						
						children[children.length]=obj;
					});
					
				} 
				}
				self.my_debug("children",children);
				if(children.length!=0)has_child=true;
				var divHtml='';
				self.templateObjects[key].children=children;
				self.templateObjects[key].has_child=has_child;
				if(!has_child){
					if(key!='share_div' && key !='stars_popup' &&key!="view_a"){
						divHtml='<div class="my_object_item" data-key="'+key+'">'+self.options.msgs[key]+'&nbsp;<a href="#javascript" class="my_hide_element" data-key="'+key+'" data-hide="0" title="'+self.options.msgs.hide_el+'"><span class="my_hide_el"><i class="fa fa-trash-o"></i></span><span class="my_show_el">'+self.options.msgs.show_el+'</span></a></div>';
					}
					else divHtml='<div class="my_object_item" data-key="'+key+'">'+self.options.msgs[key]+'</div>';
				}else {
					if(key!='share_div' && key !='stars_popup' &&key!="view_a"){
						// divHtml='<div class="my_object_item"
						// data-key="'+key+'">'+self.options.msgs[key]+'</div>&nbsp;<a
						// href="#javascript" class="my_hide_element"
						// data-key="'+key+'"
						// data-hide="0">'+self.options.msgs.show_hide+'</a>';
						// divHtml='<div class="my_object_item"
						// data-key="'+key+'">'+self.options.msgs[key]+'</div>&nbsp;<a
						// href="#javascript" class="my_hide_element"
						// data-key="'+key+'" data-hide="0"><span
						// class="my_hide_el">'+self.options.msgs.hide_el+'</span><span
						// class="my_show_el">'+self.options.msgs.show_el+'</span></a>';
						divHtml='<div class="my_object_item" data-key="'+key+'"><i class="fa fa-plus"></i>'+self.options.msgs[key]+'&nbsp;<a href="#javascript" class="my_hide_element" data-key="'+key+'" data-hide="0" title="'+self.options.msgs.hide_el+'"><span class="my_hide_el"><i class="fa fa-trash-o"></i></span><span class="my_show_el">'+self.options.msgs.show_el+'</span></a></div>';
						
					}
					else
					divHtml='<div class="my_object_item" data-key="'+key+'"><i class="fa fa-plus"></i>&nbsp;&nbsp;'+self.options.msgs[key]+'</div>';
					var divHtml1='';
					divHtml1+='<div class="my_object_item_inner" data-key="'+key+'">';
					$.each(children,function(ic,vc){
						divHtml1+='<div class="my_object_item_child" data-key="'+key+'" data-sel="'+vc.sel+'">'+vc.title+'</div>';
					})
					divHtml1+='</div>';
					$($div1).append(divHtml1);
				}
				$($div).append(divHtml);// =(".my_post_template_object_explorer").append(divHtml);
				
			});
			self.my_debug('Templates keys',self.templateObjects);
			$(".my_options_form_object_explorer").mCustomScrollbar({advanced:{
				updateOnContentResize:true
			}});
			$(".my_options_form_object_explorer1").mCustomScrollbar({advanced:{
				updateOnContentResize:true
			}});
			$(document).on('click',".my_hide_element",function(e){
				e.preventDefault();
				e.stopPropagation();
				var key=$(this).data('key');
				self.my_debug("click on",key);
				var visible=$(".my_"+key+"_row").is(":visible");
				if(visible){
					$(this).find(".my_hide_el").hide();// .css('visibility','hidden');
					$(this).find(".my_show_el").show();// .css('visibility','visible');
					
					
					$(this).attr('data-hide',1);
					$(".my_"+key+"_row").css('display','none');
					self.options.rules[key].show=0;
				}else {
					$(this).find(".my_hide_el").show();// .css('visibility','visible');
					$(this).find(".my_show_el").hide();// .css('visibility','hidden');
					
					
					$(this).attr('data-hide',0);
					self.options.rules[key].show=1;
					$(".my_"+key+"_row").css('display','');
				}
				setTimeout(function(){
					self.calculateHeight();
					$(".my_action[data-key='adjust_height']").trigger('click');
					
				},500);
			})
			$(document).on("click",".my_object_item",function(e){
				// $(".my_object_item_inner").hide();
				
				var key=$(this).data('key');
				self.my_debug("click on",key);
				if(self.my_dialog_open!=''){
					if(self.my_dialog_open=='share_div'){
						$(".my_action[data-key='edit_share_box']").trigger('click');
					}else{
						$(".my_post_tmpl_close_dialog my_action").trigger('click');
					}
				}
				self.my_dialog_open=key;
				
				if(key=='share_div'){
					$(".my_action[data-key='edit_share_box']").trigger('click');
				}else if(key=='stars_popup'){
					
					$(".my_action[data-key='edit_stars_dialog']").trigger('click');
				}else if(key=="view_a"){
					$(".my_action[data-key='edit_view_dialog']").trigger('click');
					
				}
				else {
					self.my_dialog_open='';
					$(".my_"+self.options.tmpl+" .my_"+key+"_row").trigger('click');
				}
				if($(".my_object_item_inner[data-key='"+key+"']").length>0){
					$(".my_object_item_inner[data-key='"+key+"']").slideToggle();
				}
			});
			$(document).on("click",".my_object_item_child",function(e){
				var key=$(this).data('key');
				if(key!=self.my_edit_id){
					$(".my_object_item[data-key='"+key+"']").trigger('click');
				}
				var sel=$(this).data('sel');
				self.my_debug('Click on child',{sel:sel,key:key});
				$(".my_"+self.options.tmpl+" "+sel).trigger('click');
			});
		};
		this.calculateHeight=function(){
			// return;
			self.debug=true;
			var h=0;
			var add=0;
			var max=0;
			var OtherH=0;
			var mScroll=$(".my_"+self.options.tmpl).attr('data-m_custom_scroll');
			$(".my_module_post_templates_editor_div .my_post_clear_1").remove();
			$(".my_module_post_templates_editor_div .my_post_template .my_post_row").each(function(i,v){
				// $(v).removeClass("my_post_clear");
				if($(v).is(":visible")){
				var h1=$(v).outerHeight(true);
				/*if(mScroll){
					h1=$(v).find(".my_post_content").height();
				}*/
				var w=$(v).outerWidth(true);
				if(max==0)max=h1;
				self.my_debug("Element ",{w:w,key:$(v).data('key'),h:h,max:max,add:add});
				if(w<self.w){
					add+=w;
					if(max<h1)max==h1;
				}else add=0;
				var c=$(v).attr('class');
				self.my_debug("Height",{h1:h1,c:c,w:w,add:add});
				if(add==0 || ((add>(self.w-2))&&add<(self.w+2))){
					h1=max;
					h+=h1;
					max=0;
					self.my_debug("Add Height",{h:h,h1:h1,c:c,w:w,add:add});
					if(add!=0){
						$(v).after('<div class="my_post_clear_1"></div>');// .addClass('my_post_clear');
					}
					if(c.indexOf("my_post_content_row")==-1){
						OtherH+=h1;
					}else {
						
					}
					
					add=0;
				}
				if(self.my_edit_id=='share_div'){
					var off=$(".my_post_share").offset();
					var wP=$(".my_post_share_popup").outerWidth(true);
					var hP=$(".my_post_share_popup").outerHeight(true);
					var top=off.top-hP-40;
					var wP1=$(".my_post_share").width();
					var left=off.left-wP/2+wP1/2;
					console.log('Click post share',{wP:wP,wP1:wP1,hP:hP});
					$(".my_post_share_popup").css('top',top+'px').css('left',left+'px');
				}
				}
			});
			self.my_debug("Height",{h:h,other:OtherH,tmpl:self.options.tmpl});
			$("."+self.options.tmpl).height(h);
			
			$(".my_tmpl_h").text(h+'px');
				
			
			var alreadyInitScroll=$(".my_post_content_row").data('myInitScroll');
			if(typeof mScroll!='undefined' && typeof alreadyInitScroll=='undefined'){
				// var oH=$(".my_post_content_row").outerHeight(true);
				var tH=parseInt($("#height_my_templates_id").val());
				var scrollH=tH-OtherH;
				$(".my_post_content_row").height(scrollH);
				$(".my_post_content_row").mCustomScrollbar({advanced:{
					updateOnContentResize:true
				}});
				$(".my_post_content_row").data('myInitScroll',1);
				$(".my_scrollEdit").show();
			}
			//$(document).on('click',".my_object_item",self.mySelectObject);
			
		};
		
		this.mySelectObject=function(e){
			self.debug=true;
			if(self.isGroup){
				self.showAllSectionsElements();
			}
			self.isGroup=false;
			self.my_disable_change=true;
			var i=$(this).attr('data-key');
			var title=$(this).attr('data-title');
			self.my_debug("Select Object",{i:i,title:title});
			if(self.my_edit_id!=""){
				$(self.my_edit_id).css('outline','');
			}
			$(".my_tmpl_tag").text(title);
			var w=$(i).outerWidth(true);
			var h=$(i).outerHeight(true);
			$(".my_el_h").text(h+'px');
			$(".my_el_w").text(w+'px');
			self.my_edit_id=i;
			$(i).css('outline','4px dashed #000000');
			var rules=self.options.cssRules[self.setStyle][i];
			self.my_debug("Template rules",rules);
			var usedSections=[];
			self.getSetValues(1);
			self.my_debug("Name sections",{name_section:self.name_sections,rules:rules});
			self.my_debug("Sections",self.sections);
			
			if(typeof rules!='undefined'){
				$.each(rules,function(i,v){
					
					if(typeof self.name_sections[i]!='undefined' || i=='height'){
						
						var section='box';
						if(typeof self.name_sections[i]!='undefined')section=self.name_sections[i];
						self.my_debug('Section',section);
						var obj=self.sections[section][i];
						if(i=='height')obj=self.sections[section]['height_choose'];
						self.my_debug("Object",obj);
						var val=v.value;
						if(typeof obj!='undefined'){
							var script=$(obj.obj).data('my-script');
							if(typeof script!='undefined'){
								script.set_value(val);
							}
						}
						if(i=='height'){
							if(val!=''){
								if($("#height_auto_template_vars_id").is(":checked")){
									$("#height_auto_template_vars_id").prop('checked',false);
									$("#height_auto_template_vars_id").trigger('change');
								}
							}else {
								if(!$("#height_auto_template_vars_id").is(":checked")){
									$("#height_auto_template_vars_id").prop('checked',true);
									$("#height_auto_template_vars_id").trigger('change');
								}
							}
						}
						self.my_debug("set value",{i:i,val,val});
						if($.inArray(section,usedSections)==-1){
							usedSections[usedSections.length]=section;
						}
					}
				});
			}
			self.debug=false;
			self.my_disable_change=false;
			
		},
		this.get_element_data=function(id){
			var $o=$("#"+id);
			var type=$($o).data('type');
			var name=$($o).data('base-name');
			var name1=$($o).data('name');
			var id1=$($o).data('id');
			return {
				id:id1,
				full_name:name1,
				name:name,
				type:type,
				obj:$o
			};
		},
		this.getFormStylesSections=function(){
			$(self.options.form_class+" "+self.options.form_element).each(function(i,v){
				var id=$(v).attr('id');
				var o=self.get_element_data(id);
				self.my_debug('Find object',o);
				var s=$(this).parents(".my_form_section").data('key');
				self.my_debug("Section",s);
				if(typeof self.sections[s]=='undefined'){
					self.sections[s]={};
				}
				self.sections[s][o.name]=o;
				self.name_sections[o.name]=s;
			});
		},
		this.formStylesEvents=function(){
			$("#height_auto_template_vars_id").change(function(e){
				// e.preventDefault();
				e.stopPropagation();
				if($("#height_auto_template_vars_id").is(":checked")){
					self.my_debug("Checked jheight");
					$(".my_form_element_inline_height_choose_template_vars").hide();
				}else {
					self.my_debug("UnChecked height");
					$(".my_form_element_inline_height_choose_template_vars").show();

				}
			});
		},
		this.getDomTree=function(){
			var tmplKey=".my_"+self.options.tmpl;
			var object={};
			var ugInt=0;
			var intObject=self.domIntCount;
			self.currObject={};
			$.each(self.domObjects[tmplKey].child,function(i,v){
				self.my_debug("Call findChldrenDomObjects",{i:i,v:v});
				self.domObject=v.child;
				self.findChildrenDomObjects(v.selector,1,v);
			});
			//self.parseDomObjects(self.domObjects);
			
			
		},
		this.findChildrenDomObjects=function(sel,isRow,domObject){
			var tmplKey=".my_"+self.options.tmpl;
			var arL=arguments.length;
			var lastParent={};
			if(arL==4){
				lastParent=arguments[3];	
			}
			var hasObject=$(sel).children('[data-is="1"]').length;
			self.my_debug("Find children dom",{sel:sel,has:hasObject,isRow:isRow,argL:arL,args:arguments});
			var childs=[];
			if(hasObject>0){
				//self.currObject=$(sel).find('[data-is="1"]').first();
				$(sel).children('[data-is="1"]').each(function(i,v){
					childs[childs.length]=v;
					var sel1=$(v).attr('data-selector');
					var splitArr=sel1.split(" ");
					var cCount=splitArr.length-1;
					var objectKey=splitArr[cCount];
					var title=self.getDomObjectTitle(sel1);
					self.my_debug("New object",{title:title,sel:sel,sel1:sel1,hasObject:hasObject,splitArr:splitArr,objectKey:objectKey});
					object={};
					object.child={};
					object.hasChild=false;
					object.selector=sel1;
					var myId='my_object_item_'+self.domIntCount;
					object.intObject=self.domIntCount;;
					self.domIntCount++;
					object.title=title;
					object.id=myId;
					object.title=title;
					var divHtml='<div class="my_object_item_i">{i}<div id="'+myId+'"class="my_object_item" data-title="'+title+'" data-key="'+sel1+'">'+title+'</div></div>';
					if(i!=tmplKey){
						divHtml='<div class="my_object_item_i">{i}<div id="'+myId+'" class="my_object_item" data-title="'+title+'" data-key="'+sel1+'" data-hash-child="{has_child}">'+title+'&nbsp;<a href="#javascript" class="my_hide_element" data-key="'+i+'" data-hide="0" title="'+self.options.msgs.hide_el+'"><span class="my_hide_el"><i class="fa fa-trash-o"></i></span><span class="my_show_el">'+self.options.msgs.show_el+'</span></a></div>';
					}	
					object.html=divHtml;
					domObject.child[objectKey]=object;
					domObject.hasChild=true;
					//lastObject=domObject;
					//domObject=object;
					//self.findChildrenDomObjects(sel1,0,domObject,lastObject);
					});
			lastObject=domObject;
			$.each(childs,function(iC,vC){
				var sel1=$(vC).attr('data-selector');
				var splitArr=sel1.split(" ");
				var cCount=splitArr.length-1;
				var objectKey=splitArr[cCount];
				lastObject=domObject;
				domObject=lastObject.child[objectKey];
				self.findChildrenDomObjects(sel1,0,domObject,lastObject);
				domObject=lastObject;
			});
					
					
				}
			
			
		},
		/**
		 * Get obejct title
		 */
		this.getDomObjectTitle=function(sel){
			var title=$(sel).attr('data-title');
			if(sel.indexOf(".mCSB_draggerRail")!=-1){
				title=self.options.msgs["mCSB_draggerRail"];
			}else if(sel.indexOf(".mCSB_dragger_bar")!=-1){
				title=self.options.msgs['mCSB_dragger_bar'];
			}
			if(sel.indexOf("_row")!=-1){
				var Arr=sel.split(" ");
				var keyI=Arr[1];
				keyI=keyI.replace("_row","");
				title=$(sel).find(keyI).attr('data-title');
				title+=" "+self.options.msgs.row;
				
			}
			self.my_debug("Selector title",{sel:sel,title:title});
			return title;
		},
		/**
		 * Add objcts to exporer
		 * Add css groups 
		 * show parse doom objects in the tree
		 */
		this.adjustCssRulesArray=function(){
			self.debug=true;
			$.each(self.options.cssRules,function(i,v){
				self.my_debug("Adjust shorthanf css rules",i);
				self.adjustStylesArrayShorthand(self.options.cssRules[i]);
			});
			var $div=(".my_options_form_object_explorer");
			var $div1=$(".my_options_form_object_explorer1");
			var rules=self.options.cssRules;
			var $div=(".my_options_form_object_explorer");
			var $div1=$(".my_options_form_object_explorer1");
			self.my_debug("Rules",rules);
			var curretObject;
			var ugInt=0;
			var intObject=1;
			var selChild;
			var Rows={};
			/*
			 * Init groups for selecting css for multiple groups
			 */
			if(self.options.cssGroups!=""){
				var $groupDiv=$(".my_object_groups");
				$.each(self.options.cssGroups,function(i,v){
					$.each(v.elements,function(i1,v1){
						var divHtml='<div class="my_object_group_item" data-key="'+i+'" data-sub-key="'+i1+'" data-selector="'+v1.selector+'">'+v1.title+'</div>';
						$($groupDiv).append(divHtml);
					});
				});
			}
			var object={};
			self.domObjects={};
			self.domIntCount=1;
			self.my_debug("Begin dom objects",self.domObjects);
			var tmplKey=".my_"+self.options.tmpl;
			var title="";
			$.each(rules['default'],function(i,v){
				if(i==tmplKey || i.indexOf("_row")!=-1){
					object={};
					object.child={};
					object.hasChild=true;
					object.selector=i;
					var myId='my_object_item_'+self.domIntCount;
					object.intObject=self.domIntCount;;
					self.domIntCount++;
					object.title=title;
					object.id=myId;
					object.html=divHtml;
					title=self.getDomObjectTitle(i);
					object.title=title;
					var divHtml='<div class="my_object_item_i">{i}<div id="'+myId+'"class="my_object_item" data-title="'+title+'" data-key="'+i+'">'+title+'</div></div>';
					if(i!=tmplKey){
						divHtml='<div class="my_object_item_i">{i}<div id="'+myId+'" class="my_object_item" data-title="'+title+'" data-key="'+i+'" data-hash-child="{has_child}">'+title+'&nbsp;<a href="#javascript" class="my_hide_element" data-key="'+i+'" data-hide="0" title="'+self.options.msgs.hide_el+'"><span class="my_hide_el"><i class="fa fa-trash-o"></i></span><span class="my_show_el">'+self.options.msgs.show_el+'</span></a></div>';
					}
					object.html=divHtml;
					if(i==tmplKey){
						self.my_debug("Add main dom obejct",object);
						self.domObjects[i]=object;
					}else {
						var isRow=false;
						if(i.indexOf("_row")!=-1){
							isRow=true;
							self.my_debug("row",i);
							var strTmpl=".my_"+self.options.tmpl;
							var splitRow=i.split(" ");
							if(splitRow.length==2){
								var rowText=splitRow[1];
								var rowText1=rowText;
								rowText1=rowText.replace("_row","");
								Rows[rowText1]=rowText;
								self.domObjects[tmplKey].child[splitRow[[1]]]=object;
								self.my_debug("Add row object",object);
							}else self.my_debug("Not found");
						}
					}
				}
			});
			self.domRows=Rows;
			self.my_debug("Rows",{rows:Rows,domObjects:self.domObjects});
			$.each(rules['default'],function(i1,v1){
				self.templateSelectors[i1]=v1;
				$(i1).attr('data-selector',i1);
				var isRowInt=0;
				if(i1.indexOf("_row")!=-1){
					isRowInt=1;
				}
				$(i1).attr('data-is',1);
				$(i1).attr('data-is-row',isRowInt);
			});
			self.my_debug("Template selectors",self.templateSelectors);
			self.getDomTree();
			self.parseDomObjects(self.domObjects);
			self.my_debug("Dom objects",self.domObjects);
			/*$(".my_options_form_object_explorer").mCustomScrollbar({advanced:{
				updateOnContentResize:true
			}});
			*/
			self.debug=false;
			return;
			$.each(rules['default'],function(i1,v1){
				
					var domObject={};
					var lastItemKey="";
					self.templateSelectors[i1]=v1;
					
					var splitArr=i1.split(" ");
					self.my_debug("Split arr",splitArr);
					var cCount=splitArr.length-1;
					var cCount1=cCount-1;
					/*if(isRow){
						cCount1=cCount;
					}*/
					domObject=self.domObjects;
					var ItemKey=splitArr[cCount];
					var itemCurrStr="";
					if(i1==tmplKey){
						object=self.domObjects[tmplKey];
					}else if(i1.indexOf("_row")!=-1){
						object=self.domObjects[tmplKey].child[ItemKey];
					}else {
						object.child={};
						object.hasChild=false;
						object.selector=i1;
					}
					self.my_debug("Rule and object",{ItemKey:ItemKey,i1:i1,v1:v1,object:object});
					var isChild=false;
					var isRow=false;
					
					if(i1.indexOf('_row')!=-1){
						isRow=true;
						self.my_debug("row",i1);
						/*var strTmpl=".my_"+self.options.tmpl;
						var splitRow=i1.split(" ");
						if(splitRow.length==2){
							var rowText=splitRow[1];
							rowText=rowText.replace("_row","");
							Rows[rowText]=rowText;
						}else self.my_debug("Not found");
						*/
					}
						var isRowChild=false;
						var RowKeyInsert;
						if(i1!=tmplKey){
							
							if(!isRow){
								if(splitArr.length>=2){
									var key=splitArr[1];
									if(typeof Rows[key]!='undefined'){
										// splitArr[1]=key+"_row";
										// splitArr[2]=key;
										RowKeyInsert=Rows[key];
										var newArrC=[];
										if(splitArr.length==2)isRowChild=true;
										$.each(splitArr,function(iK,vK){
											if(iK==1){
												newArrC[newArrC.length]=RowKeyInsert;
											}
											newArrC[newArrC.length]=vK;
										});
										splitArr=newArrC;
									self.my_debug("Insert row key",{key:key,Row:Rows[key],newArr:newArrC});
									
									}
									
									
								
								}
							}
						
							
							
							domObject=self.domObjects;
							$.each(splitArr,function(iC,vC){
								self.my_debug("Walking doom objects up",{object:domObject,iC:iC,vC:vC});
								if(iC==0){
									domObject=domObject[vC];
									//domObject.hasChild=true;
								}else {
									if(typeof domObject.child[vC]!='undefined'){
									
										if(iC==cCount){
										
										}else {
											
											domObject=domObject.child[vC];
											domObject.hasChild=true;
											
											self.my_debug("Go deep",{iC:iC,vC:vC});
										}
									}else {
										self.my_debug("dom object child is not defined",{child:domObject.child,iC:iC,vC:vC});
									}
								}
								self.my_debug("Walking doom objects down",{object:domObject,iC:iC,vC:vC});
								
							});
							self.my_debug("Found doom object ",domObject);
							
							if(i1!='.my_'+self.options.tmpl || !isRow){
								isChild=true;
							}
							/*for(var k=cCount;k>0;k--){
								newArr.splice(k,1);
								selChild=newArr.join(" ");
								self.my_debug("Arr sel",{arr:newArr,selChild:selChild});
								if(typeof self.domObjects[selChild]!='undefined'){
									self.domObjects[selChild].child[i1]={};
									self.domObjects[selChild].hasChild=true;
									isChild=true;
									break;
								}
							}*/
						
					
						}
					
					if(typeof v1=='object'){
						
						var title=$(i1).attr('data-title');
						if(i1.indexOf(".mCSB_draggerRail")!=-1){
							title=self.options.msgs["mCSB_draggerRail"];
						}else if(i1.indexOf(".mCSB_dragger_bar")!=-1){
							title=self.options.msgs['mCSB_dragger_bar'];
						}
						if(isRow){
							title=$(i1).children('div').attr('data-title');
							if(typeof title=='undefined'){
								var i2=i1.replace("_row","");
								title=$(i1).find(i2).attr('data-title');
								self.my_debug("Item row title",{i2:i2,title:title});
								
							}
							title+=" "+self.options.msgs.row;
							
						}
						var myId='my_object_item_'+intObject;
						object.intObject=intObject;
						intObject++;
						object.title=title;
						if(!isChild){
							object.id=myId;
							
							var divHtml='<div class="my_object_item_i">{i}<div id="'+myId+'"class="my_object_item" data-key="'+i1+'">'+title+'</div></div>';
							if(i1!='.my_'+self.options.tmpl){
								divHtml='<div class="my_object_item_i">{i}<div id="'+myId+'" class="my_object_item" data-key="'+i1+'" data-hash-child="{has_child}">'+title+'&nbsp;<a href="#javascript" class="my_hide_element" data-key="'+i1+'" data-hide="0" title="'+self.options.msgs.hide_el+'"><span class="my_hide_el"><i class="fa fa-trash-o"></i></span><span class="my_show_el">'+self.options.msgs.show_el+'</span></a></div>';
							}
							// divHtml+='<div style="display:none"
							// class="my_object_children"
							// data-key="'+i1+'"></div>';
							object.html=divHtml;
							if(isRow){
								self.domObjects[tmplKey].child[RowKeyInsert]=object;
							}
							else self.domObjects[i1]=object;
							self.my_debug("Add not child",{i1:i1,domObject:domObject,object:object,domObjects:self.domObjects});
							// $($div).append(divHtml);
						}else {
							//self.domObjects[selChild].child[i1].id=myId;
							var divHtml='<div class="my_object_item" data-key="'+i1+'">{i}'+title+'</div>';
							if(i1!='.my_'+self.options.tmpl){
								divHtml='<div id="'+myId+'" class="my_object_item" data-key="'+i1+'">'+title+'&nbsp;<a href="#javascript" class="my_hide_element" data-key="'+i1+'" data-hide="0" title="'+self.options.msgs.hide_el+'"><span class="my_hide_el"><i class="fa fa-trash-o"></i></span><span class="my_show_el">'+self.options.msgs.show_el+'</span></a></div>';
							}
							// divHtml+='<div style="display:none"
							// class="my_object_children"
							// data-key="'+i1+'"></div>';
							object.html=divHtml;
							object.hasChild=false;
							object.id=myId;
							//self.domObjects[selChild].child[i1]=object;
							domObject.child[ItemKey]=object;
							domObject.hasChild=true;
							self.my_debug("Add child to dom objects",{i1:i1,object:object,domObject:domObject,doomObjects:self.domObjects});
						}
					}
				});
				self.my_debug("Dom objects",self.domObjects);
				
			
			self.parseDomObjects(self.domObjects);
			
		},
		this.parseDomObjects=function(obj){
			var argLength=arguments.length;
			var parentId='';
			if(argLength==2)parentId=arguments[1];
			self.my_debug("parent id",parentId);
			
			var $div=(".my_options_form_object_explorer");
			$.each(obj,function(i,v){
				self.my_debug("walking object",{i:i,obj:v});			
				var id=v.id;
				var hasChild=v.hasChild;
				var child=v.child;
				var html=v.html;
				var title=v.title;
				var intObject=v.intObject;
				if(hasChild){
					var childId='my_object_children_'+intObject;
					var iHtml=self.options.object_children_sel_html;
					var title=self.options.msgs.object_children;
					iHtml=iHtml.replace('{title}',title);
					
					html=html.replace('{i}',iHtml);
					html=html.replace('{has_child}','1');
					html+='<div class="my_object_children" id="'+childId+'"></div>'
				}else {
					html=html.replace('{has_child}','0');
					html=html.replace('{i}','');
				}
				if(parentId!=""){
					$("#"+parentId).append(html);
				}
				else $($div).append(html);
				if(hasChild){
					self.parseDomObjects(child,childId);
				}
				
				
			});
			
		},
		this.countClass=function(cl){
			var c=0;
			var l=cl.length;
			
			
		},
		this.init_objects_display=function(){
			var $div=(".my_options_form_object_explorer");
			var $div1=$(".my_options_form_object_explorer1");
			if(self.options.custom==1&&self.options.tmpl=="")return;
			self.templateObjects={};
			$(".my_"+self.options.tmpl+" .my_post_row").each(function(i,v){
				var key=$(v).data('key');
				var dialog=$(v).data('type');
				var title=self.options.msgs[key];
				if(typeof title=='undefined'){
					title=$(v).attr('data-title');
				}
				var has_child=false;
				var children=[];
				self.templateObjects[key]={};

				if(key=='post_meta'){
					has_child=true;
					var obj={};
					obj.sel=".my_post_hearts i";
					obj.title=self.options.msgs.post_hearts;
					children[children.length]=obj;
					var obj={};
					obj.sel=".my_post_comments i";
					obj.title=self.options.msgs.post_comments;
					children[children.length]=obj;
					var obj={};
					obj.sel=".my_post_share i";
					obj.title=self.options.msgs.post_share;
					children[children.length]=obj;
					var newArr=[];
					/*
					 * $.each(chldren,function(i,v){ var obj={};
					 * obj.sel=".my_post_meta" obj.title=self.options.msgs.span;
					 * }));
					 */

				}else if(key=='meta_stars'){
					has_child=true;
					var obj={};
					obj.sel=".my_meta_stars .my_active:eq(0) i";
					obj.title=self.options.msgs.stars_active;
					children[children.length]=obj;
					var obj={};
					obj.sel=".my_meta_stars .my_stars li:eq(4) i";
					obj.title=self.options.msgs.stars_inactive;
					children[children.length]=obj;

				}
				// var hasPred=self.options.rules[key].predefined_classes;
				/*
				 * if(typeof hasPred!='undefined'){
				 * $.each(hasPred,function(i1,v1){
				 * 
				 * 
				 * var title=self.options.msgs[i1]; var obj={}; obj.title=title;
				 * obj.sel="."+i1;
				 * 
				 * children[children.length]=obj; }); }
				 */
				self.my_debug("children",children);
				if(children.length!=0)has_child=true;
				var divHtml='';
				self.templateObjects[key].children=children;
				self.templateObjects[key].has_child=has_child;
				if(!has_child){
					if(key!='share_div' && key !='stars_popup' &&key!="view_a"){
						divHtml='<div class="my_object_item" data-key="'+key+'">'+self.options.msgs[key]+'&nbsp;<a href="#javascript" class="my_hide_element" data-key="'+key+'" data-hide="0" title="'+self.options.msgs.hide_el+'"><span class="my_hide_el"><i class="fa fa-trash-o"></i></span><span class="my_show_el">'+self.options.msgs.show_el+'</span></a></div>';
					}
					else divHtml='<div class="my_object_item" data-key="'+key+'">'+self.options.msgs[key]+'</div>';
				}else {
					if(key!='share_div' && key !='stars_popup' &&key!="view_a"){
						// divHtml='<div class="my_object_item"
						// data-key="'+key+'">'+self.options.msgs[key]+'</div>&nbsp;<a
						// href="#javascript" class="my_hide_element"
						// data-key="'+key+'"
						// data-hide="0">'+self.options.msgs.show_hide+'</a>';
						// divHtml='<div class="my_object_item"
						// data-key="'+key+'">'+self.options.msgs[key]+'</div>&nbsp;<a
						// href="#javascript" class="my_hide_element"
						// data-key="'+key+'" data-hide="0"><span
						// class="my_hide_el">'+self.options.msgs.hide_el+'</span><span
						// class="my_show_el">'+self.options.msgs.show_el+'</span></a>';
						divHtml='<div class="my_object_item" data-key="'+key+'"><i class="fa fa-plus"></i>'+self.options.msgs[key]+'&nbsp;<a href="#javascript" class="my_hide_element" data-key="'+key+'" data-hide="0" title="'+self.options.msgs.hide_el+'"><span class="my_hide_el"><i class="fa fa-trash-o"></i></span><span class="my_show_el">'+self.options.msgs.show_el+'</span></a></div>';

					}
					else
					divHtml='<div class="my_object_item" data-key="'+key+'"><i class="fa fa-plus"></i>&nbsp;&nbsp;'+self.options.msgs[key]+'</div>';
					var divHtml1='';
					divHtml1+='<div class="my_object_item_inner" data-key="'+key+'">';
					$.each(children,function(ic,vc){
						divHtml1+='<div class="my_object_item_child" data-key="'+key+'" data-sel="'+vc.sel+'">'+vc.title+'</div>';
					})
					divHtml1+='</div>';
					$($div1).append(divHtml1);
				}
				$($div).append(divHtml);// =(".my_post_template_object_explorer").append(divHtml);

			});
		}
		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log('myAdminTemplatesBuilder\n'+t,o);
				}
			}
		};
			this.init();
			
	};
})(jQuery);		
