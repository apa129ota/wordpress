<?php
if(!defined('ABSPATH'))die('');
?>
<ul class="my_shortcode_select_ul my_clearfix">
<?php foreach($arr as $k1=>$v1){
if($k1!='content')continue;
    ?>
<?php if(!empty($v1['elements'])){
    foreach($v1['elements'] as $k2=>$v2){
        ?>
					<li data-name="<?php echo esc_attr($k2)?>" class=" my_shortcodes_select_action" data-key="add_shortcode">
						<div class="my_background_color my_shortcode_inner_div my_gradient_shortcode" style="">
						<h4><?php echo $v2['title'];?></h4>
						<span><i class="fa <?php echo $v2['icon']?>"></i></span>

						</div>
					</li>
					<?php
					}
				}
					?>
			</ul>
<?php }?>