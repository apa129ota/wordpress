(function($) {
	myVusualBuilderShortcodesList=function(o){
		var self;
		this.my_working=false;
		this.debug=true;
		this.options=o;
		this.dialog='';
		this.tmpl='';
		this.index=1;
		this.content='';
		this.objects={};
		this.countObjects=1;
		this.li_elements=[],
		this.li_icon=[],
		this.li_a=[];
		this.myId="";
		this.objectI=1;
		this.useIcon=false;
		this.useLink=false;
		this.Icon='fa-plus';
		this.link="";
		this.pre_options={
				dw:800,
				dh:600,
				diff:20,

				my_li_class:"my_shortcode_list_li",
				my_span_class:"my_shortcode_list_li_span",
				my_icon_class:"my_shortcode_list_li_icon",
				my_li_html:'<li class="{li_class}" id="{li_id}">{li}</li>',
				my_li_icon:'<i class="fa {icon} my_shortcode_list_li_icon" data-class="my_shortcode_list_li_icon"></i>',
				previewIcon:'<i class="fa fa-trash"></i>',
				my_li_span:'<span class="my_shortcode_list_li_span">{text}</span>',
				my_li_a:'<a href="{href}" class="my_shortcode_list_a">{a}</a>'

			};
			self=this;
			this.init=function(o){
				if(typeof self.options.debug!='undefined'){
					if(!self.options.debug){
						self.debug=false;
					}
				}
				self.options=$.extend( self.pre_options,self.options);

				self.my_debug("options", self.options);
				var o={
					key:self.options.key,
					debug:self.debug,
					dw:self.options.dw,
					dh:self.options.dh,
					diff:self.options.diff
				};
				self.dialog=new myVusualBuilderDialog(o);
				$(".my_shortcode_insert_list").click(function(e){
						self.insertContent();

				});
				$("#link_list_form_id_div").on("my_change",function(e,obj,val,name){
					self.my_debug("Select link",val);
					self.link=val;
				});
				$("#button_list_form_id_div").on('click',function(e){
					var val=$("#text_list_form_id").val();
					if(val==""){
						myAdminMsgs_inst.show_remove(self.options.msgs.text_is_empty,1);
						return;
					}
					self.li_elements[self.li_elements.length]=val;
					self.li_a[self.li_a.length]=self.link;	
					self.li_icon[self.li_icon.length]=self.Icon;
					self.my_debug('li elements',{li:self.li_elements,a:self.li_a,i:self.li_icon});
					html=self.generateHtml(true);
					self.addPreviewHtml(html);
				});
				$("#use_link_list_form_id_div").on('my_change',function(e,obj,val,name){
					self.my_debug("Use icon",val);
					if(val){
						self.useLink=true;
					}else {
						self.useLink=false;
					}
					html=self.generateHtml(true);
					self.addPreviewHtml(html);
				});
				$("#use_icon_list_form_id_div").on('my_change',function(e,obj,val,name){
					self.my_debug("Use icon",val);
					if(val){
						self.useIcon=true;
					}else self.useIcon=false;
					//html=self.generateHtml(true);
					//self.addPreviewHtml(html);
				});
				$("#icons_list_form_id_div").on('my_change',function(e,obj,val,name){
					self.my_debug("Use Icon",val);
					var pre=self.Icon;
					self.Icon=val;
					/*if(pre!=val){
						html=self.generateHtml(true);
						self.addPreviewHtml(html);
					}*/
				});
				$(document).on('click','.my_shortcode_list_edit_icon',function(e){
					e.preventDefault();
					var iEl=$(this).attr('data-i');
					iEl=parseInt(iEl);
					self.my_debug("Delete item",iEl);
					var arr=[];
					$.each(self.li_elements,function(i,v){
						if(i!=iEl)arr[arr.length]=v;
					});
					var arr1=[];
					if(self.useLink){
						$.each(self.li_a,function(i,v){
							if(i!=iEl)arr1[arr1.length]=v;
						});
						self.li_a=arr1;
					}
					self.my_debug("Arr",arr);
					self.li_elements=arr;
					html=self.generateHtml(true);
					self.addPreviewHtml(html);

				});

			};
			this.deleteObject=function(id){
				if(typeof self.objects[id]!='undefined'){
					delete self.objects[id];
				}
			},
			this.setFormValues=function(obj){
				var object=$("#use_icon_list_form_id_div").data('my-script');
				var useIcon=0;
				if(obj.useIcon){
					useIcon=1;
				}
				object.set_value(useIcon);
				var icon=obj.Icon;
				var object=$("#icons_list_form_id").data('my-script');
				object.set_value(icon);

			},
			this.addPreviewHtml=function(html){
				$(".my_shortcodes_list  .my_shortcode_list_ul").html(html);
			},
			this.generateHtml=function(preview){
				var html_li=self.options.my_li_html;
				var iconHtml='';
				var iconPreviewHtml='';
				if(self.useIcon){
					 iconHtml=self.options.my_li_icon;
					 //iconHtml=iconHtml.replace(/\{icon\}/g,self.Icon);
				}
				

				self.my_debug('icon',iconHtml);
				var html='';
				$.each(self.li_elements,function(i,v){
					if(self.useIcon){
						 iconHtml=self.options.my_li_icon;
						 iconHtml=iconHtml.replace(/\{icon\}/g,self.li_icon[i]);
					}
					var id="my_list_"+self.countObjects+"_"+i;
					self.my_debug("Id",id);
					var h=html_li;
					h=h.replace(/\{li_class\}/g,self.options.my_li_class);
					h=h.replace(/\{li_id\}/g,id);
					var span1=self.options.my_li_span;
					span1=span1.replace(/\{text\}/g,v);
					var span=iconHtml+span1;
					var linkHtml=span;
					if(self.useLink){
						var href=self.li_a[i];
						if(href==""){
							href="#javascript";
						}
						linkHtml=self.options.my_li_a.replace("{a}",span);
						linkHtml=linkHtml.replace('{href}',href);
						span=linkHtml;
					}
					if(preview){
						iconPreviewHtml=self.options.previewIcon;
						var iconEdit='<a href="#javascript" data-i="'+i+'" title="'+self.options.msgs.trash_item+'" class="my_shortcode_list_edit_icon">';
						iconEdit+=iconPreviewHtml+'</a>';
						span+=iconEdit;

					}
					h=h.replace(/\{li\}/g,span);
					html+=h;
				});
				return html;
			}
			this.my_edit=function(content,id){
				self.my_debug("Edit id",id);
				self.my_edit_id=id;
				self.dialog.my_open();
				self.my_debug('content',content);

			};
			this.get_content=function(){
				var id=self.my_edit_id;
				var html=self.generateHtml(false);
				return html;
			}
			this.insertContent=function(){
				var h='100px';
				var obj=$("#height_html_form_id_div").data('my-script');//.get_value();
				if(typeof obj!='undefined'){
					h=obj.get_value();
				}
				
				var content=self.get_content();
				var tmpl=self.my_get_contentReal(content);
				var objectList={};
				objectList.useIcon=self.useIcon;
				objectList.Icon=self.Icon;
				objectList.li=self.li_elements;
				objectList.li_a=self.li_a;
				objectList.li_icon=self.li_icon;
				objectList.useLink=self.useLink;
				objectList.objectI=self.countObjects;
				var $div=(".my_options_form_object_explorer");
				self.my_debug("Css rules",self.options.cssRules);
				if(self.options.cssRules!='undefined'){
					var rowId=myAdminTemplatesBuilder.my_edit_id;
					self.my_debug("Row id",rowId);
					$.each(self.options.cssRules,function(i,v){
						self.my_debug("rule",{i:i,v:v});
						myAdminTemplatesBuilder_inst.my_edit_id='#'+rowId+"#"+self.myId+" ."+i;
						myAdminTemplatesBuilder_inst.setEditIdOptions(v.css_rules);
						var dataKey='#'+rowId+" ."+i;
						var divHtml='<div class="my_object_item" data-key="'+dataKey+'">'+v.title+'&nbsp;<a href="#javascript" class="my_hide_element" data-key="'+dataKey+'" data-hide="0" title="'+self.options.msgs.hide_el+'"><span class="my_hide_el"><i class="fa fa-trash-o"></i></span><span class="my_show_el">'+self.options.msgs.show_el+'</span></a></div>';
						$($div).append(divHtml);
					});
				
				myAdminTemplatesBuilder_inst.my_edit_id=rowId;
				myAdminTemplatesBuilder_inst.setEditIdOptions(myAdminTemplatesBuilder_inst.options.cssRules[myAdminTemplatesBuilder_inst.setStyle][rowId]);
				
				}
				myVusualBuilderShortcodesSelect_inst.my_add_shortcode('list','',tmpl,{});
				self.countObjects++;	
				self.objects[tmpl.id]=objectList;
				self.dialog.my_close();


			};
			this.my_show=function(obj){
				//$(self.my_class).dialog('open');
				//self.dialog.my_open(obj);
				/*if(self.options.my_show==0){
					var id=obj.id;
					var is=$("#"+id).length;
					if(is){
						self.dialog.my_open();
					}
					else return self.my_get_contentShow();

				}else {*/
				var id=obj.id;
				var is=$("#"+id).length;
				if(is){
					//$("#my_form_html_form").hide();
					self.dialog.my_open();
					var objectList=self.objects[id];
					self.myId=
					self.my_debug("Object list",{id:id,obj:objectList});
					self.useIcon=objectList.useIcon;
					self.Icon=objectList.Icon;
					self.li_a=objectList.li_a;
					self.li_icon=objectList.li_icon;
					self.li_elements=objectList.li;
					var html=self.generateHtml();
					self.addPreviewHtml(html);
					self.setFormValues(objectList);
					//return false;
				}else {
					self.myId='my_li_'+self.countObjects;	

					//$("#my_form_html_form").show();
					$(".my_shortcodes_list .my_shortcode_list_ul").html('');
					self.li_elements=[];

					self.dialog.my_open();
					return false;
				}

				//else return self.my_get_content(obj);
				//}
			};
			this.my_get_contentReal=function(content){
				var tmpl=$("script.my_shortcode_list").html();
				var id='my_shortcode_'+self.options.key+'_'+self.index;
				var is=$("#"+id).length;
				if(is)return false;
				self.my_debug("Is",is);
				//var content;
				//content=$("script.my_shortcode_html_default").text();
				tmpl=tmpl.replace('{id}',id);
				tmpl=tmpl.replace('{i}',self.index);
				tmpl=tmpl.replace('{content}',content);
				tmpl=tmpl.replace('{object_id}',id);
				//tmpl=tmpl.replace('{sel}','p');
				self.index++;
				self.my_debug('tmpl',tmpl);
				return {id:id,tmpl:tmpl};
			},

			this.my_get_content=function(obj){
				var tmpl=$("script.my_shortcode_list").html();
				var id='my_shortcode_'+self.options.key+'_'+self.index;
				var is=$("#"+id).length;
				if(is)return false;
				self.my_debug("Is",is);
				var content;
				content=this.generateContent();
				tmpl=tmpl.replace('{id}',id);
				tmpl=tmpl.replace('{i}',self.index);
				tmpl=tmpl.replace('{content}',content);
				self.index++;
				self.my_debug('tmpl',tmpl);
				return {id:id,tmpl:tmpl};
			};
			this.my_get_contentShow=function(obj){
				var tmpl=$("script.my_shortcode_html").html();
				var id='my_shortcode_'+self.options.key+'_'+self.index;
				var is=$("#"+id).length;
				if(is)return false;
				self.my_debug("Is",is);
				var content;
				content=self.options.my_show_html;//$("script.my_shortcode_html_default").text();
				content=content.replace(/\{title\}/g,self.options.msgs.html);
				tmpl=tmpl.replace('{id}',id);
				tmpl=tmpl.replace('{i}',self.index);
				tmpl=tmpl.replace('{content}',content);
				self.index++;
				self.my_debug('tmpl',tmpl);
				return {id:id,tmpl:tmpl};
			}
			this.my_clone_object=function(content){
				var tmpl=$("script.my_shortcode_html").html();
				var id='my_shortcode_'+self.options.key+'_'+self.index;
				var is=$("#"+id).length;
				if(is)return false;
				self.my_debug("Is",is);
				//var content;
				//content=$("script.my_shortcode_html_default").text();
				tmpl=tmpl.replace('{id}',id);
				tmpl=tmpl.replace('{i}',self.index);
				tmpl=tmpl.replace('{content}',content);
				self.index++;
				self.my_debug('tmpl',tmpl);
				return {id:id,tmpl:tmpl};
			};
			this.my_debug=function(t,o){
				if(self.debug){
					if(window.console){
						console.log('Visual builder Main \n'+t,o);
					}
				}
			};
			this.init();

	};
	})(jQuery);
