<?php
if(!defined('ABSPATH'))die('');
$msgs=array(
	'saving'=>__("Saving","my_support_theme"),
	'saving_style'=>__("Saving Style","my_support_theme"),
	'saving_shortcode'=>__("Saving Shortcode","my_support_theme"),
	'select_style'=>__("Select Style","my_support_theme"),
	'load_style'=>__("Loading Style","my_support_theme"),	
	'loading_preview'=>__("Loading Preview","my_support_theme"),
	'title_is_required'=>__("Please add shortcode title","my_support_theme"),
			
	'style_title_required'=>__("Style Title is Required","my_support_theme"),		
);
return $msgs;