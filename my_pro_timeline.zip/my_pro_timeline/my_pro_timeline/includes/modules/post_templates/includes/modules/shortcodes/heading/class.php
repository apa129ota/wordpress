<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Module_Shortcodes_Heading')){
	class Class_My_Module_Shortcodes_Heading extends Class_My_Module_Shortcodes_General{
		protected $formHtml='';
	    function Class_My_Module_Shortcodes_Heading($options=array()){
			parent::Class_My_Module_Shortcodes_General($options);
			$this->renderForm();
		}
		public function display_element(){
		  // $this->renderForm();
		   $formHtml=$this->formHtml;
		    $dir=$this->module_dir.'heading/views/display.php';
		    require $dir;

		}

		public function renderForm(){
		    $my_set_debug=0;
		    $file=$this->module_dir.'heading/options.php';
		    $options=require $file;
		    $elements=$options['form'];
		    $options=array(
		        'id'=>'heading_form',
		        'elements'=>$elements,
		        'hidden'=>array(

		        ),
		        'element_template'=>'my_li.php',
		        'form_template'=>'my_form.php',
		        'my_debug'=>$my_set_debug
		    );
		    $form_class=new Class_Wp_My_Module_New_Form($options);
		    ob_start();
		    $form_class->render_form();
		    $this->formHtml=ob_get_clean();
		}
		public function display_content(){
		    ?>
					<script type="text/html" class="my_shortcode_heading">
						<div class="my_shortcode_<?php echo $this->key;?> " id="{id}" data-id="{object_id}" data-i="{i}" data-sel="{sel}">
						{content}
						</div>
					</script>

					<?php
				}
	}
}