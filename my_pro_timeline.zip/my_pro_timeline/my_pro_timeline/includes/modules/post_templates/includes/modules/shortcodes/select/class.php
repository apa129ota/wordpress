<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Module_Shortcodes_Select')){
	class Class_My_Module_Shortcodes_Select extends Class_My_Module_Shortcodes_General{
		private $shortcodes;
		protected $noDispalyCats=true;
		function Class_My_Module_Shortcodes_Select($options=array()){
			parent::Class_My_Module_Shortcodes_General($options);
			//echo $this->module_dir;
			$file=$this->module_dir.'info.php';
			$this->shortcodes=require $file;

		}
		public function display_element(){
			//$layouts=$this->options['layouts'];
			$sh=$this->shortcodes;
			if($this->noDispalyCats){
			    foreach ($sh as $key=>$val){
			        if(!empty($val['group'])){
			            $group=$val['group'];
			            if(!isset($arr[$group]['elements'])){
			                $arr[$group]['elements']=array();
			            }
			            $arr[$group]['elements'][$key]=$val;
			        }
			    }
			    $file=plugin_dir_path(__FILE__).'views/display_only.php';
			    require $file;
			}else {
			$arr=array(
				/*'post_values'=>array(
						'title'=>__("Post values","my_support_theme")
						),
				'post_meta'=>array(
						'title'=>__("Post meta","my_support_theme"),
						),
						*/
				'content'=>array(
						'title'=>__("Predefined shortcodes","my_support_theme"),
				)
			);

			foreach ($sh as $key=>$val){
				if(!empty($val['group'])){
					$group=$val['group'];
					if(!isset($arr[$group]['elements'])){
						$arr[$group]['elements']=array();
					}
					$arr[$group]['elements'][$key]=$val;
				}
				if($this->debug){
					Class_My_Module_Debug::add_section('shortcodes_arr', $arr,'shortcodes',false);
				}
			}
			$file=plugin_dir_path(__FILE__).'views/display.php';
			require $file;
			}
		}
		function display_content(){

		}
	}
}
