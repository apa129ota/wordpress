<?php
if(!defined('ABSPATH'))die('');
if(!isset($id)){
$id=100000010;
}
require $views_dir.'card.php';
unset($id);