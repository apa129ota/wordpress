<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Shortcodes_Backend_Ajax_Controller')){
	class Class_My_Shortcodes_Backend_Ajax_Controller extends Class_My_General_Controller{
		
	}
}