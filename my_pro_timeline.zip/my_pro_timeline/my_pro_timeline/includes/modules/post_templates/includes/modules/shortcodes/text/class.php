<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Module_Shortcodes_Text')){
	class Class_My_Module_Shortcodes_Text extends Class_My_Module_Shortcodes_General{
		function Class_My_Module_Shortcodes_Text($options=array()){
			parent::Class_My_Module_Shortcodes_General($options);
		}
		public function display_element(){
			
		}
		public function display_content(){
			
		}
	}
}