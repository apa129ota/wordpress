(function($) {
	myVusualBuilderShortcodesHeading=function(o){
		var self;
		this.my_working=false;
		this.debug=true;
		this.options=o;
		this.dialog='';
		this.tmpl='';
		this.index=1;
		this.content='';
		this.objects={};
		this.dragg=false;
		this.width_px=400;
		this.added_layouts=false;
		this.type='media';
		this.media_obj='';
		this.media_id='';
		this.preload=0;
		this.media_thumb='';
		this.media_sub_type;
		this.media_url='';
		this.objects={};
		this.edit=false;
		this.edit_id='';
		this.type='h1';
		this.pre_options={
				content_class:".my_post_template",
				row_class:".my_shortcode_row_row",
				item_class:".my_shortcode_item",
				actions_class:".my_shortcode_row_actions_div",
				row_class:".my_shortcode_row_row",
				my_show_html:'<div class="my_video_container"><div class="my_table_cell_1"><div class="my_table_cell"><span class="my_video_title">{title}</span><i class="fa fa-video-camera"></i></div></div></div>',
				dw:800,
				dh:400,
				diff:20,
				w:16,
				h:9,
				html_youtube:'<iframe width="100%" height="56.25%" src="https://www.youtube.com/embed/{id}"></iframe>'
			};
			self=this;
			this.init=function(o){
				if(typeof self.options.debug!='undefined'){
					if(!self.options.debug){
						self.debug=false;
					}
				}
				self.debug=true;
				self.options=$.extend( self.pre_options,self.options);

				self.my_debug("options", self.options);
				$('body').on('my_init_form',function(e,id){
					self.my_debug('Iniot form',id);
				if(id=='heading_form'){
					var o={
						key:self.options.key,
						debug:self.debug,
						dw:self.options.dw,
						dh:self.options.dh,
						diff:self.options.diff
					};
					self.dialog=new myVusualBuilderDialog(o);
					$("#type_heading_form_id_div").on('my_change',function(e,obj,val,v1){
						$(".my_choosed_video div").hide();
						self.type=val;
					});


				}});

				$(document).on('click',".my_heading_action",self.my_add_heading);
			},

			this.my_add_heading=function(){
				var type=self.type;
				var div_id="my_added_object_"+myVusualBuilderMain_inst.my_add_id+"_"+myVusualBuilderMain_inst.index;

				//self.myAddVideo(html);
				var tmpl=$("script.my_shortcode_heading").html();
				var id='my_shortcode_'+self.options.key+'_'+self.index;
				if(self.edit_id!=''){
					id=self.edit_id;
				}
				//if($("#"+id).length>0)return;
				var content=self.my_get_content();
				var html='<'+self.type+'>'+content+'</'+self.type+'>';
				tmpl=tmpl.replace('{id}',id);
				tmpl=tmpl.replace('{i}',self.index);
				tmpl=tmpl.replace('{content}',html);
				tmpl=tmpl.replace('{sel}',self.type);
				var objectVideo={};
				objectVideo.div_id=div_id;

				objectVideo.text=content;
				objectVideo.type=self.type;
				objectVideo.font_size=self.my_get_font_size();
				objectVideo.line_height=self.my_get_line_height();
				self.objects[id]=objectVideo;
				if($("#"+id).length==0)self.index++;
				else {
					$("#"+id).html(html);
					myAdminTemplatesBuilderAdmin_inst.my_post_sel=' '+objectVideo.type;
					myAdminTemplatesBuilderAdmin_inst.setEditIdOptions({font_size:objectVideo.font_size,line_height:objectVideo.line_height});
				}
				if($("#"+id).length==0){
					self.my_debug('tmpl',tmpl);
					var oTmpl={id:id,tmpl:tmpl};
					myAdminTemplatesBuilderAdmin_inst.my_post_sel=' '+self.type;

					myVusualBuilderShortcodesSelect_inst.my_add_shortcode('heading','',oTmpl,{color:"#000000,1",font_size:objectVideo.font_size,line_height:objectVideo.line_height});
				}

				self.dialog.my_close();
			};
			this.my_clone_object=function(content,id){
				var id1=myVusualBuilderMain_inst.my_edit_id;
				self.my_debug('Clone object',{id:id,id1:id1});
				if(typeof self.objects[id]!='undefined'){
					var obj=self.objects[id];
					var newObj={};
					$.each(obj,function(i,v){
						newObj[i]=v;
					});
					var newId='my_shortcode_'+self.options.key+'_'+self.index;

					self.my_debug("Objects",{obj:obj,newObj:newObj});
					var div_id="my_added_object_"+myVusualBuilderMain_inst.my_add_id+"_"+myVusualBuilderMain_inst.index;
					newObj.div_id=div_id;
					//self.myAddVideo(html);
					var tmpl=$("script.my_shortcode_heading").html();
					var id='my_shortcode_'+self.options.key+'_'+self.index;
					self.objects[newId]=newObj;
					//if($("#"+id).length>0)return;
					var html=content;//'<'+self.type+'>'+content+'</'+self.type+'>';
					tmpl=tmpl.replace('{id}',id);
					tmpl=tmpl.replace('{i}',self.index);
					tmpl=tmpl.replace('{content}',html);
					tmpl=tmpl.replace('{sel}',newObj.type);
					var oTmpl={id:id,tmpl:tmpl};
					return oTmpl;

				}else self.my_debug('Undefined object');

			};
			this.my_get_font_size=function(){
				return $("#font_size_heading_form_id_div").data('my-script').get_value();
			};
			this.my_get_line_height=function(){
				return $("#line_height_heading_form_id_div").data('my-script').get_value();
			};
			this.my_get_content=function(){
				return $("#text_heading_form_id").val();
			};
			this.my_show_form=function(id){
				var obj=self.objects[id];
				$("#font_size_heading_form_id_div").data('my-script').set_value(obj.font_size);
				$("#line_height_heading_form_id_div").data('my-script').set_value(obj.line_height);
				$("text_heading_form_id").val(obj.text);
				$("#type_heading_form_id_div").data('my-script').set_value(obj.type);
			}
			this.my_edit=function(content,id){
				self.edit_id=id;
				self.my_show_form(id);
				self.dialog.my_open();
				return false;
			};
			this.my_show=function(e){
					self.edit_id='';
					self.dialog.my_open();
					//self.my_show_form();
					return false;

			}

			this.my_debug=function(t,o){
				if(self.debug){
					if(window.console){
						console.log('Visual builder Main Video\n'+t,o);
					}
				}
			};
			this.init();

	};
	})(jQuery);