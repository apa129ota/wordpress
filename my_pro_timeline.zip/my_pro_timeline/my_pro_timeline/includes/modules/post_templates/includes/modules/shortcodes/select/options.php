<?php
if(!defined('ABSPATH'))die('');
$arr=array(
	'post'=>array(
			
		'post_title'=>array(
			'title'=>__("Post Title","my_support_theme"),	
			'options'=>array(
					'font_size','line_height','color','hover_color','a','align'
			)
		)
	)			
);
return $arr;