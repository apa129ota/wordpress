<?php
if (! defined ( 'ABSPATH' ))
    die ( '' );
