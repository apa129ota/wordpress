(function($) { 
	myVusualBuilderShortcodesTemplate=function(o){
		var self;
		this.my_working=false;
		this.debug=true;
		this.options=o;
		this.show=false;
		this.dialog='';
		this.pre_options={
			dw:600,
			dh:400,
			diff:20
		};
		self=this;
		this.init=function(o){
			if(typeof self.options.debug!='undefined'){
				if(!self.options.debug){
					self.debug=false;
				}
			}
			self.options=$.extend( self.pre_options,self.options);
			
			self.my_debug("options", self.options);
			var o={
					key:self.options.key,
					debug:self.debug,
					dw:self.options.dw,
					dh:self.options.dh,
					diff:self.options.diff
				};
				self.dialog=new myVusualBuilderDialog(o);
		};
		this.my_show=function(){
			self.dialog.my_open();
			};
		
		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log('Visual builder '+self.options.key+' \n'+t,o);
				}
			}
		};
		this.init();
		
};
})(jQuery);		