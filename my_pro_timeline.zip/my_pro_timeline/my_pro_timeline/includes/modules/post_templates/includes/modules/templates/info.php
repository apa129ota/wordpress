<?php
if(!defined('ABSPATH'))die('');
$info=array(
		'title'=>'Post_Templates_Temmplates',
		'description'=>'Module for automatic generation for post templates with wisywig editor',
		'class'=>'Class_My_Module_Post_Templates',
		
);
return $info;