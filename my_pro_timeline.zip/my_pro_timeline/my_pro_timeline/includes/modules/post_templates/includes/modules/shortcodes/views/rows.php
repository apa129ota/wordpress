<?php
if(!defined('ABSPATH'))die('');
$shortcodes_content=array(
	array(
		'columns'=>array(	
		array(
			'width'=>25	
		),
			array(
					'width'=>50
			),
			array(
					'width'=>25
			),
		)	
	)
)
?>
<div class="my_shortcodes_content">
<?php if(!empty($shortcodes_content)){
Class_My_Module_Shortcodes_Row::display_rows($shortcodes_content,true);
}?>
</div>
<div class="my_shortcode_rows my_action" data-key="add_rows">
	<h4><i class="fa fa-plus"></i>&nbsp;&nbsp;<?php echo __("Add new row","my_support_theme")?></h4>
</div>