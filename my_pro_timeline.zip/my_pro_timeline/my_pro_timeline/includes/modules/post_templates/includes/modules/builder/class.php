<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Module_Post_Templates_Builder')){
    class Class_My_Module_Post_Templates_Builder extends Class_My_General_Module{
        use MySingleton;
        protected $custom=false;
        protected $dialog=true;
        protected $templates=array();
        protected $modal=true;
        protected $w=400;
        protected $h=400;
        protected $options_form='';
        protected $template_vars_html='';
        protected $is_module=true;
        protected $use_slider=true;
        protected $shortcodeModule;
        protected $shortcodeOptions=array();
        protected $defaultShortcodeOptions=array();
        protected $shortcodeSelectHtml;
        protected $tmpl="";
        protected $ajax_action='my_module_post_templates';
        protected $customTemplates=array();
        protected $renderTemplate="";
        protected $genCssClass='';
        protected $all;
        protected $stylesCss=array();
        protected $templateFormElements=array();
        protected $advancedEditor=0;
        protected $isExternalRender=true;
        function __construct($options=array()){
            if(!empty($_GET['page'])){
                $page=$_GET['page'];
            }else $page='';
            if(empty($page))$this->page_url='';
            else $this->page_url=admin_url('admin.php?page='.$page);
            $options['url']=plugin_dir_url(__FILE__);
            $options['dir']=plugin_dir_path(__FILE__);
            parent::__construct($options);
        }
        /**
         * Init builder class
         * {@inheritDoc}
         * @see Class_My_General_Module::init()
         */
        function init($options=array()){
            if(is_admin()){
                $this->is_admin=true;
                if(!empty($_GET['my_tmpl'])){
                    $this->tmpl=$_GET['my_tmpl'];
                }
                    
            }
        }
        protected function setExternalRender(){
            $this->isExternalRender=true;
        }
        protected function loadTemplates(){
            if($this->custom){
                
                $fDir=$this->parent_module->getDir('functions');
                $fDir.='functions.php';
                require_once $fDir;
                if(!empty($this->templates)){
                    $def=$this->parent_module->loadOptions('post_custom_models.php');
                    
                    $this->templateFormElements=$this->parent_module->loadOptions('custom_templates/general_form.php');
                    $this->customTemplates=array('definedTemplates'=>array(),'templates'=>array(),'defaults'=>$def);
                    foreach($this->templates as $key=>$val){
                        $this->customTemplates['definedTemplates'][$key]['title']=$this->templates[$key]['title'];
                        $this->customTemplates['templates'][$key]=$val;
                    }
                }else {
                $def=$this->parent_module->loadOptions('post_custom_models.php');
                $info=$this->parent_module->loadOptions('custom_templates/info.php');
                $this->customTemplates=array('definedTemplates'=>array(),'templates'=>array(),'defaults'=>$def);
                $dir=$this->parent_module->getDir('options').'custom_templates/';
                $this->templateFormElements=$this->parent_module->loadOptions('custom_templates/general_form.php');
                if(!empty($info)){
                    foreach($info as $key=>$val){
                        $file=$dir.$key.'.php';
                        $this->customTemplates['definedTemplates'][$key]=$val;
                        if(file_exists($file)){
                            $t=require $file;
                            
                            foreach($t as $k1=>$v1){
                                $this->customTemplates['templates'] [$key][$k1]=$v1;
                            }
                        }
                    }
                }
                }
                if(!empty($this->tmpl)){
                self::debug("customtemplates", $this->customTemplates);
                $cssProperties=$this->parent_module->loadOptions('css_properties.php');
                $values=$this->customTemplates['templates'][$this->tmpl]['post_tags'];
                $temlateValues=array();
                //wp_my_post_templates_adjust_array($values, $temlateValues);
                //wp_my_post_templates_filter_vars($temlateValues);
                $values=$temlateValues;
                self::debug("my_template", $values);
                //$css=wp_my_post_templates_gen_css($this->tmpl, $this->customTemplates['templates']);
                $this->parent_module->loadClass('class-my-generate-css.php');
                $modOp=array(
                    'debug'=>$this->debug,
                    'tmpl'=>$this->tmpl,
                    'cssRules'=>$this->customTemplates['templates'][$this->tmpl],
                    'cssKeys'=>$cssProperties['added']
                );
                $this->genCssClass=new Class_My_Module_Post_Templates_Generate_Css($modOp);
                $defaultCss=$this->genCssClass->getCss();
                $ChildStyles=$this->genCssClass->getCssStyles();
                self::debug("childStylesPre", $ChildStyles);
                foreach($ChildStyles as $kS=>$vS){
                     $this->stylesCss[$kS]=$vS;
                     if($kS=='default'){
                         $this->stylesCss[$kS]['css']=$defaultCss;
                     }else $this->stylesCss[$kS]['css']=$vS['css'];
                }
                self::debug("childStyles", $this->stylesCss);
                
                }
            }//else 
            if(empty($templates)){
                $this->templates=$this->parent_module->loadOptions('templates.php');
               // unset($this->templates['sections']['elements']['slider']);
                $templatesAdd=$this->loadOptions('templates.php');
                
                if(!empty($templatesAdd)){
                    foreach($this->templates['predefined'] as $key=>$val){
                        if(!empty($templatesAdd[$key])){
                            foreach($templatesAdd[$key] as $key1=>$val1){
                                $this->templates['predefined'][$key][$key1]=$val1;
                            }
                        }
                    }
                }
            }

            if(!empty($this->templates['predefined']['text']['font_family'])){
                $moduleGoogledir=$this->global_plugin->getDir('modules').'google_font/includes/functions.php';
                //wp_my_general_load_module_function(MY_TESTIMONIALS_LOCAL_MODULES_DIRNAME,'google_font','functions.php');
                //global $wp_my_google_fonts_fonts;
                require $moduleGoogledir;
                $wp_my_google_fonts_fonts=wp_my_google_fonts_get_fonts_arr();
                $this->templates['predefined']['text']['font_family']['values']=$wp_my_google_fonts_fonts;
            }
        }
        public function setAdminIncludes(){
           $my_set_debug=0;
           if(class_exists('Class_My_Framework_Scripts_Class')){
               Class_My_Framework_Scripts_Class::addIncludes('fontawesome');
           }
           //require icons module
           $dirI=$this->global_plugin->getDir('modules').'icons/includes/functions/functions.php';
           require_once $dirI;
           if($this->debug){
               $my_set_debug=1;
           }
           if($this->custom){
               //$this->tmpl='template_custom_new';
           }
           $modulesDir=$this->global_plugin->getDir('modules');
           $s_options=array(
                'debug'=>$my_set_debug,
                'custom'=>$this->custom,
                'my_show'=>0,
                'global_modules'=>$modulesDir
            );
            $this->parent_module->loadModuleClass('shortcodes');
            //$s_options=$this->shortcodeOptions;

            /*
            $this->shortcodeModule=new Class_My_Module_Shortcodes_Main($s_options);
            $this->shortcodeModule->init();
            $this->shortcodeSelectHtml=$this->shortcodeModule->renderShortcodesSelectHtml();
            */
            //if(empty($this->templates)){
                $this->loadTemplates();
            //}
            if($this->use_slider){
                $this->sliderStyles=$this->parent_module->loadOptions('slider_styles.php');
            }
           // if($this->dialog){
                $this->rendeOptionsForm();
            //}
            $this->renderCssStyleForm();

            if($this->is_admin){
                add_action('admin_head', array($this,'head'),PHP_INT_MAX);
                add_action('admin_enqueue_scripts',array($this,'scripts'),PHP_INT_MAX);
                add_action('admin_footer',array($this,'footer'),PHP_INT_MAX);

            }else {

            }
        }
        public function footer(){
            if($this->custom){
                $view=$this->parent_module->getDir('views');
                //$tmpl1=$view.'new.php';
                $tmpl2=$view.'save.php';
                //require $tmpl1;
                //require $tmpl2;
                //$tmpl=$this->tmpl;
                $tmp=$this->tmpl;
                $tmpl3=$view.'templates/share_popup.php';
                require $tmpl3;
                if(!empty($this->stylesCss)){
                    ?>
                    <div class="my_<?php $this->tmpl;?>_generated_styles" style="display:none">
                    <?php 
                    foreach($this->stylesCss as $key=>$val){
                        ?>
                        <div class="my_<?php echo $this->tmpl;?>_style_<?php echo $key;?>">
                        	<?php echo $val['css'];?>
                        </div>
                        <?php 
                    }
                    ?>
                    </div>
                    <?php 
                }
            }
            return;
            if($this->dialog){
                $shortcodeSelectHtml=$this->shortcodeSelectHtml;
                $template_form=$this->template_vars_html;
                $shortcodes_html=$this->options_form;
                $viewsDir=$this->getDir('views').'admin/modal_dialog.php';
                require $viewsDir;
            }else {
                $template_form=$this->template_vars_html;
                $viewsDir=$this->getDir('views').'admin/template_form.php';
                require $viewsDir;

            }

        }
        public function getBuilderForm(){
            if(!empty($this->tmpl)&&$this->custom){
               // echo $this->tmpl;
                if($this->isExternalRender){
                    $ex=explode("_",$this->tmpl);
                    $network=$ex[0];
                    $tmpl=$ex[1];
                    $social=$this->global_plugin->getModule('social');
                    $renderTemplate=$social->renderTemplate($network,$tmpl);
                    
                }else {
                    $this->parent_module->loadClass('class-my-custom-templates-class.php');
                    Class_My_Module_Post_Templates_Class_Custom_Templates::$templates=$this->customTemplates;
                    Class_My_Module_Post_Templates_Class_Custom_Templates::$imagesUrl=$this->parent_module->getUrl('images');
                    $renderTemplate=Class_My_Module_Post_Templates_Class_Custom_Templates::renderCustomTemplate($this->tmpl,$this->customTemplates);
                }
            }
            ob_start();
            $template_form=$this->template_vars_html;
            $viewsDir=$this->getDir('views').'admin/template_form.php';
            require $viewsDir;
            $stylesFormHtml=ob_get_clean();
            ob_start();
            $shortcodeSelectHtml=$this->shortcodeSelectHtml;
            $template_form=$this->template_vars_html;
            $shortcodes_html=$this->options_form;
            $viewsDir=$this->getDir('views').'admin/page.php';
            require $viewsDir;
            $html=ob_get_clean();
            return $html;
        }
        public function scripts(){
            wp_enqueue_script('jquery');
            wp_enqueue_script("jquery-touch-pounch");
            wp_enqueue_script('jquery-ui-core');
            wp_enqueue_script("jquery-ui-widget");
            wp_enqueue_script("jquery-ui-dialog");
            wp_enqueue_script('jquery-effects-core');
            wp_enqueue_script("jquery-ui-tooltip");
            wp_enqueue_script("jquery-ui-resizable");
            wp_enqueue_script("jquery-ui-draggable");
            wp_enqueue_script("jquery-ui-droppable");
            wp_enqueue_script('jquery-ui-core');
            //wp_enqueue_script('jquery-effects-core');
            wp_enqueue_script('jquery-effects-scale');
            wp_enqueue_script('jquery-effects-slide');
           // wp_enqueue_script("jquery-ui-dialog");

            wp_enqueue_media();
            $url=$this->global_plugin->getUrl('jscript').'admin/my_ajax.js';
            wp_enqueue_script('my_framework_ajax',$url);
            $url=$this->global_plugin->getUrl('jscript').'admin/admin_msgs.js';
            wp_enqueue_script("my_framework_msgs",$url);

            $url=$this->global_plugin->getUrl('css').'msgs.css';
            wp_enqueue_style("my_testimonials_msgs_form",$url);
            $url=$this->getUrl('jscript');
            //change to new script
            wp_enqueue_script('my_builder_admin_js',$url.'my_admin.js');
            wp_enqueue_script('my_builder_new_admin_js',$url.'myBuilderNew.js');
            
            wp_enqueue_script('my_effects_script',$this->parent_module->getUrl('jscript').'myEffects.js');
            wp_enqueue_script('my_front',$this->parent_module->getUrl('jscript').'front.js');
           // wp_enqueue_style('my_general_parent',$this->parent_module->getUrl('css').'general.css');
            
          //  wp_enqueue_script('my_mapper_front_js',$url.'front.js');

            $css_url=$this->parent_module->getUrl('css');
            wp_enqueue_style('my_framework_templates_admin_css',$css_url.'admin.css');
            wp_enqueue_style('my_framework_templates_general_css',$css_url.'general.css');
            $dialog_jscript=$this->global_plugin->getUrl('jscript').'admin/myUiDialog.js';
            $dialog_jscript=$this->global_plugin->getUrl('jscript').'admin/my_dialog.js';
            wp_enqueue_script('myDialog',$dialog_jscript);
            wp_enqueue_script('myUiDialog',$dialog_jscript);
            if($this->use_slider){
                $url=$this->parent_module->getUrl('jscript');


                wp_enqueue_script('my_framework_slider_admin',$url.'my_adminSlider.js');
                wp_enqueue_script('my_framework_proslider_slider_js',$url.'myProSlider.js');
                wp_enqueue_style('my_framework_slider_general_css',$css_url.'slider/general.css');
                wp_enqueue_style('my_framework_slider_card_css',$css_url.'slider/card.css');
                if(empty($this->sliderCss)){
                    //wp_enqueue_style('my_framework_slider_card_css',$css_url.'slider/card.css');

                }
            }

        }
        public function head(){
            $my_set_debug=1;

            if(!$this->debug){
                $my_set_debug=0;
            }
            $my_set_debug=0;

            $msgs=$this->loadOptions('admin_msgs.php');
            $options=$this->global_plugin->loadOptions("ajax_options.php");
            $values=array();
            $css='';
            if(!empty($_GET['my_adv'])){
                $this->advancedEditor=1;
            }
            if(!empty($this->tmpl)){
                
               // echo $fDir;
                //require_once $fDir;
                if($this->custom){
                   
                  $css=$this->stylesCss['default']['css'];
                  
                    
                }else {
                    $values=$this->templates['template_1']['post_tags'];
                    wp_my_post_templates_filter_vars($values);
                    $css=wp_my_post_templates_gen_css($this->tmpl, $this->templates,'template_1');
                }
                /*preg_match_all($css,'/([^\{]+)\{([^\}]*)\})/ims',$matches);
                 self::debug("tmpl_matches", $matches);

                 foreach($matches[1] as $k=>$v){
                 $css1[$v]=$matches[2][$k];
                 }*/
            }
            self::debug("tmpl", $this->tmpl);
            self::debug("tmpl_values", $values);
            self::debug("tmpl_css", $css);
            if(!empty($this->tmpl)){
                $cssRules=$this->genCssClass->getAllCssRules();
            }else {
                $cssRules=array();
                $values=array();
            }
            ?>
            			<style type="text/css" id="my_css_tmpl_<?php echo $this->tmpl;?>">
            				<?php echo $css;?>
            			</style>
            <script type="text/javascript">
			//Visual builder output
			<?php //$values['predefined_classes']=$values['predefined_classes']?>
			jQuery(document).ready(function($){
				var oBuilder={};
				oBuilder.rules={};
				var myAdminTemplatesBuilderAdmin_inst=new myAdminTemplatesBuilderAdmin(oBuilder);
				var o_ajax=<?php echo json_encode($options);?>;
				var myGlobalAjaxClass_inst=new myGlobalAjaxClass(o_ajax);
				var o3={};
				var myAdminMsgs_inst=new myAdminMsgs(o3);

				var o1={};

				o1.my_debug=<?php echo $my_set_debug;?>;
				o1.animation='fade';
				o1.duration=300;
				myAdminDialog_inst=new myDialog(o1);

				var o4={};
				o4.ajax_action="<?php echo $this->ajax_action;?>";
				o4.my_debug=<?php echo $my_set_debug;?>;
				o4.msgs=<?php echo json_encode($msgs);?>;
				o4.admin_page="<?php echo $this->page_url;?>";
				o4.post=<?php echo  json_encode($this->post);?>;
				o4.rules=<?php echo json_encode($values);?>;
				o4.cssRules=<?php echo json_encode($cssRules);?>;
				o4.tmplStyle="default";
				o4.tmpl="<?php echo $this->tmpl;?>";
				o4.sections=<?php echo json_encode($this->templates['sections']['elements'])?>;
				o4.use_slider=<?php if($this->use_slider)echo '1';else echo '0';?>;
				o4.custom=<?php if($this->custom)echo '1';else echo '0';?>;
				o4.advancedEditor=<?php echo $this->advancedEditor;?>;	
			<?php if(!empty($this->customTemplates['templates'][$this->tmpl]['groups'])){ ?>
				o4.cssGroups=<?php echo json_encode($this->customTemplates['templates'][$this->tmpl]['groups']);?>;
				<?php }else {?>
				o4.cssGroups="";
				<?php }?>
				myAdminTemplatesBuilder_inst=new myAdminTemplatesBuilder(o4);
				<?php
				if($this->use_slider){
				    $styles=$this->sliderStyles;
				    $translate=array();
				    foreach ($styles['default'] as $k=>$v){
				        if(isset($v['translate']))
				            $translate[$k]=$v['translate'];
				    }
				?>

							var osl={};
							osl.translate=<?php echo json_encode($translate);?>;
							osl.my_debug=<?php echo $my_set_debug;?>;
							osl.msgs=<?php echo json_encode($msgs);?>;
							osl.styles=<?php echo json_encode($styles['styles'])?>;

							osl.is_id='0';
							var myAdminTestimonialsFrontAdmin_inst=new myAdminTestimonialsFrontAdmin(osl);
				<?php
				}
				?>
			});
			</script>
            <?php

        }
        protected function renderCssStyleForm(){
           // $tmpl='template_custom_new';
            $sections=$this->templates['sections'];
            $this->icons=wp_my_module_icons_get_icons();
            $this->templates['predefined']['list']['list_icon']['values']=$this->icons;
            foreach($sections['elements']['sections'] as $k=>$v){
                $this->templates['sections']['elements']['sections'][$k]['elements']=array();
                if($k=='slider'){
                    if($this->use_slider){
                        $arr=$this->sliderStyles['shortcodes']['thumb_slider']['styles'];
                        //  print_r($arr);
                        $elementsSlider=array();
                        foreach($arr as $keyS=>$valS){
                            $elementsSlider[$valS]=$this->sliderStyles['default'][$valS];

                        }
                        $valuesSlider=$this->sliderStyles['styles']['light'];
                        foreach($valuesSlider as $keyV=>$valV){
                            if(isset($elementsSlider[$keyV])){
                                $val=$valV;
                                if($elementsSlider[$keyV]['type']=='jscript_color_picker'){
                                    if($elementsSlider[$keyV]['transparency']){
                                        $ex=explode(",",$valV);
                                        $val=array(
                                            'color'=>$ex[0],
                                            'transp'=>$ex[1]
                                        );
                                    }

                                }
                                $elementsSlider[$keyV]['value']=$val;
                            }
                        }
                        if(!empty($this->tmplID)){
                            //if(!empty())
                        }
                        $this->templates['sections']['elements']['sections'][$k]['elements']=$elementsSlider;
                    }
                }else {
                    $this->templates['sections']['elements']['sections'][$k]['elements']=$this->templates['predefined'][$k];
                }
                self::debug("add_elements", $this->templates['predefined'][$k]);
            }
            
            self::debug("template_vars",$this->templates[$this->tmpl]);
            $options=array(
                'id'=>'template_vars',
                'elements'=>$this->templates['sections']['elements'],
                'hidden'=>array(
                    'my_nonce'=>wp_create_nonce('my-templates'),
                    'id'=>''
                ),
                'element_template'=>'my_li.php',
                'form_template'=>'my_form.php',
                'my_debug'=>0
            );
            self::debug("templates", $this->templates['sections']['elements']);
            $form_class=new Class_Wp_My_Module_New_Form($options);
            ob_start();
            $form_class->render_form();
            $this->template_vars_html=ob_get_clean();
            

        }
        protected function rendeOptionsForm(){
            $w=$this->w;$h=$this->h;

            $elements=$this->templates['form'];
            $elements['width']['value']=$w;
            $elements['height']['value']=$h;
            $elements['post_type']['values']['custom']=__("Custom Template","my_support_theme");
            /*if($this->custom){
                //unset($elements['post_type']);
                //unset($elements['use_slider']);

                $elements['post_type']['value']='custom';
            }*/
            if(!$this->custom){
                unset($elements['template']);
                unset($elements['use_slider']);
                
            }else {
                unset($elements['use_slider']);
                
                unset($elements['post_type']);
                unset($elements['template']['values']);
                $elements['template']['values']=array();
                $elements['template']['values']['']=__("New Empty Template","my_support_theme");
                $elements['tmpl_styles']=array(
                    'layout_class'=>'my_col_50',
                    'type'=>'jscript_dropdown',
                    'title'=>__("Template Styles","my_support_theme"),
                    'tooltip'=>__("Template Styles","my_support_theme"),
                    'jscript'=>array(
                        'max_c'=>1,
                        'max_sel'=>__("Maximum elements are selected","my_support_theme"),
                        'duration'=>500,
                        'animation'=>'fadein',
                        'choose_value'=>__("Plese Select value","my_support_theme"),
                    ),
                    'show_filter'=>0,
                    'multiple'=>false,
                    'choose_value'=>__("Plese Select value","my_support_theme"),
                    'default'=>'default',
                    'values'=>array(
                    ));
                foreach($this->stylesCss as $key=>$val)
                {
                    $elements['tmpl_styles']['values'][$key]=$val['title'];
                }
                    
                foreach ($this->customTemplates['definedTemplates'] as $key=>$val){
                    
                    $elements['template']['values'][$key]=$val['title'];
                }
                $elements['template']['value']=$this->tmpl;
                if(!empty($this->customTemplates['templates'][$this->tmpl]['template_form'])){
                    foreach ($this->customTemplates['templates'][$this->tmpl]['template_form'] as $k123=>$v123){
                        if(is_array($v123)){
                            $elements[$k123]=$v123;
                        }else {
                            $elements[$v123]=$this->templateFormElements[$v123];
                        }
                    }
                }
                $w=400;
                $h=400;
                if(!empty($this->customTemplates['templates'][$this->tmpl]['template']['w'])){
                    $w=$this->customTemplates['templates'][$this->tmpl]['template']['w'];
                }
                if($this->customTemplates['templates'][$this->tmpl]['template']['h']){
                    $h=$this->customTemplates['templates'][$this->tmpl]['template']['h'];
                }
                $elements['width']['value']=$w;
                $elements['height']['value']=$h;
                
            }
            if(!empty($_GET['my_type'])&&!$this->custom){
                $elements['post_type']['value']=@$_GET['my_type'];

            }else{
                if($this->custom){
                    $elements['post_type']['value']='custom';
                }
            }
            if(!empty($_GET['my_tmpl'])){
                $elements['template']['value']=$_GET['my_tmpl'];
                
            }
            if(!empty($_GET['my_slider'])){
                $elements['use_slider']['value']=1;
            }
            if(!empty($_GET['slider_templ'])){
                $elements['slider_template']['value']=$_GET['slider_templ'];
            }
            $t12='';
            if(!empty($this->tmplID)){
                $id=$this->tmplID;
                foreach($elements as $k=>$v){
                    $elements[$k]['value']=$this->tmplOptions['tmpl_arr'][$k];
                }
                $t12=$this->tmplOptions['title'];
            }

            if(!empty($elements['post_type'])){
                if(!empty($this->post_types)){
                    foreach($this->post_types as $k=>$v){
                        $name=$v;
                        if(is_object($v)){
                            $name=$v->label;
                        }
                        $elements['post_type']['values'][$k]=$name;
                    }
                }
            }
            $key='my_templates';
            $my_set_debug=$this->debug;
            $my_set_debug=0;
            $options=array(
                'id'=>$key,
                'elements'=>$elements,
                'hidden'=>array(
                    'my_nonce'=>wp_create_nonce('templates_form'),
                    'id'=>$id,
                    'title'=>$t12
                ),
                'element_template'=>'my_li.php',
                'form_template'=>'my_form.php',
                'my_debug'=>$my_set_debug
            );
            $form_class=new Class_Wp_My_Module_New_Form($options);
            ob_start();
            $form_class->render_form();
            $this->options_form=ob_get_clean();
            
        }
    }
}