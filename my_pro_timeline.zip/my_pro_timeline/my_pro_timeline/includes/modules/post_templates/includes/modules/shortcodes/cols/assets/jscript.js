(function($) { 
	myVusualBuilderShortcodesCols=function(o){
		var self;
		this.my_working=false;
		this.debug=true;
		this.options=o;
		this.dialog='';
		self=this;
		this.init=function(o){
			if(typeof self.options.debug!='undefined'){
				if(!self.options.debug){
					self.debug=false;
				}
			}
			self.my_debug("options", self.options);
			var o={
					key:self.options.key,
					debug:self.debug,
					dw:self.options.dw,
					dh:self.options.dh,
					diff:self.options.diff
				};
				self.dialog=new myVusualBuilderDialog(o);
		};
		this.my_show=function(){
			//$(self.my_class).dialog('open');
			self.dialog.my_open();
			return false;
		};
		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log('Visual builder Main \n'+t,o);
				}
			}
		};
		this.init();
		
};
})(jQuery);		