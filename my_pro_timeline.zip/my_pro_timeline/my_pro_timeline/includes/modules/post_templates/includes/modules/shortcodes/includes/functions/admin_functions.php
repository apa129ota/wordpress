<?php
if(!defined('ABSPATH'))die('');
global $wp_my_shortcodes_module_ajax_actions;
$wp_my_shortcodes_module_ajax_actions=array(
		'ajax_actions'=>array(
		//'controllers_dir'=>MY_VISUAL_CONTROLLERS_DIRNAME,
		'controller_name'=>'Class_My_Shortcodes_Backend_Ajax_Controller',
		'controller_file'=>'class-my-shortcodes-backend-ajax-controller.php',
		'action'=>'my_visual_plugin_ajax_admin',
		'only_logged'=>true,
		'actions'=>array(

		)
) );
function my_module_shortcodes_init_admin($options=array()){
	global $wp_my_module_shortcodes_options;
	global $wp_my_shortcodes_module_ajax_actions;
	$wp_my_module_shortcodes_options=$options;
	add_action('wp_ajax_my_module_shortcodes_admin_ajax','my_module_shortcodes_ajax');
	$my_set_debug=1;
	if(!$wp_my_module_shortcodes_options['debug']){
		$my_set_debug=0;
	}
	
	if($my_set_debug){
		Class_My_Module_Debug::add_section('shortcodes_action', $wp_my_module_shortcodes_options,'module_shortcodes',false);
		Class_My_Module_Debug::add_section('ajax_actions',$wp_my_shortcodes_module_ajax_actions,'ajax_actions',false);
		
	}
	
}
function my_module_shortcodes_ajax(){
	global $wp_my_module_shortcodes_options;
	$my_set_debug=1;
	if(!$wp_my_module_shortcodes_options['debug']){
		$my_set_debug=0;
	}
	$local_module_dir=$wp_my_module_shortcodes_options['local_module_dir'];
	$file=$local_module_dir.'shortcodes/controllers/class-my-shortcodes-module-backend-ajax.php';
	require $file;
	global $wp_my_shortcodes_module_ajax_actions;
	$options=$wp_my_shortcodes_module_ajax_actions;
	$options['debug']=$my_set_debug;
	$class=new Class_My_Shortcodes_Backend_Ajax_Controller($options);
}
