<?php
if(!defined('ABSPATH'))die('');
ob_start();
?>
<div class="my_header_dialog">
	<h4 class="my_no_margin">{dialog_title}</h4>
		<div class="my_timeline_modal_close_1">
			<i class="fa fa-close"></i>
		</div>
</div>
<?php 
$html=ob_get_clean();
return $html;