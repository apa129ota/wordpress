<?php
if(!defined('ABSPATH'))die('');

?>
<div id="my_testimonials_thumbs_<?php echo $id?>" class="my_testimonial_thumbs" data-count="<?php echo count($items);?>">
	<div id="my_thumb_left_<?php echo $id;?>" class="my_thumbs_nav my_thumbs_nav_left">
	
	</div>
	<div id="my_thumb_roight_<?php echo $id?>" class="my_thumbs_nav my_thumbs_nav_right">
	
	</div>
	
	<ul class="my_testimonial_thumbs_ul my_clear_after">
		<?php 
		$c=1;
		foreach($items as $key1=>$val1){
			$image=wp_my_front_testimonials_render_image($val1,$my_url);
			?>
			<li class="my_cols_8" data-i="<?php echo $c;?>" data-post-id="<?php ?>">
				<img class="my_testimonial_thumbs_thumb" src="<?php echo $image?>"/>
				<?php wp_my_front_testimonials_render_metadata($val1,$settings['thumbs_show'])?>	
			</li>
			<?php 
			$c++;
			
		}
		?>
	</ul>
</div>