<?php
if(!defined('ABSPATH'))die('');
$templatesAdd['box']=array(
    'overflow_y'=>array(
        'type'=>'jscript_dropdown',
        'value'=>'0',
        'title'=>__("Overflow Y","my_support_theme"),
        'tooltip'=>__("Set eleemnt overflow. If you want to limit height choose overflow hidden.","my_support_theme"),
        'default'=>'',
        'values'=>array(
            'hidden'=>__("Hidden","my_support_theme"),
            'scroll'=>__("Scroll","my_support_theme"),
            'auto'=>__("Auto","my_support_theme"),
        )
    )
);

return $templatesAdd;