<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Module_Shortcodes_Main')){
	class Class_My_Module_Shortcodes_Main{
		private $shortcodes=array();
		function Class_My_Module_Shortcodes_Main($options=array()){
			if (! empty ( $options )) {
				foreach ( $options as $k => $v ) {
					if(!isset($this->$k)){
						throw new Exception(__("Parameter ","my_support_theme").' '.$k.__("is not supported","my_support_theme"));
					}
					else $this->$k = $v;
				}
			}
			
		}
		public function init(){
			
		}
	}
}