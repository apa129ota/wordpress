<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Module_Shortcodes_List')){
	class Class_My_Module_Shortcodes_List extends Class_My_Module_Shortcodes_General{
        private $icons;
        private $formHtml;
		static $num=0;
		function Class_My_Module_Shortcodes_List($options=array()){
		    parent::Class_My_Module_Shortcodes_General($options);
		    $this->icons=wp_my_module_icons_get_icons();
			$this->renderForm();
			if($this->debug){
			    if(class_exists('Class_My_Module_Debug')){
			        Class_My_Module_Debug::add_section('shortcode_'.$this->key, $this->get_options(),$this->use_case,false);
			    }
			}
			
		}
		public function renderForm(){
		    $my_set_debug=0;
		    $file=$this->module_dir.'list/options.php';
		    $options=require $file;
		    $elements=$options['form'];
		    $elements['icons']['values']=$this->icons;
		    $options=array(
		        'id'=>'list_form',
		        'elements'=>$elements,
		        'hidden'=>array(

		        ),
		        'element_template'=>'my_li.php',
		        'form_template'=>'my_form.php',
		        'my_debug'=>$my_set_debug
		    );
		    $form_class=new Class_Wp_My_Module_New_Form($options);
		    ob_start();
		    $form_class->render_form();
		    $this->formHtml=ob_get_clean();
		}
		public function display_element(){
		    $this->render_buttons(array(
		        'my_shortcode_insert_list'=>array(
		            'title'=>__("Update/Insert Content","my_support_theme")
		        )
		    ));
		    echo '<div style="height:50px;"></div>';
		    ?>
		    		<div class="my_custom_template_new my_shortcode_list_preview">
		    		<h4><?php echo __("List Preview","my_support_theme")?></h4>
		                <ul class="my_shortcode_list_ul">

		                </ul>
		            </div>
		                <?php
			echo $this->formHtml;


			echo '<div style="clear:both"></div>';




		}
		public function display_content(){
			?>
			<script type="text/html" class="my_shortcode_list">
				<div class="my_shortcode_<?php echo $this->key;?> " id="{id}" data-id="{object_id}" data-i="{i}">
				  <ul class="my_shortcode_list_ul" id="{my_id}">
                    {content}
                  </ul>
				</div>
			</script>
			<script type="text/html" class="my_shortcode_html_default">
			<?php echo $this->lorem; ?>
			</script>
			<?php
		}

	}
}