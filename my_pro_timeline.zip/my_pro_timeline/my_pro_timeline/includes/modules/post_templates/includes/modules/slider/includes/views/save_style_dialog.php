<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_dialog_save_style">
	<div class="my_header_dialog">
		<h4 class="my_no_margin"><?php  echo __("Save Style","my_support_theme")?></h4>
			<div class="my_timeline_modal_close_1">
				<i class="fa fa-close"></i>
			</div>
	</div>
	<div class="my_dialog_form my_shortcode_content">
		<ul>
			<li>
			<label for="my_style_title"><?php echo __("Style Title","my_support_theme")?></label>
			</li>
			<li>
			<input type="text" name="my_style_title" id="my_style_title"/>
			</li>
			<li>
				<input class="button  button-large my_action" type="button" data-key="save_style" value="<?php  echo __("Save Style","my_support_theme") ?>"/>
				
			</li>
			
			
		</ul>
	</div>
	
</div>