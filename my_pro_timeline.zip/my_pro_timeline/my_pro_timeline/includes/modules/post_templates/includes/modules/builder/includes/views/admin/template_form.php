<?php
if(!defined('ABSPATH'))die('');
?>
<div id="my_new_css">
			</div>
			<div id="my_templates_style_css">

			</div>
<div class="my_form_options_div">
	<div class="my_options_form">
		<div class="my_slide_in_out">
				<i class="fa fa-angle-double-left" style="display:none"></i>
				<i class="fa fa-angle-double-right"></i>
			</div>
	<div class="my_options_form_inner">
	<?php
    echo $template_form;
    ?>
    </div>
   </div>
</div>