<?php
if(!defined('ABSPATH'))die('');
$arr=array(
    'html'=>__("Html","my_support_theme"),
);
return $arr;