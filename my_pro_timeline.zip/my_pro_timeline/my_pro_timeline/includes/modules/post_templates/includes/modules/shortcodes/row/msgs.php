<?php
if(!defined('ABSPATH'))die('');
$arr=array(
		'only_px'=>__("In the layout choose only px or percentage.","my_support_theme"),
		'add_columns'=>__("Please add columns.","my_support_theme"),
		'total_width'=>__("Total width has to be {1} in pixels.","my_support_theme"),
		'add_title'=>__("Please add title.","my_support_theme"),
        'title'=>__("Row ","my_support_theme").'{x}',
        'show'=>__("Show","my_support_theme"),
        'remove'=>__("Remove","my_support_theme"),



);
return $arr;