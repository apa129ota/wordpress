<?php
if(!defined('ABSPATH'))die('');
$arr=array(
	'loading'=>__("Loading","my_support_theme"),
	'please_select_row'=>__("First add row layout and then click plus sign.","my_support_theme"),	
);
return $arr;