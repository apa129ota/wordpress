<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Module_Shortcodes_Post')){
	class Class_My_Module_Shortcodes_Post extends Class_My_Module_Shortcodes_General{
		private $tags;

		function Class_My_Module_Shortcodes_Post($options=array()){
			parent::Class_My_Module_Shortcodes_General($options);
			$this->tags=require $this->module_dir.'post/options.php';
				
		}
		public function getJscriptVals(){
			return $this->tags;
		}
		
		public function display_element(){
			//$layouts=$this->options['layouts'];
			$sh=$this->tags;
			/*$arr=array(
					'post_values'=>array(
							'title'=>__("Post values","my_support_theme")
					),
					'post_meta'=>array(
							'title'=>__("Post meta","my_support_theme"),
					),
					'content'=>array(
							'title'=>__("Predefined shortcodes","my_support_theme"),
					)
			);*/
			/*foreach ($sh as $key=>$val){
				if(!empty($val['group'])){
					$group=$val['group'];
					if(!isset($arr[$group]['elements'])){
						$arr[$group]['elements']=array();
					}
					$arr[$group]['elements'][$key]=$val;
				}
				if($this->debug){
					Class_My_Module_Debug::add_section('shortcodes_arr', $arr,'shortcodes',false);
				}
			}*/
			$file=plugin_dir_path(__FILE__).'views/display.php';
			require $file;
			/*$this->render_buttons(array(
			 'my_insert'=>array(
			 		'title'=>__("Insert","my_support_theme")
			 )
			));*/
		}
		function display_content(){
				
		}
	}
}
