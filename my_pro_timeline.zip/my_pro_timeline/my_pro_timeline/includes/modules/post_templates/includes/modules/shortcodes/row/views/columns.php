<?php
if(!defined('ABSPATH'))die('');
ob_start();
?>
<div class="my_shortcode_item" data-w="{width}" style="width:{width}%" id="{id}" data-i="{i}">
	<div class="my_shortcode_item_inner">
	<div class="my_shortcodes_rows_add">
	<div class="my_shortcode_add_div">
		<a href="#javascript" class="my_add_shortcode_a my_gradient_shortcode" title="<?php __("Add Shortcode","my_support_theme")?>">
		<i class="fa fa-plus"></i>
		<?php /*&nbsp;&nbsp;<?php //echo __("Add Shortcode","my_support_theme")?>*/ ?>
		</a>
	</div>
	<div class="my_shortcode_added_html">
	</div>
	</div>
	</div>
</div>
<?php
$html=ob_get_clean();
return $html;
?>