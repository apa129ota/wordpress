<?php
if (! defined ( 'ABSPATH' ))
    die ( '' );
    $units=array(
        'px'=>'px',
        '%'=>'%',
        'px'=>'px',
        'cm'=>'cm',
        'mm'=>'mm',
        'in'=>'in',
        'pt'=>'pt',
        'pc'=>'pc',
        'ch'=>'ch',
        'em'=>'em'
    );
$options['form']=array(
        'text'=>array(
            'layout_class'=>'my_col_100',
            'type'=>'textarea',
            'title'=>__("Text","my_support_theme"),
            'tooltip'=>__("Add heading text.","my_support_theme"),
            'default'=>__("Lorem ipsum","my_support_theme"),
        ),
        'type'=>array(
            'layout_class'=>'my_col_33',
            'type'=>'jscript_dropdown',
            'jscript'=>array(
                'max_c'=>1,
                'max_sel'=>__("Maximum elements are selected","my_support_theme"),
                'duration'=>500,
                'animation'=>'fadein',
                'choose_value'=>__("Plese Select value","my_support_theme"),
            ),
            'show_filter'=>0,
            'multiple'=>false,
            'choose_value'=>__("Plese Select value","my_support_theme"),

            'tooltip'=>__("Repat background","my_support_theme"),
            'title'=>__("Heading type","my_support_theme"),
            'label'=>__("Select heading tag","my_support_theme"),
            'values'=>array(
                'h1'=>__("H1","my_support_theme"),
                'h2'=>__("H2","my_support_theme"),
                'h3'=>__("H3","my_support_theme"),
                'h4'=>__("H4","my_support_theme"),
                'h5'=>__("H5","my_support_theme"),
                'h6'=>__("H6","my_support_theme"),

            ),
            'default'=>'h1'
        ),

       'font_size'=>array(
            'layout_class'=>'my_col_33',
            'title'=>__("Font size","my_support_theme"),
			'type'=>'jscript_spinner',
			'default'=>'18',
			'default_unit'=>'px',
			'units'=>$units,
			'translate'=>array(
					'class'=>'{class}',
					'property'=>'font-size'
			)
        ),
        'line_height'=>array(
            'layout_class'=>'my_col_33',
            'title'=>__("Line height","my_support_theme"),
            'type'=>'jscript_spinner',
            'default'=>'26',
            'default_unit'=>'px',
            'units'=>$units,
            'translate'=>array(
            'class'=>'{class}',
            'property'=>'font-size'
        )
    ),

    );
return $options;