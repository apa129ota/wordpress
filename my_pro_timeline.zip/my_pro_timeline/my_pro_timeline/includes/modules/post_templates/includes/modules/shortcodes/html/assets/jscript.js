(function($) {
	myVusualBuilderShortcodesHtml=function(o){
		var self;
		this.my_working=false;
		this.debug=true;
		this.options=o;
		this.dialog='';
		this.tmpl='';
		this.index=1;
		this.content='';
		this.objects={};
		this.pre_options={
				dw:800,
				dh:600,
				diff:20,
				my_show_html:'<div class="my_video_container"><div class="my_table_cell_1"><div class="my_table_cell"><span class="my_video_title">{title}</span><i class="fa fa-align-left"></i></div></div></div>',

			};
			self=this;
			this.init=function(o){
				if(typeof self.options.debug!='undefined'){
					if(!self.options.debug){
						self.debug=false;
					}
				}
				self.options=$.extend( self.pre_options,self.options);

				self.my_debug("options", self.options);
				var o={
					key:self.options.key,
					debug:self.debug,
					dw:self.options.dw,
					dh:self.options.dh,
					diff:self.options.diff
				};
				self.dialog=new myVusualBuilderDialog(o);
				$(".my_shortcode_insert_html").click(function(e){
					if($("#my_form_html_form").is(":visible")){
						self.insertContent();
					}
				});
			};
			this.my_edit=function(content,id){
				self.my_edit_id=id;
				self.dialog.my_open();
				self.my_debug('content',content);
				tinyMCE.get('my_editor_1').setContent(content);
				var objHtml={};
				self.my_debug("Objects",{id:id,objects:self.objects});
				objHtml=self.objects[id];
				if(objHtml.useScroll){
					$("#enableScroll_html_form_id").prop('checked',true);
				}else {
					$("#enableScroll_html_form_id").prop('checked',false);
				}
				var obj=$("#height_html_form_id_div").data('my-script');
				obj.set_value(objHtml.h);

			};
			this.get_content=function(){
				var id=self.my_edit_id;
				var content=tinyMCE.get('my_editor_1').getContent();

				return content;
			}
			this.insertContent=function(){
				var h='100px';
				var obj=$("#height_html_form_id_div").data('my-script');//.get_value();
				if(typeof obj!='undefined'){
					h=obj.get_value();
				}
				var useScroll=1;
				if($("#enableScroll_html_form_id").is(":checked")){

				}else useScroll=0;
				var overflow='auto';//=$("#overflow_y_html_form_id_div").data('my-script').get_value();
				var lineColor='#000000,0.4';//$("#scrollBarLineColor_html_form_id_div").data('my-script').get_value();
				var barColor='#fffffff,0.75';//("#scrollBarDragColor_html_form_id_div").data('my-script').get_value();
				if(!useScroll){
					overflow='hidden';
				}
				self.my_debug('Height',h);
				var content=self.get_content();
				var tmpl=self.my_get_contentReal(content);
				var objHtml={};
				objHtml.height=h;
				objHtml.useScroll=useScroll;
				objHtml.overflow=overflow;
				objHtml.lineColor=lineColor;
				objHtml.barColor=barColor;
				self.my_debug("Obj",objHtml);
				myVusualBuilderShortcodesSelect_inst.my_add_shortcode('html','',tmpl,{height:h,color:'#000000,1',overflow_y:overflow});


				if(useScroll){
					myAdminTemplatesBuilderAdmin_inst.actionSubSectionsNew('mCSB_draggerRail',{bg_color:lineColor},0);
					myAdminTemplatesBuilderAdmin_inst.actionSubSectionsNew('mCSB_dragger_bar',{bg_color:barColor},0);

					var has=$("#"+tmpl.id).attr('my_has_scroll');
					if(typeof has=='undefined'){
						$("#"+tmpl.id).mCustomScrollbar({advanced:{
							updateOnContentResize:true
						}});
						$("#"+tmpl.id).attr('my_has_scroll',1);
					}
				}else {
					var has=$("#"+tmpl.id).attr('my_has_scroll');
					if(typeof has!='undefined'){
						$("#"+tmpl.id).mCustomScrollbar('destroy');
						$("#"+tmpl.id).removeAttr('my_has_scrroll');
					}
				}
				self.objects[tmpl.id]=objHtml;
				self.dialog.my_close();


			};
			this.my_show=function(obj){
				//$(self.my_class).dialog('open');
				//self.dialog.my_open(obj);
				/*if(self.options.my_show==0){
					var id=obj.id;
					var is=$("#"+id).length;
					if(is){
						self.dialog.my_open();
					}
					else return self.my_get_contentShow();

				}else {*/
				var id=obj.id;
				var is=$("#"+id).length;
				if(is){
					$("#my_form_html_form").hide();
					self.dialog.my_open();
					//return false;
				}else {
					$("#my_form_html_form").show();
					self.dialog.my_open();
					return false;
				}

				//else return self.my_get_content(obj);
				//}
			};
			this.my_get_contentReal=function(content){
				var tmpl=$("script.my_shortcode_html").html();
				var id='my_shortcode_'+self.options.key+'_'+self.index;
				var is=$("#"+id).length;
				if(is)return false;
				self.my_debug("Is",is);
				//var content;
				//content=$("script.my_shortcode_html_default").text();
				tmpl=tmpl.replace('{id}',id);
				tmpl=tmpl.replace('{i}',self.index);
				tmpl=tmpl.replace('{content}',content);
				tmpl=tmpl.replace('{sel}','p');
				self.index++;
				self.my_debug('tmpl',tmpl);
				return {id:id,tmpl:tmpl};
			},
			this.my_get_content=function(obj){
				var tmpl=$("script.my_shortcode_html").html();
				var id='my_shortcode_'+self.options.key+'_'+self.index;
				var is=$("#"+id).length;
				if(is)return false;
				self.my_debug("Is",is);
				var content;
				content=$("script.my_shortcode_html_default").text();
				tmpl=tmpl.replace('{id}',id);
				tmpl=tmpl.replace('{i}',self.index);
				tmpl=tmpl.replace('{content}',content);
				self.index++;
				self.my_debug('tmpl',tmpl);
				return {id:id,tmpl:tmpl};
			};
			this.my_get_contentShow=function(obj){
				var tmpl=$("script.my_shortcode_html").html();
				var id='my_shortcode_'+self.options.key+'_'+self.index;
				var is=$("#"+id).length;
				if(is)return false;
				self.my_debug("Is",is);
				var content;
				content=self.options.my_show_html;//$("script.my_shortcode_html_default").text();
				content=content.replace(/\{title\}/g,self.options.msgs.html);
				tmpl=tmpl.replace('{id}',id);
				tmpl=tmpl.replace('{i}',self.index);
				tmpl=tmpl.replace('{content}',content);
				self.index++;
				self.my_debug('tmpl',tmpl);
				return {id:id,tmpl:tmpl};
			}
			this.my_clone_object=function(content){
				var tmpl=$("script.my_shortcode_html").html();
				var id='my_shortcode_'+self.options.key+'_'+self.index;
				var is=$("#"+id).length;
				if(is)return false;
				self.my_debug("Is",is);
				//var content;
				//content=$("script.my_shortcode_html_default").text();
				tmpl=tmpl.replace('{id}',id);
				tmpl=tmpl.replace('{i}',self.index);
				tmpl=tmpl.replace('{content}',content);
				self.index++;
				self.my_debug('tmpl',tmpl);
				return {id:id,tmpl:tmpl};
			};
			this.my_debug=function(t,o){
				if(self.debug){
					if(window.console){
						console.log('Visual builder Main \n'+t,o);
					}
				}
			};
			this.init();

	};
	})(jQuery);
