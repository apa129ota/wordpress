(function($) {
	myVusualBuilderShortcodesRow=function(o){
		var self;
		this.my_working=false;
		this.debug=true;
		this.options=o;
		this.dialog='';
		this.tmpl='';
		this.index=1;
		this.content='';
		this.objects={};
		this.dragg=false;
		this.width_px=400;
		this.added_layouts=false;
		this.pre_options={
				content_class:".my_post_template",
				row_class:".my_shortcode_row_row",
				item_class:".my_shortcode_item",
				actions_class:".my_shortcode_row_actions_div",
				row_class:".my_shortcode_row_row",
				dw:800,
				dh:400,
				diff:20,
				objectHtml:'<div class="my_object_item" data-key="{key}"><i class="fa fa-plus"></i>{title}&nbsp;<a href="#javascript" class="my_hide_element" data-key="{key}" data-hide="0" title="{remove}"><span class="my_hide_el"><i class="fa fa-trash-o"></i></span><span class="my_show_el">{show}</span></a></div>',
				objectHtmlChildren:'<div class="my_object_item_inner" data-key="{key}" style="display: block;"></div>',
				objectHtmlChildSelector:'.my_object_explorer_child .mCSB_container',
				appendObjectSelector:'.my_options_form_object_explorer .mCSB_container'
			};
			self=this;
			this.init=function(o){
				if(typeof self.options.debug!='undefined'){
					if(!self.options.debug){
						self.debug=false;
					}
				}
				self.options=$.extend( self.pre_options,self.options);
				self.objectHtml=self.options.objectHtml;
				self.objectHtml=self.objectHtml.replace(/\{show\}/g,self.options.msgs.show);
				self.objectHtml=self.objectHtml.replace(/\{remove\}/g,self.options.msgs.remove);
				self.objectHtml=self.objectHtml.replace(/\{title\}/g,self.options.msgs.title);
				self.my_debug('Objecthtml',self.objectHtml);

				self.my_debug("options", self.options);
				var o={
					key:self.options.key,
					debug:self.debug,
					dw:self.options.dw,
					dh:self.options.dh,
					diff:self.options.diff
				};
				$(document).on('click',self.options.row_class,function(e){
					var id=$(this).attr('id');
					$(self.options.row_class).removeClass("my_selected");
					$("#"+id).addClass("my_selected");
					self.my_edit_id=id;
					//$(".my_object_item[data-key='"+id+"']").trigger('click');
					/*myVusualBuilderMain_inst.my_add_id=id;
					myVusualBuilderMain_inst.my_add_object=self.objects[id];
					*/
					myVusualBuilderMain_inst.set_row(id,self.objects[id]);
					self.my_debug("Edit id",id);
				});
				$(document).on('click',".my_action_shortcode_row",self.my_actions);
				self.dialog=new myVusualBuilderDialog(o);
				$(document).on('click',".my_shortocde_rows_ul ul",self.my_add_layout);
				self.init_objects();
				$(document).on('mouseenter',self.options.row_class,function(){
					$(this).find(self.options.actions_class).animate({opacity:1});

				});
				/*$(self.options.content_class).sortable({
				      revert: true
			    });*/
				$(document).on('mouseleave',self.options.row_class,function(){
					$(this).find(self.options.actions_class).animate({opacity:0});
				});
				$(document).on("click",self.options.actions_class+" a ",self.my_actions);
				if($("#width_my_templates_id").length>0){
					var tW=parseFloat($("#width_my_templates_id").val());
					if(typeof tW!='undefined'){
						self.my_debug('Width dialog', tW);
						self.width_px=tW;
						$("#my_dialog_width_id").html(tW);
					}
					$(document).on("change","#width_my_templates_id",function(e){
						var tW=parseFloat($("#width_my_templates_id").val());
						if(typeof tW!='undefined'){
							self.my_debug('Width dialog', tW);
							self.width_px=tW;
							$("#my_dialog_width_id").html(tW);
						}
					});
				}


			};
			this.my_actions=function(e){
				e.preventDefault();
				var key=$(this).data('key');
				var $obj=$(this).parents(self.options.row_class);
				var id=$obj.attr('id');
				self.my_debug("Action",{key:key,id:id});
				switch(key){
					case 'new_layout':
						$("#my_layout_id").val('');
						$("#my_row_width_id").val('');
						//$(".my_new_layout_preview ul").html('');
					break;
					case 'save_layout':
						var cols=$("#my_row_width_id").val();
						if(cols==''){
							var msg=self.options.add_columns;
							myAdminMsgs_inst.my_remove_window(1,msg);
							return;
						}
						var title=$("#my_layout_id").val('');
						if(title==''){
							var msg=self.options.add_columns;
							myAdminMsgs_inst.my_remove_window(1,msg);
							return;
						}
						var cols_arr=[100];
						var cols_str=['100%'];
						var haspx=false;
						var hasper=false;
						self.my_debug('Cols',cols);
						var totalW=0;
						if(cols.indexOf(",")!==-1){
							cols_str=cols.split(',');

							$.each(cols_str,function(i,v){
								if(v.indexOf('%'))hasper=true;
								if(v.indexOf('px')){
									haspx=true;
									totalW+=parseFloat(v);
								}
							});
						}else {

						}
						self.my_debug("TotalW",totalW);
						if(totalW>self.width_px){
							var msg=self.options.total_width;
							msg=msg.replace("{1}",self.width_px);
							myAdminMsgs_inst.my_remove_window(1,msg);
							return;
						}
						var w=$(".my_new_layout_preview ul li").width();
						if(!self.added_layouts){
							$(".my_new_layout_preview ul li").remove();
							self.added_layouts=true;
						}
						self.my_debug("width",w);
						if(hasper&&haspx){
							var msg=self.options.only_px;
							myAdminMsgs_inst.my_remove_window(1,msg);
							return;
						}else {
							var html='<li><ul data-width="';
							var li_html='';
							var a_w="";
							$.each(cols_str,function(i,v){
								var id=i+1;
								if(hasper){
									if(a_w.indexOf(",")!==-1)a_w+=",";
									a_w+=v;
									li_html+='<li style="width:'+v+"><span>"+id+"</span></li>";
								}else {
									if(a_w.indexOf(",")!==-1)a_w+=",";
									a_w+=v;
									var s=parseFloat(v)/w+'%';
									li_html+='<li style="width:'+s+"><span>"+id+"</span></li>";
								}

							});
							$(".my_new_layout_preview ul ").append(html+a_w+'">'+li__html+'</ul>');
						}
						/*self.my_debug("Add column",col)
						var c=col;
						if(col.indexOf('px')!==-1){
							var w=$(".my_new_layout_preview ul").width();
							var w1=parseFloat(col);
							c=w1/w;
						}else {
							c=parseFloat(col);

						}
						$(".my_new_layout_preview ul").append('<li data-widths=')
						*/
					break;
					case 'move':
						$obj.draggable({draggable:true});
					break;
					case 'delete':
						$obj.fadeOut(function(){$(this).remove()});
						delete self.objects[id];
					break;
					case 'copy':
						self.clone_row($obj);
					break;
				}
			};
			this.clone_row=function($obj){
				var id=$($obj).attr('id');
				self.my_debug("Clone object",id);
				var row_id="my_shortcode_row_row_"+self.index;
				var row_html=$("script.my_shortcode_row").html();
				var col_html=$("script.my_shortcode_row_default").html();
				//var widths_str=;
				var widths_arr=self.objects[id].widths;
				self.my_debug("Add new row",{i:self.index,widths_arr:widths_arr});
				var row_html_all='';
				$.each(widths_arr,function(i,v){
					var h=col_html;
					var id_1=row_id+"_"+i;
					h=h.replace('{id}',id_1);
					h=h.replace(/\{width\}/g,v);
					h=h.replace('{i}',i);
					row_html_all+=h;
				});
				row_html=row_html.replace('{id}',row_id);
				row_html=row_html.replace('{i}',self.index);
				row_html=row_html.replace('{content}',row_html_all);
				$(self.options.content_class).find("#"+id).after(row_html);
				var o={
					id:row_id,
					widths:widths_arr
				};
				self.objects[row_id]=o;
				self.my_debug("Objects",self.objects);
				self.index++;
				self.my_edit_id=row_id;
				$(self.options.row_class).removeClass("my_selected");
				$("#"+row_id).addClass("my_selected");
				var id=row_id;
				myVusualBuilderMain.my_add_id=id;
				myVusualBuilderMain.my_add_object=self.obects[id];
				//self.dialog.my_close();
				self.set_draggabble();
			};
			this.set_draggabble=function(){
			$(self.options.row_class).each(function(i,v){
				var is=$(v).attr('is-draggable');
				if(typeof is=='undefined'){
					self.my_debug("Set draggable",{is:is,id:$(v).attr('is')});
					$(v).draggable({
					      connectToSortable: self.options.content_class,
					      axis:"y",
					      revert: "invalid",
					      start:function( event, ui ){
					    	  self.my_debug("Start",ui);
					    	  //self.my_debug("Width",self.item_width);
					    	 // $(ui.helper).width(self.item_width);
					    	  self.my_left_pos=ui.originalPosition.top;//$(ui.helper).offset().left;
					    	  self.my_debug("Drag positon",self.my_left_pos);
					      },
					      drag:function(event,ui){
					    	  $(ui.helper).css('left',self.my_left_pos);
					    	  ui.offset.left=self.my_left_pos;

					      },
					      stop:function(event,ui){
					    	  $(self.options.row_class).draggable({disabled:true});
					      }
					    });
					$(v).disableSelection();
					$(v).attr('is-draggable',1);
				}
			});
			$(self.options.row_class).draggable({disabled:true});
			};
			this.init_objects=function(){
				var id;
				$(self.options.row_class).each(function(i,v){
					id=$(v).attr('id');
					var widths=[];
					$(v).find(self.options.item_class).each(function(i1,v1){
						var w=$(this).data("w");
						widths[widths.length]=w;
					});
					self.objects[id]={
							id:id,
							widths:widths
					};
					self.index++;
				});
				if($(self.options.row_class).length>0){
					$(self.options.row_class).eq(0).addClass("my_selected");
					self.my_edit_id=$(self.options.row_class).eq(0).attr('id');
				}
				self.my_debug("Objects",self.objects);
				self.my_debug("Sel id",self.my_edit_id);
				var id=self.my_edit_id;
				myVusualBuilderMain_inst.set_row(id,self.objects[id]);
				/*
				myVusualBuilderMain_inst.my_add_id=id;
				myVusualBuilderMain_inst.my_add_object=self.objects[id];
				*/
				self.set_draggabble();
			};
			this.my_add_layout=function(e){
				e.preventDefault();
				self.dialog.my_close();
				var row_id="my_shortcode_row_row_"+self.index;
				var row_html=$("script.my_shortcode_row").html();
				var col_html=$("script.my_shortcode_row_default").html();
				var widths_str=$(this).data('widths');
				var widths_arr;
				widths_str=widths_str.toString();
				self.my_debug("Widths str", widths_str);
				if(widths_str.indexOf(",")!==-1){
					widths_arr=widths_str.split(",");
				}else {
					widths_arr=[widths_str];
				}

				self.my_debug("Add new row",{i:self.index,widths_arr:widths_arr});
				var row_html_all='';
				$.each(widths_arr,function(i,v){
					var h=col_html;
					var id_1=row_id+"_"+i;
					h=h.replace('{id}',id_1);
					h=h.replace(/\{width\}/g,v);
					h=h.replace('{i}',i);
					row_html_all+=h;
				});
				row_html=row_html.replace('{id}',row_id);
				row_html=row_html.replace('{i}',self.index);
				row_html=row_html.replace('{content}',row_html_all);
				$(self.options.content_class).append(row_html);
				var o={
					id:row_id,
					widths:widths_arr
				};
				var objectHtml=self.objectHtml;
				objectHtml=objectHtml.replace(/\{key\}/g,row_id);
				objectHtml=objectHtml.replace('{x}',self.index);
				$(self.options.appendObjectSelector).append(objectHtml);
				var objectHtmlChild=self.options.objectHtmlChildren;
				objectHtmlChild=objectHtmlChild.replace(/\{key\}/g,row_id);
				$(self.options.objectHtmlChildSelector).append(objectHtmlChild);

				self.objects[row_id]=o;
				self.my_debug("Objects",self.objects);
				self.index++;
				self.my_edit_id=row_id;
				setTimeout(function(row_id){
					self.my_debug("Row id"+row_id);
					var rowHeight=105;//parseInt($(row_id).height());
					var preVal=parseInt($("#height_my_templates_id").val());
					var newVal=preVal+rowHeight;
					//$("#height_my_templates_id").val(newVal);
					myAdminTemplatesBuilder_inst.setHeight(newVal);
				}(row_id),1000);
				myAdminTemplatesBuilder_inst.my_edit_id='#'+row_id;
				
				self.my_debug("Row id",row_id);
				$(self.options.row_class).removeClass("my_selected");
				$("#"+row_id).addClass("my_selected");
				myVusualBuilderMain_inst.set_row(row_id,self.objects[row_id]);
				self.dialog.my_close();
				self.set_draggabble();
				/*if(typeof myAdminTemplatesBuilderAdmin_inst!='undefined'){
					myAdminTemplatesBuilderAdmin_inst.my_edit_id="#"+row_id;
					myAdminTemplatesBuilderAdmin_inst.my_edit_row=1;
					$("#my_form_section_text").hide();
				}*/
				
			}
			this.my_edit=function(content,id){
				self.my_edit_id=id;
				self.dialog.my_open();
				self.my_debug('content',content);
				tinyMCE.get('my_editor_1').setContent(content);

			};
			this.get_content=function(){
				var id=self.my_edit_id;
				var content=tinyMCE.get('my_editor_1').getContent();
				return content;
			}
			this.my_show=function(obj){
				//$(self.my_class).dialog('open');
				//elf.dialog.my_open(o);
					self.dialog.my_open();
				//}

				//else return self.my_get_content(obj);
					return false;
			};
			this.my_get_content=function(obj){
				var tmpl=$("script.my_shortcode_row").html();
				var id='my_shortcode_'+self.options.key+'_'+self.index;
				var is=$("#"+id).length;
				if(is)return false;
				self.my_debug("Is",is);
				var content;
				content=$("script.my_shortcode_html_default").text();
				tmpl=tmpl.replace('{id}',id);
				tmpl=tmpl.replace('{i}',self.index);
				tmpl=tmpl.replace('{content}',content);
				self.index++;
				self.my_debug('tmpl',tmpl);
				return {id:id,tmpl:tmpl};
			};
			this.my_clone_object=function(content){
				var tmpl=$("script.my_shortcode_html").html();
				var id='my_shortcode_'+self.options.key+'_'+self.index;
				var is=$("#"+id).length;
				if(is)return false;
				self.my_debug("Is",is);
				//var content;
				//content=$("script.my_shortcode_html_default").text();
				tmpl=tmpl.replace('{id}',id);
				tmpl=tmpl.replace('{i}',self.index);
				tmpl=tmpl.replace('{content}',content);
				self.index++;
				self.my_debug('tmpl',tmpl);
				return {id:id,tmpl:tmpl};
			};
			this.my_debug=function(t,o){
				if(self.debug){
					if(window.console){
						console.log('Visual builder Main \n'+t,o);
					}
				}
			};
			this.init();

	};
	})(jQuery);
