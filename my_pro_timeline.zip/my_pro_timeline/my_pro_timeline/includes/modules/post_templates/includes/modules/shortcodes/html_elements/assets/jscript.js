(function($) {
	myVusualBuilderShortcodesVideo=function(o){
		var self;
		this.my_working=false;
		this.debug=true;
		this.options=o;
		this.dialog='';
		this.tmpl='';
		this.index=1;
		this.content='';
		this.objects={};
		this.dragg=false;
		this.width_px=400;
		this.added_layouts=false;
		this.type='media';
		this.media_obj='';
		this.media_id='';
		this.preload=0;
		this.media_thumb='';
		this.media_sub_type;
		this.media_url='';
		this.objects={};
		this.edit=false;
		this.edit_id='';
		this.pre_options={
				content_class:".my_post_template",
				row_class:".my_shortcode_row_row",
				item_class:".my_shortcode_item",
				actions_class:".my_shortcode_row_actions_div",
				row_class:".my_shortcode_row_row",
				my_show_html:'<div class="my_video_container"><div class="my_table_cell_1"><div class="my_table_cell"><span class="my_video_title">{title}</span><i class="fa fa-video-camera"></i></div></div></div>',
				dw:800,
				dh:400,
				diff:20,
				w:16,
				h:9,
				html_youtube:'<iframe width="100%" height="56.25%" src="https://www.youtube.com/embed/{id}"></iframe>'
			};
			self=this;
			this.init=function(o){
				if(typeof self.options.debug!='undefined'){
					if(!self.options.debug){
						self.debug=false;
					}
				}
				self.debug=true;
				self.options=$.extend( self.pre_options,self.options);

				self.my_debug("options", self.options);
				$('body').on('my_init_form',function(e,id){
					self.my_debug('Iniot form',id);
				if(id=='video_form'){
					var o={
						key:self.options.key,
						debug:self.debug,
						dw:self.options.dw,
						dh:self.options.dh,
						diff:self.options.diff
					};
					self.dialog=new myVusualBuilderDialog(o);
					$("#wordpress_video_video_form_id_div").on('my_change',function(e,obj,val,v1){
						$(".my_choosed_video div").hide();

						if(!$.isEmptyObject(val)){
							$.each(val,function(i1,v1){
								var title=v1.title;
								$(".my_video_title").text(title);
								var name=v1.filename;
								$(".my_video_file").text(name);
								var l=v1.fileLength;
								$(".my_video_length").text(l);
								$(".my_choosed_media").fadeIn();
								self.media_obj=v1;
								self.media_id=i1;
								self.media_url=v1.url;
								self.media_sub_type=v1.subtype;
								if(typeof v1.width!='undefined'){
									self.options.w=v1.width;
								}
								if(typeof v1.height!='undefined'){
									self.options.h=v1.height;
								}
							});
						}else self.media_obj='';
					});

					$("#video_type_video_form_id_div").on('my_change',function(e,obj,val,v1){
						self.type=val;
						self.my_show_form();
						if(val=='youtube'){
							self.options.w=self.pre_options.w;
							self.options.h=self.pre_options.h;

							$(".my_choosed_video div").hide();
							$(".my_choosed_youtube").show();
						}else if(val=='vimeo'){
							self.options.w=self.pre_options.w;
							self.options.h=self.pre_options.h;

							$(".my_choosed_video div").hide();
							$(".my_choosed_vimeo").show();
						}else if(val=='url'){
							self.options.w=self.pre_options.w;
							self.options.h=self.pre_options.h;

							$(".my_choosed_video div").hide();
							$(".my_choosed_url").show();
						}else if(val=='wordpress'){
							$(".my_choosed_video div").hide();
							$(".my_choosed_media").show();
						}
						//self.my_show_form();
					});
					$("#video_poster_video_form_id_div").on('my_change',function(e,obj,val,v1){
						if(val==''){
							self.media_thumb='';
						}else {
							var img=obj.getSizesUrl('full');
							self.my_debug('Poster video image',img);
							self.media_thumb=img.url;
						}
					});


				}

				});

				$(document).on('click',".my_video_action",self.my_add_video);
			},
			this.my_show_form=function(){
				var arr={};
				arr['media']=['video_ratio_video_form_id_div','wordpress_video_video_form_id_div','video_poster_video_form_id_div','video_type_video_form_id_div'];
				arr['youtube']=['video_ratio_video_form_id_div','video_id_video_form_id_div','video_type_video_form_id_div'];
				arr['vimeo']=['video_ratio_video_form_id_div','video_id_video_form_id_div','video_type_video_form_id_div'];
				arr['url']=['video_ratio_video_form_id_div','video_type_video_form_id_div','mp4_video_form_id_div','m4v_video_form_id_div','webm_video_form_id_div','ogv_video_form_id_div','wmv_video_form_id_div','flv_video_form_id_div'];
				var type=self.type;
				var show=arr[self.type];
				$("#my_form_video_form > ul >li .my_new_module_element").each(function(i,v){
					var id=$(this).attr('id');
					if($.inArray(id,show)!=-1){
						$("#"+id).parents('li').show();
					}else {
						$("#"+id).parents('li').hide();
					}
				});

			}
			this.getWidth=function(){
				var id=myVusualBuilderShortcodesSelect_inst.my_add_id;
				var w=$("#"+id).width();
				self.my_debug("Width",w);
				self.contW=w;
				return w;
			},
			this.getHeight=function(){
				var w=self.options.w;
				var h=self.options.h;
				var ratio=Math.round(h/w*100)/100;
				var wr=self.contW;
				var hr=wr*ratio;
				//self.my_debug("Height",{hr:hr,w:w,h:h,wr:wr,ratio:ratio});
				//$("#id").find('iframe').height(hr+'px');
				self.my_debug('Height',hr);
				return hr;
			},
			this.my_add_video=function(){
				/*var video_id='v5P4LsUyXV4';
				var type='youtube';
				var html;
				var v=$("#video_id_video_form_id").val();

				if(type=='youtube'){
					html=self.options.html_youtube;
					html=html.replace(/\{id\}/g,video_id)


				}
				var tmpl=$("script.my_shortcode_html").html();
				var id='my_shortcode_'+self.options.key+'_'+self.index;
				*/
				var type=self.type;
				self.my_debug('Video type',type);
				if(type=='media'){
					if(self.media_obj==''){
						myAdminMsgs_inst.show_remove(self.options.msgs.add_media,1);
						return;
					}else self.callAjaxMedia();

				}
			};
			this.callAjaxMedia=function(){
				//var h=self.getHeight();
				var o1={};
				o1.data={
						id:self.media_id,
						obj:self.media_obj,
						url:self.media_url,
						thumb:self.media_thumb,
						subtype:self.media_sub_type,
						width:self.options.w,
						height:self.options.h,
						action:myAdminTemplatesBuilderAdmin_inst.options.ajax_action,
						my_action:'load_video',
						type:'media',

				};

				self.my_debug("Call video ajax",o1);
				o1.success=function(data){
					self.my_debug("Return", data);
					if(data.error==0){
						self.html=data.html;
						myAdminMsgs_inst.show_remove(data.msg,0);
						self.myAddVideo();
					}else {
						myAdminMsgs_inst.show_remove(data.msg,1);
					}

				};
				myGlobalAjaxClass_inst.call_ajax(o1,self.options.msgs.loading_video);


			}
			this.updateVideoHeightAll=function(){
				$(".my_shortcode_video").each(function(i,v){
					var id=$(v).attr('id');
					self.updateVideoHeight();
				});
			}
			this.updateVideoHeight=function(id){
				var w=parseInt($("#"+id).attr('w'));
				var h=parseInt($("#"+id).attr('h'));
				var ratio=Math.round(h/w*100)/100;
				var wr=$("#"+id).parent(self.options.element_inner).width();
				var hr=wr*ratio;
				self.my_debug("Height",{hr:hr,w:w,h:h,wr:wr,ratio:ratio});
				$("#id").find('iframe').height(hr+'px');
			};
			this.my_edit=function(e){
				if(self.my_show==0){
					myAdminMsgs_inst.show_remove(self.options.msgs.edit_from,1);
					return false;
				}
				else {
					self.dialog.my_open();
				}
			};
			this.my_show=function(e){
				if(self.options.my_show==0){
					var w=self.options.w;
					var h=self.options.h;
					var html=self.options.my_show_html;
					var div_id="my_added_object_"+myVusualBuilderMain_inst.my_add_id+"_"+myVusualBuilderMain_inst.index;

					self.my_debug("Show Html",html);
					//self.myAddVideo(html);
					var tmpl=$("script.my_shortcode_video").html();
					var id='my_shortcode_'+self.options.key+'_'+self.index;
					if($("#"+id).length>0)return;
					tmpl=tmpl.replace(/\{w\}/,w);
					tmpl=tmpl.replace(/\{h\}/,h);

					tmpl=tmpl.replace('{id}',id);
					tmpl=tmpl.replace('{i}',self.index);
					tmpl=tmpl.replace('{content}',html);
					var objectVideo={};
					objectVideo.div_id=div_id;
					if(!isShow){

					}
					//objectVideo.type=self.type;
					/*
					if(self.type=='media'){
						objectVideo.media_id=self.media_id;
						objectVideo.media_obj=self.media_obj;
					}else {

					}*/
					self.objects[id]=objectVideo;
					self.index++;
					self.my_debug('tmpl',tmpl);
					var oTmpl={id:id,tmpl:tmpl};

				}else{
					self.getWidth();
					self.dialog.my_open();
					self.my_show_form();
					return false;
				}
			}
			this.myAddVideo=function(){
				var isShow=false;

				var argLength=arguments.length;
				var html='';
				if(argLength==1){
					html=arguments[0];
					var t=self.options.msgs.video_title;
					html=html.replace(/\{title\}/g,t);
					isShow=true;
				}

				//self.dialog.my_open();
				//return false;
				var video_id='v5P4LsUyXV4';
				var type=self.type;

				var v=$("#video_id_video_form_id").val();
				var w=self.options.w;
				var h=self.options.h;
				if(html==''){
					if(type=='media'){
						html=self.html;
					}
				}
				var div_id="my_added_object_"+myVusualBuilderMain_inst.my_add_id+"_"+myVusualBuilderMain_inst.index;

				var tmpl=$("script.my_shortcode_video").html();
				var id='my_shortcode_'+self.options.key+'_'+self.index;
				if($("#"+id).length>0)return;
				tmpl=tmpl.replace(/\{w\}/,w);
				tmpl=tmpl.replace(/\{h\}/,h);

				tmpl=tmpl.replace('{id}',id);
				tmpl=tmpl.replace('{i}',self.index);
				tmpl=tmpl.replace('{content}',html);
				var objectVideo={};
				objectVideo.div_id=div_id;
				if(!isShow){

				}
				//objectVideo.type=self.type;
				/*
				if(self.type=='media'){
					objectVideo.media_id=self.media_id;
					objectVideo.media_obj=self.media_obj;
				}else {

				}*/
				self.objects[id]=objectVideo;
				self.index++;
				self.my_debug('tmpl',tmpl);
				var oTmpl={id:id,tmpl:tmpl};
				myVusualBuilderShortcodesSelect_inst.my_add_shortcode('video','',oTmpl);

				self.dialog.my_close();

			}
			this.my_debug=function(t,o){
				if(self.debug){
					if(window.console){
						console.log('Visual builder Main Video\n'+t,o);
					}
				}
			};
			this.init();

	};
	})(jQuery);