<?php
if(!defined('ABSPATH'))die('');
ob_start();
?>
<div class="my_shortcode_row_row my_clearfix" data-i="{i}" id="{id}" data-key="">
	{content}
	<div class="my_shortcode_row_actions_div ">
		<ul>
			<li>
			<a class="my_action_shortcode_row my_transition" data-key="edit_row" href="#javascript" title="<?php echo __("Edit Options","my_support_theme")?>">
				<i class="fa fa-edit"></i>
			</a> 
			</li>
			<li>
			<a class="my_action_shortcode_row my_transition" data-key="move" href="#javascript" title="<?php echo __("Move","my_support_theme")?>">
				<i class="fa fa-arrows"></i>
			</a> 
			</li>
			<li>
			<a class="my_action_shortcode_row my_transition" data-key="copy" href="#javascript" title="<?php echo __("Clone","my_support_theme")?>">
				<i class="fa fa-plus"></i>
			</a> 
			</li>
			<li>
			<a class="my_action_shortcode_row my_transition" data-key="delete" href="#javascript" title="<?php echo __("Delete","my_support_theme")?>">
				<i class="fa fa-times"></i>
			</a> 
			</li>
			<?php /*
			<li>
			<a class="my_action_shortcode_row my_transition" data-key="mobile" href="#javascript" title="<?php echo __("Small device view","my_support_theme")?>">
				<i class="fa fa-mobile"></i>
			</a> 
			</li>
			*/ ?>
			
		</ul>
	</div>
</div>
<?php 
$row=ob_get_clean();
return $row;
