<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_module_testimonials" id="my_new_css">
</div>
<div id="my_templates_style_css">

			</div>
<div class="my_timeline_modal">
	<div class=" my_header my_no_margin" style="margin-bottom: 10px;">
		<h4 class="my_no_margin"><?php echo __("Visual builder","my_support_theme")?></h4>
		<div class="my_timeline_modal_close">
			<i class="fa fa-close"></i>
		</div>

	</div>
	<div class="my_timeline_modal_content">

		<div class="my_options_form">
			<div class="my_slide_in_out">
				<i class="fa fa-angle-double-left" style="display:none"></i>
				<i class="fa fa-angle-double-right"></i>
			</div>
			<div class="my_options_form_inner">
			<?php
			echo $template_form;
			?>
			</div>
		</div>
		<div class="my_container_inner">




		<div class="my_image_mapper_add_new_div my_clearfix">

			<div class="my_image_mapper_image_div my_border_none">
			<div class="my_image_mapper_calculate">
			<ul class="my_radio_inline">
				<li><?php echo __("X","my_support_theme")?> : <span class="my_tmpl_x">0</span></li>
				<li><?php echo __("Y","my_support_theme")?> : <span class="my_tmpl_y">0</span></li>
				<li><?php echo __("Tag","my_support_theme")?> : <span class="my_tmpl_tag"></span></li>
				<li><?php echo __("Element Height","my_support_theme")?> : <span class="my_el_h"></span></li>
				<li><?php echo __("Element Width","my_support_theme")?> : <span class="my_el_w"></span></li>


				<li><?php echo __("Height","my_support_theme")?> : <span class="my_tmpl_h">400px</span></li>
			</ul>
			<ul class="my_radio_inline">

				<li><input type="button" class="button button-primary button-large my_action" data-key="adjust_height" value="<?php echo __("Adjust height","my_support_theme")?>"/></li>
				<li class="my_scrollEdit" style="display:none"><input type="button" class="button button-primary button-large my_action" data-key="edit_dragg" value="<?php echo __("Scrollbar color","my_support_theme")?>"/></li>
				<li class="my_scrollEdit" style="display:none"><input type="button" class="button button-primary button-large my_action" data-key="edit_dragg_line" value="<?php echo __("Scrollbar line Color","my_support_theme")?>"/></li>
				<li class=""><input type="button" class="button button-primary button-large my_action" data-key="edit_share_box" value="<?php echo __("Edit share box","my_support_theme")?>"/></li>
				<li class=""><input type="button" class="button button-primary button-large my_action" data-key="edit_stars_dialog" value="<?php echo __("Edit stars dialog","my_support_theme")?>"/></li>
				<li class=""><input type="button" class="button button-primary button-large my_action" data-key="edit_view_dialog" value="<?php echo __("Edit view dialog","my_support_theme")?>"/></li>
				<li class="my_start_sort"><input type="button" class="button button-primary button-large my_action" data-key="sort" value="<?php echo __("Sort elements","my_support_theme")?>"/></li>
				<li class="my_stop_sort"><input type="button" class="button button-primary button-large my_action" data-key="stop_sort" value="<?php echo __("Stop sort","my_support_theme")?>"/></li>


			</ul>



		</div>
				<?php //echo $template_html; ?>


<div class="my_module_poost_templates_title">
<h4><?php echo __("Preview Template","my_support_theme")?></h4>
</div>
<div class="my_module_post_templates_editor_div_out">
	<div class="my_module_post_templates_editor_div" data-type="" data-id="">

		<div class="my_module_post_templates_editor_div_inner">
				<div class="my_post_template my_template_custom_new my_post_clear" data-key="template_custom_new" data-post-id=="{post_id}">
				</div>
			</div>
	</div>
</div>
</div>
			<div class="my_image_mapper_styles_div">
				<?php /*<h4><?php echo __("Shortcodes","my_support_theme")?></h4>*/?>
				<?php echo $shortcodeSelectHtml;?>

				<?php /*
				<div class="my_form_options_div">
						<div class="my_options_form">

							<div class="my_options_form_inner">
				<h4><?php echo __("Styling HTML Elements","my_support_theme")?></h4>

				<?php echo $template_form;?>
				</div>
				</div>
				*/ ?>
				<h4><?php echo __("Template Options","my_support_theme")?></h4>

				<?php echo $shortcodes_html;?>

			</div>
		</div>
	</div>
	</div>
		<?php /*
		<div class="my_timeline_modal_loading">
			<span><?php echo __("Loading","my_related_posts_domain").' ... ';?><img src="<?php echo MY_RELATED_POSTS_IMAGES_URL.'wpspin.gif';?>"/></span>
		</div>
		*/ ?>
		<?php /*
		<div class="my_timeline_modal_load my_flex_display">
			<div class="my_flex_display my_slide_image" style="">
				<?php
				$c12=0;
				foreach($shortcodes as $sh=>$shVal){
					if(isset($styles['shortcodes'][$sh])){
					$settings=$styles['shortcodes'][$sh]['settings'];
					$file=$views_dir.''.$sh.'.php';
				?>
				<div class="my_view_item" data-key="<?php echo $sh;?>" style="<?php if($c12>0)echo 'display:none;'; ?>">
				<?php
				if(file_exists($file)){
				require $file;
				}else echo  $file;
				?>

				</div>

				<?php
				$c12++;
				}
				}?>
				<?php /*<div class="my_slide_image_overlay my_transition">
					<ul>
						<li><a href="#javascript" class="my_transition"><i class="fa fa-plus"></i></a>
					</ul>
				</div>
				*/ ?>
			</div>
			<?php /*
			<div class="my_flex_display my_sidebar my_border_one my_h_100 my_bg">

				<?php /*<ul class="my_window_actions">
						<li class="my_transition"><a href="#javascript" class="my_transition my_add_element"><i class="fa fa-plus"></i><span><?php echo __("Add Element","my_support_theme") ?></span></a></li>

				</ul>

				<div class="my_elemenet_section">
					<h4><a href="#javascript" class="my_transition my_open_section"><i class="fa fa-plus"></i><span><?php echo __("Template options","my_support_theme") ?></span></a></h4>

				<div class="my_section_inside">
				<ul class="my_window_actions">
							<li style="text-align:center"><span><?php echo __("Select Element","my_support_theme")?></span></li>
							<?php
						/*	global $my_shortcodes;
							if(!empty($my_shortcodes)){
								foreach($my_shortcodes as $key=>$val){
								?>
								<li class="my_transition"><a href="#javascript" title="<?php echo esc_attr($val['tooltip'])?>" class="my_transition my_add_shortcode" data-key="<?php echo esc_attr($key)?>"><i class="fa <?php echo $val['icon']?>"></i><span><?php echo $val['title'];?></span></a></li>
								<?php
								}
							}
							?>
				</ul>
				</div>
				</div>
				<ul class="my_element_actions">

				</ul>
			</div>
			*/?>
			<?php //my_new_form_footer();

			?>
		</div>
