<?php
if(!defined('ABSPATH'))die('');
?>
<?php 
$myIsLoto=@$_GET['my_is_loto'];
if(!empty($myIsLoto)){
    wp_my_loto_get_loto_arr(3,1979);
    wp_my_loto_get_joker_arr(1979);
}
?>
<div class="my_module_testimonials" id="my_new_css">
</div>
<div id="my_templates_style_css">

			</div>
<?php /*
	<div class=" my_header my_no_margin" style="margin-bottom: 10px;">
		<h4 class="my_no_margin"><?php echo __("Visual builder","my_support_theme")?></h4>
		<div class="my_timeline_modal_close">
			<i class="fa fa-close"></i>
		</div>

	</div>

	<div class="my_timeline_modal_content">
		<div class="my_options_form">
			<div class="my_slide_in_out">
				<i class="fa fa-angle-double-left" style="display:none"></i>
				<i class="fa fa-angle-double-right"></i>
			</div>
			<div class="my_options_form_inner">
			<?php
			echo $template_form;
			/*
			$c12=0;
				foreach($options_forms as $sh=>$shVal){
					$obj=$styles['shortcodes'][$sh];
					$title=$obj['title'];
				?>
					<div class="my_module_shortcodes_form" data-key="<?php echo esc_attr($sh)?>" style="<?php if($c12>0)echo 'display:none';?>">
						<h4><?php echo $title?></h4>
						<div class="my_save_div" style="text-align: center;">
							<h4 class="my_saved_style_title" style="text-align: center;display:none;"></h4><br/>
							<input class="button  button-large my_action" type="button" data-key="load_style_dialog" value="<?php  echo __("Load style","my_support_theme") ?>"/>
							<input class="button  button-large my_action" type="button" data-key="new_style" value="<?php  echo __("New style","my_support_theme") ?>"/>
							<input class="button  button-large my_action" type="button" data-key="save_style_dialog" value="<?php  echo __("Save Style","my_support_theme") ?>"/>
						</div>
						<?php echo $shVal['html'];?>
					</div>

				<?php
				}?>


			<?php /*global $wp_my_module_forms;
			$c12=0;
			foreach($wp_my_module_forms as $key=>$val){
				?>
				<div class="my_module_shortcodes_form" data-key="<?php echo esc_attr($key)?>" style="<?php if($c12>0)echo 'display:none';?>">
					<?php echo $val;?>
				</div>
				<?php
				$c12++;
			}	*/
			?>
	<?php /*
			</div>
		</div>
		*/ ?>
		<div class="my_container_inner">




		<div class="my_image_mapper_add_new_div my_clearfix">

			<div class="my_image_mapper_image_div my_border_none">
			<div class="my_image_mapper_calculate">
			<ul class="my_radio_inline">
				<li><?php echo __("X","my_support_theme")?> : <span class="my_tmpl_x">0</span></li>
				<li><?php echo __("Y","my_support_theme")?> : <span class="my_tmpl_y">0</span></li>
				<li><?php echo __("Tag","my_support_theme")?> : <span class="my_tmpl_tag"></span></li>
				<li><?php echo __("Element Height","my_support_theme")?> : <span class="my_el_h"></span></li>
				<li><?php echo __("Element Width","my_support_theme")?> : <span class="my_el_w"></span></li>


				<li><?php echo __("Height","my_support_theme")?> : <span class="my_tmpl_h">400px</span></li>
			</ul>
			<ul class="my_radio_inline">

				<li><input type="button" class="button button-primary button-large my_action" data-key="adjust_height" value="<?php echo __("Adjust height","my_support_theme")?>"/></li>
				<li class="my_scrollEdit" style="display:none"><input type="button" class="button button-primary button-large my_action" data-key="edit_dragg" value="<?php echo __("Scrollbar color","my_support_theme")?>"/></li>
				<li class="my_scrollEdit" style="display:none"><input type="button" class="button button-primary button-large my_action" data-key="edit_dragg_line" value="<?php echo __("Scrollbar line Color","my_support_theme")?>"/></li>

				<li class="my_scrollEdit1" style="display:none"><input type="button" class="button button-primary button-large my_action" data-key="edit_dragg1" value="<?php echo __("Scrollbar color","my_support_theme")?>"/></li>
				<li class="my_scrollEdit1" style="display:none"><input type="button" class="button button-primary button-large my_action" data-key="edit_dragg_line1" value="<?php echo __("Scrollbar line Color","my_support_theme")?>"/></li>

	<?php /*
				<li class=""><input type="button" class="button button-primary button-large my_action" data-key="edit_share_box" value="<?php echo __("Edit share box","my_support_theme")?>"/></li>
				<li class=""><input type="button" class="button button-primary button-large my_action" data-key="edit_stars_dialog" value="<?php echo __("Edit stars dialog","my_support_theme")?>"/></li>
				<li class=""><input type="button" class="button button-primary button-large my_action" data-key="edit_view_dialog" value="<?php echo __("Edit view dialog","my_support_theme")?>"/></li>
				*/ ?>
				<li class="my_start_sort"><input type="button" class="button button-primary button-large my_action" data-key="sort" value="<?php echo __("Sort elements","my_support_theme")?>"/></li>
				<li class="my_stop_sort"><input type="button" class="button button-primary button-large my_action" data-key="stop_sort" value="<?php echo __("Stop sort","my_support_theme")?>"/></li>


			</ul>



		</div>
				<?php //echo $template_html; ?>


<div class="my_module_poost_templates_title">
<h4><?php echo __("Preview Template","my_support_theme")?></h4>
</div>
<div class="my_module_post_templates_editor_div_out">
	<div class="my_module_post_templates_editor_div" data-type="" data-id="">

		<div class="my_module_post_templates_editor_div_inner">
				<?php if(empty($renderTemplate)){ ?>
				<div class="my_post_template my_template_custom_new my_post_clear" data-key="template_custom_new" data-post-id=="{post_id}">
				</div>
				<?php }else {
				    echo $renderTemplate;
				
				 }?>
			      
		
			</div>
	</div>
</div>
</div>
			<div class="my_image_mapper_styles_div">
				<?php /*<h4><?php echo __("Shortcodes","my_support_theme")?></h4>*/?>
				<h4><?php echo __("Template Options","my_support_theme")?></h4>
				<?php echo $shortcodes_html;?>
				
				<?php echo $shortcodeSelectHtml;?>
				<div class="my_object_groups">
					<h4><?php echo __("Object Groups Explorer","my_support_theme")?>
						<div class="my_help my_tooltip fa fa-info" style="display:inline-block;">
							<div class="my_content"><?php echo __("You can click here and adjust styles for groups of the elements.","my_support_theme")?></div>
						</div>
					</h4>
					
				</div>
				<div class="my_object_explorere_div my_post_clear">
					<h4><?php echo __("Object Explorer","my_support_theme")?>
						<div class="my_help my_tooltip fa fa-info" style="display:inline-block;">
							<div class="my_content"><?php echo __("You can click on objects to adjust their css.Objects are displayed in templates.View they are organized by children parent first element is first object Template.Click on text to adjust css properties.","my_support_theme")?></div>
						</div>
					</h4>
					<div class="my_object_explorer_parent">
										<div class="my_options_form_object_explorer">

					</div>
					</div>
			<?php /*		
			<div class="my_object_explorer_child">
			<h4><?php echo __("Object Childrens","my_support_theme")?>
					<div class="my_help my_tooltip fa fa-info" style="display:inline-block;">
				<div class="my_content"><?php echo __("This is children objects from parent .When youclick main object this will show objects which can add the styling..","my_support_theme")?></div>

			</h4>
			<div class="my_options_form_object_explorer1">

			</div>
			</div>*/?>
				</div> <!-- OBJECT EXPLORER DIV -->
				<h4><?php echo __("Adjust template Styles","my_support_theme")?>
					<div class="my_help my_tooltip fa fa-info" style="display:inline-block;">
							<div class="my_content"><?php echo __("When you select template or it's child element you can adjust template css.","my_support_theme")?></div>
						</div>
				</h4>
				
				<?php 
				echo $stylesFormHtml;
				?>
			</div>
		</div>
	</div>
