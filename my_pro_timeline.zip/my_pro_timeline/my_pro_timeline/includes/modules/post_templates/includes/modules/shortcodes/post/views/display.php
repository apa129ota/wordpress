<?php
if(!defined('ABSPATH'));
?>
<div class="my_shortcode_select_div">
	<div class="my_post_elements">
<?php /*	
	<ul class="my_shortcode_select_ul my_clearfix">
	<li data-key="<?php echo 'thumb';?>" class="my_background_color my_shortcodes_post_action">
	<h4><?php echo __("Thumb","my_support_theme");?></h4>
	</li></ul>
	<?php $image_sizes=get_intermediate_image_sizes();
	?>
	<select name="my_thumb_size">
		<?php foreach($image_sizes as $key=>$val){?>
		<option value="<?php echo esc_attr($val);?>"><?php echo $val;?>
		<?php }?>
	</select>
	*/ ?>
	<ul class="my_shortcode_select_ul my_clearfix">
<?php 


?>	
<?php foreach($sh['post'] as $key=>$val){?>
	<li data-key="<?php echo $key;?>" class="my_background_color my_shortcodes_post_action">
	<h4><?php echo $val['title']?></h4></li>
	
<?php }?>
	</ul>
	</div>
</div>		
