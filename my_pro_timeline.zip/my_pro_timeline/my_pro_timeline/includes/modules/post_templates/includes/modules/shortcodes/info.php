<?php
if(!defined('ABSPATH'))die('');
$arr=array(
	/*'cols'=>array(
			'title'=>__("Columns","my_support_theme"),
			'tooltip'=>__("Add columns to design","my_support_theme"),
			'icon'=>'fa-columns'
	),*/
    'social_icons'=>array(
        'group'=>'content',
        'title'=>__("Icons","my_support_theme"),
        'tooltip'=>__("Add Icons","my_support_theme"),
        'icon'=>'fa-social'
    ),
    'video'=>array(
        'group'=>'content',
        'title'=>__("Video","my_support_theme"),
        'tooltip'=>__("Add Video","my_support_theme"),
        'icon'=>'fa-film'
    ),
    'list'=>array(
        'group'=>'content',
        'title'=>__("Bullet List","my_support_theme"),
        'tooltip'=>__("Add bullet list","my_support_theme"),
        'icon'=>'fa-bars'
    ),
    /*
    'thumb'=>array(
        'group'=>'',
        'title'=>__("Thumb","my_support_theme"),
        'tooltip'=>__("Add Thumb","my_support_theme"),
        'icon'=>'fa-image'
    ),*/
    'row'=>array(
        'group'=>'',
        'title'=>__("Layouts","my_support_theme"),
        'tooltip'=>__("Add Layouts","my_support_theme"),
        'icon'=>'fa-align-left'
    ),
    /*'text'=>array(
        'group'=>'content',
        'title'=>__("Text","my_support_theme"),
        'tooltip'=>__("Add text","my_support_theme"),
        'icon'=>'fa-align-left'
    ),
	/*
	'post'=>array(
		'group'=>'',
		'title'=>__("Post values","my_support_theme"),
		'tooltip'=>__("Add post values to template","my_support_theme"),
		'icon'=>'fa-plus'
	)*/
	'html'=>array(
		'group'=>'content',
		'title'=>__("Text/Html","my_support_theme"),
		'tooltip'=>__("Add html text","my_support_theme"),
		'icon'=>'fa-align-left'
	),
    'heading'=>array(
        'group'=>'content',
        'title'=>__("Heading","my_support_theme"),
        'tooltip'=>__("Add heading text","my_support_theme"),
        'icon'=>'fa-align-left'
    ),
	'select'=>array(
		'group'=>'',
		'title'=>__("Select Shortcode","my_support_theme"),
		'tooltip'=>__("Select Shortcode","my_support_theme"),
		'icon'=>'fa-code'

	),
	/*'text'=>array(
				'title'=>__("Text","my_support_theme"),
				'tooltip'=>__("Add new text","my_support_theme"),
				'icon'=>'fa-file-text-o'
		),
	'template'=>array(
			'title'=>__("Template","my_support_theme"),
			'tooltip'=>__("Choose new template","my_support_theme"),
			'icon'=>'fa-desktop'
	)*/
);
return $arr;
