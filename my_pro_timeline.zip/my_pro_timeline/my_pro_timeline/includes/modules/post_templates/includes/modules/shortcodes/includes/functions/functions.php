<?php
if(!defined('ABSPATH'))die('');
function wp_my_module_shortcodes_add_options($prop,&$properties,&$arr){
	if(!empty($properties[$prop])){
		foreach($properties[$prop] as $key=>$val){
			$arr['elements'][$key]=$val;
		}
	}
}
