<?php
if (! defined ( 'ABSPATH' ))
	die ( '' );
$optons=array();
$options['layouts'] = array (
		array (
				'title'=>__("Full width","my_support_theme"),
				'layouts' => array (
						100 
				) 
		),
		array (
				'title'=>__("Two halves","my_support_theme"),
				'layouts' => array (
						50,
						50
				) 
		),
		array (
				'title'=>__("Three trids","my_support_theme"),
				'layouts' => array (
						33.3333,
						33.3333,
						33.3333
				)
		),
		array (
				'title'=>__("One thrids Two thrids","my_support_theme"),
				'layouts' => array (
						33.3333,
						66.6666
				)
		),
		array (
				'title'=>__("Two thrids One thrids","my_support_theme"),
				'layouts' => array (
						66.6666,
						33.3333
				)
		),
		
		
		array (
				'title'=>__("Four quarters","my_support_theme"),
				'layouts' => array (
						25,
						25,
						25,
						25 
				) 
		),
		
		array (
				'title'=>__("One quarters Three quarters","my_support_theme"),
				'layouts' => array (
						25,
						75
				)
		),
		array (
				'title'=>__("Three quarters One quarter","my_support_theme"),
				'layouts' => array (
						75,
						25
				)
		),
		array (
				'title'=>__("Two quarters One half","my_support_theme"),
				'layouts' => array (
						25,
						25,
						50
				)
		),
		array (
				'title'=>__("Qarter One half Quarter","my_support_theme"),
				'layouts' => array (
						25,
						50,
						25
				)
		),
		array (
				'title'=>__("One half Two Quarters","my_support_theme"),
				'layouts' => array (
						50,
						25,
						25
				)
		),
		array (
				'title'=>__("One fifth Three fifths One Fifth","my_support_theme"),
				'layouts' => array (
						20,
						60,
						20
				)
		),
		array (
				'title'=>__("One fifth One Fifth Three fifths","my_support_theme"),
				'layouts' => array (
						20,
						20,
						60,
				)
		),
		array (
				'title'=>__("Three fiifths One fifth One Fifth","my_support_theme"),
				'layouts' => array (
						60,
						20,
						20,
				)
		),
		array (
				'title'=>__("Two fifth TTwo fifths One Fifth","my_support_theme"),
				'layouts' => array (
						40,
						40,
						20
				)
		),
		array (
				'title'=>__("One Fifth Two fifths Two fifths","my_support_theme"),
				'layouts' => array (
						20,
						40,
						40,
				)
		),
		array (
				'title'=>__("Two fiifths One fifth Two Fifths","my_support_theme"),
				'layouts' => array (
						40,
						20,
						40,
				)
		),
		/*array (
				'title'=>__("Custom pixels","my_support_theme"),
				'layouts' => array (
						'350px',
						'50px',
				)
		),*/
);

return $options;