<?php
if(!defined('ABSPATH'))die('');
$arr=array(
    'show_el'=>__("Show","my_support_theme"),
    'hide_el'=>__("Hide","my_support_theme"),
    'my_shortcode_list_ul'=>__("List ul","my_support_theme"),
    'my_shortcode_list_li'=>__("List li","my_support_theme"),
    'my_shortcode_list_li_icon'=>__("List icon","my_support_theme"),
    'my_shortcode_list_li_a'=>__("List link","my_support_theme"),
    'my_shortcode_list_li_span'=>__("List text","my_support_theme"),
    'text_is_empty'=>__("Add text to the element","my_support_theme"),
    'trash_item'=>__("Delete Item","my_support_theme")
);
return $arr;