<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_elemenet_section_1 my_post_clear">
	<?php /*
	<h4><a href="#javascript" class="my_transition my_open_section"><i class="fa fa-plus"></i><span><?php echo __("Add Element","my_support_theme") ?></span></a></h4>
				
				<div class="my_section_inside">
				<ul class="my_window_actions">
							<li style="text-align:center"><span><?php echo __("Select Element","my_support_theme")?></span></li>
	*/
	?>
	<ul class="my_window_actions">
	<?php 						
							
							if(!empty($my_shortcodes)){
								foreach($my_shortcodes as $key=>$val){
								?>
								<li class="my_transition"><a href="#javascript" title="<?php echo esc_attr($val['tooltip'])?>" class="my_transition my_add_shortcode" data-key="<?php echo esc_attr($key)?>"><i class="fa <?php echo $val['icon']?>"></i><span><?php echo $val['title'];?></span></a></li>
								<?php 
								}
							}
						?>
					
				</ul>
	
</div>		