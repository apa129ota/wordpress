(function ($) {

  //myproslider: Object Instance
  $.myproslider = function(el, options) {
	var my_slider = $(el);
    var default_settings={
    		debug:true,
    		marginLeft:0,
    		swipeOn:1,
    		thumbsMargin:0,
    		has_timeline:false,
    		thumbs_animation:350,
    		marginAnimation:500,
    		regionWidth:150,
    		st_thumbs_width:40,
    		show_left_right:false,
    		slider_timeline_class:'.my_timeline_hor_list',
    		slider_timeline_l_arrow:'.my_timeline_hor_list_nav_left',
    		slider_timeline_r_arrow:".my_timeline_hor_list_nav_right",
    		animate_dialog_time:2000,
    		line_duration:2000,
    		line_easing:'easeOutQuad',
    		duration:2000,
    		easing:"easeOutQuad",
    		use_touch:true,
    		normal_width:960,
    		tooltip_hide:1000,
    		height:'60%',
    		has_thumbs:false,
    		heights:{
    			800:'70%',
    			600:'100%'
    		},
    		//lay_keys:['1600','1280','980','700',],
    		lay_keys:['700','980','1280','1600'],
    		
    		slider_class:'.my_timeline_hor_out_div'
    			
    };
    my_slider.id=$(my_slider).attr('id');
    my_slider.started = false;
    my_slider.startTimeout = null;
    var settings=$.extend(default_settings,options);
    var gesture = window.navigator && window.navigator.msPointerEnabled && window.MSGesture;
    
    var  touch = (( "ontouchstart" in window ) || gesture || window.DocumentTouch && document instanceof DocumentTouch);
    if(typeof touch=='undefined')touch=false;
    else touch=touch&&settings.use_touch;
    
    my_slider.vars=settings;
    my_slider.vars.hasTouch=touch;
    my_slider.transitions=function() {
          var obj = document.createElement('div'),
              props = ['perspectiveProperty', 'WebkitPerspective', 'MozPerspective', 'OPerspective', 'msPerspective'];
          for (var i in props) {
            if ( obj.style[ props[i] ] !== undefined ) {
              my_slider.pfx = props[i].replace('Perspective','').toLowerCase();
              my_slider.prop = "-" + my_slider.pfx + "-transform";
              return true;
            }
          }
          return false;
        }();
        	
    var div_id='#'+$(el).attr('id');
    my_slider.my_debug=function(t,o){
    	if(settings.debug){
    		if(window.console){
    			console.log('Pro slider :'+t,o);
    		}
    	}
    };
    my_slider.open_dialog_maybe=function(e){
    	//e.preventDefault();
    	var open_link_type=$(this).parents('li').data('open');
    	my_slider.my_debug("open link type",open_link_type);
    	if(typeof open_link_type!='undefined'){
    		if(open_link_type=='dialog'){
    			$(".my_timeline_modal").attr('id',my_slider.id+"_modal");
    			my_slider.dialog_is_open=true;
    			e.preventDefault();
    			my_slider.overflow_css=$("body").css("overflow");
    			my_slider.my_debug('Overrflow',my_slider.overflow_css);
    			$("body").css('overflow','hidden');
    			var v=my_slider.getViewportSize();
    			my_slider.my_debug('Widths',v);
    			var top=$(window).scrollTop();
    			my_slider.vars_12=v;
    			//$(".my_timeline_modal").css('top',top+'px');
    			//$(".my_timeline_modal").width(v.w);
    			$(".my_timeline_modal").height(v.h); 			
    			$(".my_timeline_modal").find(".my_timeline_modal_load").hide();
    			$(".my_timeline_modal").find(".my_timeline_modal_loading").show();
    			if(my_slider.transitions){
    				$(".my_timeline_modal").css(my_slider.prop,'center center');
        					
    				$(".my_timeline_modal").css(my_slider.prop,'scale(0)');
    				$(".my_timeline_modal").css('opacity',0);
    				$(".my_timeline_modal").show();
    				//$(".my_timeline_modal").css(my_slider.prop+'-transform','scale(1)');
    				
    				//$(".my_timeline_modal").css(my_slider.prop+'-transition-duration','1s;');
    				$(".my_timeline_modal").animate({
						my_scale:1,
						opacity:1
					},{
						step:function(now,fx){
							//fx.start=0;
							if(fx.prop=='my_scale'){
								//my_admin_debug("Now",now);
								my_trans=my_slider.prop;
								$(this).css(my_trans,'scale('+now+')');	
							}
						}
					,duration:my_slider.vars.animate_dialog_time});
    				
    			}else {
    				$(".my_timeline_modal").fadeIn();
    			}
    			var post_id=$(this).data('post-id');
    			var post_type=$(this).data('post-type');
    			var data={
    					action:my_slider.vars.ajax_action,
    					post_id:post_id,
    					post_type:post_type,
    					nonce:my_slider.vars.ajax_nonce,
    					timeline_id:my_slider.vars.id
    			}
    			my_slider.my_debug("Get post",data);
    			$.ajax({
    				url:my_slider.vars.ajax_url,
    				dataType:'json',
    				cache:false,
    				timeout:my_slider.vars.ajax_timeout,
    				type:'POST',
    				data:data,
    				success:function(data){
    					
    					$(".my_timeline_modal").find(".my_timeline_modal_load").html(data.html);
    					/*$(".my_timeline_modal").find(".my_timeline_modal_load").fadeIn(function(){
    						
    					});*/
    	    			$(".my_timeline_modal").find(".my_timeline_modal_loading").fadeOut(function(){
    	    				$(".my_timeline_modal").find(".my_timeline_modal_load").fadeIn(function(){
    	    					var ht=$(".my_timeline_modal").find(".my_timeline_modal_title").outerHeight();
    	    	    			var ot=my_slider.vars_12.h;
    	    	    			var p=ot-ht;
    	    	    			$(".my_timeline_modal").find(".my_timeline_modal_load").height(p);
    	    	    			
    	    	    			//if(typeof is=='undefined'){
    	    	    			setTimeout(function(){
    	    	    				$(".my_timeline_modal").find(".my_timeline_modal_load").mCustomScrollbar(
    	    	    	    				{axis:'y',
    	    	    	    				advanced:{
    	    	    	    					updateOnContentResize:true
    	    	    	    					}});
    	    	    			},400);
    	    	    			
    	    				});
        	    			
    	    			});
    	    			var ht=$(".my_timeline_modal").find(".my_timeline_modal_title").outerHeight();
    	    			var ot=my_slider.vars_12.h;
    	    			var p=ot-ht;
    	    			$(".my_timeline_modal").find(".my_timeline_modal_load").height(p);
    	    			
    	    			//if(typeof is=='undefined'){
    	    				$(".my_timeline_modal").find(".my_timeline_modal_load").mCustomScrollbar(
    	    	    				{axis:'y',
    	    	    				advanced:{
    	    	    					updateOnContentResize:true
    	    	    					}});
    	    				//$(".my_timeline_modal").find(".my_timeline_modal_load").data('is-m',1);
    	    				
    	    			/*}else {
    	    				$(".my_timeline_modal").find(".my_timeline_modal_load").mCustomScrollbar('update');
    	    			}*/
    				},
    				error:function(){
    					alert('Error');
    				}
    			});
    			
    		}
    	}
    };
    $(document).on('click','.my_timeline_item .my_timeline_open_link',my_slider.open_dialog_maybe);
    $(document).on('click','.my_timeline_modal_close',function(e){
    	e.preventDefault();
    	if(my_slider.transitions){
			
			//$(".my_timeline_modal").css(my_slider.prop+'-transform','scale(0)');
			
    		//$(".my_timeline_modal").css(my_slider.prop+'-transition-duration','1s;');
			//$(".my_timeline_modal").css(my_slider.prop+'-transform','scale(0)');
			/*setTimeout(function(){
				$(".my_timeline_modal").show();
				$("body").css('overflow',my_slider.overflow_css);
    			
			},1200);*/
    		$(".my_timeline_modal").animate({
				my_scale:0,
				opacity:0
			},{
				step:function(now,fx){
					//fx.start=0;
					if(fx.prop=='my_scale'){
						//my_admin_debug("Now",now);
						my_trans=my_slider.prop;
						$(this).css(my_trans,'scale('+now+')');	
					}
				}
			,duration:my_slider.vars.animate_dialog_time,complete:function(){
				$(this).hide();
				my_slider.dialog_is_open=false;
				$(".my_timeline_modal").find(".my_timeline_modal_load").mCustomScrollbar('destroy');
				$(".my_timeline_modal").find(".my_timeline_modal_load").css('height','');
				$(".my_timeline_modal").find(".my_timeline_modal_load").hide();
			}
    	}
    		);
			
			
		}else {
			$(".my_timeline_modal").fadeOut(1000,function(){
				//$("body").css('overflow',my_slider.overflow_css);
				my_slider.dialog_is_open=false;
				$(".my_timeline_modal").find(".my_timeline_modal_load").mCustomScrollbar('destroy');
				$(".my_timeline_modal").find(".my_timeline_modal_load").css('height','');
				$(".my_timeline_modal").find(".my_timeline_modal_load").hide();
			});
		}
    });
    my_slider.my_debug('Settings',settings);
    my_slider.my_debug('TRansforms',{t:my_slider.transitions,pfx:my_slider.pfx,prop:my_slider.prop});
    my_slider.my_debug('Touch',touch);
    //var has_timeline=false;
    if($(my_slider).find(settings.slider_timeline_class).length>0){
    	my_slider.vars.has_timeline=true;
    }
    my_slider.init_timeline_line=function(){
    	var w=$(my_slider).find(settings.slider_timeline_class).outerWidth();
    	var m_l=$(my_slider).find(settings.slider_timeline_class+" ul li.my_timeline_month").css('margin-left');
    	m_l=parseFloat(m_l)*2;
    	var w1=w-m_l;
    	my_slider.t_width=w;
    	my_slider.t_inner_w=w1;
    	$(my_slider).find(settings.slider_timeline_class +' .my_timeline_month').width(w1);
    	var c=$(my_slider).find(settings.slider_timeline_class +' ul > li.my_timeline_month').length;
    	var w2=c*w;
    	$(my_slider).find(settings.slider_timeline_class+' ul ').width(w2);
    	var h=$(my_slider).find(settings.slider_timeline_class+' ul li ').outerHeight();
    	var h2=$(my_slider).find(my_slider.vars.slider_timeline_l_arrow).height();
    	var h1=h-(h2/2);
    	my_slider.my_debug('Arrows height',{m_l:m_l,h:h,h1:h1,h2:h2});
    	//change 11 2 2015 set top
    	var my_test_top=(h2/2)+2;
    	
    	h1=my_test_top;
    	$(my_slider.vars.slider_timeline_l_arrow).css('top',h1+'px');
    	$(my_slider.vars.slider_timeline_r_arrow).css('top',h1+'px');
    	/*var hp=$(my_slider.vars.slider_timeline_class+" .my_post_item").outerHeight();
    	var of=$(my_slider).find(".my_timeline_hor_list_line").offset().top;
    	of-=hp/2;
    	$(my_slider.vars.slider_timeline_class+" .my_post_item").css('top',of+'px');
    	*/
    	
    };
    my_slider.getViewportSize=function() {

        // Use the specified window or the current window if no argument
    	var w=window;
    	/*if(my_slider.vars.preview){
    		var iframes = window.frames
        	w=iframes[0].window;
        }*/
    	

        // This works for all browsers except IE8 and before
        if (w.innerWidth != null) return { w: w.innerWidth, h: w.innerHeight };

        // For IE (or any browser) in Standards mode
        var d = w.document;
        if (document.compatMode == "CSS1Compat")
            return { w: d.documentElement.clientWidth,
               h: d.documentElement.clientHeight };

        // For browsers in Quirks mode
        return { w: d.body.clientWidth, h: d.body.clientHeight };

    };
    my_slider.init_scroll=function(){
    	
    	var is=$(my_slider).find(".my_timeline_content").data('is-scroll-init');
    	my_slider.my_debug("Is init custom scroll bar",is);
    	if(typeof is=='undefined'){
    		my_slider.my_debug('Init scrolls');
    		$(my_slider).find(".my_timeline_text").mCustomScrollbar(
    				{axis:'y',
    				advanced:{
    					updateOnContentResize:true
    					}});
    		$(my_slider).find(".my_timeline_content").data('is-scroll_init',1);
    	}else {
    		//$(my_slider).find(".my_timeline_text").mCustomScrollbar('update');
    	}
    };
    my_slider.touch=function(){
    	if(my_slider.touch){
            var startX,
              startY,
              offset,
              cwidth,
              dx,
              startT,
              onTouchStart,
              onTouchMove,
              onTouchEnd,
              scrolling = false,
              localX = 0,
              localY = 0,
              accDx = 0;

           
                onTouchStart = function(e) {
                  if (my_slider.working) {
                    e.preventDefault();
                  }else {
                	  my_slider.my_debug('E',e);
                	  cwidth = my_slider.width;
                      startT = Number(new Date());
                      // CAROUSEL:

                      // Local vars for X and Y points.
                      localX = e.originalEvent.touches[0].pageX;
                      localY = e.originalEvent.touches[0].pageY;
                      startX = localX;
                      startY =localY;

                	  $(my_slider).find(".my_timeline_hor_out_div").on('touchmove',onTouchMove);
                	  $(my_slider).find(".my_timeline_hor_out_div").on('touchend',onTouchEnd);
                	  my_slider.my_debug('Touch start',{localX:localX,localY:localY});
                  } 
                };
                onTouchMove = function(e) {
                  // Local vars for X and Y points.

                  localX = e.originalEvent.touches[0].pageX;
                  localY = e.originalEvent.touches[0].pageY;

                  dx = startX - localX;
                  scrolling = (Math.abs(dx) < Math.abs(localY - startY));;
                  my_slider.my_debug('Touch start',{localX:localX,localY:localY});	
                  var fxms = 500;

                  if ( !scrolling || Number( new Date() ) - startT > fxms ) {
                    e.preventDefault();
                    dx = dx/((my_slider.start_item === 1 && dx < 0 || my_slider.start_item === my_slider.total_items && dx > 0) ? (Math.abs(dx)/cwidth+2) : 1);
                    my_slider.my_debug("Touch move",dx);  
                    
                    }
                  
                };

                onTouchEnd = function(e) {
                  // finish the touch by undoing the touch session
                  //el.removeEventListener('touchmove', onTouchMove, false);
                	$(my_slider).find(".my_timeline_hor_out_div").unbind('touchmove',onTouchMove);		
                  if (!scrolling && !(dx === null)) {
                	  if(dx>0){
                		  my_slider.go_next();
                	  }else {
                		  my_slider.go_prev();
                	  }
                  }
                  $(my_slider).find(".my_timeline_hor_out_div").unbind('touchend',onTouchEnd);
                  startX = null;
                  startY = null;
                  dx = null;
                  offset = null;
                };

                $(my_slider).find(".my_timeline_hor_out_div").on('touchstart', onTouchStart);
                
    	}
    };
    my_slider.set_widths=function(){
    	var cols=my_slider.layout.cols;
    	var w=$(my_slider).find(my_slider.vars.slider_class).parent('div').width();
    	my_slider.my_debug("Width",w);
    	var w1=w/cols;
    	var perc=(100/cols)*(my_slider.total_items+10);
    	$(my_slider).find(my_slider.vars.slider_class +" >ul").css('width',perc+'%');
    	var p=$(my_slider).find(my_slider.vars.slider_class+" > ul > li ").css('padding-right');
    	p=parseFloat(p);
    	w1=w1-2*p;
    	my_slider.item_width=w1+2*p;//$(my_slider).find(my_slider.vars.slider_class+" > ul > li ").outerWidth();
    	my_slider.my_debug('Width',{w:w,w1:w1,p:p,id:my_slider.vars.id});
    	$(my_slider).find(my_slider.vars.slider_class +" > ul > li ").width(w1);
    	
    	//set thumbs
    	var str_sel=".my_testimonal_thumbs_div[data-id='"+my_slider.vars.id+"']";
    	var l=$(str_sel).length;
    	
    	
    	my_slider.my_debug('Has thumbs',{l:l,str_sel:str_sel});
    	str_sel+=" > div ";
    	if(l>0){
    		my_slider.vars.has_thumbs=true;
    		$(str_sel).css({overflow:'hidden',width:w});
    		var h=$(str_sel+" .my_testimonial_thumbs_ul ").height();
    		my_slider.my_debug('Height thumbs set height',{h:h});
    		//$(str_sel).height(h);
    		var c1=$(str_sel).attr('data-count');
    		var perc=(c1/8+10)*100;
    		var wt=w/8;
    		var totalCols=8;
    		if(w<600){
    			perc=(c1/4+10)*100;
    			wt=w/4;
    			totalCols=4;
    		}
    		if(wt<158){
    			wt=160;
    			perc=(w%wt+10)*100;
    			var c1=Math.floor(w/wt);
    			var c12=(w-c1*wt)/4;
    			wt+=c12;
    			var c2=w/wt;
    			if(c2>c1){
    				wt=w/c1;
    				perc=((w/wt)+10)*w/c1;
    			}
    			totalCols=c1;
    		}
    		my_slider.vars.thumbs_cols=totalCols;
    		
    		my_slider.vars.thumbs_width=wt;
    		my_slider.my_debug('Perc',perc);
    		$(str_sel+" > ul > li ").css('width',wt+'px');
    		$(str_sel+" > ul").css('width',perc+'%');
    	}
    	
    };
    my_slider.getLayout=function(){
    	var vars=my_slider.vars.lay_keys;//:['1280','980','700','small'],700,980
    	var w=my_slider.width;
    	my_slider.my_debug("Slider width",w);
    	var my_found=false;
    	$.each(vars,function(i,v){
    		var v1=parseFloat(v);
    		my_slider.my_debug("Check lkayout",v1);
    		
    		if(w<v1){
    			my_slider.my_debug("return",v1);
        		
    			return false;
    		}
    		if(w>=v1){
    			
    			my_slider.my_debug("Assign layout",{v1:v1,lay:my_slider.vars.layout[v]});
        		
    			my_found=true;
    			my_slider.layout=my_slider.vars.layout[v];
    			//return false;
    		}
    		
    	});
    	if(!my_found){
    		my_slider.layout=my_slider.vars.layout['small'];
    		
    	}
    	my_slider.my_debug("Layout",my_slider.layout);
    };
    my_slider.set_height=function(){
    	
    	var v=my_slider.getViewportSize();
    	my_slider.my_debug('View port size',v);
    	var hp=my_slider.layout.height;
    	/*
    	var hp=my_slider.vars.height;
    	if(v.w<my_slider.vars.normal_width){
    		/*var hs1=my_slider.vars.heeights;
    		$.each(hs1,function(i,v){
    			if(i<v.w){
    				return false;
    			}else {
    				hp=v;
    			}
    		});*/
    	//}
    	
    	var hp_p=parseFloat(hp);
    	var h=0;
    	my_slider.my_debug('Height',hp_p);
    	
    	if(hp.indexOf('%')!==-1){
    			h=v.h*(hp_p/100);
    		
    	}else {
    		h=hp_p;
    	}
    	my_slider.my_debug('Set height',h);
    	//var ht=$(my_slider).find(".my_timeline_text").height();
    	//my_slider.my_debug('Height timeline',ht);
    	//h+=10;
    	$(my_slider).find(my_slider.vars.slider_class).height(h);
    	 my_slider.set_test_height();
    	//$(my_slider).find(".my_timeline_slider_nav").height(h);
    	//var emh_l=$(my_slider).find(".my_timeline_slider_nav i").outerHeight();
    	//var pt_12=(h-emh_1)/2;
    	//$(my_slider).find(".my_timeline_slider_nav i").css('')
    	/*var t1=$(my_slider).find(".my_timeline_header").outerHeight();
    	var t2=$(my_slider).find(".my_timeline_media").outerHeight();
    	var t4=$(my_slider).find(".my_timeline_item").css('padding-top');
    	var t6=$(my_slider).find(".my_timeline_item").css('padding-bottom');
    	
    	var t5=$(my_slider).find(".my_timeline_text").css('margin-top');
    	t4=parseFloat(t4);
    	t5=parseFloat(t5);
    	t6=parseFloat(t6);
    	var t3=h-t1-t2-t4-t5-t6;
    	
    	my_slider.my_debug('Height timeline',{t1:t1,t2:t2,t3:t3,t4:t4,t5:t5,t6:t6});
    	
    	$(my_slider).find(".my_timeline_text").height(t3);
    	 my_slider.init_scroll();
    	 */
    };
    my_slider.set_test_height=function(){
    	if(my_slider.vars.form.show_thumbs==1){
    		my_slider.my_debug("Set thumbs");
    		var sel_thumbs=".my_testimonial_thumbs_div[data-id='"+my_slider.vars.id+"'] .my_testimonial_thumbs";
    		var h=$(sel_thumbs+" > ul ").height();
    		$(sel_thumbs).height(h);
    		var w=$(sel_thumbs).width();
    		var cols=8;
    		if(w<600){
    			cols=4;
    		}
    		
    		var count=$(sel_thumbs).data('count');
    		var wperc=100/cols*count+200;
    		my_slider.my_debug("Set thumbs params",{h:h,w:w,cols:cols,count:count,wperc:wperc});
    		
    		$(my_slider).siblings(sel_thumbs+" > ul").css('width',wperc+'%');
    		
    	}
    	$("#my_timeline_"+my_slider.vars.id+" .my_testimonial_item").each(function(i,v){
			var h=$(v).height();
			my_slider.my_debug('Height item',h);
			var w=$(v).width();
			var th_w=$(v).find(".my_testimonial_thumb").width();
			var th_h=$(v).find(".my_testimonial_thumb").height();
			my_slider.my_debug("Thumb",{w:th_w,h:th_h});
			var paddp=$(v).css('padding-top');
			paddp=parseInt(paddp);
			var float=$(v).data('float');
			if($(v).hasClass('my_testimonial_top') || $(v).hasClass('my_testimonial_bottom') || $(v).hasClass("my_testimonial_center_bottom") ||$(v).hasClass("my_testimonial_center_top")){
				var h1=$(v).find(".my_testimonial_meta_div").outerHeight();
				var padd=$(v).find(".my_testimonial_p").css('padding-top');
				/*if($(v).hasClass("my_testimonial_center_top")){
					padd=$(v).find(".my_testimonial_p").css('padding-bottom');
				}*/
				padd=parseInt(padd);
				var margin=0;
				if($(v).find(".my_testimonial_thumb_div").hasClass("my_testimonials_thumb_left")){
					margin=$(v).find(".my_testimonial_thumb_div").css('margin-left');
				}else {
					margin=$(v).find(".my_testimonial_thumb_div").css('margin-right');
				}
				margin=parseInt(margin);
				my_slider.my_debug('Height meta div',{w:w,h1:h1,padd:padd,margin:margin});
				
				//var li_w=w-margin-th_w;
				//my_slider.my_debug('Height meta div',{w:w,li_w:li_w,margin:margin});
				
				//$(v).find(".my_testimonials_metadata >li").width(li_w);
				//my_slider.my_debug('Height meta div',h1);
				//my_slider.my_debug('Padd',padd);
				
				var h2=h-h1-2*padd;//-2*paddp;
				//my_slider.my_debug('Height text item',h2);
				
				$(v).find(".my_testimonial_text").height(h2);
			}else {
				
			}
			var is_mc=$(v).find(".my_testimonial_p").attr('my-c');
			if(typeof is_mc=='undefined'){
				$(v).find(".my_testimonial_p").mCustomScrollbar({
				    axis:"y" // horizontal scrollbar
				});
				$(v).attr('my-c',1);
			}
    	});
    };
    my_slider.media_over=function(e){
    	var color=$(this).find('.my_timeline_media_overlay').css('background-color');
    	$(this).find(".my_timeline_media_icon").finish();
    	$(this).find('.my_timeline_media_overlay').finish();
    	if(color.indexOf('rgba')!==0){
    		$(this).find('.my_timeline_media_overlay').animate({opacity:0.4});
    	}else {
    		$(this).find('.my_timeline_media_overlay').animate({opacity:1});
    	}
    		$(this).find(".my_timeline_media_icon").animate({bottom:'50%',opacity:1});
    	
    	//$(this).;
    };
    my_slider.media_out=function(e){
    	//var target=e.target;
    	//my_slider.my_debug('Target')
    	//if($(target).hasClass("my_timeline_media_icon"))return;
    	$(this).find(".my_timeline_media_icon").finish();
    	$(this).find('.my_timeline_media_overlay').finish();
    	$(this).find('.my_timeline_media_overlay').animate({opacity:0});
    	$(this).find(".my_timeline_media_icon").animate({bottom:'0px',opacity:0});
    	
    };
    my_slider.line_nav=function(e){
    	dir='left';
    	if($(this).hasClass('my_timeline_hor_list_nav_right')){
    		dir='right';
    	}
    	var curr=my_slider.vars.current_line;
    	var c=my_slider.vars.hor.length;
    	var w=my_slider.t_width;
    	my_slider.my_debug("Line nav",{dir:dir,curr:curr,c:c,w:w});
    	if(dir=='left'&&curr==1)return;
    	if(dir=='right'&&c==curr)return;
    	var options={duration:my_slider.vars.line_duration,easing:my_slider.vars.line_easing};
    	my_slider.my_debug("Options",options);
    	
    	if(dir=='left'){
    		my_slider.vars.current_line--;
    		$(my_slider).find(".my_timeline_hor_list_ul").animate({'margin-left':'+='+w},options);
    	}else {
    		my_slider.vars.current_line++;
    		$(my_slider).find(".my_timeline_hor_list_ul").animate({'margin-left':'-='+w},options);
    		
    	}
    	
    	
    };
    my_slider.go_next=function(){
    	//if(my_slider.working)return;
    	//my_slider.working=true;
    	var start_item=1;
    	if(typeof my_slider.start_item!='undefined'){
    		start_item=my_slider.start_item;
    	}
    	var total=my_slider.total_items;
    	var diff=1;
    	var diff_m=Math.abs(diff)*my_slider.item_width;
    	if(start_item<total){
    		var i=start_item+1;
    		my_slider.go_to(i);
    		/*my_slider.start_item++;
        	$post=$(my_slider).find(".my_timeline_hor_ul li[data-pos='"+i+"']");
        	//$(".my_slider .my_post_item").removeClass("my_timeline_current");
        	//$post.find(".my_post_item").addClass('my_timeline_current');
        	$(my_slider).find(".my_timeline_item").removeClass("my_timeline_current");
        	//$post.find(".my_post_item").addClass('my_timeline_current');
        	$($post).find(".my_timeline_item").addClass('my_timeline_current');
        	
    		$(my_slider).find(".my_timeline_hor_ul").animate({'margin-left':"-="+diff_m},my_slider.vars.duration,function(){
    			my_slider.working=false;
    	    	
    		});
    		*/
    	}
    	
    };
    my_slider.go_prev=function(){
    	//if(my_slider.working)return;
    	//my_slider.working=true;
    	var start_item=1;
    	if(typeof my_slider.start_item!='undefined'){
    		start_item=my_slider.start_item;
    	}
    	var total=my_slider.total_items;
    	var diff=1;
    	var diff_m=Math.abs(diff)*my_slider.item_width;
    	
    	if(start_item>1){
    		var i=start_item-1;
    		my_slider.go_to(i);
    		/*
    		my_slider.start_item--;
        	$post=$(my_slider).find(".my_timeline_hor_ul li[data-pos='"+i+"']");
        	//$(".my_slider .my_post_item").removeClass("my_timeline_current");
        	//$post.find(".my_post_item").addClass('my_timeline_current');
        	$(my_slider).find(".my_timeline_item").removeClass("my_timeline_current");
        	//$post.find(".my_post_item").addClass('my_timeline_current');
        	$($post).find(".my_timeline_item").addClass('my_timeline_current');
        	
    		$(my_slider).find(".my_timeline_hor_ul").animate({'margin-left':"+="+diff_m},my_slider.vars.duration,function(){
    			my_slider.working=false;
    	    	
    		});
    		*/
    	}
    	
    };
    my_slider.adjust_left_right_thumbs=function(){
    	if(my_slider.vars.show_left_right){
    	var itemClass='#my_timeline_'+my_slider.vars.id+ ' .my_testimonial_next_left  div div ';
    	var iconClass='#my_timeline_'+my_slider.vars.id+ ' .my_nav_left';
    	var type=my_slider.vars.type_hover;
    	var curr_item=my_slider.vars.current_item;
    	//var itemPos=my_slider;
    	my_slider.my_debug("curr item",{curr:curr_item,type:type});
    	var $myPos='margin-left:84px;border-radius:50%;';
    	if(type=='left'){
    		if(curr_item==1){
    			my_slider.hide_next_prev();
    			
    			return;
    		}else {
    			itemPos=curr_item-1;	
    		}
    	}else {
    		$myPos="margin-left:84px;border-radius:50%;";
    		itemClass='#my_timeline_'+my_slider.vars.id+' .my_testimonial_next_rigth div div';
    		iconClass='#my_timeline_'+my_slider.vars.id+' .my_nav_right';
    		marginLeft='20px';
    		if(curr_item==(my_slider.total_items)){
    			my_slider.hide_next_prev();
    			return;
    		}else {
    			itemPos=curr_item+1;
    		}
    	}
    	var str=itemPos+'/'+my_slider.total_items;
    	my_slider.vars.my_item_pos_str=str;
    	$(iconClass).find(".my_nav_item").html(str);
    	var img=$(my_slider).find("li[data-pos='"+itemPos+"'] img").attr('src');
    	var html='<img class="newItem" style="'+$myPos+'" src="'+img+'" width="80px" height="80px" />';
    	if(type=='left'){
    		$(itemClass+" ").append(html);
    		setTimeout(function(){
    		$(itemClass).find("img.oldItem").animate({'margin-left':'-84px'},my_slider.vars.marginAnimation,function(){
    			$(this).remove();
    		});
    		my_slider.my_debug("Margin left",$(itemClass).find("img.newItem").css('margin-left'));
    		
    		$(itemClass).find("img.newItem").animate({'margin-left':'-=84px'},my_slider.vars.marginAnimation,function(){
    			my_slider.my_debug("Margin left",$(itemClass).find("img.newItem").css('margin-left'));
    			$(this).attr('class','oldItem');
    			
        			
    		});
    		},100);
    	}else {
    		$(itemClass+" ").append(html);
    		setTimeout(function(){
        		
    		$(itemClass).find("img.oldItem").animate({'margin-left':'-84px'},my_slider.vars.marginAnimation,function(e){
    			$(this).remove();
    		});
    		$(itemClass).find("img.newItem").animate({'margin-left':'-=84px'},my_slider.vars.marginAnimation,function(){
    			my_slider.my_debug("Margin left",$(itemClass).find("img.newItem").css('margin-left'));
    			
    			$(this).attr('class','oldItem');
    			
    		});}
    		,100);
    	}
    	
    	
    	}
    	
    };
    my_slider.goToMarginThumbs=function(i){
    	//if(my_slider.working)return;
    	//my_slider.working=true;
    	var start_item=1;
    	if(typeof my_slider.start_item!='undefined'){
    		start_item=my_slider.start_item;
    	}
    	var diff=i-start_item;
    	var diff_m=Math.abs(diff)*my_slider.vars.thumbs_width;
    	var marginLeft=parseInt($("#my_testimonials_thumbs_12_"+my_slider.vars.id+" .my_testimonial_thumbs_ul").css('margin-left'));
    	var endMarginLeft;
    	
    	if(i>0){
    		
    		endMarginLeft=-(i-1)*my_slider.vars.thumbs_width;
    	}else {
    		endMarginLeft=0;
    	}
    	var diffMargin;
    	diffMargin=Math.abs(endMarginLeft-marginLeft);
    	var multiply = diffMargin/my_slider.vars.thumbs_width;
    	var speed=parseInt(my_slider.vars.thumbs_animation);
    	speed*=(1+(1/5)*(multiply-1));
    	my_slider.my_debug("Got to pos margin",{multiply:multiply,speed:speed,i:i,start_item:start_item,marginLeft:marginLeft,endMarginLeft:endMarginLeft,diffMargin:diffMargin});
    	//$post=$(my_slider).find(".my_timeline_hor_ul li[data-pos='"+i+"']");
    	//$(my_slider).find(".my_timeline_item").removeClass("my_timeline_current");
    	//$post.find(".my_post_item").addClass('my_timeline_current');
    	//$($post).find(".my_timeline_item").addClass('my_timeline_current');
    	if(diff<0){
    		
    		$("#my_testimonials_thumbs_12_"+my_slider.vars.id+" .my_testimonial_thumbs_ul").animate({'margin-left':"+="+diffMargin},speed,my_slider.vars.easing,function(){
    			my_slider.working=false;
    			my_slider.vars.marginLeft=parseInt($(this).css('margin-left'));
    			
    		});
    	}else {
    		$("#my_testimonials_thumbs_12_"+my_slider.vars.id+" .my_testimonial_thumbs_ul").animate({'margin-left':"-="+diffMargin},speed,my_slider.vars.easing,function(){
    			my_slider.working=false;
    			my_slider.vars.marginLeft=parseInt($(this).css('margin-left'));
    	    	
    		});
    		
    	}
    	my_slider.go_to(i);
    	/*if(my_slider.vars.has_thumbs){
    		my_slider.my_debug("Go to thumbs",i);
    		my_slider.go_thumbs(i);
    	}
    	my_slider.vars.current_item=i;
    	my_slider.start_item=i;
    	my_slider.adjust_left_right_thumbs();
    	*/
    };
    
    my_slider.goToMargin=function(i){
    	if(my_slider.working)return;
    	my_slider.working=true;
    	var start_item=1;
    	if(typeof my_slider.start_item!='undefined'){
    		start_item=my_slider.start_item;
    	}
    	var diff=i-start_item;
    	var diff_m=Math.abs(diff)*my_slider.item_width;
    	var marginLeft=parseInt($(my_slider).find(".my_timeline_hor_ul").css('margin-left'));
    	var endMarginLeft;
    	
    	if(i>0){
    		
    		endMarginLeft=-(i-1)*my_slider.item_width;;
    	}else {
    		endMarginLeft=0;
    	}
    	var diffMargin;
    	diffMargin=Math.abs(endMarginLeft-marginLeft);
    	var multiply = diffMargin/my_slider.item_width;
    	var speed=parseInt(my_slider.vars.duration);
    	speed*=(1+(1/5)*(multiply-1));
    	my_slider.my_debug("Got to pos margin",{multiply:multiply,speed:speed,i:i,start_item:start_item,marginLeft:marginLeft,endMarginLeft:endMarginLeft,diffMargin:diffMargin});
    	$post=$(my_slider).find(".my_timeline_hor_ul li[data-pos='"+i+"']");
    	$(my_slider).find(".my_timeline_item").removeClass("my_timeline_current");
    	//$post.find(".my_post_item").addClass('my_timeline_current');
    	$($post).find(".my_timeline_item").addClass('my_timeline_current');
    	if(diff<0){
    		
    		$(my_slider).find(".my_timeline_hor_ul").animate({'margin-left':"+="+diffMargin},speed,my_slider.vars.easing,function(){
    			my_slider.working=false;
    			my_slider.vars.marginLeft=parseInt($(this).css('margin-left'));
    			
    		});
    	}else {
    		$(my_slider).find(".my_timeline_hor_ul").animate({'margin-left':"-="+diffMargin},speed,my_slider.vars.easing,function(){
    			my_slider.working=false;
    			my_slider.vars.marginLeft=parseInt($(this).css('margin-left'));
    	    	
    		});
    		
    	}
    	if(my_slider.vars.has_thumbs){
    		my_slider.my_debug("Go to thumbs",i);
    		my_slider.go_thumbs(i);
    	}
    	my_slider.vars.current_item=i;
    	my_slider.start_item=i;
    	my_slider.adjust_left_right_thumbs();
    	
    };
    my_slider.go_to=function(i){
    	if(my_slider.working)return;
    	
    	/**
    	 * Adjust show thumbs on transition
    	 */
    	my_slider.working=true;
    	var start_item=1;
    	if(typeof my_slider.start_item!='undefined'){
    		start_item=my_slider.start_item;
    	}
    	var diff=i-start_item;
    	var diff_m=Math.abs(diff)*my_slider.item_width;
    	$post=$(my_slider).find(".my_timeline_hor_ul li[data-pos='"+i+"']");
    	$(my_slider).find(".my_timeline_item").removeClass("my_timeline_current");
    	//$post.find(".my_post_item").addClass('my_timeline_current');
    	$($post).find(".my_timeline_item").addClass('my_timeline_current');
    	var multiply = diff_m/my_slider.item_width;
    	var speed=parseInt(my_slider.vars.duration);
    	speed*=(1+1/5*(multiply-1));
    	my_slider.my_debug("Got to",{multiply:multiply,speed:speed,i:i});
    	if(diff<0){
    		
    		$(my_slider).find(".my_timeline_hor_ul").animate({'margin-left':"+="+diff_m},speed,my_slider.vars.easing,function(){
    			my_slider.working=false;
    			my_slider.vars.marginLeft=parseInt($(this).css('margin-left'));
    			
    		});
    	}else {
    		
    		$(my_slider).find(".my_timeline_hor_ul").animate({'margin-left':"-="+diff_m},speed,my_slider.vars.easing,function(){
    			my_slider.working=false;
    			my_slider.vars.marginLeft=parseInt($(this).css('margin-left'));
    	    	
    		});
    	}
    	if(my_slider.vars.has_thumbs){
    		my_slider.my_debug("Go to thumbs",i);
    		my_slider.go_thumbs(i);
    	}
    	my_slider.vars.current_item=i;
    	my_slider.start_item=i;
    	my_slider.adjust_left_right_thumbs();
    	
    };
    my_slider.go_thumbs=function(i){
    	var start_item=1;
    	if(typeof my_slider.thumb_start_item!='undefined'){
    		start_item=my_slider.thumb_start_item;
    	}
    	var diff=i-start_item;
    	var str_sel=".my_testimonal_thumbs_div[data-id='"+my_slider.vars.id+"'] .my_testimonial_thumbs_ul";
    	var diff_m=Math.abs(diff)*my_slider.vars.thumbs_width;
    	my_slider.my_debug("go to id thumbs",{i:i,diff:diff,start_item:start_item,diff_m:diff_m});
    	my_slider.thumb_start_item=i;
    	var multiply = diff_m/my_slider.item_width;
    	var speed=parseInt(my_slider.vars.duration);
    	speed*=(1+1/5*(multiply-1));
    	my_slider.my_debug("Got to thumbs",{multiply:multiply,speed:speed,i:i});
    	if(diff<0){
    		$(str_sel).animate({'margin-left':"+="+diff_m},speed,my_slider.vars.easing,function(){
    			//my_slider.working=false;
    			my_slider.vars.thumbsMargin=parseInt($(this).css('margin-left'));
    			
    			
    		});
    	}else {
    		$(str_sel).animate({'margin-left':"-="+diff_m},speed,my_slider.vars.easing,function(){
    			//my_slider.working=false;
    			my_slider.vars.thumbsMargin=parseInt($(this).css('margin-left'));
    		});
    	}
    	
    	
    };
    my_slider.show_tooltip=function(e){
    	//var $el=$(this).parents(".my_post_item");
    	//if($(".my_timeline_line_box").is(":visible"))return;
    	var v=my_slider.getViewportSize();
    	clearTimeout(my_slider.tooltip_timeout);
    	/*if(my_slider.vars.preview){
    		var w=200;
        	var h=100;
    		var diff=10;
        	var diff_1=$(my_slider).find(".my_post_item i").width();
    		var top=$(this).offset().top;
        	var left=$(this).offset().left;
        	has_pos='bottom';
			new_left=left-w/2+diff_1/2;
			new_top=top+diff;
			pos_class='my_timeline_top_arrow';
    	}else {*/
    	var w=200;
    	var h=100;
    	var top=$(this).offset().top;
    	var left=$(this).offset().left;
    	var sc=$(window).scrollTop();
    	var top_1=top-sc;
    	var top_2=top_1+v.h-h;
    	var diff=10;
    	var diff_1=$(my_slider).find(".my_post_item i").width();
    	diff+=diff_1;
    	$(".my_timeline_line_box").attr('id',my_slider.id+'_line_box');
    	my_slider.my_debug('Top Left ',{top:top,left:left});
    	var html=$(this).find(".my_timeline_tooltip_item").html();
    	$(".my_timeline_line_box_div").html(html);
    	var new_top,new_left,pos_class='my_timeline_left_arrow';
    	$(".my_timeline_line_box").mCustomScrollbar('update');
    	var has_pos=false;
    	if(my_slider.vars.preview){
    		
        	has_pos='bottom';
			new_left=left-w/2+diff_1/2;
			new_top=top+diff;
			pos_class='my_timeline_top_arrow';
    	}else {
    	if(top_1>(h+diff)){
    		if(left>(w/2)){
    			has_pos='top';
    			new_left=left-w/2+diff_1/2;
    			new_top=top-diff-h;
    			pos_class='my_timeline_bottom_arrow';
    		}
    	}else if(top_2>(h+diff)){
    		if(left>(w/2)){
    			has_pos='bottom';
    			new_left=left-w/2+diff_1/2;
    			new_top=top+diff;
    			pos_class='my_timeline_top_arrow';
    		}
    	}
    	else if(top_1>(h/2)){
    		//right or left pos
    		if(left>(w+diff)){
    			has_pos='left';
    			new_left=left-w-diff+diff_1/2;
    			new_top=top-h/2-diff_1/2;
    			pos_class='my_timeline_right_arrow';
    		}else if(v.w>(left+w)){
    			has_pos='right';
    			new_left=left+diff;
    			new_top=top-h/2-diff_1/2;
    			
    		}
    	}
    	}
    	//}
    	my_slider.my_debug('Find pos',{has_pos:has_pos,new_top:new_top,new_left:new_left,pos_class:pos_class});
    	if(has_pos===false){
    		my_slider.my_debug('Not found pos');
    		has_pos='right';
			new_left=left+diff;
			new_top=top-h/2-diff_1/2;
    	}
    	$(".my_timeline_line_box").css('top',new_top+'px');
    	$(".my_timeline_line_box").css('left',new_left+'px');
    	var c=$(".my_timeline_line_box").data('class');
    	if(c!=''){
    		$(".my_timeline_line_box").removeClass(c);
    	}		
    	$(".my_timeline_line_box").data('class',pos_class);
    	$(".my_timeline_line_box").addClass(pos_class);
    	$(".my_timeline_line_box").fadeIn(function(){
    		//$(my_slider).find(".my_post_item").mouseleave(my_slider.show_tooltip);
    		$(".my_timeline_line_box").mouseover(function(){
    			my_slider.my_debug("Mouse over box clear timeout");
    			
    			//$(this).fadeOut();
    			clearTimeout(my_slider.tooltip_timeout);
    		});
    		$(".my_timeline_line_box").mouseenter(function(){
    			my_slider.my_debug("Mouse over box clear timeout");
    			
    			//$(this).fadeOut();
    			clearTimeout(my_slider.tooltip_timeout);
    			$(".my_timeline_line_box").unbind('mouseleave');
        		$(".my_timeline_line_box").mouseleave(function(){
        			my_slider.my_debug("Mouse leave box set timeout");    			
        			my_slider.tooltip_timeout=setTimeout(function(){
        				$(".my_timeline_line_box").fadeOut();
        			},my_slider.vars.tooltip_hide);
        		});  
    		});
    		  		
    	});
    
    };
    my_slider.line_go_to=function(i){
    	//if(my_slider.working)return;
    	//my_slider.working=true;
    	var start_item=1;
    	if(typeof my_slider.start_item!='undefined'){
    		start_item=my_slider.vars.current_line;
    	}
    	var c=$(my_slider).find(my_slider.vars.slider_timeline_class+" > ul > li").length-1;
    	var diff=start_item-i;
    	var diff_abs=Math.abs(diff);
    	my_slider.my_debug('Go to line',{i:i,c:c,start_item:start_item});
    	var options={duration:my_slider.vars.line_duration,easing:my_slider.vars.line_easing};
    	my_slider.my_debug("Options",options);
    	var w=diff_abs*my_slider.t_width;
    	
    	if(diff<0){
    		
    		my_slider.vars.current_line=i;
    		$(my_slider).find(".my_timeline_hor_list_ul").animate({'margin-left':'-='+w},options,function(){
    			my_slider.working=false;
    			
    			
    		});
    	}else {
    		my_slider.vars.current_line=i;
    		$(my_slider).find(".my_timeline_hor_list_ul").animate({'margin-left':'+='+w},options,function(){
    			my_slider.working=false;
    			
    		});
    		
    	}
    	
    	
    };
    my_slider.autoplay=function(){
    	if(my_slider.autoplay_over)return;
    	if(my_slider.dialog_is_open){
      		my_slider.autoplay_timeout=setTimeout(my_slider.autoplay,my_slider.vars.form.autoplay_timeout);
      		return;
    	}
    	var start_item=1;
    	if(typeof my_slider.start_item!='undefined'){
    		start_item=my_slider.start_item;
    	}
    	var total=my_slider.total_items;
    	var dir='right';
    	if(start_item==total){
    		my_slider.autoplay_dir='left';
    	}else if(start_item==1){
    		my_slider.autoplay_dir='right';
    	}else if(typeof my_slider.autoplay_dir=='undefined'){
    		if(start_item<total){
    			my_slider.autoplay_dir='right';
    		}else {
    			my_slider.autoplay_dir='left';
    		}
    	}
    	dir=my_slider.autoplay_dir;
    	if(dir=='left'){
    		my_slider.go_prev();
    	}else {
    		my_slider.go_next();
    	}
    	setTimeout(function(){
    		if(my_slider.autoplay_timeout!=''){
    			clearTimeout(my_slider.autoplay_timeout);
    		}
    		my_slider.autoplay_timeout=setTimeout(my_slider.autoplay,my_slider.vars.form.autoplay_timeout);
    	},my_slider.vars.duration);
    };
    my_slider.slider_nav=function(e){
    	e.preventDefault();
    	var start_item=1;
    	if(typeof my_slider.start_item!='undefined'){
    		start_item=my_slider.start_item;
    	}
    	var dir=$(this).data('type');
    	var c=$(my_slider).find(my_slider.vars.slider_class+" > ul > li").length-1;
    	my_slider.my_debug("Go",{dir:dir,start_item:start_item,c:c});
		
    	
    	if(dir=='left'){
    		if(start_item>1){
    			my_slider.my_debug("Go left",{start_item:start_item});
    			var new_item=start_item-1;
    			my_slider.go_to(new_item);
    		}
    	}else if(dir=='right'){
    		if(start_item<=c){
    			my_slider.my_debug("Go right",{start_item:start_item});
    			var new_item=start_item+1;
    			my_slider.go_to(new_item);
    		}
    	}
    	
    };
    my_slider.my_click_nav=function(e){
    	e.preventDefault();
    };
    my_slider.go_to_post=function(e){
    	e.preventDefault();
    	var post_type=$(this).data('type');
    	var post_id=$(this).data('id');
    	var id="my_post_"+post_type+"_"+post_id;
    	my_slider.my_debug("Go to post",{post_type:post_type,post_id:post_id,id:id});
    	//$(my_slider).find(".my_post_item").removeClass()
    	var $post=$("#"+id);
    	//$post=$(my_slider).find(".my_timeline_hor_ul li[data-pos='"+i+"']");
    	//$(".my_slider .my_post_item").removeClass("my_timeline_current");
    	//$post.find(".my_post_item").addClass('my_timeline_current');
    	$(my_slider).find(".my_timeline_item").removeClass("my_timeline_current");
    	//$post.find(".my_post_item").addClass('my_timeline_current');
    	$($post).find(".my_timeline_item").addClass('my_timeline_current');
    	
		var date=$post.data('date');
		var data_i=$post.data('i');
		var data_pos=$post.data('pos');
		my_slider.go_to(data_pos);
		$(my_slider).find(".my_post_item").removeClass('my_timeline_start_item');
		var i_pos=$(my_slider).find(".my_timeline_month[data-date='"+date+"']").data('i');
		
		my_slider.my_debug("Start item",{date:date,data_i:data_i,i_pos:i_pos});
		my_slider.line_go_to(i_pos);
		
		$(my_slider).find(".my_timeline_hor_list_ul li[data-date='"+date+"'] .my_post_item[data-i='"+data_i+"']").addClass("my_timeline_start_item");
		
    };
    my_slider.move_thumbs=function(e){
    	e.preventDefault();
    	var dir='left';
    	if($(this).hasClass("my_thumbs_nav_right")){
    		dir='right';
    	}
    	var start_item=1;
    	if(typeof my_slider.thumb_start_item!='undefined'){
    		start_item=my_slider.thumb_start_item;
    	}
    	var i=start_item;
    	if(dir=='left'){
    		if(start_item==1)return;
    		i--;
    		
    	}else {
    		if(start_item==(my_slider.vars.count_thumbs-1)){
    			return;
    		}
    		i++; 		
    	}
    	/*if(!my_slider.vars.hasTouch){
    		my_slider.thumb_start_item=i;
    	}else {*/
    		my_slider.my_debug("Go to thumbs",{start_item:start_item,i:i});
    		my_slider.go_thumbs(i);
    	//}
    	
    };
    my_slider.moveMouse=function(e){
    	if(my_slider.vars.myMouseDown){
			var xpos=my_slider.vars.myMouseDownEvent.pageX;
			var xmargin = my_slider.vars.marginLeft-xpos + e.pageX;
			var count=my_slider.vars.myTotalItems;
			var minMargin=-(count-1)*my_slider.item_width;
			if(xmargin<minMargin || xmargin>0 ){
				return;
			}
			my_slider.my_debug("Mouse move",{x:e.pageX,xpos:xpos,xmargin:xmargin,minMargin:minMargin});
			
			$(my_slider).find(".my_timeline_hor_ul").css({marginLeft:xmargin+'px'});
			}
    };
    my_slider.touchEnd1=function(e){
    	//var newx = e.originalEvent.touches[0].pageX,
		//newy = e.originalEvent.touches[0].pageY;
    	var newx=my_slider.vars.my_newx,
		newy=my_slider.vars.my_newy;
    	my_slider.my_debug("Touch end",{newx:newx,newy:newy});
    	my_slider.vars.myTouchStart=false;
    	var marginLeft=parseInt($(my_slider).find(".my_timeline_hor_ul").css('margin-left'));
		var preMargin=my_slider.vars.marginLeft;
		var cols=my_slider.layout.cols;;
		var w=my_slider.item_width;
		var c=Math.floor(Math.abs((marginLeft-preMargin))/w);
		var c1=Math.ceil(Math.abs((marginLeft-preMargin))/w);
		var diff=marginLeft-preMargin;
		my_slider.my_debug("c",{c1:c1,c:c,preMargin:preMargin,marginLeft:marginLeft,w:w});
		var start_item=1;
    	if(typeof my_slider.start_item!='undefined'){
    		start_item=my_slider.start_item;
    	} 
    	//var count=$(my_slider).find(".my_timeline_hor_ul > ul >li").length;
    	var count=my_slider.vars.myTotalItems;
    	var newItem=start_item;
    	var upN=4;
		if(c==0){
			if(Math.abs(diff)>(w/upN)){
				if(diff<0){
					newItem++;
					//my_slider.go_to(newItem);
				}else {
					newItem--;
					//my_slider.go_to(newItem);
					
				}
				my_slider.my_debug("Got to new item",{c:c,w:w,cols:cols,start_item:start_item,newItem:newItem});
				my_slider.goToMargin(newItem);
			}else {
				my_slider.my_debug("Remove margin",{diff:diff,c:c,w:w,cols:cols,start_item:start_item,newItem:newItem});
				
				if(diff<0){
					diff=Math.abs(diff);
					$(my_slider).find(".my_timeline_hor_ul").animate({'margin-left':"+="+diff},my_slider.vars.duration/5,function(){
					});
					
				}else {
					$(my_slider).find(".my_timeline_hor_ul").animate({'margin-left':"-="+diff},my_slider.vars.duration/5,function(){
					});
				}
			}
		}else {
			if(diff<0){
				newItem+=c1;
				if(newItem>=count){
					newItem=count-1;
				}
				
			}else {
				newItem-=c1;
				if(newItem<0){
					newItem=0;
				}
				
			}
			
			my_slider.my_debug("Got to new item",{c:c,w:w,cols:cols,start_item:start_item,newItem:newItem});
			my_slider.goToMargin(newItem);	
		}
		my_slider.vars.myTouchHorizontal=false;
		
		
    };
    my_slider.init=function(){
    	var count=$(my_slider).find(".my_timeline_hor_out_div > ul >li").length;
    	my_slider.vars.myTotalItems=count;
    	my_slider.my_debug("Total items",count);
    	if(my_slider.vars.hasTouch){
    		$(document).bind('touchend',my_slider.touchEnd1);
    		$(my_slider).bind('touchstart',function(e){
    			my_slider.vars.xposTouch = e.originalEvent.touches[0].pageX,
    			my_slider.vars.yposTouch = e.originalEvent.touches[0].pageY;
    			my_slider.my_debug("Touch start");
    			my_slider.vars.myTouchStart=true;
    			$(my_slider).unbind('touchmove');
    			$(my_slider).bind('touchmove', function(e){
    				
    				var newx = e.originalEvent.touches[0].pageX,
					newy = e.originalEvent.touches[0].pageY;
    				my_slider.vars.my_newx=newx;
    				my_slider.vars.my_newy=newy;
    				if(!my_slider.vars.myTouchHorizontal) {
    					if(Math.abs(newx-my_slider.vars.xposTouch) > Math.abs(newy-my_slider.vars.yposTouch)) {
    						my_slider.vars.myTouchHorizontal = true;
    					}
    				}
    				else if(my_slider.vars.myTouchHorizontal) {
    					e.preventDefault();
    					var xpos=my_slider.vars.xposTouch;
    					var xmargin = my_slider.vars.marginLeft-xpos + newx;
    					var count=my_slider.vars.myTotalItems;
    					var minMargin=-(count-1)*my_slider.item_width;
    					if(xmargin<minMargin || xmargin>0 ){
    						return;
    					}
    					
    					my_slider.my_debug("Touch move",{x:newx,xpos:xpos,xmargin:xmargin,minMargin:minMargin});
    					
    					$(my_slider).find(".my_timeline_hor_ul").css({marginLeft:xmargin+'px'});	
    				}
    			});
    			
    		});
    		
    	}
    	else if(my_slider.vars.swipeOn){
    		$(document).mousemove(my_slider.moveMouse);
    		$(my_slider).mousedown(function(e){
    			my_slider.my_debug("Mouse down",e.pageX);
    			my_slider.vars.myMouseDown=true;
    			my_slider.vars.myMouseDownEvent=e;
    			my_slider.myXmargin=0;
    			
    			
    		});
    		$(document).on('mouseup',function(e){
    			if(!my_slider.vars.myMouseDown)return;
    			my_slider.vars.myMouseDown=false;
    			var marginLeft=parseInt($(my_slider).find(".my_timeline_hor_ul").css('margin-left'));
    			var preMargin=my_slider.vars.marginLeft;
    			var cols=my_slider.layout.cols;;
    			var w=my_slider.item_width;
    			var c=Math.floor(Math.abs((marginLeft-preMargin))/w);
    			var c1=Math.ceil(Math.abs((marginLeft-preMargin))/w);
    			var diff=marginLeft+Math.abs(preMargin);
    			my_slider.my_debug("c",{c1:c1,c:c,preMargin:preMargin,marginLeft:marginLeft,w:w});
    			var start_item=1;
    	    	if(typeof my_slider.start_item!='undefined'){
    	    		start_item=my_slider.start_item;
    	    	} 
    	    	my_slider.my_debug("Mouse up",{start_item:start_item,diff:diff,c:c,c1:c1,marginLeft:marginLeft,preMargin:preMargin});
    	    	//var count=$(my_slider).find(".my_timeline_hor_ul > ul >li").length;
    	    	var count=my_slider.vars.myTotalItems;
    	    	var newItem=start_item;
    	    	var upN=4;
    			if(c==0){
    				if(Math.abs(diff)>(w/4)){
    					if(diff<0){
    						newItem++;
    						//my_slider.go_to(newItem);
    					}else {
    						newItem--;
    						//my_slider.go_to(newItem);
    						
    					}
    					my_slider.my_debug("Got to new item",{c:c,w:w,cols:cols,start_item:start_item,newItem:newItem});
    					my_slider.goToMargin(newItem);
    				}else {
    					my_slider.my_debug("Remove margin",{diff:diff,c:c,w:w,cols:cols,start_item:start_item,newItem:newItem});
        				
    					if(diff<0){
    						diff=Math.abs(diff);
    						$(my_slider).find(".my_timeline_hor_ul").animate({'margin-left':"+="+diff},my_slider.vars.duration/5,function(){
    						});
    						
    					}else {
    						$(my_slider).find(".my_timeline_hor_ul").animate({'margin-left':"-="+diff},my_slider.vars.duration/5,function(){
    						});
    					}
    				}
    			}else {
    				if(diff<0){
    					newItem+=c1;
    					if(newItem>=count){
    						newItem=count-1;
    					}
    					
    				}else {
    					newItem-=c1;
    					if(newItem<0){
    						newItem=0;
    					}
    					
    				}
    				
    				my_slider.my_debug("Got to new item",{c:c,c1:c1,w:w,cols:cols,start_item:start_item,newItem:newItem});
    				my_slider.goToMargin(newItem);	
    			}
    			
    			
    		});
    		
    	}
    	var str_sel=".my_testimonal_thumbs_div[data-id='"+my_slider.vars.id+"']";
    	if(!my_slider.vars.hasTouch){
    		my_slider.find(".my_line_nav").css({opacity:0});
    		$(my_slider).mouseenter(function(e){
    			my_slider.autoplay_over=true;
    			my_slider.find(".my_line_nav").animate({opacity:1},150);
    		});
    		$(my_slider).mouseleave(function(e){
    			my_slider.find(".my_line_nav").animate({opacity:0},150);
    			my_slider.vars.show_left_right=false;
    			my_slider.hide_next_prev();
    		});
    	}
    	
    	/**
    	 * Init thumbs data left right and everything about thumbs
    	 */
    	var l=$(str_sel).length;
    	if(l>0){
    		/*if(my_slider.vars.hasTouch){
        		$(document).bind('touchend',my_slider.touchEndThumbs);
        		$("#my_testimonials_thumbs_12_"+my_slider.vars.id).bind('touchstart',function(e){
        			my_slider.vars.myTouchHorizontalThumbs=false;
        			my_slider.vars.xposTouchThumbs = e.originalEvent.touches[0].pageX,
        			my_slider.vars.yposTouchThumbs = e.originalEvent.touches[0].pageY;
        			my_slider.my_debug("Touch start");
        			my_slider.vars.myTouchStartThumbs=true;
        			$("#my_testimonials_thumbs_12_"+my_slider.vars.id).inbind('touchmove');
        			$("#my_testimonials_thumbs_12_"+my_slider.vars.id).bind('touchmove', function(e){
        				
        				var newx = e.originalEvent.touches[0].pageX,
    					newy = e.originalEvent.touches[0].pageY;
        				my_slider.vars.my_newxThumbs=newx;
        				my_slider.vars.my_newyThumbs=newy;
        				if(!my_slider.vars.myTouchHorizontalThumbs) {
        					if(Math.abs(newx-my_slider.vars.xposTouchThumbs) > Math.abs(newy-my_slider.vars.yposTouchThumbs)) {
        						my_slider.vars.myTouchHorizontalThumbs = true;
        					}
        				}
        				else if(my_slider.vars.myTouchHorizontalThumbs) {
        					e.preventDefault();
        					var xpos=my_slider.vars.xposTouchThumbs;
        					var xmargin = my_slider.vars.thumbsMargin-xpos + newx;
        					var count=my_slider.vars.count_thumbs;
        					var minMargin=-(count-1)*my_slider.vars.thumbs_width;
        					if(xmargin<minMargin || xmargin>0 ){
        						return;
        					}
        					
        					my_slider.my_debug("Touch move",{x:newx,xpos:xpos,xmargin:xmargin,minMargin:minMargin});
        					
        					$("#my_testimonials_thumbs_12_"+my_slider.vars.id+" >div > ul").css({marginLeft:xmargin+'px'});	
        				}
        			});
        			
        		});
        		
        	}*/
        	/*else if(my_slider.vars.swipeOn){
        		$(document).mousemove(my_slider.moveMouseThumbs);
        		$("#my_testimonials_thumbs_12_"+my_slider.vars.id).mousedown(function(e){
        			my_slider.my_debug("Mouse down",e.pageX);
        			if(typeof my_slider.working!='undefined' && my_slider.working)return;
        			my_slider.vars.myMouseDownThumbs=true;
        			my_slider.vars.myMouseDownEventThumbs=e;
        			my_slider.myXmarginThumbs=0;
        			
        			
        		});
        		$(document).on('mouseup',function(e){
        			if(!my_slider.vars.myMouseDownThumbs)return;
        			my_slider.vars.myMouseDownThumbs=false;
        			var marginLeft=parseInt($("#my_testimonials_thumbs_12_"+my_slider.vars.id+" .my_testimonial_thumbs_ul").css('margin-left'));
        			var preMargin=my_slider.vars.thumbsMargin;
        			var cols=my_slider.vars.thumbs_cols;;
        			var w=my_slider.vars.thumbs_width;
        			var c=Math.floor(Math.abs((marginLeft-preMargin))/w);
        			var c1=Math.ceil(Math.abs((marginLeft-preMargin))/w);
        			var diff=marginLeft+Math.abs(preMargin);
        			my_slider.my_debug("c",{c1:c1,c:c,preMargin:preMargin,marginLeft:marginLeft,w:w});
        			var start_item=1;
        	    	if(typeof my_slider.start_item!='undefined'){
        	    		start_item=my_slider.start_item;
        	    	} 
        	    	my_slider.my_debug("Mouse up",{start_item:start_item,diff:diff,w:w,cols:cols,c:c,c1:c1,marginLeft:marginLeft,preMargin:preMargin});
        	    	//var count=$(my_slider).find(".my_timeline_hor_ul > ul >li").length;
        	    	var count=my_slider.vars.count_thumbs;
        	    	var newItem=start_item;
        	    	var upN=2;
        			if(c==0){
        				if(Math.abs(diff)>(w/upN)){
        					if(diff<0){
        						newItem++;
        						//my_slider.go_to(newItem);
        					}else {
        						newItem--;
        						//my_slider.go_to(newItem);
        						
        					}
        					my_slider.my_debug("Got to new item",{c:c,w:w,cols:cols,start_item:start_item,newItem:newItem});
        					my_slider.goToMarginThumbs(newItem);
        				}else {
        					my_slider.my_debug("Remove margin",{diff:diff,c:c,w:w,cols:cols,start_item:start_item,newItem:newItem});
            				
        					if(diff<0){
        						diff=Math.abs(diff);
        						$("#my_testimonials_thumbs_12_"+my_slider.vars.id+" .my_testimonial_thumbs_ul").animate({'margin-left':"+="+diff},my_slider.vars.duration/5,function(){
        						});
        						
        					}else {
        						$("#my_testimonials_thumbs_12_"+my_slider.vars.id+" .my_testimonial_thumbs_ul").animate({'margin-left':"-="+diff},my_slider.vars.duration/5,function(){
        						});
        					}
        				}
        			}else {
        				if(diff<0){
        					newItem+=c1;
        					if(newItem>=count){
        						newItem=count-1;
        					}
        					
        				}else {
        					newItem-=c1;
        					if(newItem<0){
        						newItem=0;
        					}
        					
        				}
        				
        				my_slider.my_debug("Got to new item",{c:c,c1:c1,w:w,cols:cols,start_item:start_item,newItem:newItem});
        				my_slider.goToMarginThumbs(newItem);	
        			}
        			
        			
        		});
        		
        	}*/
        	var str_sel=".my_testimonal_thumbs_div[data-id='"+my_slider.vars.id+"']";
        	if(!my_slider.vars.hasTouch){
        		my_slider.find(".my_line_nav").css({opacity:0});
        		$(my_slider).mouseenter(function(e){
        			my_slider.autoplay_over=true;
        			my_slider.find(".my_line_nav").animate({opacity:1},150);
        		});
        		$(my_slider).mouseleave(function(e){
        			my_slider.find(".my_line_nav").animate({opacity:0},150);
        			my_slider.vars.show_left_right=false;
        			my_slider.hide_next_prev();
        		});
        	}
        	
    		my_slider.my_debug("Has thumbs",l);
    		my_slider.vars.has_thumbs=true;
    		my_slider.vars.count_thumbs=$(str_sel+" .my_testimonial_thumbs_ul > li").length;
    		my_slider.vars.thumbs_timeout='';
    		
    		$("#my_testimonials_thumbs_"+my_slider.vars.id+" .my_testimonial_thumbs_ul > li").on('click',function(e){
    			e.preventDefault();
    			var i=$(this).data('i');
    			my_slider.my_debug("Go to", i)
    			my_slider.go_to(i);
    			my_slider.go_thumbs(i);
    		});
    		if(!my_slider.vars.hasTouch){
    		$("#my_testimonials_thumbs_"+my_slider.vars.id+" .my_thumbs_nav").css({opacity:0});
    		$("#my_testimonials_thumbs_"+my_slider.vars.id).on("mouseenter",function(e){
    			$("#my_testimonials_thumbs_"+my_slider.vars.id+" .my_thumbs_nav").finish();
    			$("#my_testimonials_thumbs_"+my_slider.vars.id+" .my_thumbs_nav").animate({opacity:1});
    		});
    		$("#my_testimonials_thumbs_"+my_slider.vars.id).on("mouseleave",function(e){
    			$("#my_testimonials_thumbs_"+my_slider.vars.id+" .my_thumbs_nav").finish();
    			$("#my_testimonials_thumbs_"+my_slider.vars.id+" .my_thumbs_nav").animate({opacity:0});
    		});
    		$("#my_testimonials_thumbs_"+my_slider.vars.id+" .my_thumbs_nav").on("mouseenter",function(e){
    			my_slider.vars.$thumb_nav=$(this);
    			my_slider.my_debug("Mouse enter");
    			my_slider.vars.thumbs_timeout=setTimeout(function(){
    				my_slider.my_debug("Mouse enter timeout");
    				var dir='left';
    				if($(my_slider.vars.$thumb_nav).hasClass("my_thumbs_nav_right")){
    					dir='right';
    				}
    				my_slider.my_debug("Mouse enter timeout",dir);
    				var margin=my_slider.vars.thumbsMargin;
    				$("#my_testimonials_thumbs_"+my_slider.vars.id+" .my_testimonial_thumbs_ul").finish();
    				if(dir=='left'){
    					$("#my_testimonials_thumbs_"+my_slider.vars.id+" .my_testimonial_thumbs_ul").animate({marginLeft:"+="+my_slider.vars.st_thumbs_width+"px"},my_slider.vars.thumbs_animation,function(){
    						my_slider.vars.thumbs_timeout='';
    					});
    					
    				}else {
    					$("#my_testimonials_thumbs_"+my_slider.vars.id+" .my_testimonial_thumbs_ul").animate({marginLeft:"-="+my_slider.vars.st_thumbs_width+"px"},my_slider.vars.thumbs_animation,function(){
    						my_slider.vars.thumbs_timeout='';
    					});
    				}
    			},200);
    		});
    		$("#my_testimonials_thumbs_"+my_slider.vars.id+" .my_thumbs_nav").on("mouseleave",function(e){
    			my_slider.my_debug("Mouse leave ");
    			$("#my_testimonials_thumbs_"+my_slider.vars.id+" .my_testimonial_thumbs_ul").finish();
				if(my_slider.vars.thumbs_timeout!=''){
					clearTimeout(my_slider.vars.thumbs_timeout);
					my_slider.my_debug("Mouse leave clear timeout");
					return;
				}
				var dir='left';
				if($(my_slider.vars.$thumb_nav).hasClass("my_thumbs_nav_right")){
					dir='right';
				}
				my_slider.my_debug("Mouse leave",dir);
				var margin=my_slider.vars.thumbsMargin;
				//$("#my_testimonials_thumbs_"+my_slider.vars.id+" .my_testimonial_thumbs_ul").finish();
				if(dir=='left'){
					$("#my_testimonials_thumbs_"+my_slider.vars.id+" .my_testimonial_thumbs_ul").animate({marginLeft:"-="+my_slider.vars.st_thumbs_width+"px"},my_slider.vars.thumbs_animation,function(){
						my_slider.vars.thumbs_timeout='';
					});
					
				}else {
					$("#my_testimonials_thumbs_"+my_slider.vars.id+" .my_testimonial_thumbs_ul").animate({marginLeft:"+="+my_slider.vars.st_thumbs_width+"px"},my_slider.vars.thumbs_animation,function(){
						my_slider.vars.thumbs_timeout='';
					});
				}
				
    		});
    		}
    		$("#my_testimonials_thumbs_"+my_slider.vars.id+" .my_thumbs_nav").on("click",my_slider.move_thumbs);
    		
    	}
    	var w=$(my_slider).find(my_slider.vars.slider_class).outerWidth();
    	my_slider.width=w;
    	my_slider.total_items=$(my_slider).find(my_slider.vars.slider_class+" > ul > li").length;
    	
    	 my_slider.getLayout();
    	my_slider.set_height();
    	my_slider.set_widths();
    	$(my_slider).find(".my_timeline_media").mouseenter(my_slider.media_over);
    	$(my_slider).find(".my_timeline_media").mouseleave(my_slider.media_out);
    	var arr=[];
    	$(my_slider).find(".my_timeline_hor_list_ul > li").each(function(i,v){
    		arr[arr.length]=$(this).data('pos');
    	});
    	my_slider.vars.hor=arr;
    	/*if(arr.length<=1){
    		$(my_slider).find(".my_line_nav").addClass('my_disabled_05');
    	}else {
    		$(my_slider).find(".my_line_nav").click(my_slider.line_nav);
    	}*/
    	my_slider.my_debug('Lines',arr);
    	my_slider.vars.current_line=1;
    	my_slider.vars.current_item=1;
    	my_slider.vars.my_start_item=1;
    	if(typeof my_slider.vars.form.start_item!='undefined'){
    		my_slider.vars.my_start_item=my_slider.vars.form.start_item;
    		my_slider.go_to(my_slider.vars.my_start_item);
    		
    		
    	}
    	/*$(my_slider).find(".my_timeline_hor_out_div").mouseenter(function(e){
    		$(my_slider).find(".my_timeline_slider_nav").fadeIn();
    	});
    	$(my_slider).find(".my_timeline_hor_out_div").mouseleave(function(e){
    		$(my_slider).find(".my_timeline_slider_nav").fadeOut();
    	});*/
    	$(my_slider).find(".my_line_nav").click(my_slider.slider_nav);
    	//$(my_slider).find(".my_post_item").mouseenter(my_slider.show_tooltip);
    	//$(my_slider).find("..my_post_item i").mouseenter(my_slider.show_tooltip);
    	$(my_slider).find(".my_post_item").mouseleave(function(e){
    		my_slider.my_debug("Mouse leave post item set timeout");
			
    		my_slider.tooltip_timeout=setTimeout(function(){
    				$(".my_timeline_line_box").fadeOut();
    			},(2*my_slider.vars.tooltip_hide));
    	});
    	$(".my_timeline_line_box_div").mCustomScrollbar(
    				{axis:'y',
    				advanced:{
    					updateOnContentResize:true
    					}});
    	if(typeof my_slider.vars.start_item!='undefined'){
    		var $post=$("#"+my_slider.vars.start_item);
    		var date=$post.data('date');
    		var data_i=$post.data('i');
    		var data_pos=$post.data('pos');
    		my_slider.go_to(data_pos);
    		var i_pos=$(my_slider).find(".my_timeline_month[data-date='"+date+"']").data('i');
    		$($post).find(".my_timeline_item").addClass('my_timeline_current');
    		
    		my_slider.my_debug("Start item",{date:date,data_i:data_i,i_pos:i_pos});
    		my_slider.line_go_to(i_pos);
    		
    		$(my_slider).find(".my_timeline_hor_list_ul li[data-date='"+date+"'] .my_post_item[data-i='"+data_i+"']").addClass("my_timeline_start_item");
    		
    	}
    	$(document).on("click",".my_timeline_line_box a",my_slider.go_to_post);
    	//$(my_slider).find(".my_timeline_slider_nav").click(my_slider.my_click_nav);
    	$(my_slider).animate({opacity:1});
    	//my_slider.touch();
    	/*$(my_slider).find(".my_timeline_media a").prettyPhoto();
    	$(my_slider).find(".my_timeline_media").on('click',function(e){
    		e.preventDefault();
    		var alt=$(this).find('a').data('alt');
    		var href=$(this).find('a').attr('href');
    		my_slider.my_debug("Open att",{alt:alt,href:href});
    		var images=[];
    		var alt=[];
    		if(typeof my_slider.my_images!='undefined'){
    			images=my_slider.my_images;
    			alt=my_slider.my_alt;
    		}else {
    		$(my_slider).find(".my_timeline_media a").each(function(i,v){
    			var alt1=$(v).data('alt');
        		var href=$(v).attr('href');
        		images[images.length]=href;
        		alt[alt.length]=alt1;
    		});
    		if(typeof my_slider.my_images=='undefined'){
    			my_slider.my_images=images;
    			my_slider.my_alt=alt;
    		}
    		}
    		var pos=0;
    		$.each(images,function(i,v){
    			if(v==href){
    				pos=i;
    				return false;
    			}
    		})
    		my_slider.my_debug("Images",{images:images,alt:alt,pos:pos});
    		$.prettyPhoto.open(images,alt,alt,pos);
    		
    		});
    		*/
    	my_slider.my_debug('Vars',my_slider.vars);
    	if(typeof my_slider.vars.form.autoplay!='undefined' &&(!my_slider.vars.mobile) && (my_slider.vars.form.autoplay==1)){
    		my_slider.my_debug('Set autoplay');
    		$(my_slider).mouseover(function(e){
    			my_slider.my_debug("Mouse over");
    			my_slider.autoplay_over=true;
    			clearTimeout(my_slider.autoplay_timeout);
    		});
    		$(my_slider).mouseout(function(e){
    			my_slider.my_debug("Mouse out");
    			my_slider.autoplay_over=false;
    			
    			setTimeout(my_slider.autoplay,my_slider.vars.form.autoplay_timeout);
    		});
    		my_slider.autoplay_timeout=setTimeout(my_slider.autoplay,my_slider.vars.form.autoplay_timeout);
    		
    	}
    	if(my_slider.vars.form.show_nav==1&&!my_slider.vars.hasTouch){
    		my_slider.my_debug('Show nav');
    		my_slider.vars.left_next_offset=$(my_slider).find(".my_testimonial_next_left").offset();
    		my_slider.vars.right_next_offset=$(my_slider).find(".my_testimonial_next_rigth").offset(); 
    		my_slider.vars.show_left_right=false;
    		$(my_slider).mouseover(function(e){
    			var x=e.pageX;
    			var y=e.pageY;
    			
    			my_slider.vars.left_next_offset=$(my_slider).find(".my_testimonial_next_left").offset();
        		my_slider.vars.right_next_offset=$(my_slider).find(".my_testimonial_next_rigth").offset(); 
        		var left_x=my_slider.vars.left_next_offset.left;
        		var left_y=$(my_slider).offset().top;
        		var right_x=my_slider.vars.right_next_offset.left+$(my_slider).find(".my_testimonial_next_rigth").width();
        		var right_y=$(my_slider).offset().top;
        		var regionWidth=my_slider.vars.regionWidth;
        		my_slider.my_debug("Region",regionWidth);
        		if(regionWidth>(my_slider.item_width/2)){
        			regionWidth=my_slider.item_width/2-20;
        			my_slider.my_debug("Region",regionWidth);
        		}
        		var h=$(my_slider).height();
        		var inner=false;
        		my_slider.my_debug("Mouse over",{h:h,x:x,y:y,left_x:left_x,left_y:left_y,right_x:right_x,right_y:right_y});
        		var type;
        		var $this;
        		if((x>=left_x)&&(x<(left_x+regionWidth))){
        			if((y>=left_y)&&(y<=(left_y+h))){
        				inner=true;
        				type='left';
        				my_slider.my_debug("Mouse over left regiont");
        				if(typeof my_slider.my_line_nav_timeout!='undefined'){
            				clearTimeout(my_slider.my_line_nav_timeout);
            			}
        				$this=$(my_slider).find(".my_testimonial_next_left");
        			}
        		}else{
        			if((x>=right_x-regionWidth)&&(x<=(right_x))){
            			if((y>=left_y)&&(y<=(left_y+h))){
            				type='right';
            				inner=true;
            				$this=$(my_slider).find(".my_testimonial_next_rigth");
            				my_slider.my_debug("Mouse over left regiont");
            				if(typeof my_slider.my_line_nav_timeout!='undefined'){
                				clearTimeout(my_slider.my_line_nav_timeout);
                			}
            			}
            		
        		}
        		}
        		
        		if(inner&&!my_slider.vars.show_left_right){
        			my_slider.vars.type_hover=type;
        			my_slider.vars.show_left_right=true;
        			my_slider.my_debug("Mouse over show",type);
        			my_slider.animate_hover($this);		
        		}else if(!inner&&my_slider.vars.show_left_right){
        			my_slider.vars.show_left_right=false;
        			my_slider.my_debug("Mouse out");
        			my_slider.hide_next_prev();
        			//my_slider.vars.my_next_timeout=setTimeout(my_slider.hide_next_prev,my_slider.vars.form.circle_duration);
        	    	
        		}
        		
    		});
    		//$(my_slider).find(".my_line_nav").fadeOut();
    		/*$(my_slider).mouseenter(function(e){
    			my_slider.my_debug('Mouse enter');
    			if(typeof my_slider.my_line_nav_timeout!='undefined'){
    				clearTimeout(my_slider.my_line_nav_timeout);
    			}
    			$(my_slider).find(".my_line_nav").fadeIn();
    			$(my_slider).unbind("mouseleave",my_slider.hide_nav);
    			$(my_slider).mouseleave(my_slider.hide_nav);
    			
    			
    		});*/
    		/*
    		$(my_slider).find(".my_testimonial_next").mouseover(function(e){
    			if(typeof my_slider.my_line_nav_timeout!='undefined'){
    				clearTimeout(my_slider.my_line_nav_timeout);
    			}
    			
    		});
    		$(my_slider).find(".my_testimonial_next").mouseenter(function(e){
    			var type='left';
    			if($(this).hasClass('my_testimonial_next_rigth'))type='right';
    			my_slider.my_debug("Mouse ente next",type);
    			my_slider.vars.type_hover=type;
    			$(this).unbind("mouseleave");
    			$(this).mouseleave(function(e){
    				my_slider.my_debug('Leave next',$(e.target).attr('class'));
    				if($(e.target).hasClass("my_line_nav")){
    					
    					return;
    				}
    				my_slider.vars.my_next_timeout=setTimeout(my_slider.hide_next_prev,my_slider.vars.form.circle_duration);
    			});
    			$(my_slider).find(".my_line_nav").mouseenter(function(e){
    				if(typeof my_slider.vars.my_next_timeout!='undefined'){
    					my_slider.my_debug('Clear mouse leave timeout');
    					clearTimeout(my_slider.vars.my_next_timeout);
    				}
    			});
    			$(my_slider).find(".my_line_nav").mouseleave(function(e){
    				my_slider.my_debug('Clear mouse leave timeout',$(e.target).attr('class'));
    				if($(e.target).hasClass("my_testimonial_next"))return;
    				my_slider.vars.my_next_timeout=setTimeout(my_slider.hide_next_prev,my_slider.vars.form.circle_duration);
    			    
    			});
    			
    			$(this).unbind('mouseover');
    			$(this).mouseover(function(e){
    				if(typeof my_slider.vars.my_next_timeout!='undefined'){
    					my_slider.my_debug('Clear mouse leave timeout');
    					clearTimeout(my_slider.vars.my_next_timeout);
    				}
    			});
    			/*$(this).find(".my_testimonial_next").unbind('mouseover');
    			$(this).find(".my_testimonial_next").mouseover(function(e){
    				if(typeof my_slider.vars.my_next_timeout!='undefined'){
    					my_slider.my_debug('Clear mouse leave timeout');
    					clearTimeout(my_slider.vars.my_next_timeout);
    				}
    			});
    			my_slider.animate_hover(this);
    			
    		});*/
    	}
    	//$(my_slider).parents('.my_testimonial_shortcode').css('visibility','visible');
    	$(my_slider).parents('.my_testimonial_shortcode').fadeIn();
    	 $(my_slider).data('myproslider',my_slider);
    	
    };
    my_slider.animate_hover=function(el){
    	$(this).finish();
    	var type=my_slider.vars.type_hover;
    	var curr_item=my_slider.vars.current_item;
    	my_slider.my_debug("Animate",{item:curr_item,type:type});
    	var itemPos;										
    	var itemClass='#my_timeline_'+my_slider.vars.id+ ' .my_testimonial_next_left div div ';
    	var iconClass='#my_timeline_'+my_slider.vars.id+ ' .my_nav_left';
    	
    	var marginLeft='-20px';
    	if(type=='left'){
    		if(curr_item==1){
    			return;
    		}else {
    			itemPos=curr_item-1;	
    		}
    	}else {
    		itemClass='#my_timeline_'+my_slider.vars.id+' .my_testimonial_next_rigth div div';
    		iconClass='#my_timeline_'+my_slider.vars.id+' .my_nav_right';
    		marginLeft='20px';
    		if(curr_item==my_slider.total_items){
    			return;
    		}else {
    			itemPos=curr_item+1;
    		}
    	}
    	var str=itemPos+'/'+my_slider.total_items;
    	my_slider.vars.my_item_pos_str=str;
    	$(iconClass).find(".my_nav_item").html(str);
    	my_slider.my_debug("Classes",{itemClass:itemClass,iconClass:iconClass,duration:my_slider.vars.form.circle_duration});
    	var preColor=$(iconClass).css('background-color');
    	my_slider.my_debug("Classes",preColor);
    	$(iconClass).finish();
    	$(iconClass).find(".my_nav_arrow").finish();
    	$(iconClass).find(".my_nav_item").finish();
    	$(itemClass).finish();
    	var color=my_slider.vars.form.circle_hover_color;
    	my_slider.my_debug("Animate color",{color:color});
    	$(iconClass).animate({backgroundColor:color},my_slider.vars.form.circle_duration);
    		$(iconClass).find(".my_nav_arrow").animate({left:'-41px'},my_slider.vars.form.circle_duration/2,function(){
    		$(iconClass).find(".my_nav_item").animate({left:'0px'},my_slider.vars.form.circle_duration/2);
    		
    	});
    	var img=$(my_slider).find("li[data-pos='"+itemPos+"'] img").attr('src');
    	var html='<img class="oldItem" src="'+img+'" width="80px" height="80px" style="border-radius:50%"/>';
    	if(type=='left'){
    		$(itemClass+" ").html(html);
    	}else {
    		$(itemClass+" ").html(html);
    	}
    	if(my_slider.transitions){
    	//	self.my_debug('Transitions');
    		$(itemClass).css(my_slider.prop,'scale(0)');
    		$(itemClass).my_scale=0;
    		$(itemClass).animate({
				my_scale:1
			},{
				step:function(now,fx){
					if(fx.prop=='my_scale'){
							var my_trans=my_slider.prop;//+'transform';
							//my_slider.my_debug("Trans",{trans:my_trans,now:now});
							$(this).css(my_trans,'scale('+now+')');
					}
				},
				complete:function(){
					
				},duratuon:my_slider.vars.form.circle_duration
			});
    	}else {
    		self.my_debug('Fadein');
    		$(itemClass).css('opacity',0);
    		$(itemClass).animate({opacity:1},my_slider.vars.form.circle_duration);
			
    	}
    	
    };
    my_slider.hide_next_prev=function(el){
    	//var el=$(this);
    	$(this).finish();
    	var type=my_slider.vars.type_hover;
    	var curr_item=my_slider.vars.current_item;
    	my_slider.my_debug("Animate close",{item:curr_item,type:type});
    	var itemPos;
    	var itemClass='#my_timeline_'+my_slider.vars.id+ ' .my_testimonial_next_left div div';
    	var iconClass='#my_timeline_'+my_slider.vars.id+ ' .my_nav_left';
    	var marginLeft='-20px';
    	if(type=='left'){
    		if(curr_item==1){
    			//return;
    		}else {
    			itemPos=curr_item-1;	
    		}
    	}else {
    		itemClass='#my_timeline_'+my_slider.vars.id+' .my_testimonial_next_rigth div div';
    		iconClass='#my_timeline_'+my_slider.vars.id+' .my_nav_right';
    		marginLeft='20px';
    		if(curr_item==my_slider.total_items){
    			//return;
    		}else {
    			itemPos=curr_item+1;
    		}
    	}
    	my_slider.my_debug("Classes",{itemClass:itemClass,iconClass:iconClass});
    	
    	$(iconClass).finish();
    	$(iconClass).find(".my_nav_arrow").finish();
    	$(iconClass).find(".my_nav_item").finish();
    	$(itemClass).finish();
    	var color=my_slider.vars.form.circle_back_color;
    	my_slider.my_debug("Animate color",{color:color});
    	$(iconClass).animate({backgroundColor:color},my_slider.vars.form.circle_duration);
    	$(iconClass).find(".my_nav_item").animate({'left':'41px'},my_slider.vars.form.circle_duration/2,function(){
    		$(iconClass).find(".my_nav_arrow").animate({left:'0px'},my_slider.vars.form.circle_duration/2);
    	});
    	/*var img=$(my_slider).find("li[data-pos='"+itemPos+"'] img").attr('src');
    	var html='<img src="'+img+'" width="80px" height="80px" style="bortde-radius:50%"/>';
    	if(type=='left'){
    		$(itemClass+" div").html(html);
    	}else {
    		$(itemClass+" div").html(html);
    	}*/
    	if(my_slider.transitions){
    		//self.my_debug('Transitions');
    		//$(itemClass).css(my_slider.prop+'transform',0);
    		$(itemClass).animate({
				my_scale:0
			},{
				step:function(now,fx){
					if(fx.prop=='my_scale'){
							var my_trans=my_slider.prop;//+'transform';
							//my_slider.my_debug("Trans",{trans:my_trans,now:now});
							$(this).css(my_trans,'scale('+now+')');
					}
				},
				complete:function(){
					
				},duratuon:my_slider.vars.form.circle_duration
			});
    	}else {
    		self.my_debug('Animat opacity');
    		//$(itemClass).css('opacity',0);
    		$(itemClass).animate({opacity:0},my_slider.vars.form.circle_duration);
			
    	}
    };
    my_slider.hide_nav=function(e){
    	my_slider.my_debug('Mouse leave');
    	my_slider.my_line_nav_timeout=setTimeout(function(){
    		$(my_slider).find(".my_line_nav").fadeOut();
			
    	},200);
    };
    
    if(my_slider.vars.has_timeline){
    	my_slider.init_timeline_line();
    	//$("#"+div_id+" ")
    }
    my_slider.init();
    $(window).resize(function(e){
    	my_slider.my_debug("Widnow resize");
    	$(".my_timeline_line_box").fadeOut();
    	var w=$(my_slider).find(my_slider.vars.slider_class).outerWidth();
    	my_slider.width=w;
    	var start_item=1;
    	if(typeof my_slider.start_item!='undefined'){
    		start_item=my_slider.start_item;
    	}
    	
    	 my_slider.getLayout();
    	
    	if(my_slider.vars.has_timeline){
    		var normal_width=my_slider.vars.normal_width;
        	my_slider.init_timeline_line();
        	/*if(my_slider.t_width<normal_width){
        		var r=my_slider.t_width/normal_width;
        		my_slider.my_debug("Change widnow",{r:r,normal:normal_width,t_width:my_slider.t_width});
        		$(my_slider).find(settings.slider_timeline_class+" .my_post_item .fa").css(my_slider.prop,'scale('+r+')');
        		
        	}*/
        	//$("#"+div_id+" ")
        }
    	
    	my_slider.set_height();
    	my_slider.set_widths();
    	var diff=-(start_item-1)*my_slider.item_width;
    	$(my_slider).find(".my_timeline_hor_ul").css('margin-left',diff);
    	var start_item=1;
    	if(typeof my_slider.start_item!='undefined'){
    		start_item=my_slider.vars.current_line;
    	}
    	diff=-my_slider.t_width*(start_item-1);
    	$(my_slider).find(".my_timeline_hor_list_ul").css('margin-left',diff);
    		
			
    	
    	if(my_slider.dialog_is_open){
    		var v=my_slider.getViewportSize();
			my_slider.my_debug('Widths',v);
			//var top=$(window).scrollTop();
			my_slider.vars_12=v;
    		var ht=$(".my_timeline_modal").find(".my_timeline_modal_title").outerHeight();
			var ot=v.h;
			var p=ot-ht;
			$(".my_timeline_modal").find(".my_timeline_modal_load").height(p);
			
    	}
    	
    });
  };
  
  $.fn.myproslider=function(options){
	  if (options === undefined) { options = {}; }
	  if(typeof options=='object'){
	  return this.each(function() {
		  	var $this = $(this);   
	        if ($this.data('myproslider') === undefined) {
	          var inst=new $.myproslider(this, options);
	         
	        }
	      });
	  }else {
		  //Call slider functions
		  var $slider=$(this).data('myproslider');
		  switch (options) {
		 
		  }
		  
	  }
  };
})(jQuery);