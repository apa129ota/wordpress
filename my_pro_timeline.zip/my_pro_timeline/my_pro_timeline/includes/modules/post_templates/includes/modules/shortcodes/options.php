<?php
if(!defined('ABSPATH'))die('');
require 'global_options.php';
global $wp_my_module_shortcodes_global_properties;
if(empty($wp_my_module_shortcodes_global_properties)){
	$wp_my_module_shortcodes_global_properties=$properties;
}
$options['box']=array(
	'section_title'=>__("Box properties","my_support_theme"),
	'elements'=>array(	
	
		/*'width'=>array(
				'title'=>__("Width","my_support_theme"),
				'type'=>'text',
				'property'=>'top',
				'default'=>''
		),*/
		'sections'=>array(	
				'el'=>array(
						'title'=>__("Element options","my_support_theme"),
						'elements'=>array(
					
				)
				),
				'dimensions'=>array(
				'title'=>__("Dimensions","my_support_theme"),
		'elements'=>array(			
		'height'=>array(
					'title'=>__("Height","my_support_theme"),
					'type'=>'multi',
					'elements'=>array(
						'auto'=>array(
							'css'=>array(
								'width'=>'30px'
							),	
							'type'=>'checkbox',
							'default'=>1,
							'label'=>__("Auto","my_support_theme"),
								'translate'=>array(
										'class'=>'{class}',
										'property'=>'height'
								)
							),
						'choose'=>array(
								'css'=>array(
									'display:none',
								),
								
								'type'=>'jscript_spinner',
								'property'=>'height',
								'default'=>'0',
								'default_unit'=>'px',
								'units'=>$units,
								'translate'=>array(
										'class'=>'{class}',
										'property'=>'height'
								)
						)				
						
					))	
		),
			
		),
		'background'=>array(
				'title'=>__("Background","my_support_theme"),
				'elements'=>array(
						
					)				
				)	
			)	
		/*	
		'top'=>array(
			'title'=>__("Top","my_support_theme"),
			'type'=>'text',
			'property'=>'top',	
			'default'=>''			
		),
		'bottom'=>array(
					'title'=>__("Bottom","my_support_theme"),
					'type'=>'text',
					'property'=>'bottom',
					'default'=>''
		),
		'left'=>array(
					'title'=>__("Left","my_support_theme"),
					'type'=>'text',
					'default'=>''
		),
		'right'=>array(
			'title'=>__("Right","my_support_theme"),
			'type'=>'text',
			'default'=>''			
		),
		
		'margin'=>array(
				'title'=>__("Margin","my_support_theme"),
				'type'=>'text',
				'default'=>'0'
		),
		'padding'=>array(
					'title'=>__("Padding","my_support_theme"),
					'type'=>'text',
					'default'=>'0'
		),
		
		'center_horozontal'=>array(
				'title'=>__("Center","my_support_theme"),
				'value'=>__("Center horizontally","my_support_theme"),
				'type'=>'button',
				'class'=>'button button-primary my_center_hor',
				'default'=>'1'
		),
		'center_verticaly'=>array(
					'title'=>__("Center","my_support_theme"),
					'value'=>__("Center verticaly","my_support_theme"),
					'class'=>'button button-primary my_center_vert',
					'type'=>'button',
					'default'=>'1'
			)
		*/	
	)	
);
wp_my_module_shortcodes_add_options('background',$properties,$options['box']['elements']['sections']['background']);
foreach($properties['default'] as $k1=>$v1){
	$options['box']['elements']['sections']['el']['elements'][$k1]=$v1;
}
foreach($properties['padding'] as $k1=>$v1){
	$options['box']['elements']['sections']['dimensions']['elements'][$k1]=$v1;
}
foreach($properties['margin'] as $k1=>$v1){
	$options['box']['elements']['sections']['dimensions']['elements'][$k1]=$v1;
}

$options['responsive_box']=array(
		'section_title'=>__("Extra small devices <500px","my_support_theme"),
		'elements'=>array(
				'unit'=>array(
						'title'=>__("Units","my_support_theme"),
						'type'=>'radio_list',
						'values'=>array(
								'px'=>'px',
								'%'=>'%',
									
						),
						'display'=>'inline',
						'default'=>'px'
				),
				'show'=>array(
						'title'=>__("Show element","my_support_theme"),
						'type'=>'radio_list',
						'values'=>array(
								'0'=>__("No","my_support_theme"),
								'1'=>__("Yes","my_support_theme")
									
						),
						'display'=>'inline',
						'default'=>'1'
				),
				
				'width'=>array(
						'title'=>__("Width","my_support_theme"),
						'type'=>'text',
						'property'=>'top',
						'default'=>''
				),
				/*
				'top'=>array(
						'title'=>__("Top","my_support_theme"),
						'type'=>'text',
						'property'=>'top',
						'default'=>''
				),
				'bottom'=>array(
						'title'=>__("Bottom","my_support_theme"),
						'type'=>'text',
						'property'=>'bottom',
						'default'=>''
				),
				'left'=>array(
						'title'=>__("Left","my_support_theme"),
						'type'=>'text',
						'default'=>''
				),
				'right'=>array(
						'title'=>__("Right","my_support_theme"),
						'type'=>'text',
						'default'=>''
				),*/
				'margin'=>array(
						'title'=>__("Margin","my_support_theme"),
						'type'=>'text',
						'default'=>'0'
				),
				'padding'=>array(
						'title'=>__("Padding","my_support_theme"),
						'type'=>'text',
						'default'=>'0'
				)
				)
);
$options['row_box']=array(
		'section_title'=>__("Row Properties","my_support_theme"),
		'elements'=>array(
				'height'=>array(
						'title'=>__("Height","my_support_theme"),
						'type'=>'text',
						'property'=>'height',
						'default'=>'auto'
				),
		)
);
return $options;