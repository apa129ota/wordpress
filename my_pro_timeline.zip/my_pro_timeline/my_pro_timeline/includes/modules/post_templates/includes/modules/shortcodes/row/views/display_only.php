<?php
?>
<ul class="my_shortocde_rows_ul my_clearfix">
<?php
if (!empty($layouts)) {
    foreach($layouts as $key => $val ) {
        $lay=$val['layouts'];
        ?>
			<li>
			<ul data-widths="<?php echo implode(",",$lay)?>" class="my_clearfix">
				<?php foreach($lay as $k1=>$v1){?>
				<?php if(strpos($v1,'px')===false){
					$wstr=$v1.'%';
				}else $wstr=$v1;
				?>
				<li style="width:<?php echo $wstr;?>">
				<span class="my_gradient_shortcode"><?php
				if(strpos($v1,'px')!==false){
					echo $wstr;
				}else {
				switch ($v1){
						case 100:
							echo '1';
						break;
						case 33.3333:
							echo '1/3';
						break;
						case 25:
							echo '1/4';
						break;
						case 20:
							echo '1/5';
						break;
						case 40:
							echo '2/5';
						break;
						case 60:
							echo '3/5';
						break;
						case 66.6666:
							echo '2/3';
						break;
						case 75:
							echo '3/4';
						break;
						case 50:
							echo '1/2';
						break;
					}
				}
				?></span>
				</li>
				<?php }?>
			</ul>
			</li>
			<?php
			}
		}
		?>
	</ul>