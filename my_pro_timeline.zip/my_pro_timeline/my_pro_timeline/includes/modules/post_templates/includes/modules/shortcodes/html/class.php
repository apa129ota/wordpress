<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Module_Shortcodes_Html')){
	class Class_My_Module_Shortcodes_Html extends Class_My_Module_Shortcodes_General{
		private $editor_options;
		private $editor_height=100;
		private $editor_id;
		static $num=0;
		function Class_My_Module_Shortcodes_Html($options=array()){
			Class_My_Module_Shortcodes_Html::$num++;
			$this->editor_id='my_editor_'.(Class_My_Module_Shortcodes_Html::$num);
			parent::Class_My_Module_Shortcodes_General($options);
			if(!empty($options['editor_options'])){
				$this->editor_options=$options['editor_options'];
			}else {
				$this->editor_options=array(
				            'forced_root_block' => "",
							'media_buttons'=>true,
							'wpautop'=>false,
							'editor_height'=>100,
							'teeny'=>true,
							'quicktags'=>false
					);
			}
			$this->renderForm();
		}
		public function renderForm(){
		    $my_set_debug=0;
		    $file=$this->module_dir.'html/options.php';
		    $options=require $file;
		    $elements=$options['form'];
		    $options=array(
		        'id'=>'html_form',
		        'elements'=>$elements,
		        'hidden'=>array(

		        ),
		        'element_template'=>'my_li.php',
		        'form_template'=>'my_form.php',
		        'my_debug'=>$my_set_debug
		    );
		    $form_class=new Class_Wp_My_Module_New_Form($options);
		    ob_start();
		    $form_class->render_form();
		    $this->formHtml=ob_get_clean();
		}
		public function display_element(){
		    $this->render_buttons(array(
		        'my_shortcode_insert_html'=>array(
		            'title'=>__("Update/Insert Content","my_support_theme")
		        )
		    ));
		    echo '<div style="height:50px;"></div>';
			echo $this->formHtml;
			echo '<div style="clear:both"></div>';
		    $value=$this->lorem;
			wp_editor($value,$this->editor_id,$this->editor_options);
			echo '<div style="clear:both"></div>';




		}
		public function display_content(){
			?>
			<script type="text/html" class="my_shortcode_html">
				<div class="my_shortcode_<?php echo $this->key;?> " id="{id}" data-id="{object_id}" data-i="{i}" data-sel="{sel}">
				{content}
				</div>
			</script>
			<script type="text/html" class="my_shortcode_html_default">
			<?php echo $this->lorem; ?>
			</script>
			<?php
		}

	}
}