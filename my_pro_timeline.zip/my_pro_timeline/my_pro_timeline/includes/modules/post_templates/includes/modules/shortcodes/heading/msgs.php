<?php
if(!defined('ABSPATH'))die('');
$arr=array(
        'video_title'=>__("Video","my_support_theme"),
        'lorem'=>__("Lorem ipsum","my_support_theme"),
		'add_media'=>__("Please Select Media Object ","my_support_theme"),
        'loading_video'=>__("Loading video Html","my_support_theme"),
        'edit_from'=>__("You can't edit now this item","my_support_theme"),
);
return $arr;