<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Module_Shortcodes_General')){
	class Class_My_Module_Shortcodes_General{
	    use MyDebug;
		protected $debug=true;
		protected $module_dir='';
		protected $module_url='';
		protected $lorem='';
		protected $dialog_header;
		protected $use_case='module_shortcodes';
		protected $key='';
		protected $options=array();
		function Class_My_Module_Shortcodes_General($options=array()){
			if(!empty($options)){
				foreach($options as $key=>$val){
					$this->$key=$val;
				}
			}
			if(empty($this->module_dir)){
				$this->module_dir=plugin_dir_path(__FILE__);
			}
			if(empty($this->module_url)){
				$this->module_url=plugin_dir_url(__FILE__);
			}
			if($this->debug){
				Class_My_Module_Debug::add_section('init_module_shortcodes_genreal', $options,$this->use_case,false);
			}
			if(empty($this->lorem)){
				$this->lorem='Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris luctus placerat dolor, id laoreet ipsum. Vivamus nisl nunc, tincidunt et tellus nec, pulvinar dictum diam. Praesent vitae tincidunt ligula. Aenean dignissim a elit id tempus. Vestibulum faucibus, metus in accumsan aliquam, tortor urna facilisis leo, in vulputate dolor est a dui. Nullam at purus at nunc eleifend elementum. Fusce blandit imperdiet enim a fermentum. Aenean semper neque at massa ornare, quis dapibus neque malesuada. Fusce accumsan orci ut purus blandit, aliquam imperdiet lectus scelerisque. Integer pulvinar efficitur tellus, id fringilla sem tincidunt mollis. Aenean in justo eget augue auctor accumsan. Donec sit amet tincidunt metus.';
			}
			$this->init_options();
		}
		public function getJscriptVals(){
			return array();
		}
		public function init_options(){
			$file=$this->module_dir.$this->key.'/options.php';
			if(file_exists($file)){
				$this->options=require $file;
				//print_r($this->options);
			}
		}
		public function get_options(){
			return $this->options;
		}
		public function render_buttons($buttons){
			?>
			<div class="my_shortcodes_buttons  my_clear_after">
				<div class="my_shortcodes_button_div">
					<ul>
					<?php foreach ($buttons as $key=>$val){?>
					<li><input type="button" class="button button-primary button-large <?php echo $key;?>" value="<?php echo $val['title']?>"/></li>
					<?php }?>
					</ul>
				</div>
			</div>
			<?php 
		}
		public function get_dialog_header(){
			return $this->dialog_header;
		}
		protected function display_element(){
			
		}
		protected function display_content(){
			
		}
		protected function init_jscript(){
			
		}

	}
}