<?php 
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Testimonials_Front_Module_Backend_Controller')){
	class Class_My_Testimonials_Front_Module_Backend_Controller extends Class_My_General_Controller{
		use MyDebug;
		
		protected $use_case='my_framework';
		private $module_class;
		function __construct($options=array()){
			if(!empty($options['debug'])){
				self::setDebugOptions($this->use_case);
			}
			$this->module_class=$options['module_class'];
			unset($options['module_class']);
			self::debug('testimonials_front_controller', $options,false);
			parent::Class_My_General_Controller($options);
			$this->ret['my_debug']=Class_My_Module_Debug::get_debug_source($this->use_case);	
		}
		public function route_ajax(){
			parent::route_ajax();
			if($this->debug){
				if(!empty($this->ajax_errors)){
					self::debug("errors", $this->ajax_errors,false);		
				}
			}
			if($this->debug){
				$this->ret['debug']=Class_My_Module_Debug::get_debug_source($this->use_case);
			}
			echo json_encode($this->ret);
			
			die('');	
		}
		protected function load_style(){
			$id=@$_POST['id'];
			$this->plugin_object->loadModuleClass('meta');
			$options=$this->plugin_object->loadOptions('meta_options.php');
			$class_meta=new Class_My_Module_Meta($options);
			$object=$class_meta->get_object($id);
			$ret['error']=0;
			$ret['msg']='';
			//if(!empty($object))
			if(!empty($object)&&$object->object_type=='style'){
				$type=$class_meta->get_object_meta($id, 'type');
				$title=$object->title;
				$values=$class_meta->get_object_meta($id, 'style');
				$ret['added_style']=array(
						'type'=>$type,
						'id'=>$id,
						'title'=>$title
				);
				$ret['values']=$values;
				$ret['msg']=__("Style is loaded","my_support_theme");
			}else {
				$ret['msg']=__("Error","my_support_theme");
				$ret['error']=1;
				
			}
			$this->ret=$ret;
		}
		protected function save(){
			$type=@$_POST['type'];
			$new=false;
			$form_data=@$_POST['form_data'];
			self::debug('form_post', $_POST);
			$form_arr=array();
			parse_str($form_data,$form_arr);
			$ret['error']=0;
			$ret['msg']='';
				
				
			if(!in_array($type, array('card','slider','grid','vertical'))){
				$ret['msg']=__("Error","my_support_theme");
				$ret['error']=1;
			}else {
				$elements=$this->module_class->getShortcodeElements($type);
					
				self::debug("elements", $elements);
				self::debug("shortcode_type", $type);
				wp_my_general_load_module_function(MY_TESTIMONIALS_LOCAL_MODULES_DIRNAME,'new_form','functions.php');
				$form_arr=my_new_form_clean_data($form_arr,$elements,array(
						'my_nonce',
						'my_section',
						'id',
				));
				self::debug("form_arr", $form_arr);
				$nonce=$form_arr['my_nonce'];
				if(!wp_verify_nonce($nonce,$type)){
					$ret['error']=1;
					$ret['msg']=__("Error","my_support_theme");
				}else {				
					$id=$form_arr['id'];
					$this->plugin_object->loadModuleClass('meta');
					$options=$this->plugin_object->loadOptions('meta_options.php');
					$class_meta=new Class_My_Module_Meta($options);
					if(empty($id))$new=true;
					else{
						$object=$class_meta->get_object($id);
						if($object->object_type!='shortcode'){
							$ret['error']=1;
							$ret['msg']=__("Error","my_support_theme");
							$this->ret=$ret;
							return;	
						}
					}	
					
					if($new){
						$title=$form_arr['title'];
						$id=$class_meta->insert_update_object($title, 'shortcode');
						$class_meta->add_update_object_meta($id, 'type', $type);
						$class_meta->add_update_object_meta($id, 'array', $form_arr);
						$ret['msg']=__("Shortcode has been saved !","my_support_theme");
						
					}else {
						$title=$form_arr['title'];
						$class_meta->insert_update_object($title, 'shortcode',$id);
						//$class_meta->add_update_object_meta($id, 'type', $type);
						self::debug("save_array", $form_arr);
						$class_meta->add_update_object_meta($id, 'array', $form_arr);
						$ret['msg']=__("Shortcode has been updated !","my_support_theme");
						
					}
					$ret['id']=$id;
				}
			}
			$this->ret=$ret;
		}
		protected function save_style(){
			$type=@$_POST['type'];
			
			$title=@$_POST['title'];
			$new_style=false;
			
				self::debug("save_style", array(
				'type'=>$type,'id'=>$id,$title=>$title
				));
			
			$form_data=@$_POST['form_data'];
			self::debug('form_post', $_POST);
			$form_arr=array();
			parse_str($form_data,$form_arr);
			$type=str_replace('_style', '', $type);
			self::debug("save_style", array(
					'type'=>$type,'id'=>$id,$title=>$title
			));
				
			$ret['error']=0;
			$ret['msg']='';
			
			
			if(!in_array($type, array('card','slider','grid','vertical'))){
				$ret['msg']=__("Error","my_support_theme");
				$ret['error']=1;
			}else {
				$elements=$this->module_class->getStylesElements($type);
				wp_my_general_load_module_function(MY_TESTIMONIALS_LOCAL_MODULES_DIRNAME,'new_form','functions.php');
				self::debug("styles_elements", $elements);
				$form_arr=my_new_form_clean_data($form_arr,$elements,array(
								'my_nonce',
								'my_section',
								'id',
						));
				self::debug("Form arr", $form_arr);
				$translate=array();
				foreach($elements as $k=>$v){
					if(!empty($v['translate'])){
						$translate[$k]=$v['translate'];
					}
				}
				$gen_css=wp_my_general_generate_simple_css_new($form_arr,'#my_timeline_{id}',$translate);
				self::debug("Gen css", $gen_css);
				
				$nonce=$form_arr['my_nonce'];
				if(!wp_verify_nonce($nonce,'shortcodes_module')){
					$ret['error']=1;
					$ret['msg']=__("Error","my_support_theme");
				}else {
				$id=$form_arr['id'];	
				if(empty($id))$new_style=true;
					
				$this->plugin_object->loadModuleClass('meta');
				$options=$this->plugin_object->loadOptions('meta_options.php');
				$class_meta=new Class_My_Module_Meta($options);
				$meta_key=$type.'_style';
				
				if($new_style){
					$id=$class_meta->insert_update_object($title, 'style');
					$class_meta->add_update_object_meta($id, 'type', $type.'_style');
						
					$class_meta->add_update_object_meta($id, 'style', $form_arr);
					$class_meta->add_update_object_meta($id, 'css', $gen_css);
					
					$ret['added_style']=array(
						'type'=>$type,
						'id'=>$id,
						'title'=>$title	
					);
					$ret['msg']=__("Style has been added !","my_support_theme");
				}else {
					$is=$class_meta->is_exists_object_by_type($id, 'style');
					if(!empty($is)){
						$ret['msg']=__("Style has been updated !","my_support_theme");
						$class_meta->insert_update_object($title, 'style',$id);
						$class_meta->add_update_object_meta($id, 'css', $gen_css);
						$class_meta->add_update_object_meta($id, 'style', $form_arr);
					}else {
						$ret['error']=1;
						$ret['msg']=__("Error","my_support_theme");
					}
					}
				}
			}
			$this->ret=$ret;
			
		}
	}
}