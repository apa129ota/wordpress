<?php
if(!defined('ABSPATH'))die('');
$styles['default']=array(
	'predefined_styles'=>array(
		'type'=>'jscript_dropdown',
		'tooltip'=>__("Styles","my_support_theme"),
		'title'=>__("Predefined Styles","my_support_theme"),
		'default'=>'gray',
		'values'=>array(
			'gray'=>__("Gray","my_support_theme"),
			'light'=>__("Light","my_support_theme"),
			'dark'=>__("Dark","my_support_theme"),
		),
			'jscript'=>array(
						'max_c'=>1,
						'max_sel'=>__("Maximum elements are selected","my_social_posts_domain"),
						'duration'=>500,
						'animation'=>'fadein',
						'choose_value'=>__("Plese Select value","my_social_posts_domain"),
				),
				'show_filter'=>0,
				'multiple'=>false,
				'choose_value'=>__("Plese Select value","my_social_posts_domain"),			
	),
	
	/*'active_item_color'=>array(
				'type'=>'jscript_color_picker',
				'title'=>__("Active item Color","my_social_posts_domain"),
				'tooltip'=>__("Choose color for an active card item","my_social_posts_domain"),
				'jscript'=>array(
					'pick_title'=>__("Pick a Color","my_support_theme"),
					'close_title'=>__("Close","my_support_theme"),
					'hex_title'=>__("Hex value","my_support_theme"),
					'transp_title'=>__("Transparency","my_support_theme")
				),
				'transparency'=>true,
				'default'=>array(
						"color"=>"#08b9f3",
						"transp"=>1),
				'translate'=>array(
					'class'=>'.my_timeline_current',
					'property'=>'border-color'
				)
					
	),*/
		'font-family'=>array(
				'type'=>'jscript_dropdown',
				'title'=>__("Font","my_social_posts_domain"),
				'tooltip'=>__("Choose default font or some google fonts","my_social_posts_domain"),
				'jscript'=>array(
						'max_c'=>1,
						'max_sel'=>__("Maximum elements are selected","my_social_posts_domain"),
						'duration'=>500,
						'animation'=>'fadein',
						'choose_value'=>__("Plese Select value","my_social_posts_domain"),
				),
				'show_filter'=>1,
				'multiple'=>false,
				'choose_value'=>__("Plese Select value","my_social_posts_domain"),
				'default'=>'default',
				'translate'=>array(
					'class'=>'.my_testimonial_item *:not(i)',
					'property'=>'font-family'
				)
					
	),
	'shortcode_color'=>array(
			'type'=>'jscript_color_picker',
			'tooltip'=>__("Shortcode Background Color","my_support_theme"),
			'title'=>__("Background Color","my_support_theme"),
			'pick_title'=>__("Pick a Color","my_support_theme"),
			'close_title'=>__("Close","my_support_theme"),
			'default'=>array(
					'color'=>'#ffffff',
					'transp'=>0
			),
			'jscript'=>array(
					'pick_title'=>__("Pick a Color","my_support_theme"),
					'close_title'=>__("Close","my_support_theme"),
					'hex_title'=>__("Hex value","my_support_theme"),
					'transp_title'=>__("Transparency","my_support_theme")
			),
			'transparency'=>true,
			'translate'=>array(
					'class'=>'.my_testimonial_shortcode_div',
					'property'=>'background-color'
			)
				),
	'load_more_back_color'=>array(
				'type'=>'jscript_color_picker',
				'tooltip'=>__("Load More Background Color","my_support_theme"),
				'title'=>__("Load More Background Color","my_support_theme"),
				'pick_title'=>__("Pick a Color","my_support_theme"),
				'close_title'=>__("Close","my_support_theme"),
				'default'=>array(
						'color'=>'#cccccc',
						'transp'=>1
				),
				'jscript'=>array(
						'pick_title'=>__("Pick a Color","my_support_theme"),
						'close_title'=>__("Close","my_support_theme"),
						'hex_title'=>__("Hex value","my_support_theme"),
						'transp_title'=>__("Transparency","my_support_theme")
				),
				'transparency'=>true,
				'translate'=>array(
						'class'=>'.my_testimonial_load_more',
						'property'=>'background-color'
				)
		),
		'load_more_color'=>array(
				'type'=>'jscript_color_picker',
				'tooltip'=>__("Load More Color","my_support_theme"),
				'title'=>__("Load More Color","my_support_theme"),
				'pick_title'=>__("Pick a Color","my_support_theme"),
				'close_title'=>__("Close","my_support_theme"),
				'default'=>'#ffffff',
				'jscript'=>array(
						'pick_title'=>__("Pick a Color","my_support_theme"),
						'close_title'=>__("Close","my_support_theme"),
						'hex_title'=>__("Hex value","my_support_theme"),
						'transp_title'=>__("Transparency","my_support_theme")
				),
				'transparency'=>false,
				'translate'=>array(
						'class'=>'.my_testimonial_load_more_span , .my_testimonial_load_more_span i',
						'property'=>'color'
				)
		),
	'thumbs_background_color'=>array(
				'type'=>'jscript_color_picker',
				'tooltip'=>__("Thumbs Background Color","my_support_theme"),
				'title'=>__("Thumbs Background Color","my_support_theme"),
				'pick_title'=>__("Pick a Color","my_support_theme"),
				'close_title'=>__("Close","my_support_theme"),
				'default'=>array(
						'color'=>'#ffffff',
						'transp'=>0
				),
				'jscript'=>array(
						'pick_title'=>__("Pick a Color","my_support_theme"),
						'close_title'=>__("Close","my_support_theme"),
						'hex_title'=>__("Hex value","my_support_theme"),
						'transp_title'=>__("Transparency","my_support_theme")
				),
				'transparency'=>true,
				'translate'=>array(
						'class'=>'.my_testimonial_thumbs_ul',
						'property'=>'background-color'
				)
		),
	'card_current_color'=>array(
				'type'=>'jscript_color_picker',
				'tooltip'=>__("Active Item Color","my_support_theme"),
				'title'=>__("Active Item Color","my_support_theme"),
				'pick_title'=>__("Pick a Color","my_support_theme"),
				'close_title'=>__("Close","my_support_theme"),
				'default'=>array(
						'color'=>'#08b9f3',
						'transp'=>1
				),
				'jscript'=>array(
						'pick_title'=>__("Pick a Color","my_support_theme"),
						'close_title'=>__("Close","my_support_theme"),
						'hex_title'=>__("Hex value","my_support_theme"),
						'transp_title'=>__("Transparency","my_support_theme")
				),
				'transparency'=>true,
				'translate'=>array(
						'class'=>'.my_timeline_current:after{{css}}',
						'property'=>array(
							'css'=>'content:"";width:100%;display:block;position:absolute;top:0px;left:0px;border-top:5px solid {val} !important;'	
					
							)
				)
		),
	'item_background'=>array(
			'type'=>'jscript_color_picker',
			'tooltip'=>__("Item Background Color","my_support_theme"),
			'title'=>__("Item Background Color","my_support_theme"),
			'pick_title'=>__("Pick a Color","my_support_theme"),
			'close_title'=>__("Close","my_support_theme"),
			'default'=>array(
					'color'=>'#000000',
					'transp'=>0
			),
			'jscript'=>array(
					'pick_title'=>__("Pick a Color","my_support_theme"),
					'close_title'=>__("Close","my_support_theme"),
					'hex_title'=>__("Hex value","my_support_theme"),
					'transp_title'=>__("Transparency","my_support_theme")
			),
			'transparency'=>true,
			'translate'=>array(
					'class'=>'.my_testimonial_item',
					'property'=>'background-color'
			)
	),
	'text_background'=>array(
				'type'=>'jscript_color_picker',
				'tooltip'=>__("Text Background Color","my_support_theme"),
				'title'=>__("Text Background Color","my_support_theme"),
				'pick_title'=>__("Pick a Color","my_support_theme"),
				'close_title'=>__("Close","my_support_theme"),
				'default'=>'#cccccc',
				'jscript'=>array(
						'pick_title'=>__("Pick a Color","my_support_theme"),
						'close_title'=>__("Close","my_support_theme"),
						'hex_title'=>__("Hex value","my_support_theme"),
						'transp_title'=>__("Transparency","my_support_theme")
				),
				'transparency'=>false,
				'translate'=>array(
						'class'=>'.my_testimonial_text',
						'property'=>'background-color',
						'css'=>array(
							'.my_top_arrow{
								border-bottom:10px solid {val} !important;
							}',
							'.my_bottom_arrow{
								border-top:10px solid {val} !important;
							}',
							'.my_testimonial_text{
								background-color: {val} !important;	
							}'		
							
						)
				)
		),
		'text_border_color'=>array(
				'type'=>'jscript_color_picker',
				'tooltip'=>__("Text Border Color","my_support_theme"),
				'title'=>__("Adjust text border Color","my_support_theme"),
				'pick_title'=>__("Pick a Color","my_support_theme"),
				'close_title'=>__("Close","my_support_theme"),
				'default'=>'#cccccc',
				'jscript'=>array(
						'pick_title'=>__("Pick a Color","my_support_theme"),
						'close_title'=>__("Close","my_support_theme"),
						'hex_title'=>__("Hex value","my_support_theme"),
						'transp_title'=>__("Transparency","my_support_theme")
				),
				'transparency'=>false,
				'translate'=>array(
						'class'=>'.my_testimonial_text',
						'property'=>'border-color',
						'css'=>array(
								'.my_top_arrow_inner{
								 border-bottom:11px solid {val} !important;
							}',
							'.my_bottom_arrow_inner{
								border-top:11px solid {val} !important;
							}'
			
						)
				)
		),
	'thumb_border_color'=>array(
			'type'=>'jscript_color_picker',
			'tooltip'=>__("Thumb border Color","my_support_theme"),
			'title'=>__("Thumb border Color","my_support_theme"),
			'pick_title'=>__("Pick a Color","my_support_theme"),
			'close_title'=>__("Close","my_support_theme"),
			'default'=>'#cccccc',
			'jscript'=>array(
					'pick_title'=>__("Pick a Color","my_support_theme"),
					'close_title'=>__("Close","my_support_theme"),
					'hex_title'=>__("Hex value","my_support_theme"),
					'transp_title'=>__("Transparency","my_support_theme")
			),
			'transparency'=>false,
			'translate'=>array(
					'class'=>'.my_testimonial_item img, .my_testimonial_thumbs_thumb',
					'property'=>'border-color'
			)
	),	
	'thumb_arrow_border_color'=>array(
				'type'=>'jscript_color_picker',
				'tooltip'=>__("Thumb Arrow border Color","my_support_theme"),
				'title'=>__("Thumb Arrow border Color","my_support_theme"),
				'pick_title'=>__("Pick a Color","my_support_theme"),
				'close_title'=>__("Close","my_support_theme"),
				'default'=>'#08b9f3',
				'jscript'=>array(
						'pick_title'=>__("Pick a Color","my_support_theme"),
						'close_title'=>__("Close","my_support_theme"),
						'hex_title'=>__("Hex value","my_support_theme"),
						'transp_title'=>__("Transparency","my_support_theme")
				),
				'transparency'=>false,
				'translate'=>array(
						'class'=>'.my_testimonial_next img',
						'property'=>'border-color'
				)
		),
	'text_color'=>array(
			'type'=>'jscript_color_picker',
			'tooltip'=>__("Text Color","my_support_theme"),
			'title'=>__("Text Color","my_support_theme"),
			'pick_title'=>__("Pick a Color","my_support_theme"),
			'close_title'=>__("Close","my_support_theme"),
			'default'=>'#000000',
			'jscript'=>array(
					'pick_title'=>__("Pick a Color","my_support_theme"),
					'close_title'=>__("Close","my_support_theme"),
					'hex_title'=>__("Hex value","my_support_theme"),
					'transp_title'=>__("Transparency","my_support_theme")
			),
			'transparency'=>false,
			'translate'=>array(
					'class'=>'.my_testimonial_text',
					'property'=>'color'
			)
	),
	'arrows_color'=>array(
				'type'=>'jscript_color_picker',
				'tooltip'=>__("Arrows Color","my_support_theme"),
				'title'=>__("Arrows Color","my_support_theme"),
				'pick_title'=>__("Pick a Color","my_support_theme"),
				'close_title'=>__("Close","my_support_theme"),
				'default'=>'#000000',
				'jscript'=>array(
						'pick_title'=>__("Pick a Color","my_support_theme"),
						'close_title'=>__("Close","my_support_theme"),
						'hex_title'=>__("Hex value","my_support_theme"),
						'transp_title'=>__("Transparency","my_support_theme")
				),
				'transparency'=>false,
				'translate'=>array(
						'class'=>'.my_line_nav span i, .my_line_nav span',
						'property'=>'color'
				)
	),
	'arrows_background_color'=>array(
				'type'=>'jscript_color_picker',
				'tooltip'=>__("Arrows background Color","my_support_theme"),
				'title'=>__("Arrows background color ","my_support_theme"),
				'pick_title'=>__("Pick a Color","my_support_theme"),
				'close_title'=>__("Close","my_support_theme"),
				'default'=>'#cccccc',
				'jscript'=>array(
						'pick_title'=>__("Pick a Color","my_support_theme"),
						'close_title'=>__("Close","my_support_theme"),
						'hex_title'=>__("Hex value","my_support_theme"),
						'transp_title'=>__("Transparency","my_support_theme")
				),
				'transparency'=>false,
				'translate'=>array(
						'class'=>'.my_line_nav',
						'property'=>'background-color'
				)
		),
	'arrows_hover_color'=>array(
				'type'=>'jscript_color_picker',
				'tooltip'=>__("Arrows Hover Color","my_support_theme"),
				'title'=>__("Arrows Hover Color","my_support_theme"),
				'pick_title'=>__("Pick a Color","my_support_theme"),
				'close_title'=>__("Close","my_support_theme"),
				'default'=>'#ccccccc',
				'jscript'=>array(
						'pick_title'=>__("Pick a Color","my_support_theme"),
						'close_title'=>__("Close","my_support_theme"),
						'hex_title'=>__("Hex value","my_support_theme"),
						'transp_title'=>__("Transparency","my_support_theme")
				),
				'transparency'=>false,
				/*'translate'=>array(
						'class'=>'.my_line_nav',
						'property'=>'background-color'
				)*/
		),
	'arrows_border_color'=>array(
				'type'=>'jscript_color_picker',
				'tooltip'=>__("Arrows Border Color","my_support_theme"),
				'title'=>__("Arrows Border Color","my_support_theme"),
				'pick_title'=>__("Pick a Color","my_support_theme"),
				'close_title'=>__("Close","my_support_theme"),
				'default'=>'#ffffff',
				'jscript'=>array(
						'pick_title'=>__("Pick a Color","my_support_theme"),
						'close_title'=>__("Close","my_support_theme"),
						'hex_title'=>__("Hex value","my_support_theme"),
						'transp_title'=>__("Transparency","my_support_theme")
				),
				'transparency'=>false,
				'translate'=>array(
						'class'=>'.my_line_nav',
						'property'=>'border-color'
				)
		),
		'metadata_color'=>array(
				'type'=>'jscript_color_picker',
				'title'=>__("Metadata Text color","my_support_theme"),
				'tooltip'=>__("Adjust color for comapny and other fields","my_support_theme"),
				'pick_title'=>__("Pick a Color","my_support_theme"),
				'close_title'=>__("Close","my_support_theme"),
				'default'=>'#000000',
				'jscript'=>array(
						'pick_title'=>__("Pick a Color","my_support_theme"),
						'close_title'=>__("Close","my_support_theme"),
						'hex_title'=>__("Hex value","my_support_theme"),
						'transp_title'=>__("Transparency","my_support_theme")
				),
				'translate'=>array(
						'class'=>'.my_testimonials_metadata li span',
						'property'=>'color'
				)
		),
		'link_color'=>array(
				'type'=>'jscript_color_picker',
				'title'=>__("Metadata Link color","my_support_theme"),
				'tooltip'=>__("Adjust Link color for comapny url","my_support_theme"),
				'pick_title'=>__("Pick a Color","my_support_theme"),
				'close_title'=>__("Close","my_support_theme"),
				'default'=>"#08b9f3",
				'jscript'=>array(
						'pick_title'=>__("Pick a Color","my_support_theme"),
						'close_title'=>__("Close","my_support_theme"),
						'hex_title'=>__("Hex value","my_support_theme"),
						'transp_title'=>__("Transparency","my_support_theme")
				),
				'translate'=>array(
						'class'=>'.my_testimonials_metadata li a',
						'property'=>'color'
				)
		),
		'link_hover_color'=>array(
				'type'=>'jscript_color_picker',
				'title'=>__("Metadata Link Hover color","my_support_theme"),
				'tooltip'=>__("Adjust Link Hover color for comapny url","my_support_theme"),
				'pick_title'=>__("Pick a Color","my_support_theme"),
				'close_title'=>__("Close","my_support_theme"),
				'default'=>"#08b9f3",
				'jscript'=>array(
						'pick_title'=>__("Pick a Color","my_support_theme"),
						'close_title'=>__("Close","my_support_theme"),
						'hex_title'=>__("Hex value","my_support_theme"),
						'transp_title'=>__("Transparency","my_support_theme")
				),
				'translate'=>array(
						'class'=>'.my_testimonials_metadata li a:hover',
						'property'=>'color'
				)
		),
		'stars_color'=>array(
				'type'=>'jscript_color_picker',
				'title'=>__("Star color","my_support_theme"),
				'tooltip'=>__("Adjust  star color","my_support_theme"),
				'pick_title'=>__("Pick a Color","my_support_theme"),
				'close_title'=>__("Close","my_support_theme"),
				'default'=>"#EEAA00",
				'jscript'=>array(
						'pick_title'=>__("Pick a Color","my_support_theme"),
						'close_title'=>__("Close","my_support_theme"),
						'hex_title'=>__("Hex value","my_support_theme"),
						'transp_title'=>__("Transparency","my_support_theme")
				),
				'translate'=>array(
						'class'=>'.my_jscript_stars ul li i',
						'property'=>'color'
				)
		),
		'stars_active_color'=>array(
				'type'=>'jscript_color_picker',
				'title'=>__("Active star color","my_support_theme"),
				'tooltip'=>__("Adjust Active star color","my_support_theme"),
				'pick_title'=>__("Pick a Color","my_support_theme"),
				'close_title'=>__("Close","my_support_theme"),
				'default'=>"#ff7700",
				'jscript'=>array(
						'pick_title'=>__("Pick a Color","my_support_theme"),
						'close_title'=>__("Close","my_support_theme"),
						'hex_title'=>__("Hex value","my_support_theme"),
						'transp_title'=>__("Transparency","my_support_theme")
				),
				'translate'=>array(
						'class'=>'.my_jscript_stars ul li i.my_stars_active',
						'property'=>'color'
				)
		),
		
		

);
$styles['default_style']='gray';
$styles['styles']['gray']=array(
		'shortcode_color'=>'#ffffff,0',
		'item_background'=>'#ffffff,1',
		'text_background'=>'#F5F5F5',
		'text_border_color'=>'#ccccccc',
		'text_color'=>'#000000',
		'arrows_color'=>'#ffffff',
		'arrows_background_color'=>'#cccccc',
		'arrows_hover_color'=>'#08b9f3',
		'arrows_border_color'=>'#ffffff',
		'metadata_color'=>'#000000',
		'link_color'=>"#08b9f3",
		'link_hover_color'=>"#08b9f3",
		'card_current_color'=>"#08b9f3",
		'thumb_border_color'=>'#cccccc',
		'thumb_arrow_border_color'=>'#08b9f3',
		'stars_color'=>"#EEAA00",
		'stars_active_color'=>"#ff7700",
		'thumbs_background_color'=>'#ffffff,1',
		'load_more_back_color'=>'#ccccccc'
);
$styles['styles']['dark']=array(
		'shortcode_color'=>'#ffffff,0',
		'item_background'=>'#ffffff,1',
		'text_background'=>'#333333',
		'text_border_color'=>'#1C1D1F',
		'text_color'=>'#70747d',
		'arrows_color'=>'#ffffff',
		'arrows_background_color'=>'#70747d',
		'arrows_hover_color'=>'#dd5555',
		'arrows_border_color'=>'#ffffff',
		'metadata_color'=>'#70747d',
		'link_color'=>"#f62d4c",
		'link_hover_color'=>"#f62d4c",
		'card_current_color'=>"#70747d",
		'backgrouund_image'=>'',
		'thumb_border_color'=>'#1C1D1F',
		'thumb_arrow_border_color'=>'#1C1D1F',
		'stars_color'=>"#EEAA00",
		'stars_active_color'=>"#ff7700",
		'thumbs_background_color'=>'#ffffff,1',
		'load_more_back_color'=>'#333333'
);
$styles['styles']['light']=array(
		'shortcode_color'=>'#ffffff,0',
		'thumbs_background_color'=>'#ffffff,1',
		'item_background'=>'#ffffff,1',
		'text_background'=>'#eaeaea',
		'text_border_color'=>'#cccccc',
		'text_color'=>'#70747d',
		'arrows_color'=>'#ffffff',
		'arrows_background_color'=>'#70747d',
		'arrows_hover_color'=>'#dd5555',
		'arrows_border_color'=>'#ffffff',
		'metadata_color'=>'#70747d',
		'link_color'=>"#dd5555",
		'link_hover_color'=>"#dd5555",
		'card_current_color'=>"#dd5555",		
		'thumb_border_color'=>'#dd5555',
		'thumb_arrow_border_color'=>'#dd5555',
		'stars_color'=>"#EEAA00",
		'stars_active_color'=>"#dd5555"

);
$styles['shortcodes']['card']=array(
	'title'=>__("Card Styles","my_support_theme"),
	'styles'=>array(
			'predefined_styles',
			'font-family',
			'shortcode_color',
			'thumbs_background_color',
			'item_background',
			'text_background',
			'text_color',
			'text_border_color',
			'card_current_color',
			'thumb_border_color',
			'thumb_arrow_border_color',
			'arrows_color',
			'arrows_background_color',
			'arrows_border_color',
			'arrows_hover_color',
			'metadata_color',
			'link_color',
			'link_hover_color',
			'stars_color',
			'stars_active_color',
			
			
	),
	'settings'=>array(
		'show_thumbs'=>1,
		'thumbs_pos'=>'below',
		'shadow'=>'show',	
		'thumbs_show'=>array(
			'{stars}'
		),				
		'show_nav'=>1,	
		'layout_cols'=>3,
		'float'=>'right',
		'nav_type'=>'circle',
		'template'=>'center_bottom',
		'show_text_border'=>1,
		'swipeOn'=>1,
		'form'=>array(
			'autoplay'=>0,
			'show_nav'=>1,
			'show_thumbs'=>1,
			'start_item'=>5,
			'circle_hover_color'=>'#08b9f3',
			'circle_back_color'=>'#ccc',
			'circle_duration'=>400					
		),
		'layout'=>array(
			'1600'=>array(
				'height'=>'400px',
				'cols'=>5
				),
			'1280'=>array(
						'height'=>'400px',
						'cols'=>3
				),
			'980'=>array(
						'height'=>'400px',
						'cols'=>3
				),
			'700'=>array(
						'height'=>'400px',
						'cols'=>3
				),
			'small'=>array(
						'height'=>'400px',
						'cols'=>1
				)
				
		)					
	)		
);
$styles['shortcodes']['slider']=array(
		'title'=>__("Slider Styles","my_support_theme"),
		'styles'=>array(
				'predefined_styles',
				'font-family',
				'shortcode_color',
				'thumbs_background_color',
				'item_background',
				'text_background',
				'text_color',
				'text_border_color',
				'card_current_color',
				'thumb_border_color',
				'thumb_arrow_border_color',
				'arrows_color',
				
				'arrows_background_color',
				'arrows_border_color',
				'arrows_hover_color',
				'metadata_color',
				'link_color',
				'link_hover_color',
				'stars_color',
				'stars_active_color',
				
		
		),
		'settings'=>array(
				'show_thumbs'=>1,
				'thumbs_pos'=>'below',
				'shadow'=>'show',
				'thumbs_show'=>array(
						'{stars}'
				),
				'show_nav'=>1,
				'layout_cols'=>3,
				'float'=>'right',
				'nav_type'=>'circle',
				'template'=>'bottom',
				'show_text_border'=>1,
				'swipeOn'=>1,
				'form'=>array(
						'autoplay'=>0,
						'show_nav'=>1,
						'show_thumbs'=>1,
						'start_item'=>5,
						'circle_hover_color'=>'#08b9f3',
						'circle_back_color'=>'#ccc',
						'circle_duration'=>400
				),
				'layout'=>array(
						'1600'=>array(
								'height'=>'500px',
								'cols'=>1
						),
						'1280'=>array(
								'height'=>'500px',
								'cols'=>1
						),
						'980'=>array(
								'height'=>'500px',
								'cols'=>1
						),
						'700'=>array(
								'height'=>'500px',
								'cols'=>1
						),
						'small'=>array(
								'height'=>'500px',
								'cols'=>1
						)

				)
		)
);
$styles['shortcodes']['grid']=array(
		'title'=>__("Grid Styles","my_support_theme"),
		'styles'=>array(
				'predefined_styles',
				'font-family',
				'shortcode_color',
				//'thumbs_background_color',
				'item_background',
				'text_background',
				'text_color',
				'text_border_color',
				//'card_current_color',
				'thumb_border_color',
				//'thumb_arrow_border_color',
				//'arrows_color',

				//'arrows_background_color',
				//'arrows_border_color',
				//'arrows_hover_color',
				'metadata_color',
				'link_color',
				'link_hover_color',
				'load_more_color',
				'load_more_back_color',
				'stars_color',
				'stars_active_color',
				
		),
		'settings'=>array(
				'show_thumbs'=>1,
				'thumbs_pos'=>'below',
				'shadow'=>'show',
				'thumbs_show'=>array(
						'{stars}'
				),
				'show_nav'=>1,
				'layout_cols'=>3,
				'float'=>'right',
				'nav_type'=>'circle',
				'template'=>'bottom',
				'show_text_border'=>1,
				'swipeOn'=>1,
				'form'=>array(
						'autoplay'=>0,
						'show_nav'=>1,
						'show_thumbs'=>1,
						'start_item'=>5,
						'circle_hover_color'=>'#08b9f3',
						'circle_back_color'=>'#ccc',
						'circle_duration'=>400
				),
				'layout'=>array(
						'1600'=>array(
								'height'=>'400px',
								'cols'=>5
						),
						'1280'=>array(
								'height'=>'400px',
								'cols'=>4
						),
						'980'=>array(
								'height'=>'400px',
								'cols'=>3
						),
						'700'=>array(
								'height'=>'400px',
								'cols'=>2
						),
						'small'=>array(
								'height'=>'400px',
								'cols'=>1
						)

				)
		)
);

return $styles;