<?php
if(!defined('ABSPATH'))die('');
global $wp_my_module_shortcode_google_fonts;
$units1=array(
    'px'=>'px',
    '%'=>'%',
);

$options=array(
	'section_title'=>__("HTML Style Options","my_support_theme"),
	'elements'=>array(
		'save'=>array(
			'title'=>__("Save Style","my_support_theme"),
			'type'=>'button',
			'value'=>__("Save Style","my_support_theme"),
			'class'=>'button button-primary my_save_style',
			'type'=>'button',
			'default'=>'0'
		),
		'load'=>array(
					'title'=>__("Load Style","my_support_theme"),
					'type'=>'button',
					'value'=>__("Load Style","my_support_theme"),
					'class'=>'button button-primary my_load_style',
					'type'=>'button',
					'default'=>'0'
			),
		'font-size'=>array(
				'title'=>__("Font Size","my_support_theme"),
				'type'=>'text',
				'default'=>'14px',
				'translate'=>array(
						'class'=>'{class} *',
						'property'=>'font-size'
				)
		),
		'background-color'=>array(
					'type'=>'jscript_color_picker',
					'tooltip'=>__("Background Color if you want to be invisibvle set transparency to 0","my_support_theme"),
					'title'=>__("Bakcground Color","my_support_theme"),
					'pick_title'=>__("Pick a Color","my_support_theme"),
					'close_title'=>__("Close","my_support_theme"),
					'default'=>array(
							'color'=>'#000000',
							'transp'=>0.3
					),
					'jscript'=>array(
							'pick_title'=>__("Pick a Color","my_support_theme"),
							'close_title'=>__("Close","my_support_theme"),
							'hex_title'=>__("Hex value","my_support_theme"),
							'transp_title'=>__("Transparency","my_support_theme")
					),
					'transparency'=>true,
					'translate'=>array(
						'class'=>'{class}',
						'property'=>'background-color'
					)

			),
		'font-color'=>array(
				'type'=>'jscript_color_picker',
				'tooltip'=>__("Pick font color","my_support_theme"),
				'title'=>__("Font Color","my_support_theme"),
				'pick_title'=>__("Pick a Color","my_support_theme"),
				'close_title'=>__("Close","my_support_theme"),
				'default'=>'#ffffff',
				'jscript'=>array(
						'pick_title'=>__("Pick a Color","my_support_theme"),
						'close_title'=>__("Close","my_support_theme"),
						'hex_title'=>__("Hex value","my_support_theme"),
						'transp_title'=>__("Transparency","my_support_theme")
				),
				'transparency'=>false,
				'translate'=>array(
						'class'=>'{class} *:not(a)',
						'property'=>'color'
				)
		),
		'line-height'=>array(
					'title'=>__("Line Height","my_support_theme"),
					'type'=>'text',
					'default'=>'18px',
					'translate'=>array(
						'class'=>'{class} *',
						'property'=>'line-height'
					)
		),
		'font-family'=>array(
					'title'=>__("Font Family","my_support_theme"),
					'type'=>'jscript_dropdown',
					'values'=>$wp_my_module_shortcode_google_fonts,
					'widths'=>array(
						600=>'100%',
						1200=>'100%',
					),
					'jscript'=>array(
						'max_c'=>1,
						'max_sel'=>__("Maximum elements are selected","my_support_theme"),
						'duration'=>500,
						'animation'=>'fadein',
						'choose_value'=>__("Plese Select value","my_support_theme"),
					),
					'show_filter'=>1,
					'multiple'=>false,
					'choose_value'=>__("Font","my_support_theme"),
					'default'=>'default',
					'translate'=>array(
						'class'=>'{class} *',
						'property'=>'font-family'

					)
		),
		'link-color'=>array(
				'type'=>'jscript_color_picker',
				'tooltip'=>__("Html a color","my_support_theme"),
				'title'=>__("Link Color","my_support_theme"),
				'pick_title'=>__("Pick a Color","my_support_theme"),
				'close_title'=>__("Close","my_support_theme"),
				'default'=>'#0074A2',
				'jscript'=>array(
						'pick_title'=>__("Pick a Color","my_support_theme"),
						'close_title'=>__("Close","my_support_theme"),
						'hex_title'=>__("Hex value","my_support_theme"),
						'transp_title'=>__("Transparency","my_support_theme")
				),
				'transparency'=>false,
				'translate'=>array(
						'class'=>'{class} a',
						'property'=>'color'
				)
		),
		'link-hover-color'=>array(
				'type'=>'jscript_color_picker',
				'tooltip'=>__("Html a hover color","my_support_theme"),
				'title'=>__("Link Hover","my_support_theme"),
				'pick_title'=>__("Pick a Color","my_support_theme"),
				'close_title'=>__("Close","my_support_theme"),
				'default'=>'#0074A2',
				'jscript'=>array(
						'pick_title'=>__("Pick a Color","my_support_theme"),
						'close_title'=>__("Close","my_support_theme"),
						'hex_title'=>__("Hex value","my_support_theme"),
						'transp_title'=>__("Transparency","my_support_theme")
				),
				'transparency'=>false,
				'translate'=>array(
						'class'=>'{class} a:hover',
						'property'=>'color'
				)
				)

	)
);
$options['form']=array(
    'text'=>array(
        'layout_class'=>'my_col_100',
        'tooltip'=>__("Text in list item","my_support_theme"),
        'title'=>__("Text","my_support_theme"),
        'type'=>'textarea',
        'default'=>__("Lorem ipsum","my_support_theme"),

    ),
    'link'=>array(
        'layout_class'=>'my_col_50',
        'type'=>'jscript_autocomplete',
        'title'=>__("Get Link from autocomplete","my_support_theme"),
        'multiple'=>false,
        'nonce_str'=>'my_list_autocomplete',
        'show_values'=>true,
        'jscript'=>array(
            'show_values'=>0,
            'multiple'=>0,
            'url'=>admin_url('admin-ajax.php'),
            'min_length'=>3,
            'ajax_data'=>array(
                'action'=>'my_module_post_templates',
                'my_action'=>'my_get_link'
                
            ),
            'events'=>array(
                        //'select_event'=>'myVusualBuilderShortcodesList_inst.selectLink'
               )
           )
                
            
        
    ),
    'use_link'=>array(
        'layout_class'=>'my_col_25',
        'type'=>'on_off',
        'title'=>__("Add link to li","my_support_theme"),
        'tooltip'=>__("Specify link to li element","my_support_theme"),
        
    ),
    
    'use_icon'=>array(
        'layout_class'=>'my_col_25',
        'type'=>'on_off',
        'title'=>__("Use Icon","my_support_theme"),
        'tooltip'=>__("Add icon to elements","my_support_theme"),

    ),
    'icons'=>array(

        'type'=>'jscript_dropdown',
        'layout_class'=>'my_col_100',
         'use_filter'=>1,
        'jscript'=>array(
            'icon'=>1,
            'use_filter'=>1,
        ),
        'title'=>__("Icon","my_support_theme"),
        'tooltip'=>__("Add icon to elements","my_support_theme"),
        'default'=>'fa-plus',

    ),
    'button'=>array(
        'type'=>'button',
        'class'=>array(
            'my_shortcode_list_add_list_item','button-primary','button-large'
        ),
        'value'=>__("Add list item","my_support_theme"),
    )

   /* 'overflow_y'=>array(
        'type'=>'jscript_dropdown',
        'layout_class'=>'my_col_50',

        'value'=>'0',
        'title'=>__("Overflow Y","my_support_theme"),
        'tooltip'=>__("Set eleemnt overflow. If you want to limit height choose overflow hidden.","my_support_theme"),
        'default'=>'auto',
        'values'=>array(
            'hidden'=>__("Hidden","my_support_theme"),
            'scroll'=>__("Scroll","my_support_theme"),
            'auto'=>__("Auto","my_support_theme"),
        )
    ),
    */
/*
    'scrollBarLineColor'=>array(
        'layout_class'=>'my_col_50',

        'type'=>'jscript_color_picker',
        'tooltip'=>__("Scroll Line color","my_support_theme"),
        'title'=>__("Scroll Line Color","my_support_theme"),
        'pick_title'=>__("Pick a Color","my_support_theme"),
        'close_title'=>__("Close","my_support_theme"),
        'default'=>array(
            'color'=>'#000000',
            'transp'=>0.4
        ),
        'jscript'=>array(
            'pick_title'=>__("Pick a Color","my_support_theme"),
            'close_title'=>__("Close","my_support_theme"),
            'hex_title'=>__("Hex value","my_support_theme"),
            'transp_title'=>__("Transparency","my_support_theme")
        ),
        'property'=>array(
            'class'=>'{class}',
            'property'=>'background'
        ),
        'transparency'=>true,
    ),
    'scrollBarDragColor'=>array(
        'layout_class'=>'my_col_50',

        'type'=>'jscript_color_picker',
        'tooltip'=>__("Scroll Bar color","my_support_theme"),
        'title'=>__("Scroll Bar Color","my_support_theme"),
        'pick_title'=>__("Pick a Color","my_support_theme"),
        'close_title'=>__("Close","my_support_theme"),
        'default'=>array(
            'color'=>'#ffffff',
            'transp'=>0.75
        ),
        'jscript'=>array(
            'pick_title'=>__("Pick a Color","my_support_theme"),
            'close_title'=>__("Close","my_support_theme"),
            'hex_title'=>__("Hex value","my_support_theme"),
            'transp_title'=>__("Transparency","my_support_theme")
        ),
        'property'=>array(
            'class'=>'{class}',
            'property'=>'background'
        ),
        'transparency'=>true,
    ),
    /* 'overflow'=>array(

    )*/

);
$options['styles']=array(
    'my_shortcode_list_ul'=>array(
        'title'=>__("List Ul","my_support_theme"),
        'css_rules'=>array(
            'list_style_type'=>'none',
            'list_style_image'=>'',
            'list_style_position'=>'inside',
            'list_style_icon'=>''
        )
    ),
    'my_shortcode_list_li'=>array(
        'title'=>__("List li","my_support_theme"),
        'css_rules'=>array(
            /*'list_style_type'=>'none',*/
            'padding'=>'5px 0px 0px 5px',
        )
    ),
    'my_shortcode_list_a'=>array(
        'title'=>__("List link","my_support_theme"),
        
        'css_rules'=>array(
            
        )
    ),
    'my_shortcode_list_li_icon'=>array(
        'title'=>__("List icon","my_support_theme"),
        'css_rules'=>array(
            'font-size'=>'14px',
            'display'=>'inline-block',
            'color'=>'#ffffff,1',
            'hover_color'=>'#ffffff,0.8',
            'line-height'=>'20px',
            'paddding'=>'0px 5px 0px 0px'
        )
    ),
    'my_shortcode_list_li_span'=>array(
        'title'=>__("List text","my_support_theme"),
        'css_rules'=>array(
            'font-size'=>'14px',
            'display'=>'inline-block',
            'color'=>'#ffffff,1',
            'hover_color'=>'#ffffff,0.8',
            'line-height'=>'20px'
            
        )
    )
);
return $options;
