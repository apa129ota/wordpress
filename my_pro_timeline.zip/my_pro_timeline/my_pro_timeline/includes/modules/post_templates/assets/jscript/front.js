/**
 * 
 */
jQuery(document).ready(function($){
	$(window).load(function(e){
		my_post_showed_dialog=false;
		my_post_showed_id='';
		my_comments_effect_dialog_close=function(eff,o){
			var myEffectComm=eff;
			var opt=o;
		$(document).on("click",".my_comments_dialog_close",function(e){
			var network="";
			network=$(this).attr('data-network');
			var selComm=".my_"+network+"_comments";
			$(selComm).hide(myEffectComm,{direction:"down"},500);
		});
		}
		my_comments_effect_dialog=function(eff,o){
			var myEffectComm=eff;
			$(document).on('click','.my_comments',function(e){
				var h=$(this).parents('.my_post_template').outerHeight(true);
				
				var network="";
				if($(this).hasClass('my_social_facebook_comments'))network="facebook";
				e.preventDefault();
				var opt=o;
				var selComm=".my_"+network+"_comments";
				$(selComm).height(h);
				$(selComm+" img").each(function(i,v){
					var d=$(v).data('img');
					var isD=$(v).attr('src');
					if(isD!=d){
						$(v).attr('src',d);
						$(v).load(function(e){
							$(this).siblings('.my_load').remove();
						});
					}
				});
				//var opt={};
				
				$(selComm).show(myEffectComm,opt,500,function(){
					
					var is=$(this).attr('data-isCustomScrollbar');
					if(typeof is=='undefined'){
						$(this).attr('data-isCustomScrollbar',1);
					
					$(this).find(selComm+"_inner").mCustomScrollbar({advanced:{
				updateOnContentResize:true
					}});
					}
			
				});
			});
		}
		my_comments_effect_dialog_close('slide',{direction:'down'});
		my_comments_effect_dialog('slide',{direction:'down'});
		/*$("body").click(function(e){
			
			if(my_post_showed_dialog){
				
				//debug('Close Dialog');
				$("#my_timeline_share_click").animate({opacity:0},function(){
					my_showed_dialog=false;
				});
				
			}
		});*/
		$(document).on('click','.my_post_share_popup a:not(a.my_share_email)',function(e){
			
			e.preventDefault();
			//e.preventDefault();
			var href=$(this).attr('href');
			//var service=$(this).data('service');
			//self.my_debug("Openb share window",{href:href,service:service});
			//self.getViewport();
			//var v_ww=self.viewport['w'];
			//var v_hh=self.viewport['h'];
			var v_ww=window.outerWidth;
			var v_hh=window.outerHeight;
			var ww=800;
			var hh=400;
			/*if(service=='google'){
				
			}*/
			/*var my_is_twitter=0;
			if($(this).hasClass('my_social_share_link_twitter')){
				self.my_a_obj=$(this);
				self.my_c_t_12=0;
				my_is_twitter=1;
				//console.log('Twiiter Class');
			}*/
			if(v_ww<ww){
				ww=v_ww;
			}
			if(v_hh<hh){
				hh=v_hh;
			}
			var left=Math.floor((v_ww-ww)/2);
			var top=Math.floor((v_hh-hh)/2);
			//self.my_debug("Window",{ww:ww,hh:hh,v_ww:v_ww,v_hh:v_hh,top:top,left:left});
			var win=window.open(this.href, "my_social_share", "scrollbars=1,menubar=0,location=0,toolbar=0,status=0,width="+ww+", height="+hh+", top="+top+", left="+left);
			
		});
		$(document).on('click',".my_post_share",function(e){
			e.preventDefault();
			//e.stopPropagation();
			
			var html=$(this).parents(".my_post_template").find(".my_post_share_div").html();
			var id=$(this).find(".my_post_share_div ul").data('id');
			var off=$(this).offset();
			$(".my_post_share_popup").find(".my_post_row").html(html);
			$(".my_post_share_popup").css('top','-10000px');
			$(".my_post_share_popup").css('left','-10000px');
			var wP=$(".my_post_share_popup").outerWidth(true);
			var hP=$(".my_post_share_popup").outerHeight(true);
			var top=off.top-hP-10;
			var wP1=$(this).width();
			var left=off.left;
			
			console.log('Click post share',{html:html,id:id,wP:wP,wP1:wP1,hP:hP});
			
			left=left-wP/2+wP1/2;
			if(my_post_showed_dialog){
				if(id==my_post_showed_id){
					$(".my_post_share_popup").fadeOut();//.animate({opacity:0});
				}
				my_post_showed_id='';
				my_post_showed_dialog=false;
				return;
				
			}else {
				
					$(".my_post_share_popup").css('top',top+'px').css('left',left+'px').fadeIn(function(){
						//my_showed_dialog=true;
						
					
			});
					my_post_showed_dialog=true;
					my_post_showed_id=id;
			
			}
		});
		
	});
	$(document).on('click',".my_post_popup li",function(e){
		e.preventDefault();
		//$("#my_timeline_share_click").fadeOut(100);
		//self.getViewport();
		//var v_ww=self.viewport['w'];
		//var v_hh=self.viewport['h'];
		var v_ww=window.outerWidth;
		var v_hh=window.outerHeight;
		var ww=800;
		var hh=400;
		if(v_ww<ww){
			ww=v_ww;
		}
		if(v_hh<hh){
			hh=v_hh;
		}
		var left=Math.floor((v_ww-ww)/2);
		var top=Math.floor((v_hh-hh)/2);
		var href=$(this).find('a').attr('href');
		//debug('Open window',href);
		var win=window.open(href, "my_social_share", "scrollbars=1,menubar=0,location=0,toolbar=0,status=0,width="+ww+", height="+hh+", top="+top+", left="+left);
		
	});
});