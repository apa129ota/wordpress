/**
 * 
 */
(function($) { 
	myPostEffects=function(o){
		var self;
		this.my_working=false;
		this.debug=true;
		this.animations={};
		this.animate=false;
		this.my_transitions=false;
		this.my_transitions_prefix="";
		this.my_transform=false;
		this.my_transform_prefix="";
		this.my_filter_prop="";
		this.myCssProperties={};
		self=this;
		this.init=function(o){
			self.debug=false;
			self.my_transform=(function(){
				var obj = document.createElement('div');
	              var props = ['transform', 'WebkitTransform', 'MozTransform', 'OTransform', 'msTransform'];
	              for (var i in props) {
			            if ( obj.style[ props[i] ] !== undefined ) {
			            if(props[i]=='transform'){
			            	self.my_transform_prefix="";
				            
			            }else {
			            var my_pref=props[i].replace('Transform','').toLowerCase();
			            if(my_pref==""){
			            	self.my_transform_prefix="";
			            }else {
			            	self.my_transform_prefix="-"+my_pref+"-";
			            }
			            }
			            self.my_debug("TRansform Prefix ",self.my_transform_prefix);
			              return true;
			            }
			            }
	          return false;    
			}());
			if(self.my_transform){
				self.my_debug("Has transform");
			}else self.my_debug("Has no transform");
			self.my_transitions=(function(){
				var obj = document.createElement('div');
	            var props=['transition','WebkitTransition','MozTransition','MsTransition','OTransition'];
	            for (var i in props) {
		            if ( obj.style[ props[i] ] !== undefined ) {
		            if(props[i]=='transition'){
		            	self.my_transitions_prefix="";
			            
		            }else {
		            var my_pref=props[i].replace('Transition','').toLowerCase();
		            if(my_pref==""){
		            self.my_transitions_prefix="";
		            }else {
		            self.my_transitions_prefix="-"+my_pref+"-";
		            }
		            }
		            self.my_debug("Trnasitions prefix",self.my_transitions_prefix);
		              return true;
		            }
		            }
	            return false;
			}());
			if(self.my_transitions){
				self.my_debug("Has transitions");
			}else self.my_debug("No transitions");
			self.hasProperty('filter',['filter','WebkitFilter']);
			self.my_debug("CssProperties",self.myCssProperties);
		},
		this.hasProperty=function(prop,props){
			var obj = document.createElement('div');
           // var props = ['filter','WebKitFilter'];
			var foundProp="";
            for (var i in props) {
		            if ( obj.style[ props[i] ] !== undefined ) {
		            if(props[i]==prop){
		            	//self.my_transform_prefix="";
			            foundProp=prop;
			            self.myCssProperties[prop]=prop;
		            }else {
		            	var p2='';
		            var my_pref=props[i].replace(prop,'').toLowerCase();
		            if(my_pref==""){
		            	//self.my_transform_prefix="";
		            	self.myCssProperties[prop]=prop;
		            }else {
		            	self.myCssProperties[prop]="-"+my_pref+"-"+prop;
		            	//self.my_transform_prefix="-"+my_pref+"-";
		            }
		            }
		              
		            return true;
		            }
		            }
          
		},
		this.goUpFromBottom=function(c,duration,bottom,easing){
			if(self.animations.goUp!='undefined'){
				/*if(typeof self.animations.goUp[c]!='undefined'){
					return false;
				}*/
			}
			var h=$("."+c).outerHeight();
			var h1=$(".c").parent().height();
			if(bottom.indexOf('%')!=-1){
				var b=bottom.replace('%','');
				var c=parseFloat(b)/100;
				var p=(h1)*c-h;
				bottom=p+'px';
			}
			
			if(typeof self.animations.goUp=='undefined'){
				self.animations.goUp={};
			}
			self.animations.goUp.c=$("."+c).css('bottom');
			$("."+c).animate({bottom:bottom},duration,easing,function(){
				delete self.animations.goUp[c];
			})
		},
		this.removeEffect=function(parentClass,type){
			var setData=$(parentClass).attr('data-'+type);
			if(typeof setData=='undefined')return;
			if(setData==0)return;
			else $(parentClass).attr('data-'+type,0);
			
			//$(parentClass).removeAttr('data-'+type);
			
		},
		this.removeCss=function(prop,childClass){
			var p=self.myCssProperties[prop];
			$(childClass).css(p,'');
		},
		this.filterGrayscale=function(parentClass,triggerOn,triggerOff,duration,childClass,easing,fromVal,toVal){
			//$(parentClass).finish();
			var property=self.myCssProperties.filter;
			if(typeof property=='undefined')return;
			var setVilter=$(childClass).css(property);
			var setData=$(parentClass).attr('data-grayscale');
			if(typeof setData!='undefined'){
				//if(setData==0)return;
			}
			var keyT=parentClass+"_"+childClass;
			//if(typeof setData=='undefined'){
				$(parentClass).attr('data-grayscale',1);
				//steData=1;
				/*self.animations.grayscale={};
				self.animations.grayscale[keyT]={
						
						'parentClass':parentClass,
						'triggerOn':triggerOn,
						'triggerOff':triggerOff,
						'duration':duration,
						'childClass':childClass,
						'easing':easing,
						'from':fromVal,
						'to':toVal
				};
				*/
				var n1=fromVal*100;
				
				$(childClass).css(property,'grayscale('+n1+'%)');
				$(childClass).attr('data-grayscale-from',fromVal);
				$(childClass).attr('data-grayscale-to',toVal);
				$(childClass).attr('data-grayscale-duration',duration);
				$(childClass).attr('data-grayscale-easing',easing);
				$(childClass).attr('data-parent-class',parentClass);
			
			//}
			
			self.my_debug("property",property);
			
			//if(typeof setFilter=='undefined'){
					
				
				
				
				
			//}
			if(typeof setData=='undefined'){
			$(parentClass).on(triggerOn,function(e){
				/*var keyT=$(childClass).attr('data-grayscale');
				var obj=self.animations[keyT];
				var fromVal=parseInt(obj.from);
				var toVal=parseInt(obj.to);
				*/
				var setData=$(this).attr('data-grayscale');
				if(typeof setData!='undefined'){
					if(setData==0)return;
				}
				var fromVal=$(childClass).attr('data-grayscale-from');
				var toVal=$(childClass).attr('data-grayscale-to');
				var duration=parseInt($(childClass).attr('data-grayscale-duration'));
				var easing=$(childClass).attr('data-grayscale-easing');
				
				fromVal=parseInt(fromVal);
				toVal=parseInt(toVal);
				
				var property=self.myCssProperties.filter;
				
				$(childClass).finish();
				$(childClass).animate({
					my_filter:fromVal
				},
				{step:function(now,fx){
					//fx.start=fromVal;
					var n12=now;
					var n1;
					if(fromVal==1){
						n1=1-n12;
					}else {
						n1=1-n12;
					}
					n1*=100;
					self.my_debug("Filter On",{fromVal:fromVal,toVal:toVal,now:now,n1:n1});
					
					if(fx.prop=='my_filter'){
							$(this).css(property,'grayscale('+n1+'%)');	
					}
				}
				,duration:duration,
				complete:function(){
					/*var n1=toVal*100;
					$(this).css(property,'grayscale('+n1+'%)');
					*/
				}
				});
			
			});
			$(parentClass).on(triggerOff,function(e){
				var setData=$(this).attr('data-grayscale');
				if(typeof setData!='undefined'){
					if(setData==0)return;
				}
				
				/*var keyT=$(this).attr('data-grayscale');
				var obj=self.animations[keyT];
				var fromVal=parseInt(obj.from);
				var toVal=parseInt(obj.to);
				var property=self.myCssProperties.filter;
				*/
				var fromVal=$(childClass).attr('data-grayscale-from');
				var toVal=$(childClass).attr('data-grayscale-to');
				var duration=parseInt($(childClass).attr('data-grayscale-duration'));
				var easing=$(childClass).attr('data-grayscale-easing');
				
				fromVal=parseInt(fromVal);
				toVal=parseInt(toVal);
				
				var property=self.myCssProperties.filter;
				$(childClass).finish();
				$(childClass).animate({
					my_filter:toVal
				},
				{step:function(now,fx){
					//fx.start=toVal;
					var n12=now;
					var n1;
					if(fromVal==1){
						n1=1-n12;
					}else {
						n1=1-n12;
						
					}
					n1*=100;
					self.my_debug("Filter Off",{fromVal:fromVal,toVal:toVal,now:now,n1:n1});
					
					if(fx.prop=='my_filter'){
							$(this).css(property,'grayscale('+n1+'%)');	
					}
				}
				,duration:duration,
				complete:function(){
					/*var n1=fromVal*100;
					
					$(this).css(property,'grayscale('+n1+'%)');
					*/
				}
				});
			
			});
			}
			
		},
		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log('Effects script\n'+t,o);
				}
			}
		};

			this.init();
	}
})(jQuery);
myPostEffects_inst=new myPostEffects();