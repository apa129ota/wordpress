(function($) { 
	myAdminTemplatesAdmin=function(o){
		var self;
		this.my_working=false;
		this.debug=true;
		this.options=o;
		this.network='';
		this.network_ids='';
		this.my_pre_open_post_id='';
		this.search_ids={};
		this.my_get_all=false;
		this.my_save_all=false;
		this.included_fonts={};
		this.my_image_id='';
		this.pins=[];
		this.my_edit_id="";//my_post_title_row";
		this.sections={};
		this.name_sections={};
		this.my_edit_icon='';
		this.my_sub_section='';
		this.my_disable_change=false;
		this.default_values={};
		this.sub_sections={};
		this.w=400;
		this.h=400;
		this.my_globals={};
		this.my_is_global='';
		this.myPropHeight={};
		this.dialog_save;
		this.dialog_new;
		this.dialog_stars;
		this.my_dialog_open='';
		this.my_sort_option=false;
		this.my_add_clear=false;
		this.fonts={};
		this.fonts_objects={};
		this.included_fonts={};
		this.pre_options={
				w:30,
				h:30,
				form_class:'.my_options_form',
				form_element:".my_new_module_element",
				li_form:".my_form_element_outer",
				class_cont:".my_image_mapper_image_image_div_1",
				class_img:".my_image_mapper_image_image_div_1 img",
				editor_class:".my_slide_image_inner",
				element_inner:".my_shortcode_content_new",
				ul_button:".my_shotcode_actions_ul",
				outter_class:".my_outter_object",
				form_class:".my_options_form",
				form_element:".my_new_module_element",
				shortcode_content:".my_shortcode_content_new",
				item_add_class:".my_shortcode_added_html",
				item_class:".my_shortcode_item",
				row_class:".my_shortcode_row_row"	
		};
		
		self=this;
		
		this.init=function(o){
			 var gesture = window.navigator && window.navigator.msPointerEnabled && window.MSGesture;
			var  touch = (( "ontouchstart" in window ) || gesture || window.DocumentTouch && document instanceof DocumentTouch);
			self.touch=touch;  
			if(typeof self.options.my_debug!='undefined'){
				if(!self.options.my_debug){
					self.debug=false;
				}
			}
				
			self.debug=true;
			if(typeof self.options.rules.fonts!='undefined'){
				self.fonts=self.options.rules.fonts;
			}else {
					self.options.rules.fonts={};
			}
			self.init_objects_display();
			var o={
					key:'save',
					debug:self.debug,
					dw:400,
					dh:300,
					diff:20,
					modal:true
				};
			self.dialog_save=new myVusualBuilderDialog(o);
			/*var o1={
					key:'stars',
					debug:self.debug,
					dw:400,
					dh:200,
					diff:20,
					modal:false
				};
			self.dialog_stars=new myVusualBuilderDialog(o1);
			var o1={
					key:'view_a',
					debug:self.debug,
					dw:800,
					dh:'100%',
					diff:20,
					modal:false
				};
			self.dialog_view=new myVusualBuilderDialog(o1);
		*/
		$(document).on('click',".my_post_share_popup a",function(e){
			e.preventDefault();
			//e.stopPropagation();
		});
		self.initFonts();
		var o1={
				key:'new',
				debug:self.debug,
				dw:'100%',
				dh:600,
				diff:20,
				modal:true
			};
		self.dialog_new=new myVusualBuilderDialog(o1);
			
			self.options=$.extend(self.pre_options,self.options);
			if(typeof self.options.pins !='undefined'){
				self.pins=self.optipns.pins();
			}
			/*if(self.options.tmpl=='template_3' || self.options.tmpl=='template_4' || self.options.tmpl=='template_5' ||self.options.tmpl=='template_6'||self.options.tmpl=='template_7' ||self.options.tmpl=='template_8'){
				var h=$(".my_post_thumb").height();
				$(".my_post_content_row").height(h);
				//$(".my_post_content_row").css(h);
				$(".my_post_content_row").mCustomScrollbar({advanced:{
					updateOnContentResize:true
				}});
				$(".my_scrollEdit").show();
				
			}*/
			self.my_debug("Options",self.options);
			/*$(document).on('my_open_dialog','body',function(e,obj,key){
				self.my_debug("Dialog open event",key);
				if(key=='stars'){
					//setTimeout(function(){
						$(".my_stars_popup_row").trigger('click');
					//},500);
				}
				else if(key=="view_a"){
					//setTimeout(function(){
						$(".my_view_a_row").trigger('click');
					//},500);
				}
			});*/
			$(document).on('click',".my_action",self.my_action);
			//$(document).on('click','.my_image_mapper_image_image_div img',self.my_add_pin);
			var w=$(".my_image_mapper_add_new_div").width();
			w-=500;
			$(".my_image_mapper_image_div").width(w);
			$(window).resize(function(e){
				var w=$(".my_image_mapper_add_new_div").width();
				w-=500;
				$(".my_image_mapper_image_div").width(w);
				
			});
			if($("#font_family_my_templates_id_div").length>0){
				$("#font_family_my_templates_id_div").on("my_change",function(e,obj,val,name){
					self.my_debug("Set Font Val",val);
					if(typeof self.prevFont!='undefined'){
						var valF=self.prevFont;
						$("head").find(".my_image_mapper_fonts_css[data-key='"+valF+"']").remove();
						delete included_fonts[valF];//=1;
						delete self.options.rules.fonts[valF];//=1;
					}
					if(typeof self.included_fonts[val]=='undefined'){
						self.my_debug("Set Font Inlcude new font",val);
						var value=val.replace(/ /g,'+');
						self.my_debug("SetFont Inlcude new font",value);
						$("head").append('<link class="my_image_mapper_fonts_css"  data-key="'+val+'" rel="stylesheet" href="https://fonts.googleapis.com/css?family='+value+'"/>');
						self.included_fonts[val]=1;
						self.options.rules.fonts[val]=1;
						self.prevFont=val;
						var cssR="{font-family:"+val+" , serif !important\n}";
						var css=".my_post_title "+css+"\n .my_post_content "+css+"\n";
						css+=" .my_woo_view_a "+css+"\n";
						self.my_debug("Set font",css);
						var id="myFont";
						var has=$("#my_templates_style_css #"+id).length;
						if(has==0){
							$("#my_templates_style_css").append('<style type="text/css" id="'+id+'">'+css+'</style>');
													
							}else {
								$("#my_templates_style_css #"+id).html(css);
							}
					}
				});
			}
			if($("#width_my_templates_id").length>0){
				var dW=parseFloat($("#width_my_templates_id").val());
				self.w=dW;
				self.my_debug("Change dialog width",dW);
				$(".my_module_post_templates_editor_div").width(dW);
				$("#width_my_templates_id").change(function(e){
					var dW=parseFloat($("#width_my_templates_id").val());
					self.w=dW;
					self.my_debug("Change dialog width",dW);
					$(".my_module_post_templates_editor_div").width(dW);
					
				});
				
			}
			if($("#height_my_templates_id").length>0){
				var dH=parseFloat($("#height_my_templates_id").val());
				self.h=dH;
				self.my_debug("Change dialog width",dH);
				$(".my_module_post_templates_editor_div").height(dH);
				
				$("#height_my_templates_id").change(function(e){
					var dH=parseFloat($("#height_my_templates_id").val());
					self.h=dH;
					self.my_debug("Change dialog width",dH);
					$(".my_module_post_templates_editor_div").height(dH);
					$.each(self.myPropHeight,function(i,v){
							var oVal=v;
							var id=i;
							if(oVal.val.indexOf('%')!=-1){
								
								var vH=parseFloat(val)/100*self.h;
								self.my_debug('Height',vH);
								val=vH+'px';
								
								var has=$("#my_templates_style_css #"+id).length;
								var css=oVal.rowClass+"{ height:"+val+"!important}";
								
								if(has==0){
										$("#my_templates_style_css").append('<style type="text/css" id="'+id+'">'+css+'</style>');
					
								}else {
										$("#my_templates_style_css #"+id).html(css);
								}								}
							self.my_debug("Prop heigjht",{id:id,css:css,val:val,oVal:oVal});
						
					})
					
				});
				
			}
			$("#use_slider_my_templates_id").on('change',function(e){
				var type=$("#post_type_my_templates_id").val();
				var val=$("#template_my_templates_id").val();
				var url=self.options.admin_page+'&my_tmpl='+val+"&my_type="+type;
				var tmpl=$("#slider_template_my_templates_id").val();
				if($(this).is(":checked")){
					url+='&my_slider=1';
				}
				window.location.href=url;
			});
			$("#template_my_templates_id_div").on("my_change",function(e){
				var type=$("#post_type_my_templates_id").val();//.data('my-script').get_value();
				var $o=$(this).data('my-script');
				var val=$o.get_value();
				self.my_debug("Change post type",{val:val,type:type});
				var url=self.options.admin_page+'&my_tmpl='+val+"&my_type="+type;
				window.location.href=url;
			});
			$("#post_type_my_templates_id_div").on("my_change",function(e){
				var tmpl=$("#template_my_templates_id").val();//$("#template_my_templates_id_div").data('my-script').get_value();
				
				var $o=$(this).data('my-script');
				var val=$o.get_value();
				self.my_debug("Change post type",{val:val,tmpl:tmpl});
				var url=self.options.admin_page+'&my_type='+val+"&my_tmpl="+tmpl;
				window.location.href=url;
			});
			/*$(document).on("click",".my_accordian_header",function(e){
				e.preventDefault();
				var is=0;
				if($(this).parents(".my_accordian").find(".my_accordian_inner").is(":visible")){
					is=1;
				}
				is=!is;
				if(!is){
					$(this).parents(".my_accordian").find(".fa-minus").hide();
					$(this).parents(".my_accordian").find(".fa-plus").show();
					
				}else {
					$(this).parents(".my_accordian").find(".fa-plus").hide();
					$(this).parents(".my_accordian").find(".fa-minus").show();
					
					
				}
				if(!is)
				$(this).parents(".my_accordian").attr('data-on',0);
				else $(this).parents(".my_accordian").attr('data-on',1);
				
			    $(this).parents(".my_accordian").find(".my_accordian_inner").slideToggle('fast');
			});*/
			$(".my_object_explorere_div").mCustomScrollbar({advanced:{
				updateOnContentResize:true
			}});
			$(".my_options_form_inner").mCustomScrollbar({advanced:{
				updateOnContentResize:true
			}});
			/*
			$(".my_image_mapper_removed").mCustomScrollbar({advanced:{
				updateOnContentResize:true
			}});*/
			$(document).on('click',".my_options_form .my_slide_in_out i",function(e){
				e.preventDefault();
				e.stopPropagation();
				self.my_debug("Click",$(this).attr('class'));
				if($(this).hasClass('fa-angle-double-right')){
					$(".my_options_form").animate({left:'0px'});
					$(this).hide();
					$(this).parents(".my_slide_in_out").find(".fa-angle-double-left").show();
				}else {
					$(".my_options_form").animate({left:'-400px'});
					$(this).hide();
					$(this).parents(".my_slide_in_out").find(".fa-angle-double-right").show();
				}
			});
			  $("#height_auto_template_vars_id").change(function(e){
				//e.preventDefault();
				e.stopPropagation();
				if($("#height_auto_template_vars_id").is(":checked")){
					self.my_debug("Checked jheight");
					$(".my_form_element_inline_height_choose_template_vars").hide();
				}else {
					self.my_debug("UnChecked height"); 
					$(".my_form_element_inline_height_choose_template_vars").show();
					
				}
				
			}); 
			
			$(self.options.form_class+" "+self.options.form_element).each(function(i,v){
				self.my_change_el(i,v);
			});
			$(self.options.form_class+" "+self.options.form_element).each(function(i,v){
				var id=$(v).attr('id');
				var o=self.get_element_data(id);
				self.my_debug('Find object',o);
				var s=$(this).parents(".my_form_section").data('key');
				self.my_debug("Section",s);
				if(typeof self.sections[s]=='undefined'){
					self.sections[s]={};
				}
				self.sections[s][o.name]=o;
				self.name_sections[o.name]=s;
			});
			var my_has_hidden=false;
			self.my_debug("Rules",self.options.rules);
			$.each(self.options.rules,function(i4,v4){
				if(i4!='sort'&&i4!='sort_arr'){
				if(typeof v4.show!='undefined'){
					if(v4.show==0){
						$(".my_"+i4+"_row").css('display','none');
						my_has_hidden=true;
						$(".my_hide_el[data-key='"+i4+"'] .my_hide_el").hide();
						$(".my_hide_el[data-key='"+i4+"'] .my_show_el").show();
						
					}
				}
				var my_do=false;
				var my_is_global=0;
				if(i4=='predefined_classes'){
					my_is_global=1;
					$.each(v4,function(i,v){
						self.actionSubSections(i,v,my_is_global);
					});
				}
				$.each(v4,function(i,v){
				if(i=='predefined_classes'){
					my_do=true;
					my_is_global=0;
					
				
					$.each(v,function(i1,v1){
						self.actionSubSections(i1,v1,my_is_global);
					
					});
				}
			});
				}
			});
			if(my_has_hidden){
				self.calculateHeight();
				$(".my_action[data-key='adjust_height']").trigger('click');
			}
			self.my_debug("sections",self.sections);
		
			
			$(".my_module_post_templates_editor_div .my_post_row").click(self.set_edit);
			$(".my_stars_popup .my_post_row").click(self.set_edit);
			$(".my_dialog_view_a .my_post_row").click(self.set_edit);
			$(".my_post_share_popup .my_post_row").click(self.set_edit);
			
			$(".my_module_post_templates_editor_div .my_post_meta_row li i").click(self.edit_icon);
			$(".my_module_post_templates_editor_div .my_stars li i").click(self.edit_icon);
			
			
			self.calculateHeight();
			$(".my_module_post_templates_editor_div").animate({opacity:1},1000);
			
			setTimeout(self.checkInit,1000);
		
			
		};
		this.setThumbHeight12=function(){
			if(self.options.tmpl!='template_11'){
				var h=0;
	    		var tmpH=0;
	    		var max=0;
	    		var addedH=false;
	    		var tmplWidth=parseInt($(".my_post_template .my_post_row").outerWidth(true));
	    		var $tmplF=$(".my_post_template");
	    			$($tmplF).children(".my_post_row").each(function(i,v){
	    			if(!$(v).hasClass("my_post_thumb_row")){
	    				addedH=false;
	    				tmpH=$(v).outerHeight(true);
	    				var wEl=$(v).outerWidth(true);
	    				if(wEl<tmplWidth){
	    					if(max<tmpH){
	    						max=tmpH;
	    						self.my_debug("Max",max);
	    						
	    					}
	    				}else {
	    					
	    					if(max!=0){
	    						self.my_debug("Add max",max);
	    						
	    						h+=max;
	    						max=0;
	    						addedH=true;
	    						
	    					}
	    					self.my_debug("Height pre",h);
	    					//if(!addedH)
	    					h+=tmpH;
	    					self.my_debug("Height after",h);
	    					
	    				}
	    				self.my_debug("Element",{tmplW:tmplWidth,cl:$(this).attr('class'),tmpH:tmpH,h:h,max:max,wEl:wEl});
	    				
	    				//if(max==0&&!addedH)h+=tmpH;
	    				
	    			}
	    			});
	    			$(".my_post_thumb").css('height',h+'px');
			}
		};
		this.initFonts=function(){
			
			var hasFonts=false;
			
			$("head link.my_image_mapper_fonts_css").each(function(i,v){
				hasFonts=true;
				var val=$(v).data('key');
				self.my_debug("font",val);
				self.included_fonts[val]=1;
				/*if(typeof self.options.rules.fonts[val]=='undefined'){
					self.options.rules.fonts[val]=1;
				}*/
			})
			if(hasFonts){
				$.each(self.options.rules,function(i,v){
					var font=v.font_family;
					if(typeof font !='undefined'){
						if(font!='default'){
							self.addFontObject(font,i);
						}
					}
					if(typeof v.predefined_classes!='undefined'){
						$.each(v.predefined_classes,function(i1,v1){
							var font=v.font_family;
							if(typeof font !='undefined'){
								if(font!='default'){
									self.addFontObject(font,i+'_'+i1);
								}
							}
							
						});
					}
				});
			}
			self.my_debug("Init fonts",{fonts:self.included_fonts,objects:self.fonts_objects});
		};
		this.addFontObject=function(font,idElem){
			var val=font;
			if(typeof self.fonts_objects[val]=='undefined'){
				var objF={};
				objF.elems={};
				objF.length=0;
				self.fonts_objects[val]=objF;
				
				
			}
			self.fonts_objects[val].length++;
			self.fonts_objects[val].elems[idElem]=1;
		};
		this.checkInit=function(){
			return '';
			self.my_debug("check init");
			if(typeof wpMyModuleNewFormMainScript_template_vars=='undefined'){
				setTimeout(self.checkInit,1000);
			}
			else if(wpMyModuleNewFormMainScript_template_vars.init_el){
				self.getSetValues(0);
				$("#my_form_section_icon").hide();
				$('#my_form_section_slider').hide();
				self.calculateHeight();
				$(".my_action[data-key='adjust_height']").trigger('click');
		
			}else {
				setTimeout(self.checkInit,1000);
					
			}
		};
		this.getSetValues=function(set){
			self.my_disable_change=true;
			if(set==0){
				$(self.options.form_class+" "+self.options.form_element).each(function(i,v){
					var id=$(v).attr('id');
					var o=self.get_element_data(id);
					var name=o.name;
					if($('#'+id).parents('#my_form_section_slider').length==0){
					var s=$("#"+id).data('my-script');
					if(typeof s!='undefined'){
						var val=s.get_value();
						self.my_debug("Get default values",{id:id,name:name,val:val});
						self.default_values[id]=val;
					}
					}
				});
				self.my_debug("Default values",self.default_values);
				
			}else {
				self.my_debug("Set Default values",self.default_values);
				$.each(self.default_values,function(i,v){
					var id=i;
					var o=self.get_element_data(id);
					self.my_debug("Set default values",{name:o.name,id:id,val:v});
					
					var s=$("#"+id).data('my-script');
					if(typeof s!='undefined'){
						s.set_value(v);
					}
				});
			}
			self.my_disable_change=false;
			
		};
		this.findRuleAddedCss=function(o,v1){
			var find=[];
			self.my_debug("Find rule",{o:o,v1:v1});
			$.each(o,function(i,v){
				if(i.indexOf(",")!=-1){
					var indexes=i.split(",");
					if($.inArray(v1,indexes)!=-1){
						if(typeof v=='string'){
							find[find.length]=v;
						}else {	
						self.my_debug("prop is array");
							
							$.each(v,function(i1,v1){
								find[find.length]=v1;
							});
						}
					}
					
				}else {
					if(i==v1){
					if(typeof v=='string'){
						find[find.length]=v
					}else {
						self.my_debug("prop is array");
						$.each(v,function(i1,v1){
							find[find.length]=v1;
						});
					}
					}
				
				}
			});
			self.my_debug("find added css",find);
			return find;
		};
		this.genCssAddedCss=function(rule,v1,val){
			var css;
			var itemClass='';
			var rule1=rule;
			if(rule1.indexOf('{val}')!=-1){
				rule1=rule1.replace(/\{val\}/,val);
		
			}else {
			if(v1=='text_decoration'){
				css=itemClass+"{text-decoration:"+val+" !important}";
			}
			else
			if(v1=='font_weight'){
				css=itemClass+"{font-weight:"+val+" !important;}";
			}
			else
			if(v1=='font_style'){
				css=itemClass+"{font-style:"+val+" !important;}";
			}
			else if(v1=='font_size'){
				css=itemClass+"{font-size:"+val+" !important;}";
			}
			else if(v1=='line_height'){
				css=itemClass+"{line-height:"+val+" !important;}";
			}
			else if(v1=='hover_color'){
				css=itemClass+":hover , "+itemClass+":hover a {color:"+val+" !important;}";
			}else if(v1=='color'){
				css=itemClass+" , "+itemClass+" a {color:"+val+" !important;}";
				
			}else if(v1=='align'){
				css=itemClass+" , "+itemClass+":hover a {text-align:"+val+" !important;}";
			}else if(v1=='letter_spacing'){
				css=itemClass+" {letter-spacing:"+val+" !important;}";
			}
			else css=itemClass+"{"+v1+":"+val+" !important;}";
			rule1=rule1.replace(/\{css\}/,css);
			}
			self.my_debug("Added css from an rule",rule1);
			return rule1;
		};
		/**
		 * init objects display
		 */
		this.init_objects_display=function(){
			var $div=(".my_options_form_object_explorer");
			var $div1=$(".my_options_form_object_explorer1");
			//if(self.options.custom==1)return;
			self.templateObjects={};
			$(".my_"+self.options.tmpl+" .my_post_row").each(function(i,v){
				var key=$(v).data('key');
				var dialog=$(v).data('type');
				var title=self.options.msgs[key];
				var has_child=false;
				var children=[];
				self.templateObjects[key]={};
				
				if(key=='post_meta'){
					has_child=true;
					var obj={};
					obj.sel=".my_post_hearts i";
					obj.title=self.options.msgs.post_hearts;
					children[children.length]=obj;
					var obj={};
					obj.sel=".my_post_comments i";
					obj.title=self.options.msgs.post_comments;
					children[children.length]=obj;
					var obj={};
					obj.sel=".my_post_share i";
					obj.title=self.options.msgs.post_share;
					children[children.length]=obj;
					var newArr=[]
					/*$.each(chldren,function(i,v){
						var obj={};
						obj.sel=".my_post_meta"
						obj.title=self.options.msgs.span;
					}));
					*/
					
				}else if(key=='meta_stars'){
					has_child=true;
					var obj={};
					obj.sel=".my_meta_stars .my_active:eq(0) i";
					obj.title=self.options.msgs.stars_active;
					children[children.length]=obj;
					var obj={};
					obj.sel=".my_meta_stars .my_stars li:eq(4) i";
					obj.title=self.options.msgs.stars_inactive;
					children[children.length]=obj;
				
				}				
				if(typeof self.options.rules[key]!='undefined'){
				var hasPred=self.options.rules[key].predefined_classes;
				if(typeof hasPred!='undefined'){
					$.each(hasPred,function(i1,v1){
						
						
						var title=self.options.msgs[i1];
						var obj={};
						obj.title=title;
						obj.sel="."+i1;
						
						children[children.length]=obj;
					});
					
				} 
				}
				self.my_debug("children",children);
				if(children.length!=0)has_child=true;
				var divHtml='';
				self.templateObjects[key].children=children;
				self.templateObjects[key].has_child=has_child;
				if(!has_child){
					if(key!='share_div' && key !='stars_popup' &&key!="view_a"){
						divHtml='<div class="my_object_item" data-key="'+key+'">'+self.options.msgs[key]+'&nbsp;<a href="#javascript" class="my_hide_element" data-key="'+key+'" data-hide="0" title="'+self.options.msgs.hide_el+'"><span class="my_hide_el"><i class="fa fa-trash-o"></i></span><span class="my_show_el">'+self.options.msgs.show_el+'</span></a></div>';
					}
					else divHtml="";//divHtml='<div class="my_object_item" data-key="'+key+'">'+self.options.msgs[key]+'</div>';
				}else {
					if(key!='share_div' && key !='stars_popup' &&key!="view_a"){
						//divHtml='<div class="my_object_item" data-key="'+key+'">'+self.options.msgs[key]+'</div>&nbsp;<a href="#javascript" class="my_hide_element" data-key="'+key+'" data-hide="0">'+self.options.msgs.show_hide+'</a>';
						//divHtml='<div class="my_object_item" data-key="'+key+'">'+self.options.msgs[key]+'</div>&nbsp;<a href="#javascript" class="my_hide_element" data-key="'+key+'" data-hide="0"><span class="my_hide_el">'+self.options.msgs.hide_el+'</span><span class="my_show_el">'+self.options.msgs.show_el+'</span></a>';
						divHtml='<div class="my_object_item" data-key="'+key+'"><i class="fa fa-plus"></i>'+self.options.msgs[key]+'&nbsp;<a href="#javascript" class="my_hide_element" data-key="'+key+'" data-hide="0" title="'+self.options.msgs.hide_el+'"><span class="my_hide_el"><i class="fa fa-trash-o"></i></span><span class="my_show_el">'+self.options.msgs.show_el+'</span></a></div>';
						
					}
					else
					divHtml='';//='<div class="my_object_item" data-key="'+key+'"><i class="fa fa-plus"></i>&nbsp;&nbsp;'+self.options.msgs[key]+'</div>';
					var divHtml1='';
					divHtml1+='<div class="my_object_item_inner" data-key="'+key+'">';
					$.each(children,function(ic,vc){
						divHtml1+='<div class="my_object_item_child" data-key="'+key+'" data-sel="'+vc.sel+'">'+vc.title+'</div>';
					})
					divHtml1+='</div>';
					$($div1).append(divHtml1);
				}
				$($div).append(divHtml);//=(".my_post_template_object_explorer").append(divHtml);
				
			});
			self.my_debug('Init objects display Templates keys',self.templateObjects);
			$(".my_options_form_object_explorer").mCustomScrollbar({advanced:{
				updateOnContentResize:true
			}});
			$(".my_options_form_object_explorer1").mCustomScrollbar({advanced:{
				updateOnContentResize:true
			}});
			$(document).on('click',".my_hide_element",function(e){
				e.preventDefault();
				e.stopPropagation();
				var key=$(this).data('key');
				self.my_debug("click on",key);
				var visible=$(".my_"+key+"_row").is(":visible");
				if(visible){
					$(this).find(".my_hide_el").hide();//.css('visibility','hidden');
					$(this).find(".my_show_el").show();//.css('visibility','visible');
					
					
					$(this).attr('data-hide',1);
					$(".my_"+key+"_row").css('display','none');
					self.options.rules[key].show=0;
				}else {
					$(this).find(".my_hide_el").show();//.css('visibility','visible');
					$(this).find(".my_show_el").hide();//.css('visibility','hidden');
					
					
					$(this).attr('data-hide',0);
					self.options.rules[key].show=1;
					$(".my_"+key+"_row").css('display','');
				}
				setTimeout(function(){
					self.calculateHeight();
					$(".my_action[data-key='adjust_height']").trigger('click');
					
				},500);
			})
			$(document).on("click",".my_object_item",function(e){
				//$(".my_object_item_inner").hide();
				
				var key=$(this).data('key');
				self.my_debug("click on",key);
				if(self.my_dialog_open!=''){
					if(self.my_dialog_open=='share_div'){
						$(".my_action[data-key='edit_share_box']").trigger('click');
					}else{
						$(".my_post_tmpl_close_dialog my_action").trigger('click');
					}
				}
				self.my_dialog_open=key;
				
				if(key=='share_div'){
					$(".my_action[data-key='edit_share_box']").trigger('click');
				}else if(key=='stars_popup'){
					
					$(".my_action[data-key='edit_stars_dialog']").trigger('click');
				}else if(key=="view_a"){
					$(".my_action[data-key='edit_view_dialog']").trigger('click');
					
				}
				else {
					self.my_dialog_open='';
					$(".my_"+self.options.tmpl+" .my_"+key+"_row").trigger('click');
				}
				if($(".my_object_item_inner[data-key='"+key+"']").length>0){
					$(".my_object_item_inner[data-key='"+key+"']").slideToggle();
				}
				//self.showVisual();
			});
			$(document).on("click",".my_object_item_child",function(e){
				var key=$(this).data('key');
				if(key!=self.my_edit_id){
					$(".my_object_item[data-key='"+key+"']").trigger('click');
				}
				var sel=$(this).data('sel');
				self.my_debug('Click on child',{sel:sel,key:key});
				$(".my_"+self.options.tmpl+" "+sel).trigger('click');
			});
		};
		this.my_change_el=function(i,v){
			
			var id=$(v).attr('id');
			var o=self.get_element_data(id);
			var nN=o.name;
			if(nN.indexOf('box_shadow_')===0){
				
				return;
			}
			self.my_debug('Init Init change',o);
			
			if(self.my_disable_change)return;
			switch(o.type){
			
				case 'jscript_box_shadow':
				case 'jscript_color_picker':
				case 'jscript_dropdown':
				case 'jscript_spinner':
				case 'thumb':	
				case 'jscript_border':	
					//return false;
											
					
					
					//var o=self.get_element_data(id);
					var type=o.type;
					self.my_debug('Init chnage 1',o);
					
					$(o.obj).on('my_change',function(e,obj,val,v1){
						if(self.my_edit_id=='')return;
						if(self.my_disable_change)return;
						var id=$(this).attr('id');
						var o=self.get_element_data(id);
						if(self.options.use_slider&&self.my_edit_id=='post_thumb'){
							if($('#'+id).parents('#my_form_section_slider').length>0){
								self.options.rules.post_thumb[o.name]=val;
								self.my_debug("Change slider",{name:o.name,val:val});
								return;
							}									
						
						}
						var css='';
						var backupVal=val;
						var oldSetValue='';
						/*if(self.my_sub_section==''){
							var prevFont=self.options.rules[self.my_edit_id].font_family;
							oldSetValue=prevFont;
						}else {
							var prevFont=self.options.rules[self.my_edit_id][self.my_sub_section].font_family;
							oldSetValue=prevFont;
						}*/
						
						self.my_debug("Change handler Change element",{id:id,o:o,val:val,v1:v1,edit_id:self.my_edit_id,icon:self.my_edit_icon});
						if(self.my_edit_id=='')return;
						if(self.my_edit_icon!=''){
							self.my_debug("Change handler Change icon",{o:o,id:id,name:v1,edit_icon:self.my_edit_icon});
							var rowClass='';//'.my_'+self.options.tmpl+' .my_'+self.my_edit_id+"_row";
							var itemClass='';//'.my_'+self.options.tmpl+" .my_"+self.my_edit_id;
							
							if(o.name=='i_icon'){
								
							}
							if(o.name=='i_color'){
								backupVal=v1;
								v1='color';
							}else if(o.name=='i_color_hover'){
								backupVal=v1;
								v1='hover_color';
							}
							var itemClass1='.my_'+self.options.tmpl;
							if(self.my_edit_id=='post_meta'){
								if(o.name=="i_color" || o.name=="i_color_hover"){
									self.my_debug("Change Handler Val set val",{val:val,backupVal:backupVal});
									self.options.rules[self.my_edit_id][self.my_edit_icon][o.name]=backupVal;
									self.my_debug("Change Handler Val set val",self.options.rules[self.my_edit_id]);
									
									}
							}
							
							if(self.my_edit_icon=='meta_stars'){
								if(v1=='hover_color'){
									itemClass=itemClass1+" .my_stars .my_active i ,"+itemClass1+" .my_stars .my_active a i";
									//itemClass+=itemClass1+" my_stars:hover i ,"+itemClass1+"my_stars:hover a i";
									
								}
								else itemClass=itemClass1+" .my_stars i ,"+itemClass1+" .my_stars a i";
								self.options.rules.meta_stars[o.name]=backupVal;
							}else {
								if(v1=='hover_color'){
									itemClass=itemClass1+" .my_post_meta .my_"+self.my_edit_icon+":hover i, "+itemClass1+" .my_post_meta .my_"+self.my_edit_icon+":hover a i ";
								}	
								else itemClass=itemClass1+" .my_post_meta .my_"+self.my_edit_icon+" i, "+itemClass1+" .my_"+self.my_edit_icon+" i a";
							}					
							var realKey=v1;
							if(v1=='hover_color')realKey='color';
							if(v1=='i_font_size' ){
								
										realKey='font-size';
								if(self.my_edit_id=='post_meta'){
									/*$.each(self.options.rules.post_meta,function(i,v){
										v[v1]=val;
									});*/
									
										self.options.rules.post_meta[self.my_edit_icon][o.name]=val;
										
										css=itemClass+"{"+realKey+" : "+val+" !important}";
									
								}
								else css=itemClass+"{"+realKey+" : "+val+"!important}";
							}else if(v1=="i_line_height"){
								realKey='line-height';
								if(self.my_edit_id=='post_meta'){
									/*$.each(self.options.rules.post_meta,function(i,v){
										v[v1]=val;
									});*/
									self.options.rules.post_meta[self.my_edit_icon][o.name]=val;
								}
								css=itemClass+" {"+realKey+" : "+val+" !important}";
								
							}
							else css=itemClass+"{"+realKey+" : "+val+"!important}";
							
						}else {
						/*if(o.name==''){
							
						}*/	
						if(o.name=='bg_hover_color'){
							backupVal=v1;
							v1='bg_hover_color';
						}	
						else if(o.name=='bg_color'){
							backupVal=v1;
							v1='bg_color';
						}
						else if(o.name=='color'){
							backupVal=v1;
							v1='color';
						}else if(o.name=='hover_color'){
							backupVal=v1;
							v1='hover_color';
						}else if(o.name=='i_color'){
							backupVal=v1;
							v1='i_color';
						}else if(o.name=='i_color_hover'){
							backupVal=v1;
							v1='i_color_hover';
						}
						
						var rowClass='.my_'+self.options.tmpl+' .my_'+self.my_edit_id+"_row";
						var itemClass='.my_'+self.options.tmpl+" .my_"+self.my_edit_id;
						if(self.my_sub_section!=''){
							//if($.inArray(self.my_sub_section,['fa-facebook','fa-google-plus','fa-twitter','fa-pinterest'])!=-1){
								itemClass='.my_'+self.options.tmpl+" ."+self.my_sub_section;
							//}
							//else itemClass='.my_'+self.options.tmpl+" .my_"+self.my_edit_id+" ."+self.my_sub_section;
							self.sub_sections[self.my_sub_section][o.name]=backupVal;
							
						}
						
						//if(v1=='')
						self.my_debug('Call change script',{v1:v1,val:val,edit_id:self.my_edit_id,rowClass:rowClass,itemClass:itemClass});
						
						if(typeof val!='undefined'){
						if(v1=='bg_image'){
							
						}
						else if(self.my_sub_section==''){
							self.options.rules[self.my_edit_id][v1]=backupVal;
							if(v1=='border'){
								var cssB=o.script.getBorderRadiusCss();
								self.options.rules[self.my_edit_id]['border_radius']=cssB;
							}
						}
						
						switch(v1){
							case 'box_shadow':
								css=$("#"+id).data('my-script').generate_css(itemClass);
								/*var m=css1.match(/\{.*\}/ig);
								var css="";
								self.my_debug("m",m);
								$.each(m,function(i2,v2){
									css+="\n"+itemClass+" {"+v2+"}\n";
								})
								*/
								self.my_debug("Box shadow css",css);
								//self.my_debug("Box shadow css",css);
								
							break;	
							case 'font_family':
								itemClass;
								var idElem=self.my_edit_id;
								if(self.my_sub_section!=''){
									idElem+="_"+self.my_sub_section;
								}
								
								if(val=='default'){
								
									self.my_debug("Prev font",{font:prevFont,objects:self.fonts_objects});
									if(typeof prevFont!='undefined'){
										var objE=self.fonts_objects[prevFont];
										if(objE.length==1){
											self.my_debug("Remove font",prevFont);
											$("head link.my_image_mapper_fonts_css[data-key='"+prevFont+"']").remove();
											delete self.included_fonts[prevFont];
											delete self.options.rules.fonts[prevFont];
											delete self.fonts_objects[prevFont];
										}else {
											objE.length--;
											delete objE[prevFont].elems[idElem];
										}
										self.my_debug("Prev font",{font:prevFont,objects:self.fonts_objects});
										
										delete objE.elems[idElem];
									}
									css=itemClass+"{font-family:inherit !important};";
								}else {
								
								if(typeof self.options.rules.fonts[val]=='undefined'){
									self.options.rules.fonts[val]=1;
								}
								if(typeof self.included_fonts[val]=='undefined'){
										self.my_debug("Inlcude new font",val);
										var value=val.replace(/ /g,'+');
										self.my_debug("Inlcude new font",value);
										$("head").append('<link class="my_image_mapper_fonts_css"  data-key="'+val+'" rel="stylesheet" href="https://fonts.googleapis.com/css?family='+value+'"/>');
										self.included_fonts[val]=1;
										self.options.rules.fonts[val]=1;
								}
								var idElem=self.my_edit_id;
								if(self.my_sub_section!=''){
									idElem+="_"+self.my_sub_section;
								}
								css=itemClass+"{font-family:"+val+" , serif !important\n}";
								if(typeof self.fonts_objects[val]=='undefined'){
									var objF={};
									objF.elems={};
									objF.length=0;
									self.fonts_objects[val]=objF;
									
									
								}
								self.fonts_objects[val].length++;
								self.fonts_objects[val].elems[idElem]=1;
								
								}
							break;	
							case 'bg_hover_color':
								if(self.my_edit_id=='woo_data'){
								css=rowClass+" li:hover {background-color:"+val+" !important;}";	
								}
								
								else css=rowClass+":hover {background-color:"+val+" !important;}";
								
							break;	
							case 'bg_color':
								if(self.my_sub_section=='mCSB_draggerRail' || self.my_sub_section=='mCSB_dragger_bar'){
									//$(".my_form_element_outer").hide();
									//$(".my_form_element_outer[data-name='bg_color_template_vars']").show(); 
									css='.my_'+self.options.tmpl+" ."+self.my_sub_section+"{\n background-color:"+val+"!important;}";
									
								}
								else css=rowClass+"{background-color:"+val+" !important;}";
							break;
							case 'bg_image':
								if(val==''){
									css='';
									if(self.my_sub_section==''){self.options.rules[self.my_edit_id][v1]='';
									}
									else self.sub_sections[self.my_sub_section][o.name]=val;;
								}else {
									var myObj=$(o.obj).data('my-script');
									img=myObj.getSizesUrl('full').url;	
									thumb_id=$(o.obj).data('my-script').get_value();
									if(self.my_sub_section==''){
										self.options.rules[self.my_edit_id][v1]=thumb_id;
									}else {
										self.sub_sections[self.my_sub_section][o.name]=thumb_id;
									}
									$(o.obj).data('my-script').getObjectValue();
									css=rowClass+"{background-image:url('"+img+"') !important;}";
								}
							break;	
							case 'bg_repeat':
								css=rowClass+"{background-repeat:"+val+" !important}"
								
							break;	
							case 'align':
							case 'color':
							case 'hover_color':
							case 'font_size':
							case 'line_height':	
							case 'font_style':
							case 'font_weight':
							case 'text_decoration':
							case 'letter_spacing':	
								
								if(v1=='text_decoration'){
									css=itemClass+"{text-decoration:"+val+" !important;}";
								}
								else
								if(v1=='font_weight'){
									css=itemClass+"{font-weight:"+val+" !important;}";
								}
								else
								if(v1=='font_style'){
									css=itemClass+"{font-style:"+val+" !important;}";
								}
								else if(v1=='font_size'){
									css=itemClass+"{font-size:"+val+" !important;}";
								}
								else if(v1=='line_height'){
									css=itemClass+"{line-height:"+val+" !important;}";
								}
								else if(v1=='hover_color'){
									css=itemClass+":hover , "+itemClass+":hover a {color:"+val+" !important;}";
								}else if(v1=='color'){
									css=itemClass+" , "+itemClass+" a {color:"+val+" !important;}";
									
								}else if(v1=='align'){
									css=itemClass+" , "+itemClass+":hover a {text-align:"+val+" !important;}";
								}else if(v1=='letter_spacing'){
									css=itemClass+" {letter-spacing:"+val+" !important;}";
								}
								else css=itemClass+"{"+v1+":"+val+" !important;}";
								
							break;	
							case 'border':
							case 'outline':	
							case 'width':
							case 'height_choose':	
							case 'margin-left':
							case 'margin-right':
							case 'margin-top':
							case 'margin-bottom':
							case 'padding-left':
							case 'padding-right':
							case 'padding-top':
							case 'padding-bottom':
								if(v1=='height_choose'){
									v1='height';
									if(val.indexOf('%')!=-1){
										var vH=parseFloat(val)/100*self.h;
										self.my_debug('Height',vH);
										val=vH+'px';
									}
									if(self.my_edit_id=='post_thumb'){
										rowClass=".my_"+self.options.tmpl+" .my_post_thumb_row ";
										
									}
								}
								if(v1=='border'){
									css=='';
									$.each(val,function(i3,v3){
										css+=" border-"+i3+":"+v3+" !important;\n";
										
									});
									var cssB=o.script.getBorderRadiusCss();
									css=rowClass+" { "+css+"\n"+"border-radius:"+cssB+" !important;}";
								}else if(v1=='outline'){
									css=='';
									$.each(val,function(i3,v3){
										css+=rowClass+" { outline-"+i3+":"+v3+" !important;}\n";
										
									});
								}
								else css=rowClass+" { "+v1+":"+val+" !important;}";
								
								if(v1=='width'&&self.my_edit_id!='share_div'){
									var dw=parseFloat(val);
									my_do=false;
									if(val.indexOf('%')!==-1&&dw<100){
									my_do=true;
									}else if(val.indexOf('px')!==-1&&dw<self.w){
										my_do=true;
									}
									if(my_do){
										css+=rowClass+"{ float:left !important;}";
									}
								}
								
							break;	
						}
						}
						}
						var elemName=v1.replace(/-/g,'_');
						var id=self.my_edit_id+"_"+elemName;
						if(self.my_edit_icon!='')id+='_'+self.my_edit_icon;
						var has=$("#my_templates_style_css #"+id).length;
						if(v1=='height'){
							if(typeof self.myPropHeight[id]!='undefined'){
								if(backupVal.indexOf('%')==-1){
									delete self.myPropHeight[id];
								}
							}
							if(backupVal.indexOf('%')==-1){
								var oVal={name:elemName,val:backupVal,rowClass:rowClass};
								self.myPropHeight[id]=oVal;
							}
						}
						if(has==0){
							$("#my_templates_style_css").append('<style type="text/css" id="'+id+'">'+css+'</style>');
							
						}else {
							$("#my_templates_style_css #"+id).html(css);
						}
						var o=self.options.rules[self.my_edit_id];
						
						if(self.my_sub_section!=''){
							o=self.options.rules[self.my_edit_id][self.my_sub_section];
						}
							if(typeof o!='undefined'){
							if(typeof o.added_css!='undefined'){
								var find=self.findRuleAddedCss(o.added_css,v1);
								if(find.length>0){
									var added_css='';
									$.each(find,function(iF,vF){
										added_css+=self.genCssAddedCss(vF,v1,val);
									});
									self.my_debug("added  css from element",css);
									var id1=self.my_edit_id+"_added_css_"+elemName;
									var has1=$("#my_templates_style_css #"+id1).length;
									if(has1==0){
										$("#my_templates_style_css").append('<style type="text/css" id="'+id1+'">'+added_css+'</style>');
										
									}else {
										$("#my_templates_style_css #"+id1).html(added_css);
									}
								}
							}
							}
							setTimeout(function(){
								self.calculateHeight();
							},500);
						self.my_debug("add css",css);
						
						});
				break;	
				case 'text':
				case 'radio_list':
				case 'radio':
				case 'checkbox':
					self.my_debug('Call change script');
					
				break;
					}
			
		
				
			
		}
		this.setTextOverflow=function(e){
			
		};
		this.actionSubSections=function(i1,v1,my_is_global){
			$(v1).attr('data-global',my_is_global);
					if(my_is_global==1){
						self.my_globals[i1]=1;
					}
					$(".my_form_section "+self.options.form_element).parents('li').show();
					self.sub_sections[i1]=v1;
					self.my_debug("Add sub section",{i1:i1,v1:v1});
					$(document).on("click","."+i1,function(e){
						var my_is_global=0;//$(this).attr('data-global');
						if(self.my_edit_id==''&&my_is_global==0)return;
						self.my_edit_icon='';
						var edit_cl=$(this).parents(".my_post_row").attr('data-key');
						$("i").attr('style','');
						self.my_debug("Edit cl",{edit_cl:edit_cl,g:self.my_edit_id});
						if(edit_cl!=self.my_edit_id)return;
						if(my_is_global){
							self.my_edit_id=$(this).attr('class');
						}
						e.preventDefault();
						e.stopPropagation();
						var show_sections=[];
						var e_class=$(this).attr('class');
						var e_class1=$(this).attr('data-class');
						if(typeof e_class1!='undefined' && e_class1!=''){
							e_class=e_class1;
						}
						/*
						if(e_class.indexOf('fa ')!='-1'){
							e_class=e_class.replace('fa ','');
							self.my_debug("Edit cl",{edit_cl:edit_cl,g:self.my_edit_id});
							
						}*/
						
						self.my_sub_section=e_class;
						var prop=self.sub_sections[e_class];
						self.my_disable_change=true;
						if(e_class=='mCSB_draggerRail' || e_class=='mCSB_dragger_bar'){
							$(".my_options_form_inner .my_form_element_outer").hide();
							$(".my_options_form_inner .my_form_element_outer[data-name='bg_color_template_vars']").show(); 
							
							
						}
						$.each(prop,function(i2,v2){
							var sec=self.name_sections[i2];
							if(typeof sec=='undefined'){
								if(i2=='padding'){
									show_sections[show_sections.length]='padding';
								}else if(i2=='margin'){
									show_sections[show_sections.length]='margin';
								}
							}
							self.my_debug("Check section",sec);
							if($.inArray(sec,show_sections)==-1){
								
								show_sections[show_sections.length]=sec;
							}
							var id=i2+"_template_vars_div_id";
							var o=self.get_element_data(id);
							var name=o.name;
							//self.my_debug("Element",{id:id,name:name,sec:sec,val:v2});
							var s=$("#"+id).data('my-script');
							if(typeof s!='undefined'){
								s.set_value(v2);
							}else{
									self.my_debug("object undefined");
							}
							
						});
						self.my_disable_change=false;
						self.my_debug("Predefined",{name_sections:self.name_sections,e_class:e_class,prop:prop,show_sections:show_sections});
						$(".my_form_section").hide();
						$.each(show_sections,function(i2,v2){
							self.my_debug("Show section",v2);
							  
							$("#my_form_section_"+v2).show();
							$("#my_form_section_"+v2+" "+self.options.form_element).each(function(i3,v3){
								var name=$(v3).data('base-name');
								self.my_debug("Check element",{name:name});
								if(typeof prop[name]=='undefined'){
									self.my_debug("Hide element",{name:name});
									
									$(v3).parents('li').hide();
								}else {
									self.my_debug("Hide element",{name:name});
									
									$(v3).parents('li').show();
								}
							});
						});
						
						
						//if(self.my_edit_id!=''){
							var e_id=self.my_edit_id;
							$.each(self.sub_sections,function(i2,v2){
								$("."+i2).css('outline','none');
							});
							//if($(this).parents(".my_post_row").hasClass('my_'+e_id)){
							if(my_is_global==0)
								$(this).css('outline','5px dashed black');
							 
								
							//}
						//}
					});
					
		};
		/**
		 * Calculate dialog height
		 */
		this.calculateHeight=function(){
			//return;
			if(self.options.tmpl=='template_11'){
				var h=$(".my_post_thumb_row").height();
				var w=$(".my_post_thumb_row").width();
				$(".my_post_content_div_row").attr('style','width:'+w+"px !important;");
				self.my_debug("Calculate Height Height",{h:h,tmpl:self.options.tmpl});
				$(".my_post_template").height(h+"px");
				var hD=h+parseInt($(".my_post_template").css('margin-top'))+parseInt($(".my_post_template").css('margin-bottom'));
				$(".my_tmpl_h").text(h+'px');
				$("#height_my_templates_id").val(h);
				$(".my_module_post_templates_editor_div").height(hD);
				return;
			}
			var h=0;
			var add=0;
			var max=0;
			var tmplW=$(".my_post_template").width();
			$(".my_module_post_templates_editor_div .my_post_clear_1").remove();
			$(".my_module_post_templates_editor_div .my_post_template .my_post_row").each(function(i,v){
				//$(v).removeClass("my_post_clear");
				if($(v).is(":visible")){
				var h1=$(v).outerHeight(true);
				var w=$(v).outerWidth(true);
				var doCalc=true;
				/*if($(v).css('position')=='absolute'){
					doCalc=false;
					self.my_debug()
				}*/
				//if(max==0)max=h1;
				self.my_debug("Calculate Height Element Start ",{h1:h1,newtmplWidth:tmplW,tmplW:self.w,w:w,key:$(v).data('key'),h:h,max:max,add:add});
				if(w<tmplW){
					add+=w;
					if(max<h1)max=h1;
					self.my_debug("Calculate height W is smaller",{w:w,max:max,h1:h1})
				}else {
					add=0;
				}
				var c=$(v).attr('class');
				self.my_debug("Calculate Height Class",{add:add,max:max,h:h,h1:h1,c:c,w:w,add:add});
				if(add==0){
					h+=h1;
					self.my_debug("Calculate height Add Height",{h:h,h1:h1,c:c,w:w,add:add});
					
				}
				else if(((add>(tmplW-10))&&add<(tmplW+10))){
					h1=max;
					h+=h1;
					max=0;
					self.my_debug("Calculate height Add Height small",{h:h,h1:h1,c:c,w:w,add:add});
					if(add!=0){
						$(v).after('<div class="my_post_clear_1"></div>');//.addClass('my_post_clear');
					}
					add=0;
				} 
				self.my_debug("Calculate Height Element End ",{newtmplWidth:tmplW,tmplW:self.w,w:w,key:$(v).data('key'),h:h,max:max,add:add});
				
				if(self.my_edit_id=='share_div'){
					var off=$(".my_post_share").offset();
					var wP=$(".my_post_share_popup").outerWidth(true);
					var hP=$(".my_post_share_popup").outerHeight(true);
					var top=off.top-hP-40;
					var wP1=$(".my_post_share").width();
					var left=off.left-wP/2+wP1/2;
					console.log('Click post share',{wP:wP,wP1:wP1,hP:hP});
					$(".my_post_share_popup").css('top',top+'px').css('left',left+'px');
				}
				}
			});
			self.my_debug("Calculate Height Height",{h:h,tmpl:self.options.tmpl});
			$(".my_post_template").height(h+"px");
			var hD=h+parseInt($(".my_post_template").css('margin-top'))+parseInt($(".my_post_template").css('margin-bottom'));
			$(".my_tmpl_h").text(h+'px');
			$("#height_my_templates_id").val(h);
			$(".my_module_post_templates_editor_div").height(hD);
		};
		this.edit_icon=function(e){
			if(self.my_edit_id=="")return;
			if(self.my_edit_id!='post_meta' || self.my_edit_id!='meta_stars'){
				$(this).parents(".my_post_row").trigger('click');
			}
			e.stopPropagation();
			e.preventDefault();
			
			$("#my_form_section_icon").show();
			var key=$(this).parents('.my_post_row').attr('data-key');
			self.my_edit_icon=key;
			if(key=='post_meta'){
				key=$(this).parents('li').attr('class');
				self.my_debug("Class",key);
				if(typeof key !='undefined'){
					key=key.substr(3);
					self.my_edit_icon=key;
				}
				
			}
			//key=key.substr(3);
			
				
			self.my_sub_section='';
			$(".my_post_meta_row li i, .my_stars li i").attr('style','');
			$(this).attr('style','border:1px solid black;');
			self.my_debug('Edit key',key);
			self.my_debug('Edit icon',key);
			var obj=self.options.rules.post_meta[key];
			if(key=='meta_stars'){
				obj=self.options.rules.meta_stars;
			}
			$.each(self.sub_sections,function(i2,v2){
				$("."+i2).css('border','none');
			});
			$(".my_form_section").hide();
			$("#my_form_section_icon").show();
			self.my_disable_change=true;
			if(typeof obj!='undefined'){
				$.each(obj,function(i,v){
					var name=i;
					var id=i+'_template_vars_id_div';
					var o=self.get_element_data(id);
					var name=o.name;
					var s=$("#"+id).data('my-script');
					if(typeof s!='undefined'){
						s.set_value(v);
					}else{
							self.my_debug("object undefined");
					}
				});
			}
			self.my_disable_change=false;
		}
		this.set_edit=function(e){
			if(self.my_sort_option)return;
			var key=$(this).data('key');
			if(key==self.my_edit_id)return;
			
			e.stopPropagation();
			e.preventDefault();
			self.getSetValues(1);
			self.my_sub_section='';
			self.my_debug('click key',key);
			$(".my_post_row").removeClass("my_selected_el");			
			$(this).addClass("my_selected_el");
			self.my_edit_id=key;
			var tag=self.options.msgs[key];
			if(typeof tag!='undefined')
			$(".my_tmpl_tag").text(tag);
			$(".my_form_section "+self.options.form_element).parents('li').show();
			if(key=='post_thumb'){
				if(self.options.use_slider==1){
					$("#my_form_section_slider").show();
				}
			}else {
				$("#my_form_section_slider").hide();
				
			}
			if(key=='meta_stars' || key=='post_meta'){
				$("#my_form_section_icon").show();
			}
			else {
				$("#my_form_section_icon").hide();
				self.my_edit_icon='';
			}
			$.each(self.sub_sections,function(i,v){
				$("."+i).css('outline','');
			})
			var hEl=$(this).outerHeight(true);
			var wEl=$(this).outerWidth(true);
			var off=$(this).offset();
			var off1=$(".my_"+self.options.tmpl).offset();
			if(key!='share_div'&&key!='stars_popup'&&key!='view_a'){
			$(".my_tmpl_y").text(Math.abs(off1.top-off.top));
			$(".my_tmpl_x").text(Math.abs(off1.left-off.left));
			}
			$(".my_el_h").text(hEl+'px');
			$(".my_el_w").text(wEl+'px');
			
			
			
			/*switch(key){
				case 'post_title':
				case 'post_date':
				case 'post_content':
				case 'meta_stars':	
					$(".my_form_section").show();
					$("#my_form_section_thumb").hide();
				break;	
				case 'post_meta':
				
				break;	
				case 'post_thumb':
					$(".my_form_section").show();
				break;
			}*/
			self.my_disable_change=true;
			self.setValues(self.options.rules[key],key);
			self.my_disable_change=false;
			self.myShowVisual();
			if(key=='share_div'){
				$("#my_form_section_border").hide();
			}else {
				$("#my_form_section_border").show();
			}
		};
		this.show_sections=function(show){
			if(show==1){
				$(".my_form_section").each(function(i,v){
					var id=$(v).attr('id');
					self.my_debug('Show section',id);
					$(v).find(".my_form_section_inner").show();
					$(v).find(".fa-minus").css('display','inline-block');
					
					$(v).find(".fa-plus").hide();
				});
			}else {
				$(".my_form_section").each(function(i,v){
					var id=$(v).attr('id');
					self.my_debug('Hide section',id);
					$(v).find(".my_form_section_inner").hide();
					$(v).find(".fa-minus").hide();
					$(v).find(".fa-plus").css('display','inline-block');
					
				});
			}
		};
		/*
		 * Set values
		 */
		this.setValues=function(values,key){
			var sections_incl={};
			self.my_debug("Set values",values);
			$(".my_form_section").show();
			var has_val={};
			//$(".my_form_section .fa-plus")..trigger('click');
			self.show_sections(1);
			var has_border=false;
			var has_height=false;
			$.each(values,function(i,val){
				if(i.indexOf("#")!==0){
				if(i=='border'){
					has_border=true;
				}
				if(i=='height'){
					if(val=='auto'){
						$(".my_form_element_inline_height_choose_template_vars").hide();
						$("#height_auto_template_vars_id").prop("checked",true);
					}else {
						has_height=true;
						$(".my_form_element_inline_height_choose_template_vars").show();
						$("#height_auto_template_vars_id").prop("checked",false);
					}
				}
				var name=i;
				has_val[name]=1;
				var id=i+'_template_vars_id_div';
				if(i=='height' && has_height){
					id='height_choose_'+'template_vars_id_div';
				}
				var o=self.get_element_data(id);
				var name=o.name;
				var sec=self.name_sections[name];
				if(typeof sections_incl[sec]=='undefined')sections_incl[sec]=1;
				self.my_debug("Element",{id:id,name:name,sec:sec,val:val});
				if(i=='border_radius'){
					var s=$("#border_template_vars_id_div").data('my-script');
					
					 s.setBorderRadius(val);
				 }else {
				var s=$("#"+id).data('my-script');
				if(typeof s!='undefined'){
					  s.set_value(val);
				}else{
					
					 self.my_debug("object undefined");
				}
				 }
				}else {
					self.my_debug("Set values double",{i:i,val:val});
				}
				
			});
			if(!has_border){
				self.my_debug('ha nbo border');
				var id='border_'+'template_vars_id_div';
				var s=$("#"+id).data('my-script');
				if(typeof s!='undefined'){
					s.set_value();
				}
			}
			self.my_debug('show section',sections_incl);
			
			$.each(self.section_names,function(i,v){
				if(typeof has_val[i]=='undefined'){
				var id=i+'_template_vars_id_div';
				$("#"+id).parents('li').hide();	
				}
			});
			self.show_sections(0);
			$(".my_form_section_inner").hide();
			$.each(sections_incl,function(i,val){
				self.my_debug('show section',i);
				$("#my_form_section_"+i).show();
				
			});
			//$(".my_form_section .fa-minus").trigger('click');
			
			
		};
		this.get_element_data=function(id){
			var $o=$("#"+id);
			var type=$($o).data('type');
			var name=$($o).data('base-name');
			var name1=$($o).data('name');
			var id1=$($o).data('id');
			var script=$($o).data('my-script');
			return {
				id:id1,
				full_name:name1,
				name:name,
				type:type,
				obj:$o,
				script:script
			};
		};
		this.my_change_element=function(obj){
			self.my_debug("Change jscript color picker",{obj:obj,val:val});
			if(self.my_disable_change)return;
			var form_prefix=obj.form_prefix;//$().parents('form').find("input[name='my_form_id']").val();
			//var id=$(o.obj).attr('id');
			var object_id=self.my_edit_id;
			var prop=form_prefix;
			var name=obj.name;
			var val=obj.val;
			//var val=obj[1];
			if(typeof self.options.translate[prop]!='undefined'){
				var p=self.options.translate[prop];
				self.my_debug("P",p);
				if(typeof p[name]!=undefined){
					var property=p[name];
					self.my_debug("Property",property);
					var sel=property['class'];
					var css_prop=property.property;
					var p_sel="#"+object_id+"  "+self.options.shortcode_content;
					self.my_debug('p_sel',p_sel);
					self.my_debug("property",css_prop);
					sel=sel.replace('{class}',p_sel);
					self.my_debug("sel",sel);
					//if(sel.indexOf(":")!==-1){
						var css_id=object_id+'_'+name;
						var css=sel+"{\n"+css_prop+":"+val+" !important;\n}";
						if($("#"+css_id).length>0){
							$("#"+css_id).text(css);
						}else {
							$("#"+object_id).append('<style type="text/css" id="'+css_id+'">'+css+'</style>');
						}
						if(typeof self.objects[object_id].style=='undefined'){
							self.objects[object_id].style={};
						}
						self.objects[object_id].style[name]=val;
						
						self.my_debug("Properties style",self.objects[object_id].style);
				}
			}
						
		};
		this.update_properties=function(id,object,type){
			self.my_debug("update properties",{id:id,object:object,type:type});
			self.my_disable_change=true;
			var form_id='#my_form_box';
			
			if(type=='responsive'){
				form_id="#my_form_responsive_box";
			}else if(type!='box'){
				form_id="#my_form_"+self.my_edit_key+"_style";
			}
			self.my_debug("form_id",form_id);
			//if(typeof o[type]!='undefined'){
			//	$.each(o[type],function(i,v){
			$(form_id+" "+self.options.form_element).each(function(i,v){
				var id=$(v).attr('id');
				self.my_debug("id",id);
				var el=self.get_element_data(id);
				var name=el.name;
				self.my_debug('Property update',{el:el,o_type:object[type],name:name});
				var id=el.id;
				var $o=el.obj;
				/*
					var id=i+'_'+type+'_style_id';
					if(type=='box'){
						id=i+'_box_id';
					}else if(type=='responsive'){
						id=i+'_responsive_box_id';
					}
					
					var el=self.get_element_data(id);
					self.my_debug("Element types",{el:el,id:id,v:v});
					*/
					if(typeof el!='undefined'){
						var val='';
						var has_val=false;
						if(typeof object[type]!=='undefined'){
							if(typeof object[type][name]!='undefined'){
								val=object[type][name];
								has_val=true;
								
							}
						}
						self.my_debug("Update element",{id:id,val:val,has_val:has_val,el_type:el_type});
						var el_type=el.type;
						
						if(el_type=='text'){
							if(val==''&&!has_val){
								val=$($o).data('default');
							}
							$("#"+id).val(val);
						}else if(el_type=='radio_list'){
							if(val==''&&!has_val){
								val=$($o).data('default');
							}
							$($o).find("input[type='radio'][value='"+v+"']").trigger('click');
						}else if(el_type=='jscript_color_picker'){
							var s=$($o).data('my-script');
							if(val==''&&!has_val){
								s.set_default();
							}
							else s.set_value(val);
						}else if(el_type=='jscript_dropdown'){
							var s=$($o).data('my-script');
							if(val==''&&!has_val){
								s.set_default();
							}
							else s.set_value(val);
						}
						
					}
					
				});
			//}
			self.my_disable_change=false;
		};
		/**
		 * show visual editor
		 * if id is selected then
		 * scroll to that element
		 */
		this.myShowVisual=function(){
			var id=self.my_edit_id;
			var off=$(".my_post_template").offset();
			self.my_debug("Off",off);
			var w=$(".my_post_template").outerWidth(true);
			var h=$(".my_post_template").outerHeight(true);
			var t=off.top-h-60;
			var l=w+80;
			
			if(typeof id!="undefined" && id!=""){
				off=$(".my_"+self.my_edit_id).offset();
				t=off.top-60-h-parseInt($(".my_"+self.my_edit_id).height());
				
			}
			self.my_debug("Top offset",{off:off,w:w,h:h,t:t,l:l});
			//$("body,html").animate({scrollTop:t});
			$(".my_options_form_window").css('top',t+'px');
			$(".my_options_form_window").css('left',l+'px');
			$(".my_options_form_window").animate({opacity:1},function(){
				$(this).attr('data-open',1);
			});
		};
		this.my_action=function(e){
			e.preventDefault();
			var t=$(this).attr('data-key');
			self.my_debug('My Action',t);
			switch(t){
			
				case 'hideVisual':
					$(".my_options_form_window").animate({opacity:0},function(){
						$(this).attr('data-open',0);
						$(this).css('top','-1000px');
						$(this).css('left','-1000px');
					});
				break;	
				case 'showVisual':
					self.myShowVisual();
				break;	
				case 'new_template':
					var type=$("#post_type_my_templates_id").val();
					var val=$("#template_my_templates_id").val();
					var url=self.options.admin_page+'&my_tmpl=template_custom_new&my_type='+type;
					window.location.href=url;
				break;
				case 'close_dialog':
					$(".my_post_tmpl_close_dialog").fadeOut();
					
					self.dialog_open.my_close();
				break;
				case  'edit_view_dialog':
					$(".my_post_tmpl_close_dialog").fadeIn();
					
					self.dialog_view.my_open();
					/*setTimeout(function(){
						$(".my_view_a_row").trigger('click');
					},1000);*/
					self.dialog_open=self.dialog_view;
				break;	
				case 'edit_stars_dialog':
					$(".my_post_tmpl_close_dialog").fadeIn();
					
					$(".my_post_title_stars").text(self.options.post.post_title);
					self.dialog_stars.my_open();
					/*setTimeout(function(){
						$(".my_stars_popup_row").trigger('click');
					},1000);
					*/
					self.dialog_open=self.dialog_stars;
				break;	
				case  'edit_share_box':
					$(".my_post_meta_row").trigger('click');
					$(".my_post_share").trigger('click');
					$(".my_share_div_row").trigger('click');
				break;	
				case 'adjust_height':
					var hV=parseInt($(".my_tmpl_h").text());
					self.h=hV;
					$(".my_module_post_templates_editor_div").height(self.h);
					$("#height_my_templates_id").val(self.h);
				break;	
				case 'save_template':
					var id=$("input[name='id_my_templates']").val();
					if(id!=''){
						var t=$("input[name='title_my_templates']").val();
						$("#my_name_tmpl_id_12").val(t);
						$(".my_action[data-key='my_save_tmpl']").trigger('click');
						return;
					}
					self.dialog_save.my_open();
				break;
				case 'my_save_tmpl':
					//Save template
					var title=$("#my_name_tmpl_id_12").val();
					if(title==''){
						$("#my_name_tmpl_id_12").focus();
						myAdminMsgs_inst.show_remove(self.options.msgs.title_is_required,1);
						return;
					}
					var o1={};
					o1.show_msg=1;
					var css='';
					$("#my_templates_style_css style").each(function(i,v){
						css+="\n"+$(v).text()+"\n";
					});
					var id=$("input[name='id_my_templates']").val();
					o1.data={
							id:id,
							tmpl_data:$("#my_form_my_templates").serialize(),
							action:self.options.ajax_action,
							my_action:'save_template',
							title:title,
							css:css,
							form_data:self.options.rules
					};
					self.my_debug("Save template daa ",o1);
					o1.success=function(data){
						self.my_debug("Return", data);
						if(data.error==0){
							if(typeof data.added!='undefined'){
								$(".my_radio_inline").append('<li data-id="'+data.added.id+'" class="my_action" data-key="load_template">'+data.added.title+'</li>');
								$("input[name='id_my_templates']").val(data.added.id);
								$("input[name='title_my_templates']").val(data.title);
							}
							myAdminMsgs_inst.show_remove(data.msg,0);
						}else {
							myAdminMsgs_inst.show_remove(data.msg,1);
						}
						
					};
					myGlobalAjaxClass_inst.call_ajax(o1,self.options.msgs.saving_shortcode);
					
					
				break;
				case 'edit_dragg':
					$(".my_post_content_row").trigger('click');
					$(".my_module_post_templates_editor_div_inner").find(".mCSB_dragger_bar").trigger('click');
					
				break;	
				case 'edit_dragg_line':
					$(".my_post_content_row").trigger('click');
					$(".my_module_post_templates_editor_div_inner").find(".mCSB_draggerRail").trigger('click');
					
				break;	
				
				case 'load_template':
					var id=$(this).data('id');
					self.my_debug("load id",id);
					var url=self.options.admin_page+'&my_tmpl_id='+id;
					window.location.href=url;
				break;	
				case 'new_template':
					var type=$("#post_type_my_templates_id").val();//.data('my-script').get_value();
					
					self.my_debug("Change post type",{val:val,type:type});
					var url=self.options.admin_page+"&my_tmpl=new&my_type="+type;
					window.location.href=url;
					
				break;	
				case 'sort':
					self.my_sort_option=true;
					$(".my_module_post_templates_editor_div .my_post_row").find('*').each(function(){
					$(this).css({'-webkit-touch-callout': 'none',
									'-webkit-user-select': 'none',
									'-khtml-user-select': 'none',
									'-moz-user-select': 'none',
									'-ms-user-select': 'none',
									'user-select': 'none'});
					});
					$(".my_module_post_templates_editor_div").find(".my_post_row").each(function(i,v){
						var w=$(v).outerWidth(true);
						var h=$(v).outerHeight(true);
						$(v).attr('data-w',w);
						$(v).attr('data-h',h);
					});
					$(".my_module_post_templates_editor_div .my_"+self.options.tmpl).sortable({
						
						items:"  .my_post_row",
						sort:function(event,ui){
							var h=$(ui.item).attr('data-h');
						      var w=$(ui.item).attr('data-w');
						      self.my_debug("Sort Elements Ui item",{ui:ui,w:w,h:h});
						      //var st=$(ui.item).attr('style');
						      //$(ui.item).attr('style',st+';width:'+w+'px;!important;height:'+h+'px !important');
						      
						},
						stop:function(event,ui){
							self.my_debug("Stop");
							$("#my_added_css_sortable").remove();
						},
						 start: function( event, ui ) { 
						      var h=$(ui.item).attr('data-h');
						      var w=$(ui.item).attr('data-w');
						      var st=$(ui.item).attr('style');
						      var k=$(ui.item).attr('data-key')
						      var css='<style type="text/css" id="my_added_css_sortable">.my_'+self.options.tmpl+' .my_'+k+'_row{width:'+w+'px !important;height:'+h+'px !important;}';
						      
						      self.my_debug("Ui item",{w:w,h:h,k:k,css:css});
						      $("head").append(css);
						      
						      //$(ui.item).attr('style',st+';width:'+w+'px;!important;height:'+h+'px !important');
						      
						      //$(ui.item).css('height',h+'px');
						      //.addClass("yellow");
						    },
						change:function(e,ui){
							var arr=[];
							//$("#my_added_css_sortable").remove();
							$(".my_module_post_templates_editor_div .my_"+self.options.tmpl+" .my_post_row").each(function(i,v){
								var k=$(v).data('key');
								if(typeof k!='undefined'){
								arr[arr.length]=k;
								}
								
							});
							//$(ui.item).attr('style','');
							
							self.my_debug("Sort Elements New sort array",arr);
							self.options.rules.sort=true;
							self.options.rules.sort_arr=arr;
						}
					});
					$(".my_start_sort").hide();
					$(".my_stop_sort").show();
					break;
				case 'stop_sort':
					var arr=[];
					self.my_debug("Sort elements","stop_sort")
					$(".my_module_post_templates_editor_div .my_"+self.options.tmpl+" .my_post_row").each(function(i,v){
								var k=$(v).data('key');
								if(typeof k!='undefined'){
								arr[arr.length]=k;
								}
								
							});
					/*$(".my_module_post_templates_editor_div .my_"+self.options.tmpl+" .my_post_row").each(function(i,v){
								
							var k=$(v).data('key');
							self.my_debug("Sort elements : key",k)
								if(typeof key!='undefined'){
									arr[arr.length]=k;
								}
								
							});*/
							self.my_debug("Sort elements New sort array",arr);
							if(arr.length>0){
								self.options.rules.sort=true;
								self.options.rules.sort_arr=arr;
							}
				
					self.my_sort_option=false;
					$(".my_stop_sort").hide();
					$(".my_start_sort").show();
					$(".my_module_post_templates_editor_div my_"+self.options.tmpl).sortable("destroy");
					//$(".my_start_sort").hide();
					$($(".my_module_post_templates_editor_div .my_post_row")).find('*').each(function(){
						$(this).css({'-webkit-touch-callout': '',
										'-webkit-user-select': '',
										'-khtml-user-select': '',
										'-moz-user-select': '',
										'-ms-user-select': '',
										'user-select': ''});
						});
					setTimeout(function(){
						self.my_add_clear=true;
						self.calculateHeight();
						$(".my_action[data-key='adjust_height']").trigger('click');
						self.my_add_clear=false;
					},500);
				break;	
			}
		};
		this.adjust_predefined_style=function(prop,name,type,form_prefix,o){
			$("#new_css_id").html('');
			self.my_debug("Change style",{prop:prop,name:name,type:type,form_prefix:form_prefix,o:o});
			self.my_debug("All styles",self.options.styles);
			var style=o.val;
			var styles=self.options.styles[style];
			self.my_debug("Choose style",styles);
			var c1,c2;
			var img='';
			if(typeof styles['background_image']!='undefined'){
				img=styles['background_image'];
			}
			
			$.each(styles,function(i,v){
				if(i=='arrows_background_color'){
					c2=v;
				}
				if(i=='arrows_hover_color'){
					c1=v;
				}
				if(i!='background_image'){
					var name=i;
					var id=i+'_'+self.my_edit_id+'_id_div';
					self.my_debug("set value",{name:name,v:v,id:id});
					if($("#"+id).length>0){
						$("#"+id).data('my-script').set_value(v);
					}
					if(name=='arrows_background_color')c2=v;
					else if(name=='arrows_hover_color')c1=v;
					
				}
				if(i=='text_background'&&img!=''){
					var css='.my_testimonial_text{backgorund:'+o.val+' url("'+img+'") !important;}';
					$(".new_css_id").append(css);
				}
				/*var css1='';
				if(i=='text_background'){
					css1+='<style type="text/css" id="'+i+self.my_edit_id+'_1">';
					css1+='.my_top_arrow{border-bottom-color:'+v+' !important;}';
					css1+='.my_bottom_arrow{border-top-color:'+v+' !important}';
					css1+='</style>';
					
				}
				if(i=='text_border_color'){
					css1+='<style type="text/css" id="'+i+self.my_edit_id+'_1">';
					
					css1+='.my_top_arrow_inner{border-bottom-color:'+v+'!important}';
					css1+='.my_bottom_arrow_inner{border-bottom-color:'+v+'!important}';
					css1+='</style>';
				}
				if(css1!=''){
					$("#new_css_id").append(css1);
				}*/
			});
			var edit=self.my_edit_id;
			self.my_debug("Colors",{edit:edit,c1:c1,c2:c2});
			if(edit=='card_style'){
				var sl=$("#my_timeline_1000000").data('myproslider');
				
				sl.vars.form.circle_hover_color=c1;
				sl.vars.form.circle_back_color=c2;
				self.my_debug("Slider Vars",sl.vars);
			}
			
			
		};
		this.adjust_style=function(prop,name,type,form_prefix,o){
			self.my_debug("Edit type",{prop:prop,name:name,type:type,form_prefix:form_prefix,translations:self.options.translate});
			var translate=self.options.translate[name];
			self.my_debug("Translate",translate);
			var c1='',c2='';
			if(name=='arrows_background_color'){
				c2=o.val;
			}
			if(name=='arrows_hover_color'){
				c1=o.val;
			}
			if(typeof translate!='undefined'){
				var p=translate;//self.options.translate[prop];
				//if(typeof p[name]!=undefined){
					var property=p;//p[name];
					var object_id=name;
					self.my_debug("Property",property);
					var sel=property['class'];
					var css_prop=property.property;
					var p_sel="#"+object_id+"  "+self.options.shortcode_content;
					var val=o.val;
					//if(self.my_add_id){
					//	p_sel='#'+object_id;
					//}
					//self.my_debug('p_sel',p_sel);
					self.my_debug("property",css_prop);
					sel=sel.replace('{class}',p_sel);
					self.my_debug("sel",sel);
					
					//if(sel.indexOf(":")!==-1){
						var css_id=object_id+'_'+name;
						if(name=='font-family'){
							if(typeof self.included_fonts[val]=='undefined'){
								self.my_debug("Inlcude new font",val);
								var value=val.replace(/ /g,'+');
								self.my_debug("Inlcude new font",value);
								if($("head").find("#my_testimonial_fonts_css").length>0){
									$("head #my_testimonial_fonts_css").attr('href','https://fonts.googleapis.com/css?family='+value);
									
								}
								else $("head").append('<link id="my_testimonial_fonts_css" rel="stylesheet" href="https://fonts.googleapis.com/css?family='+value+'"/>');
								
								//self.included_fonts[val]=1;
							}
						}
						
						var css;
						if(typeof translate.css !='undefined'){
							css='';
							$.each(property.css,function(i,v){
							var newCss=v;
							newCss=newCss.replace('{val}',val);
							if(css.length>0)css+="\n";
							css+=newCss;//c.replace('{css}',newCss);
							self.my_debug('Property css',css);
							});
							var css_id_1=object_id+'_'+name+'_css';
							if($("#"+css_id_1).length>0){
								$("#"+css_id_1).text(css);
							}else {
								$("#my_new_css").append('<style type="text/css" id="'+css_id_1+'">'+css+'</style>');
							}
							
						}
						if(typeof css_prop.css!='undefined'){
							css=sel;
							var newCss=css_prop.css;
							newCss=newCss.replace('{val}',val);
							css=css.replace('{css}',newCss);
							
							//css=sel+css;
							self.my_debug('Css properyt',css);
						}else {
						if(name=='font-family'){
							
							css=sel+"{\n"+css_prop+":"+val+" , serif !important\n}";

						}
						else css=sel+"{\n"+css_prop+":"+val+" !important\n}";
						}
						if($("#"+css_id).length>0){
							$("#"+css_id).text(css);
						}else {
							$("#my_new_css").append('<style type="text/css" id="'+css_id+'">'+css+'</style>');
						}
						var css1='';
						if(name=='text_background'){
							var id1=name+self.my_edit_id+'_1';
							var has=$("#"+id1).length;
							
							if(!has)css1+='<style type="text/css" id="'+name+self.my_edit_id+'_1">';
							css1+='.my_top_arrow{border-bottom-color:'+val+' !important;}';
							css1+='.my_bottom_arrow{border-top-color:'+val+' !important}';
							if(!has)css1+='</style>';
							if(has){
								$("#"+id1).html(css1);
							}else {
									$("#new_css_id").append(css1);
							}
							self.my_debug("Adjust arrow",{id1:id1,name:name,val:val,css1:css1});
						}
						if(name=='text_border_color'){
							var id1=name+self.my_edit_id+'_1';
							var has=$("#"+id1).length;
							
							if(!has)css1+='<style type="text/css" id="'+name+self.my_edit_id+'_1">';
							
							css1+='.my_top_arrow_inner{border-bottom-color:'+val+'!important}';
							css1+='.my_bottom_arrow_inner{border-bottom-color:'+val+'!important}';
							if(!has)css1+='</style>';
							if(has){
								$("#"+id1).html(css1);
							}else {
									$("#new_css_id").append(css1);
							}
							self.my_debug("Adjust arrow",{id1:id1,name:name,val:val,css1:css1});
						}	
						
						
					
						
					/*	
					}else {
						$(sel).css(css_prop,value);
					
					}*/
						
					/*	if(form_prefix=='responsive_box'){
							if(typeof object.responsive=='undefined'){
								object.responsive={};
							}
							object.responsive[o.name]=val;
							self.my_debug("Repossive",self.objects[self.my_edit_id].responsive);
						}
						else	if(form_prefix=='box'){
					if(typeof object.box=='undefined'){
						object.box={};
						
					}	
					object.box[name]=val;
					self.change_box_model(o);
						}else {
					if(typeof object.style=='undefined'){
						object.style={};
					}
					if(type='jscript_color_picker'){
						val=v1;
					}
					object.style[name]=val;
						}
					self.my_debug("Properties style",object);*/
				}
			var edit=self.my_edit_id;
			
			if(edit=='card_style'){
				var sl=$("#my_timeline_1000000").data('myproslider');
				if(c1!=''){
					sl.vars.form.circle_hover_color=c1;
				}
				if(c2!=''){
					sl.vars.form.circle_back_color=c2;
				}
				self.my_debug("Slider Vars",sl.vars);
			}else if(edit=='slider_style'){
				var sl=$("#my_timeline_100000010").data('myproslider');
				if(c1!=''){
					sl.vars.form.circle_hover_color=c1;
				}
				if(c2!=''){
					sl.vars.form.circle_back_color=c2;
				}
				self.my_debug("Slider Vars",sl.vars);
			
			}
			//}

		};
		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log('Post templates Admin\n'+t,o);
				}
			}
		};
			this.init(o);
			
	};
})(jQuery);		