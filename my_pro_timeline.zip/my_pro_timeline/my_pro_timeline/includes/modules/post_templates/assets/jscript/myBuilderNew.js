/**
 * New builder class for adjusting post template properties 
 */
(function($) { 
	myAdminTemplatesBuilder=function(o){
		var self;
		this.my_working=false;
		this.debug=true;
		this.options=o;
		this.network='';
		this.network_ids='';
		this.my_pre_open_post_id='';
		this.search_ids={};
		this.my_get_all=false;
		this.my_save_all=false;
		this.included_fonts={};
		this.my_image_id='';
		this.pins=[];
		this.my_edit_id="";//my_post_title_row";
		this.sections={};
		this.name_sections={};
		this.my_edit_icon='';
		this.my_sub_section='';
		this.my_disable_change=false;
		this.default_values={};
		this.sub_sections={};
		this.w=400;
		this.h=400;
		this.my_globals={};
		this.my_is_global='';
		this.myPropHeight={};
		this.dialog_save;
		this.dialog_new;
		this.dialog_stars;
		this.my_dialog_open='';
		this.my_sort_option=false;
		this.my_add_clear=false;
		this.fonts={};
		this.fonts_objects={};
		this.included_fonts={};
		this.pre_options={
				w:30,
				h:30,
				form_class:'.my_options_form',
				form_element:".my_new_module_element",
				li_form:".my_form_element_outer",
				class_cont:".my_image_mapper_image_image_div_1",
				class_img:".my_image_mapper_image_image_div_1 img",
				editor_class:".my_slide_image_inner",
				element_inner:".my_shortcode_content_new",
				ul_button:".my_shotcode_actions_ul",
				outter_class:".my_outter_object",
				form_class:".my_options_form",
				form_element:".my_new_module_element",
				shortcode_content:".my_shortcode_content_new",
				item_add_class:".my_shortcode_added_html",
				item_class:".my_shortcode_item",
				row_class:".my_shortcode_row_row"	
		};
		
		self=this;
		
		this.init=function(o){
			 var gesture = window.navigator && window.navigator.msPointerEnabled && window.MSGesture;
			var  touch = (( "ontouchstart" in window ) || gesture || window.DocumentTouch && document instanceof DocumentTouch);
			self.touch=touch;  
			if(typeof self.options.my_debug!='undefined'){
				if(!self.options.my_debug){
					self.debug=false;
				}
			}
				
			self.debug=true;
			self.my_debug("Options",options);
		},
		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log('Post templates Admin\n'+t,o);
				}
			}
		};
			this.init();
			
	};
})(jQuery);		
