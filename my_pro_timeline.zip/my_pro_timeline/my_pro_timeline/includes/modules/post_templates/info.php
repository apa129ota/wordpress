<?php
if(!defined('ABSPATH'))die('');
$info=array(
        'name'=>'post_templates',
		'title'=>'Post_Templates',
		'description'=>'Module for automatic generation for post templates with wisywig editor',
		'class'=>'Class_My_Module_Post_Templates',
		
);
return $info;