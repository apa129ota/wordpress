<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Module_Post_Templates')){
	class Class_My_Module_Post_Templates extends Class_My_General_Module{
		use MySingleton;
		private $post_types;
		private $templates;
		private $options_form;
		private $class_post_tags;
		public $post;
		public $post_model;
		public $page_url;
		public $tmpl_html='';
		private $tmpl;
		protected $post_meta_key='_my_mapper_12_';
		private $is_includes=false;
		private $template_vars_html='';
		private $is_woo=0;
		protected $ajax_action='my_module_post_templates';
		private $metaClass;
		private $userTemplates;
		private $tmplID='';
		private $tmplOptions=array();
		private $use_slider=false;
		private $sliderStyles;
		private $template_new=0;
		private $template_custom_new=0;
		public $builder;
		protected $useExpertBuilder=false;
		/*protected $isFromFront=false;*/
		function __construct($options=array()){
			$options['url']=plugin_dir_url(__FILE__);
			$options['dir']=plugin_dir_path(__FILE__);
			if(!empty($_GET['page'])){
			    $page=$_GET['page'];
			}else $page='';
			if(empty($page))$this->page_url='';
			else $this->page_url=admin_url('admin.php?page='.$page);
			
			$options['use_case']="post_templates";
			//$options['debug']=1;
			parent::__construct($options);

		}
		public function insertSamplePost(){
		   // $image_url=$this->images_url.'niagara-falls.jpg';
		   // echo 'image_url'.$image_url;
		    //return;
		    $hasAdded=wp_my_pro_testimonials_get_option('addedOnePost');
		    if(empty($hasAdded)){
		    $post_id=wp_insert_post(array(
		       'post_type'=>'my_timeline',
		       'post_title'=>__("Niagara Falls","my_suport_teheme"),
		       'post_content'=>"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed feugiat neque mi, ut porta tellus mollis sit amet. Pellentesque convallis libero quis lacinia gravida. Vestibulum vel porta odio. Donec sit amet libero fringilla, suscipit erat sed, congue orci. Ut non imperdiet mi. Aliquam sit amet lorem tincidunt magna ullamcorper facilisis. Ut eget mattis quam. Morbi ultrices, nibh in accumsan pretium, sapien mi pharetra nulla, at posuere ex leo ut libero. Aliquam rhoncus velit ut tellus ultricies, feugiat bibendum metus placerat. Duis ex lectus, malesuada vitae enim a, dapibus auctor ex. Proin nisl magna, blandit sed rhoncus quis, cursus vitae elit.

Mauris semper sem magna, fringilla molestie sem vulputate sed. In vulputate justo vel ligula congue suscipit. Nullam nisi purus, sollicitudin eget sem eu, ullamcorper semper velit. Ut quis pretium orci, vitae ultricies tellus. Nam fringilla velit a eros posuere, venenatis vehicula metus rutrum. Curabitur tincidunt urna ligula, at ullamcorper risus luctus tempus. Proin commodo, enim non lacinia pulvinar, purus diam eleifend lorem, et scelerisque turpis felis et leo. Sed vel odio at dolor lacinia commodo vitae nec est.

Praesent sit amet lobortis enim. Curabitur lacinia ante sit amet suscipit volutpat. Quisque vel eros mauris. Ut tempus hendrerit metus non tempor. Integer sollicitudin leo id egestas suscipit. Duis molestie pharetra nisl, ac facilisis nibh placerat ut. Vivamus efficitur aliquet erat non gravida. Curabitur nec arcu consectetur, dignissim quam eget, euismod justo. Ut nec mauris lacus. Ut commodo aliquam lorem et interdum.

Ut sed augue nec justo elementum varius in sit amet dui. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin at faucibus nunc. Quisque vestibulum est non nisl malesuada, ut commodo est hendrerit. Ut eget gravida enim. Nulla auctor felis eu nisl fringilla, quis laoreet turpis porttitor. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Nullam rutrum nunc urna, a pulvinar ex rutrum non. Proin rhoncus orci nec risus pharetra, eu porttitor turpis volutpat. Mauris non dui diam. Suspendisse viverra dui a ligula dictum dapibus. Nam tincidunt nisl quis consectetur tincidunt. Nullam hendrerit, mauris nec bibendum mattis, risus metus hendrerit elit, id rhoncus leo felis sed turpis. Nullam laoreet molestie mi, semper rhoncus urna dignissim vel. Etiam cursus felis non neque feugiat venenatis. Quisque molestie, nisl et rutrum volutpat, leo metus consequat lectus, id elementum lorem massa sit amet ligula.

Donec orci arcu, dapibus eu leo ac, facilisis semper nunc. Etiam ex justo, consequat sit amet consectetur vel, vestibulum in ligula. Nam quis feugiat massa. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Quisque malesuada, mi ut consequat rhoncus, purus massa porttitor massa, id pellentesque diam turpis ut enim. Proin mollis in orci vitae egestas. Nulla facilisi. Duis congue pretium feugiat. Morbi dignissim tellus efficitur iaculis sagittis. Quisque tempor ultrices quam et tincidunt. Cras pellentesque ipsum at porttitor viverra. Proin aliquam rutrum ante. Maecenas bibendum odio non nunc sollicitudin tristique. Donec dignissim est sit amet urna pulvinar, vel tincidunt lacus auctor. Praesent feugiat feugiat massa, ac placerat eros egestas sit amet.",
		        'post_excerpt'=>"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed feugiat neque mi, ut porta tellus mollis sit amet. Pellentesque convallis libero quis lacinia gravida. Vestibulum vel porta odio.",
		        'post_status'=>'draft'
		    ));
		    wp_my_pro_testimonials_save_option("addedOnePost", 1);
		    /*
		    $upload_dir = wp_upload_dir();
		    $image_data = file_get_contents($image_url);
		    $filename = basename($image_url);
		    if(wp_mkdir_p($upload_dir['path']))     $file = $upload_dir['path'] . '/' . $filename;
		    else                                    $file = $upload_dir['basedir'] . '/' . $filename;
		    file_put_contents($file, $image_data);
		    
		    $wp_filetype = wp_check_filetype($filename, null );
		    $attachment = array(
		        'post_mime_type' => $wp_filetype['type'],
		        'post_title' => sanitize_file_name($filename),
		        'post_content' => '',
		        'post_status' => 'inherit'
		    );
		    $attach_id = wp_insert_attachment( $attachment, $file, $post_id );
		    require_once(ABSPATH . 'wp-admin/includes/image.php');
		    $attach_data = wp_generate_attachment_metadata( $attach_id, $file );
		    $res1= wp_update_attachment_metadata( $attach_id, $attach_data );
		    $res2= set_post_thumbnail( $post_id, $attach_id );
		    */
		    }
		    
		}
		function init($options=array()){
		   // $this->insertSamplePost();
		    add_action("plugins_loaded",array($this,'insertSamplePost'));
		    $_GET['my_type']='my_timeline';
			parent::init(array());
			$this->getPostTypes();
			if(is_admin()){
			    add_action('wp_ajax_'.$this->ajax_action,array($this,'backend_ajax'));
			}


		}
		public function getTmplId(){
		    return $this->tmplID;
		}
		/**
		 * Get user defined tmpl
		 * @param unknown $tmpl
		 */
		protected function getUserDefinedTmpl($tmpl){
		    if(isset($this->templates[$tmpl]))return;
		    $this->global_plugin->loadModuleClass('meta');
		    $options=$this->global_plugin->loadOptions('meta_options.php');
		    $this->metaClass=new Class_My_Module_Meta($options);
		    $this->templates[$tmpl]=array();
		    $arr=$this->metaClass->get_object_meta($tmpl, 'rules');
		    $this->templates[$tmpl]=$arr;
		    $this->cssTmplCache=$this->metaClass->get_object_meta($tmpl, 'cssCache');
		    
		    
		}
		/**
		 * Get defined templates
		 */
		protected function getUserDefinedTemplates(){
		    $this->global_plugin->loadModuleClass('meta');
		    $options=$this->global_plugin->loadOptions('meta_options.php');
		    $this->metaClass=new Class_My_Module_Meta($options);
		    $objs=$this->metaClass->getObjectTypes('template_style');
		    self::debug("templateObjs", $objs);
		    $this->userTemplates=$objs;

		}
		/**
		 * Include visial builder modal
		 * @param string $custom
		 * @param string $dialog
		 * @param array $templates
		 */
		public function includeModalVisualBuilder($custom=true,$dialog=true,$all=false,$templates=array()){
		   
		    $this->loadModuleClass('builder');
		    $this->global_plugin->loadModuleClass('new_form');
            $post_types=$this->getPostTypes();
            self::debug("post_types", $post_types);
           
		    $module_options=array(
		        'dir'=>$this->global_plugin->getDir('modules').'post_templates/includes/modules/builder/',
		        'url'=>$this->global_plugin->getUrl('modules').'post_templates/includes/modules/builder/',
		        'debug'=>1,
		        'all'=>$all,
		        'global_plugin'=>$this->global_plugin,
		        'parent_module'=>$this,
		        'custom'=>$custom,
		        'dialog'=>$dialog,
		        'post_types'=>$post_types
		    );
		    if(!empty($templates)){
		        $module_options['templates']=$templates;
		    }else {
		        $templates=$this->templates;
		    }
		    $this->builder=new Class_My_Module_Post_Templates_Builder($module_options);
		    $this->builder->init();
		    $this->builder->setAdminIncludes();

		}
		public function getUserTemplates(){
		    return $this->userTemplates;
		}
		/**
		 * Backeend ajax action
		 */
		public function backend_ajax(){
		    $this->global_plugin->loadController("class-my-general-controller.php");
		    $ajax_options=$this->loadOptions("ajax_actions.php");
		    $this_options=$ajax_options['backend'];
		    $this_options['module_class']=$this;
		    $this_options['plugin_object']=$this->global_plugin;
		    $this_options['nonce_str']=$this->get_ajax_nonce_str($this->ajax_action);
            $my_set_debug=0;
            if($this->debug){
                $my_set_debug=1;
            }
		    self::debug("ajax_options", $this_options);
		    /*self::debug("session",$_SESSION,false);
		     self::debug("session_name", $this->session_name,false);
		     */
		    $this->routeAjax($this_options);
		}
		private function checkTemplate(){
		    $is=$this->metaClass->is_exists_object($this->tmplID);
		    if(empty($is)){
		        $this->tmplID='';
		    }else {
		        $arr['rules']=$this->metaClass->get_object_meta($this->tmplID, 'rules');
		        $arr['tmpl_arr']=$this->metaClass->get_object_meta($this->tmplID, 'tmpl_arr');
		        $arr['title']=$this->metaClass->get_object($this->tmplID)->title;
		        $_GET['my_tmpl']=$this->metaClass->get_object_meta($this->tmplID, 'template');
		        $_GET['my_type']=$this->metaClass->get_object_meta($this->tmplID, 'post_type');
		        if(!empty($arr['tmpl_arr']['use_slider'])){
		            $_GET['my_slider']=1;
		            $_GET['slider_templ']=$arr['tmpl_arr']['slider_template'];

		        }
		        $this->tmplOptions=$arr;
		    }
		}
		public function displayVisualEditor($custom=true){
		    if($custom){

		    }else {

		    }
		}
		/**
		 * Call admin includes front controller
		 */
		public function setAdminIncludes(){
		    $this->getPostTypes();
		    $this->getOnePost();
		    $use_slider=0;
		    $this->template_new=0;
		    if(!empty($_GET['my_tmpl'])){
		        $tmpl=$_GET['my_tmpl'];
		        if($tmpl=='template_new'){
		            $this->template_new=1;
		        }else if($tmpl=='template_custom_new'){
		            $this->template_custom_new=1;
		        }
		    }
		    if(!empty($_GET['my_slider'])){
		        $use_slider=1;
		    }
		    $this->use_slider=$use_slider;
		    if($this->use_slider){
		        $this->sliderStyles=$this->loadOptions('slider_styles.php');
		    }

		    if(class_exists('Class_My_Framework_Scripts_Class'))
		    Class_My_Framework_Scripts_Class::addIncludes('fontawesome');
		    $this->getUserDefinedTemplates();

		    if(!empty($_GET['my_tmpl_id'])){
		        $this->tmplID=$_GET['my_tmpl_id'];
		        $this->checkTemplate();
		    }
		    $this->global_plugin->loadModuleClass('new_form');
			$this->loadFunctions('functions.php');
			$t='template_1';
			$s_t=@$_GET['my_tmpl'];
			if(!empty($s_t)){
				$t=$s_t;
			}
			//$this->global_plugin->loadModuleClass('front');
			$moduleGoogledir=$this->global_plugin->getDir('modules').'google_font/includes/functions.php';
			//wp_my_general_load_module_function(MY_TESTIMONIALS_LOCAL_MODULES_DIRNAME,'google_font','functions.php');
			//global $wp_my_google_fonts_fonts;
			require $moduleGoogledir;
			$this->wp_my_google_fonts_fonts=wp_my_google_fonts_get_fonts_arr();
			$this->templates=$this->loadOptions('templates.php');

			//$this->templates['predefined']['text']['font_family']['values']=$wp_my_google_fonts_fonts;

			if($this->post_model->getVar('is_woo')){

			    $i=7;
			    $this->templates['template_'.$i]['post_tags']['post_woo_price']['width']='50%';
			    $this->templates['template_'.$i]['post_tags']['post_woo_price']['float']='left';
			    $this->templates['template_'.$i]['post_tags']['post_title']['width']='50%';
			    $this->templates['template_'.$i]['post_tags']['post_title']['float']='left';
			}
			if(!empty($this->tmplID)){
			    $this->templates[$t]['post_tags']=$this->tmplOptions['rules'];
			    $this->templates[$t]['width']=$this->tmplOptions['tmpl_arr']['width'];
			    $this->templates[$t]['height']=$this->tmplOptions['tmpl_arr']['height'];


			}
			$this->tmpl=$t;
			$sections=$this->templates['sections'];
			self::debug("sections", $this->templates['sections']);
			self::debug("predefined", $this->templates['predefined']);
			/*wp_my_general_load_module_function($this->modules_dir,'icons','functions/functions.php');
			$dir_icons=$this->global_plugin->getDir('modules');
			$icons= wp_my_module_icons_get_icons($dir_icons.'icons/includes/options/');
			self::debug("icons", $icons);
			*/
		//	$this->templates['predefined']['icon']['i_icon']['values']=$icons;
            if(!$this->useExpertBuilder){
                unset($this->templates['predefined']['box']['width']);
                unset($this->templates['predefined']['box']['height']);
                unset($this->templates['predefined']['box']['display']);
                unset($this->templates['predefined']['box']['bg_image']);
                unset($this->templates['predefined']['box']['bg_repeat']);
                unset($this->templates['predefined']['box']['box_shadow']);
                
                
                
            }
			foreach($sections['elements']['sections'] as $k=>$v){
				$this->templates['sections']['elements']['sections'][$k]['elements']=array();
				if($k=='slider'){
				    if($this->use_slider){
				        $arr=$this->sliderStyles['shortcodes']['thumb_slider']['styles'];
				      //  print_r($arr);
				        $elementsSlider=array();
				        foreach($arr as $keyS=>$valS){
				            $elementsSlider[$valS]=$this->sliderStyles['default'][$valS];

				        }
				        $valuesSlider=$this->sliderStyles['styles']['light'];
				        foreach($valuesSlider as $keyV=>$valV){
				            if(isset($elementsSlider[$keyV])){
				                $val=$valV;
				                if($elementsSlider[$keyV]['type']=='jscript_color_picker'){
				                    if($elementsSlider[$keyV]['transparency']){
				                        $ex=explode(",",$valV);
				                        $val=array(
				                          'color'=>$ex[0],
				                           'transp'=>$ex[1]
				                        );
				                    }

				                }
				                $elementsSlider[$keyV]['value']=$val;
				            }
				        }
				        if(!empty($this->tmplID)){
				         //if(!empty())
				        }
				        $this->templates['sections']['elements']['sections'][$k]['elements']=$elementsSlider;
				    }
				}else {
				    $this->templates['sections']['elements']['sections'][$k]['elements']=$this->templates['predefined'][$k];
				}
				self::debug("add_elements", $this->templates['predefined'][$k]);
			}
			self::debug("template_vars",$this->templates[$this->tmpl]);
			$options=array(
					'id'=>'template_vars',
					'elements'=>$this->templates['sections']['elements'],
					'hidden'=>array(
							'my_nonce'=>wp_create_nonce('my-templates'),
							'id'=>''
					),
			        'myDebugInfo'=>false,
					'element_template'=>'my_li.php',
					'form_template'=>'my_form.php',
					'my_debug'=>0
			);
			$form_class=new Class_Wp_My_Module_New_Form($options);
			ob_start();
			$form_class->render_form();
			$this->template_vars_html=ob_get_clean();
			/*$options=array(
			    'id'=>'new_template_vars',
			    'elements'=>$this->templates['sections']['elements'],
			    'hidden'=>array(
			        'my_nonce'=>wp_create_nonce('my-templates'),
			        'id'=>''
			    ),
			    'element_template'=>'my_li.php',
			    'form_template'=>'my_form.php',
			    'my_debug'=>0
			);
			$form_class=new Class_Wp_My_Module_New_Form($options);
			ob_start();
			$form_class->render_form();
			$this->template_vars_html_new=ob_get_clean();
			*/
			$this->is_includes=true;


			self::debug("templates", $this->templates);
            if($this->is_admin){
			 add_action('admin_head', array($this,'admin_head'),PHP_INT_MAX);
			 add_action('admin_enqueue_scripts',array($this,'admin_scripts'),PHP_INT_MAX);
			 add_action('admin_footer',array($this,'admin_footer'),PHP_INT_MAX);
            }else {
                add_action('wp_head', array($this,'admin_head'),PHP_INT_MAX);
                add_action('wp_enqueue_scripts',array($this,'admin_scripts'),PHP_INT_MAX);
                add_action('wp_footer',array($this,'admin_footer'),PHP_INT_MAX);
            }
			add_action('wp_ajax_'.$this->ajax_action,array($this,'backend_ajax'));


			//$this->initShortcodes();
			$this->showTemplate();
			$this->renderOptionsForm();

		}
		/**
		 * 
		 * @param unknown $post
		 * @param string $t
		 */
		public function renderTemplate($post,$t="template_1",$params=array()){
		    $sort=array();
		    $this->loadFunctions('functions.php');
		    $user_slider=0;
		    $sliderOptions=array();
		    $view_tmpl=$this->getDir('views').'templates/'.$t.'.php';
		    $this->loadClass('class-post-tags.php');
		    $enableStars=0;
		    if(!empty($params['enableStars'])){
		        $enableStars=1;
		        
		    }
		    if(preg_match('/^[0-9]+$/',$t)){
		        $this->getUserDefinedTmpl($t);
		        if(!empty($this->templates[$t]['sort'])){
		            $sort=$this->templates[$t]['sort_arr'];
		        }
		        //echo 'T='.$t;
		        //var_dump($t);
		        //var_dump($this->templates[8]);
		        //var_dump($sort);
		        $t=$this->metaClass->get_object_meta($t, 'template');
		        //if($t=="template_11")unset($sort);
		        //echo 'Template '.$t;
		        //print_r($sort);
		        $view_tmpl=$this->getDir('views').'templates/'.$t.'.php';
		        
		    }
		    $slider_tmpl="";
		    $prefix=$this->global_plugin->getModule("timeline")->getProperty('postMetaPrefix');
		    $options=array(
		        'prefix'=>$prefix,
		        'enableStars'=>$enableStars,
		        'dir'=>$this->getDir('views').'templates/',
		        'tmpl'=>$view_tmpl,
		        'sort'=>$sort,
		        'tmplKey'=>$t,
		        'slider_tmpl'=>$slider_tmpl,
		        'use_slider'=>$user_slider,
		        'is_woo'=>$this->is_woo,
		        'post_meta_key'=>$this->post_meta_key,
		        'templates'=>$this->templates,
		        'debug'=>0,
		        'isFront'=>1,
		        'global_plugin'=>$this->global_plugin,
		        'post_model'=>$post,
		        'post_type'=>"my_timeline",
		        'module_object'=>$this,
		        'slider_options'=>$sliderOptions,
		        'params'=>$params
		        
		    );
		    //print_r($options);
		    $class_post_tags=new Class_My_Module_Post_Templates_Class_Post_Tags($options);
		    $class_post_tags->init();
		    $tmpl_html=$class_post_tags->render();
		    return $tmpl_html;
		    
		    
		}
		protected function showTemplate(){
			$t='template_1';
			$s_t=@$_GET['my_tmpl'];
			if(!empty($s_t)){
				$t=$s_t;
			}
			$sort=array();
			if(!empty($this->tmplID)){
			    self::debug('tmplOptions', $this->tmplOptions);
			    if(!empty($this->tmplOptions['rules']['sort'])){
			        $sort=$this->tmplOptions['rules']['sort_arr'];
			    }

			}
			$user_slider=0;
			if(!empty($_GET['my_slider'])){
			    $user_slider=1;
			}
			$slider_tmpl='slider_1.php';
			if(!empty($_GET['slider_templ'])){
			    $slider_tmpl=$_GET['slider_templ'];
			}
			$sliderOptions=array();
			$this->use_slider=$user_slider;
			if($this->use_slider){
			    $sliderOptions=$this->sliderStyles['shortcodes']['thumb_slider']['settings'];
			}

			$view_tmpl=$this->getDir('views').'templates/'.$t.'.php';
			$this->loadClass('class-post-tags.php');

			$options=array(
				'dir'=>$this->getDir('views').'templates/',
				'tmpl'=>$view_tmpl,
			    'sort'=>$sort,
				'tmplKey'=>$t,
			    'slider_tmpl'=>$slider_tmpl,
			    'use_slider'=>$user_slider,
				'is_woo'=>$this->is_woo,
				'post_meta_key'=>$this->post_meta_key,
				'templates'=>$this->templates,
				'debug'=>0,
				'global_plugin'=>$this->global_plugin,
				'post_model'=>$this->post_model,
				'post_type'=>$this->post_model->getPostVar('post_type')	,
			    'module_object'=>$this,
			    'slider_options'=>$sliderOptions

			);
			if($this->template_custom_new){
			 $this->tmpl_html='';
			 $fT=$this->getDir('views').'templates/template_custom_new.php';
			 ob_start();
			     require $fT;
			 $this->tmpl_html=ob_get_clean();

			}else {
			 $this->class_post_tags=new Class_My_Module_Post_Templates_Class_Post_Tags($options);
			 $this->class_post_tags->init();
			 $this->tmpl_html=$this->class_post_tags->render();
			//print_r($this->tmplOptions['rules']['fonts']);
			}

		}
		private function initShortcodes(){
			return;
			$my_set_debug=0;
			if($this->debug){
				$my_set_debug=1;
			}
			global $my_shortcodes;
			$my_shortcodes=array();
			$file=$this->getDir('modules').'shortcodes/info.php';
			$my_shortcodes=require $file;
			$dir=$this->getDir('modules');
			$global_modules_dir=$this->global_plugin->getDir('modules');
			wp_my_general_load_module($dir, 'shortcodes');
			$s_options=array(
					'debug'=>$my_set_debug,
					'global_modules'=>$global_modules_dir,
					'post'=>$this->post
			);
			$class=new Class_My_Module_Shortcodes_Main($s_options);
			$class->init();
			global $wp_my_module_forms;
			$wp_my_module_forms=$class->render_options();
		}

		protected function renderOptionsForm(){
			$id=@$_GET['id'];
			if(!isset($id))$id='';
			$w=400;$h=400;
			if(!empty($this->templates[$this->tmpl]['width'])){
				$w=$this->templates[$this->tmpl]['width'];
			}
			if(!empty($this->templates[$this->tmpl]['height'])){
				$h=$this->templates[$this->tmpl]['height'];
			}
			if($this->is_woo){
				$h+=30;
			}
			$this->templates['form']['font_family']['values']=$this->wp_my_google_fonts_fonts;
			$elements=$this->templates['form'];
			unset($elements['post_type']);
			unset($elements['use_expert']);
			$elements['width']['value']=$w;
			$elements['height']['value']=$h;
			if(!empty($_GET['my_type'])){
				$elements['post_type']['value']=@$_GET['my_type'];

			}
			if(!empty($_GET['my_tmpl'])){
			    $elements['template']['value']=$_GET['my_tmpl'];
			}
			if(!empty($_GET['my_slider'])){
			    $elements['use_slider']['value']=1;
			}
			if(!empty($_GET['slider_templ'])){
			    $elements['slider_template']['value']=$_GET['slider_templ'];
			}
			$t12='';
			if(!empty($this->tmplID)){
			    $id=$this->tmplID;
			    foreach($elements as $k=>$v){
			        $elements[$k]['value']=$this->tmplOptions['tmpl_arr'][$k];
			    }
			    $t12=$this->tmplOptions['title'];
			}

			if(!empty($elements['post_type'])){
				if(!empty($this->post_types)){
					foreach($this->post_types as $k=>$v){
						$name=$v;
						if(is_object($v)){
							$name=$v->label;
						}
						$elements['post_type']['values'][$k]=$name;
					}
				}
			}
			$key='my_templates';
			$my_set_debug=$this->debug;
			$my_set_debug=0;
			$options=array(
					'id'=>$key,
					'elements'=>$elements,
					'hidden'=>array(
							'my_nonce'=>wp_create_nonce('templates_form'),
							'id'=>$id,
					         'title'=>$t12
					),
					'element_template'=>'my_li.php',
					'form_template'=>'my_form.php',
					'my_debug'=>$my_set_debug
			);
			$form_class=new Class_Wp_My_Module_New_Form($options);
			ob_start();
			$form_class->render_form();
			$this->options_form=ob_get_clean();
		}
		public function generateCssCache($tmpl,$rules,$save=true){
		    $this->loadFunctions('functions.php');
		    $values=$rules;
		    wp_my_post_templates_filter_vars($values);
		    $css=wp_my_post_templates_gen_css($tmpl, array($tmpl=>$rules));
		    
		    return $css;
		}
		/**
		 * Render template css
		 * @param string $tmpl
		 * @return string
		 */
		public function renderCss($tmpl="template_1",$params=array()){
		    
		    $templates=$this->loadOptions("templates.php");
		    $css="";
		    $enableStars=0;
		    $this->loadFunctions('functions.php');
		    if(!empty($params['enableStars'])){
		        $enableStars=1;
		    }
		    if(empty($enableStars)){
		        if($tmpl=="template_2"){
		            $templates[$tmpl]['post_tags']['post_title']['width']='100%';
		            $templates[$tmpl]['post_tags']['post_title']['align']='center';
		        }
		        else if(in_array($tmpl, array("template_1","template_6"))){
		            $templates[$tmpl]['post_tags']['post_meta']['width']='100%';
		        }
		    }
		    if(preg_match('/^[0-9]+$/',$tmpl)){
		        if(!is_admin()){
		            $this->getUserDefinedTmpl($tmpl);
		        }
		        $css=$this->cssTmplCache;
		    }else{
		      if(!empty($templates[$tmpl])){
		          $values=$templates[$tmpl]['post_tags'];
		          //$values=$this->templates[$this->tmpl]['post_tags'];
		          wp_my_post_templates_filter_vars($values);
		          $css=wp_my_post_templates_gen_css($tmpl, $templates);
		          if($tmpl=="template_10"){
		            
		            //$css.=".my_post_share_div{background-color:#3c5993}\n";
		            //$css.=".my_post_share:after{border-top-color:#3c5993}\n";
		            }
		          }
		        }
		    return $css;
		    
		}
		public function admin_head(){
		    if($this->adminPageSlug=='my_pro_grid_new_templates')return;
			$my_set_debug=0;
			if($this->debug){
				$my_set_debug=1;
			}
			$msgs=$this->loadOptions('admin_msgs.php');
			$options=$this->global_plugin->loadOptions("ajax_options.php");
			$values=array();
			$css='';
			if(!empty($this->tmpl)){

			    $values=$this->templates[$this->tmpl]['post_tags'];
				wp_my_post_templates_filter_vars($values);
				$css=wp_my_post_templates_gen_css($this->tmpl, $this->templates);
				/*preg_match_all($css,'/([^\{]+)\{([^\}]*)\})/ims',$matches);
				self::debug("tmpl_matches", $matches);

				foreach($matches[1] as $k=>$v){
					$css1[$v]=$matches[2][$k];
				}*/
			}
			self::debug("tmpl", $this->tmpl);
			self::debug("tmpl_values", $values);
			self::debug("tmpl_css", $css);
			?>
			<style type="text/css">
                .my_object_explorer_parent{
                	width:50% !important;
                	float:left;
                }
                .my_object_explorer_child{
                width:50% !important;
                	float:left;
                	display:block !important;
                    }
                }
            </style>
			<style type="text/css" id="my_css_tmpl_<?php echo $this->tmpl;?>">
				<?php echo $css;?>
			</style>
			<script type="text/javascript">
			jQuery(document).ready(function($){
				var o_ajax=<?php echo json_encode($options);?>;
				myGlobalAjaxClass_inst=new myGlobalAjaxClass(o_ajax);
				var o3={};
				myAdminMsgs_inst=new myAdminMsgs(o3);
				var o={};
				o.my_debug=<?php echo $my_set_debug;?>;
				myAdminMsgs_inst=new myAdminMsgs(o);
				var o4={};
				o4.ajax_action="<?php echo $this->ajax_action;?>";
				o4.my_debug=<?php echo $my_set_debug;?>;
				o4.msgs=<?php echo json_encode($msgs);?>;
				o4.admin_page="<?php echo $this->page_url;?>";
				o4.post=<?php echo  json_encode($this->post);?>;
				o4.rules=<?php echo json_encode($values);?>;
				o4.tmpl="<?php echo $this->tmpl;?>";
				o4.sections=<?php echo json_encode($this->templates['sections']['elements'])?>;
				o4.use_slider=<?php if($this->use_slider)echo '1';else echo '0';?>;
				o4.custom=<?php echo $this->template_custom_new;?>;
				myAdminTemplatesAdmin_inst=new myAdminTemplatesAdmin(o4);
				<?php
				if($this->use_slider){
				    $styles=$this->sliderStyles;
				    $translate=array();
				    foreach ($styles['default'] as $k=>$v){
				        if(isset($v['translate']))
				            $translate[$k]=$v['translate'];
				    }
				?>

							var osl={};
							osl.translate=<?php echo json_encode($translate);?>;
							osl.my_debug=<?php echo $my_set_debug;?>;
							osl.msgs=<?php echo json_encode($msgs);?>;
							osl.styles=<?php echo json_encode($styles['styles'])?>;

							osl.is_id='0';
							myAdminTestimonialsFrontAdmin_inst=new myAdminTestimonialsFrontAdmin(osl);
				<?php
				}
				?>
			});
			</script>
			<?php
			//print_r($this->tmplOptions['rules']['fonts']);
			if(!empty($this->tmplOptions['rules']['fonts'])){
			 foreach($this->tmplOptions['rules']['fonts'] as $kF=>$vF){
			     ?>
			     			<link  class="my_image_mapper_fonts_css"  data-key="<?php echo $kF;?>" rel="stylesheet" href="https://fonts.googleapis.com/css?family=<?php echo urlencode($kF)?>"/>

			     <?php
			 }
			}

		}
		public function getStyleFormHtml(){
		    $file=$this->getDir('views').'styleForm.php';
		    $template_vars_html=$this->template_vars_html;
		    ob_start();
		    require $file;
		    $html=ob_get_clean();
		    return $html;
		    
		  
		}
		/**
		 * Load subtemplate
		 * @param unknown $tmpl
		 */
		public function loadSubTemplate($tmpl){
		    $view=$this->getDir('views');
		    $file=$view.'templates/'.$tmpl;
		    if(file_exists($file)){
		      require $file;
		    }
		}
		public function admin_footer(){
		    //return '';
		    //if($this->adminPageSlug=='my_pro_grid_new_templates')return;
			?>
			<div class="my_shortcodes_dialog_overlay">
			</div>
			<div class="my_post_tmpl_close_dialog my_action" data-key="close_dialog">
				<?php echo __("Close open dialog","my_support_theme") ?>
			</div>
			<?php
			$view=$this->getDir('views');
			//$tmpl1=$view.'new.php';
			$tmpl2=$view.'save.php';
			//require $tmpl1;
			require $tmpl2;
			$tmpl=$this->tmpl;
			$tmpl3=$view.'templates/share_popup.php';
			$tmpl4=$view.'templates/stars_popup.php';
			$tmpl5=$view.'templates/view_dialog.php';
			require $tmpl3;
			require $tmpl4;
			require $tmpl5;


		}
		public function admin_scripts(){
		    if($this->adminPageSlug=='my_pro_grid_new_templates')return;
			wp_enqueue_script('jquery');
			wp_enqueue_script("jquery-touch-pounch");
			wp_enqueue_script('jquery-ui-core');
			wp_enqueue_script("jquery-ui-widget");
			wp_enqueue_script("jquery-ui-dialog");
			wp_enqueue_script('jquery-effects-core');
			wp_enqueue_script("jquery-ui-tooltip");
			wp_enqueue_script("jquery-ui-resizable");
			wp_enqueue_script("jquery-ui-draggable");
			wp_enqueue_script("jquery-ui-droppable");
			wp_enqueue_media();
			$url=$this->global_plugin->getUrl('jscript').'admin/my_ajax.js';
			wp_enqueue_script('my_framework_ajax',$url);
			$url=$this->global_plugin->getUrl('jscript').'admin/admin_msgs.js';
			wp_enqueue_script("my_framework_msgs",$url);
			$url=$this->global_plugin->getUrl('css').'msgs.css';
			
			wp_enqueue_style("my_testimonials_msgs_form",$url);
			$url=$this->getUrl('jscript');
			wp_enqueue_script('my_mapper_admin_js',$url.'my_admin.js');
			wp_enqueue_script('my_mapper_front_js',$url.'front.js');

			$css_url=$this->getUrl('css');
			
			wp_enqueue_style('my_framework_templates_admin_css',$css_url.'admin.css');
			
			wp_enqueue_style('my_framework_templates_general_css',$css_url.'general.css');
			wp_enqueue_style('my_framework_templates_newCss_css',$css_url.'newCss.css');
			
			$dialog_jscript=$this->global_plugin->getUrl('jscript').'admin/myUiDialog.js';
			wp_enqueue_script('myUiDialog',$dialog_jscript);


			if($this->use_slider){
			 wp_enqueue_script('my_framework_slider_admin',$url.'my_adminSlider.js');
			 wp_enqueue_script('my_framework_proslider_slider_js',$url.'myProSlider.js');
			 wp_enqueue_style('my_framework_slider_general_css',$css_url.'slider/general.css');
			 wp_enqueue_style('my_framework_slider_card_css',$css_url.'slider/card.css');
			 if(empty($this->sliderCss)){
			     //wp_enqueue_style('my_framework_slider_card_css',$css_url.'slider/card.css');

			 }

			}
			//wp_enqueue_script('my_mapper_main_js',$url.'main.js');

		}
		public function getAdminPageTemplate(){
			//$tmpl_html=$this->tmpl_html;
			$dir=$this->getDir('views').'editor.php';
			return $dir;
		}

		private function getOnePost(){
		    
			$my_post_type=@$_GET['my_type'];
			if(!isset($my_post_type)){
				$my_post_type='post';
			}
			//$this->loadModel('class-post.php');
			$this->global_plugin->loadModel('class-post.php');
			//$this->post_model=new Class_My_Module_Post_Templates_Post_Model(array('admin_tmpl'=>true,'debug'=>$this->debug,'post_type'=>$my_post_type,'post_meta_key'=>$this->post_meta_key));
			$this->post_model=new  Class_My_General_Post_Model(array('admin_tmpl'=>true,'debug'=>$this->debug,'post_type'=>$my_post_type,'post_meta_key'=>$this->post_meta_key));
			$this->post_model->init();
			$post=$this->post_model->getVar('post');
			$this->post['post_type']=$my_post_type;
			$is_woo=0;
			if($my_post_type=='product'){
				if(class_exists( 'WooCommerce' )){
					$is_woo=1;
					$this->post['currency']=get_woocommerce_currency_symbol();
				}
			}
			$this->post['woocommerce']=$is_woo;
			$this->is_woo=$is_woo;
			$this->post['post']=$post;
			$post_meta=$this->post_model->getVar('post_meta');
			$this->post['post_meta']=$post_meta;
			$thumbs=$this->post_model->getVar('post_thumbs');
			$this->post['thumbs']=$thumbs;
			if($my_post_type=='post'){
				$this->post['cats']=$this->post_model->getVar('post_categories');
				$this->post['terms']=$this->post_model->getVar('post_terms');
			}else {
				$this->post['terms']=$this->post_model->getVar('post_terms');
			}

		}
		public function getAdminPageOptions(){
			$dir=$this->getDir('views').'options.php';
			//return $dir;
			$options_form=$this->options_form;
			$dir1=$this->getDir('views').'my_modal_options.php';
			ob_start();
			//require $dir1;
			require $dir;
			$html=ob_get_clean();
			return $html;
		}
		/**
		 * 
		 */
		private function getPostTypes(){
			$this->post_types=array(
				'post'=>__("Post","my_support_theme")
			);
			$args = array(
					'public'   => true,
					'_builtin' => false
			);

			$output = 'objects'; // names or objects, note names is the default
			$operator = 'and'; // 'and' or 'or'

			$post_types = get_post_types( $args, $output, $operator );
			foreach($post_types as $k=>$v){
				$this->post_types[$k]=$v;

			}
			self::debug("post_types", $this->post_types);
		}
	}
}
