<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Module_Debug')){
	class Class_My_Module_Debug {
		static $is_ajax=false;
		static $debug;
		static $url;
		static $debug_footer=true;
		static $dir;
		static $tmp_debug;
		static $debug_fp;
		static $doDebug=false;
		static $saveErrors=true;
		static $debugJs=true;
		//static $errorFile="Errors.tmp";
		static function init(){
			//Class_My_Module_Debug::$url=plugin_dir_url(__FILE__);
			self::$dir=plugin_dir_path(__FILE__);
			if(Class_My_Module_Debug::$debug_footer && Class_My_Module_Debug::$doDebug){
				$file=self::$dir.'includes/functions.php';
				require_once $file;
				if(is_admin()){
					add_action ('admin_enqueue_scripts', array ('Class_My_Module_Debug','admin_scripts'),PHP_INT_MAX );
					add_action('admin_footer',array('Class_My_Module_Debug','admin_footer'),PHP_INT_MAX);
				}else {
					//add_action ( 'admin_head', array (&$this,'admin_head') );
					add_action ('wp_enqueue_scripts', array ('Class_My_Module_Debug','admin_scripts'),PHP_INT_MAX);
					add_action('wp_footer',array('Class_My_Module_Debug','admin_footer'),PHP_INT_MAX);
				}
				
			}
			if(self::$saveErrors){
			    register_shutdown_function(array('Class_My_Module_Debug','save_errors'));
			}
		}
		static function array_map($arr,$ug=0,$call=true){
		    $ug++;
		    $tab="";
		    for($i=0;$i<$ug;$i++){
		        $tab.="\t";
		    }
		    static $myTimelineHtml='';
		    ob_start();
		    foreach($arr as $k=>$v){
		        if(is_array($v)&&$call){
		            echo $tab."key=".$k."\n";
		            //self::array_map($v,$ug,$call);
		        }
		        else if(is_scalar($v))echo $tab."key=".$k.";".$v."\n";
		    }
		    $myTimelineHtml.=ob_get_clean();
		    $ug--;
		    return $myTimelineHtml;
		}
		static function saveTmpErrors($file=""){
		    if(!empty(self::$debug['errors'])){
		        $fp=fopen($file,"w");
		        $dateStr=date('Y/m/d H:i:s');
		        fwrite($fp,"Date=".$dateStr."\n");
		        if(defined("DOING_AJAX")){
		          fwrite($fp,"AJAX\n");
		          fwrite($fp,"ACTION=".$_REQUEST['action']."\n");
		          fwrite($fp,"MY_ACTION=".$_REQUEST['my_action']."\n");
		         }else {
		          fwrite($fp,"PATH=".$_SERVER['REQUEST_URI']."\n");   
		         }
		         $errors=self::$debug['errors'];
		         if(!empty($fp)){
		             foreach($errors as $key=>$val){
		                 $arr=$errors[$key];
		                 foreach($arr as $key1=>$val1){
		                     fwrite($fp,"********************Error*********************\n");
		                     fwrite($fp,"Type=".$key."\n");
		                     $html=self::array_map($val1);
		                     fwrite($fp,$html);
		                     fwrite($fp,"********************Error*********************\n");
		                     
		                 }
		             }
		             fclose($fp);
		         }    
		      }
		}
		static function save_debug_to_file($file){
		    $fp=fopen($file,"w");
		    if(!empty($fp)){
		        $str="<?php if(!defined('ABSPATH'))die('');\n";
		        $str.="ob_start();?>";
		        $str.=maybe_serialize(self::$debug);
		        $str.="<?php ";
		        $str.="\$ret=ob_get_clean();\n";
		        $str.="return \$ret;";
		        fwrite($fp,$str);
		        fclose($fp);
		    }
		}
		static function save_errors(){
		    if(current_user_can('administrator')){
		        $errorFile=self::$tmp_debug.'errors/bug.tmp';
		        self::saveTmpErrors($errorFile);
		        $debugFile=self::$tmp_debug.'errors/debug.php';
		        self::save_debug_to_file($debugFile);
		        
		    }
		    if(!empty(self::$debug['errors'])){
		        //$file=self::$tmp_debug.'errors/Errors.php';
		        $allFile=self::$tmp_debug.'errors/errors.tmp';
		        $errors=self::$debug['errors'];
		        $o=maybe_serialize($errors);
		        //$str="<?php if(!defined('ABSPATH')) die('');\n";
		        //$str.="\$str='".$o."';\n";
		        //$str.="return \$str;\n";
		        $a=false;
		        if(file_exists($allFile)){
		            $a=true;
		            $size=filesize($allFile);
		            if($size>1000000){
		                $fp=fopen($allFile, "w");
		            }
		            else $fp=fopen($allFile, "a");  
		        }else $fp=fopen($allFile,"w");
		        if(!empty($fp)){
		            foreach($errors as $key=>$val){
		                $arr=$errors[$key];
		                foreach($arr as $key1=>$val1){
		                    fwrite($fp,"********************Error*********************\n");
		                    fwrite($fp,"Type=".$key."\n");
		                    $html=self::array_map($val1,0,false);
		                    fwrite($fp,$html);
		                    fwrite($fp,"********************Error*********************\n");
		                    
		                }
		            }
		            fclose($fp);
		        }
		    }
		}
		static function debug_file($key,$title,$var){
			if(!isset(self::$debug_fp[$key])){
				$file=self::$tmp_debug.$key.'.tmp';
				self::$debug_fp[$key]=fopen($file,'w');
			}
			$fp=self::$debug_fp[$key];
			ob_start();
			echo $title;
			var_dump($var);
			$h=ob_get_clean();
			fwrite($fp,$h);
		}
		static function debug_file_close($key){
			$fp=self::$debug_fp[$key];
			fclose($fp);
		}
		static function admin_scripts(){
			$assets_url=Class_My_Module_Debug::$url.'assets/';
			wp_enqueue_style('wp_my_module_debug_css',$assets_url.'debug.css');
			wp_enqueue_script('wp_my_module_debug_js',$assets_url.'jscript.js');
		}
		static function admin_footer(){
		    if(self::$debugJs){
		        ?>
		        <script type="text/javascript">
					var myDebugObj=<?php echo json_encode(self::$debug);?>;
					if(window.console){
						console.log("myDebug",myDebugObj);
						}
		        </script>
		        <?php 
		        return;
		    }
			$dir=self::$dir.'views/debug.php';
			require $dir;
		}
		static function add_section($key,$values,$source='plugin',$is_array=true){
			if(!isset(Class_My_Module_Debug::$debug[$source])){
				Class_My_Module_Debug::$debug[$source]=array();
			}
			if(!isset(Class_My_Module_Debug::$debug[$source][$key])){
				if($is_array){
					Class_My_Module_Debug::$debug[$source][$key]=array();
				}	
			}
			if($is_array){
				Class_My_Module_Debug::$debug[$source][$key][]=$values;
			}else {
				Class_My_Module_Debug::$debug[$source][$key]=$values;
			}
		}
		static function get_debug_source($source){
			if(isset(Class_My_Module_Debug::$debug[$source])){
				return Class_My_Module_Debug::$debug[$source];
			}else return 0;
		}	
		static function get_debug_source_key($source,$key){
			if(isset(Class_My_Module_Debug::$debug[$source])){
				if(isset(Class_My_Module_Debug::$debug[$source][$key])){
					return Class_My_Module_Debug::$debug[$source][$key];
				}else return 0;
			}else return 0;
		}
		static function get_debug(){
			if ( defined( 'SAVEQUERIES' ) && SAVEQUERIES ) {
				global $wpdb;
				Class_My_Module_Debug::$debug['wpdb_queries']=$wpdb->queries;
			}
				return Class_My_Module_Debug::$debug;
			
		}
	}
}
