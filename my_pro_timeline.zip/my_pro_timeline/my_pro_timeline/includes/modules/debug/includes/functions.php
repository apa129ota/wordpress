<?php
if(!defined('ABSPATH'))die('');
function my_module_debug_render_val($var,$level=1,$key=''){
	//echo 'level '.$level.' key '.$key.' type '.gettype($var).'<br/>';
	static $my_module_debug_var_html;
	if($level==1){
		$my_module_debug_var_html='';
	}
	$my_simple_vars_html='';;
	static $module_debug_level;
	$module_debug_level=$level;
	$level++;
	if(is_array($var)){
		foreach($var as $key1=>$val1){
			if(is_array($val1) || is_object($val1)){
				ob_start();
				?>
				<ul class="my_debug_module_level_<?php echo $level?>" data-key="<?php echo esc_attr($key)?>" data-i="<?php echo $level?>">
					<li class="my_debug_ul_li_tree" data-open="0" data-key="<?php echo esc_attr($key1)?>"><i class="fa fa-plus"></i><i class="fa fa-minus" style="display:none"></i>&nbsp;&nbsp;
					<?php echo $key1;?>
				<?php 
				$my_module_debug_var_html.=ob_get_clean();
				my_module_debug_render_val($val1,$level,$key1);
				$my_module_debug_var_html.='</li></ul>';
			}else {
				$my_simple_vars_html.=my_module_debug_render_simple_var($key1, $val1);;
				//$my_module_debug_var_html.=my_module_debug_render_simple_var($key1, $val1);
			}
			
		}
		$my_module_debug_var_html.=$my_simple_vars_html;
			
	}else if(is_object($var)){
		foreach($var as $key1=>$val1){
			if(is_array($val1) || is_object($val1)){	
				ob_start();
?>
				<ul class="my_debug_module_level_<?php echo $level?>" data-key="<?php echo esc_attr($key)?>" data-i="<?php echo $level?>">
					<li class="my_debug_ul_li_tree" data-open="0" data-key="<?php echo esc_attr($key1)?>"><i class="fa fa-plus"></i><i class="fa fa-minus" style="display:none"></i>&nbsp;&nbsp;
					<?php echo $key1;?>
				<?php 
				$my_module_debug_var_html.=ob_get_clean();
				
			
				my_module_debug_render_val($val1,$level,$key1);
				$my_module_debug_var_html.='</li></ul>';
			}else {
				$my_simple_vars_html.=my_module_debug_render_simple_var($key1, $val1);;
				//$my_module_debug_var_html.=my_module_debug_render_simple_var($key1, $val1);
			}
			
		}
		$my_module_debug_var_html.=$my_simple_vars_html;
	}else {
		$html.=my_module_debug_render_simple_var($key, $var);
	}
	$level--;
	if($level==1)return $my_module_debug_var_html;
}
function my_module_debug_render_simple_var($key,$val){
ob_start();
?>
	<li><label style="color:green"><?php echo $key;?></label>=<label style="color:blue"><?php echo $val?></label></li>
<?php 
	$t=ob_get_clean();
	return $t;
}