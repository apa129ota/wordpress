<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Module_Icons')){
	class Class_My_Module_Icons extends Class_My_General_Module{
		use MySingleton;
		function __construct($options=array()){
			parent::__construct($options);
		}
		function init(){
				
		}
	}
}
