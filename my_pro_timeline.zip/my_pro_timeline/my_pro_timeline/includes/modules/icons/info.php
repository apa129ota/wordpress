<?php
if(!defined('ABSPATH'))die('');
$info=array(
		'title'=>'Icons',
		'description'=>'Module for adding fa icons',
		'class'=>'Class_My_Module_Icons',
		
);
return $info;