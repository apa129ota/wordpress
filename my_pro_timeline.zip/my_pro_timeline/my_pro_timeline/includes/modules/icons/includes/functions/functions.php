<?php
if(!defined('ABSPATH'))die('');
function wp_my_module_icons_get_icons($dir=''){
    if(empty($dir)){
        $dir=realpath(dirname(__FILE__).'/../options/').'/';
    }
   // echo $dir;
	$file=$dir.'icons.php';
	$icons1=require $file;
	$icons=array();
	foreach($icons1 as $key=>$val){
		//$icons[$key]='<i class="fa '.$key.'"></i>&nbsp;&nbsp;'.$val['title'];
		$icons[$key]=$val['title'].'&nbsp;&nbsp<i class="fa '.$key.'"></i>';
	}
	asort($icons);
	return $icons;
}
function wp_my_module_icons_parse_css($from,$dir,$file_name){
	ob_start();
	echo 'From :'.$from.'<br/>';
	$file=$from.'icons';
	$str=file_get_contents($file);
	$icons=array();
	if(!empty($str)){
		$arr=explode("\n",$str);
		if(!empty($arr)){
			foreach($arr as $key=>$val){
				$p=$val;
				if(preg_match('/(\.[a-z]+[\-]([a-z\-]+))/ims', $p,$match)){
					echo 'V '.$p;
					echo '<pre>';
					print_r($match);
					echo '</pre>';
					$obj=array();
					$k1=substr($match[0], 1);

					$icons[$k1]=array(
						'class'=>$match[0],
						'title'=>ucfirst($match[2])
					);
				}
			}
		}
	}
	$i="<?php if(!defined('ABSPATH'))die('');\n";
	$i.="\$str='';\n";
	$i.="ob_start();\n?>".maybe_serialize($icons)."<?php\n;\$str=ob_get_clean();";
	$i.="\$ret=maybe_unserialize(\$str);\n";
	$i.="return \$ret;";
	$f=$dir.$file_name;
	file_put_contents($f, $i);
	echo '<pre>';
	print_r($icons);
	echo '</pre>';

	$s=ob_get_clean();
	return $s;
}