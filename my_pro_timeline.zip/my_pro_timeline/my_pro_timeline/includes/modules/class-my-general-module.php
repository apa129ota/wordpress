<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_General_Module')){
    /**
     * Class general module
     * @author tiw126itwa
     *
     */
	class Class_My_General_Module{
	    use MyArrayOptions,MyLoadFiles,MyDebug,MyWordpressMenu,MyWordpressAssets;
				protected $is_admin=false;
				protected $dir;
				protected $url;
				protected $version='1.0';
				protected $css_url;
				protected $images_url;
				protected $jscript_url;
				protected $modules_dir;
				protected $modules_url;
				protected $class_dir;
				protected $assets_dir;
				protected $controllers_dir;
				protected $models_dir;
				protected $options_dir;
				protected $functions_dir;
				protected $views_dir;
				protected $debug=0;
				protected $use_case='my_framework';
				protected $scripts_class;
				protected $module_options;
				protected $global_plugin;
				protected $template_vars;
				protected $ajax_controller;
				protected $views_url;
				protected $parent_module;
                protected $shortcodes;
                protected $activeController='';
                protected $myIsPlugin=1;
                protected $myAssets=array();
                protected $mySubModules=array();
                protected $moduleName;
                protected $formModuleObj="";
                protected static $allModules=array();
                protected static $instId=0;
                protected $metaModuleObj="";
                protected $ret;
				function __construct($options=array(),$not=array()){
					//print_r($options);
					if(!empty($not)){
						foreach ($not as $k=>$v){
							unset($options[$v]);
						}
					}
					$this->setOptions($options);
					if($this->debug){
						self::setDebugOptions($this->use_case);
					}
					$file=$this->dir.'info.php';
					$opt=require $file;
					self::$instId++;
					if(!empty($opt['name'])){
					    $this->moduleName=$opt['name'];
					}else {
					    $this->moduleName='unkownId_'.self::$instId;
					}
					self::$allModules[$this->moduleName]=&$this;
					self::debug("create_module_class", $options);
					$this->assets_dir=$this->dir.'assets/';
					$this->css_url=$this->url.'assets/css/';
					$this->images_url=$this->url.'assets/images/';
					$this->modules_url=$this->url.'includes/modules/';
					$this->jscript_url=$this->url.'assets/jscript/';
					$this->modules_dir=$this->dir.'includes/modules/';
					$this->class_dir=$this->dir.'includes/class/';
					$this->functions_dir=$this->dir.'includes/functions/';
					$this->options_dir=$this->dir.'includes/options/';
					$this->views_dir=$this->dir.'includes/views/';
					$this->models_dir=$this->dir.'includes/models/';
					$this->controllers_dir=$this->dir.'includes/controllers/';
				    $this->views_url=$this->url.'includes/views/';
				    
				}
				/**
				 * 
				 * @param unknown $msg
				 */
				protected function ajaxError($msg){
				    $this->ret['error']=1;
				    $this->ret['msg']=$msg;
				}
				/**
				 * 
				 * @param unknown $msg
				 */
				protected function ajaxOk($msg){
				    $this->ret['error']=0;
				    $this->ret['msg']=$msg;
				}
				
				/**
				 * 
				 * @param array $options
				 */
				protected function initMetaModule($options=array()){
				    $module_dir=$this->global_plugin->getDir("modules");
				    wp_my_general_load_module($module_dir, "meta");
				    $this->metaModuleObj=new Class_My_Module_Meta($options);
				    
				}
				/**
				 * 
				 * @return string|Class_My_Module_Meta
				 */
				protected function getMetaModule(){
				    return $this->metaModuleObj;
				}
				/**
				 * 
				 * @param array $params
				 * @param number $debug
				 */
				public function loadFormModule($params=array(),$debug=0){
				    $this->global_plugin->loadModuleClass('new_form');
				    $my_set_debug=$debug;
				    $formId=$this->moduleName.'_form';
				    $options=array(
				        'id'=>$formId,
				        'elements'=>array(),
				        'hidden'=>array(
				            'my_nonce'=>wp_create_nonce($formId),
				            
				        ),
				        'element_template'=>'my_li.php',
				        'form_template'=>'my_form.php',
				        'my_debug'=>$my_set_debug
				    );
				    if(!empty($params)){
				        foreach($params as $k=>$v){
				            $options[$k]=$v;
				        }
				    }
				    self::debug("formClassParams", $options);
				    $this->formModuleObj=new Class_Wp_My_Module_New_Form($options);
				}
				/**
				 * 
				 * @param string $inst
				 * @return string|Class_Wp_My_Module_New_Form|boolean
				 */
				public function getFormClassObj($inst=true){
				    if($inst){
				    if(empty($this->formModuleObj)){
				        $this->loadFormModule();
				        return $this->formModuleObj;
				    }
				    }else {
				        if(empty($this->formModuleObj)){
				            return false;
				        }else return $this->formModuleObj;
				    }
				    
				}
				/**
				 * 
				 * @param unknown $key
				 * @param unknown $element
				 * @return string
				 */
				public function renderFormElement($key,$element){
				    if(!empty($this->formModuleObj)){
				        return $this->formModuleObj->renderSingleElement($key, $element);
				    }else return false;
				}
				/**
				 * 
				 * @param unknown $name
				 * @throws Exception
				 * @return mixed
				 */
				public static function getModuleInstance($name){
				    if(isset(self::$allModules[$name])){
				        return self::$allModules[$name];
				    }else {
				        $exc=new Exception(__("Module Class Not found","my_support_theme").":".$name,1000);
				        throw $exc;
				    }
				}
				/**
				 * 
				 * @return unknown|boolean
				 */
				protected function getAdminPage(){
				    $page=@$_GET['page'];
				    if(!empty($page)){
				        return $page;
				    }else return false;
				}
				/**
				 * set partial options
				 * @param array $args
				 */
				protected function setPartialOptions($args=array()){
				    $this->setOptions($args);
				}
				/**
				 * Load submodule
				 * @param unknown $module
				 */
				protected function loadSubModule($module,$params=array()){
				    $url=$this->url;
				    $dir=$this->dir;
				    $infoFile=$this->getDir('modules').$module.'/info.php';
				    $info=require $infoFile;
				    $options=array(
				        'url'=>$url.'includes/modules/'.$module.'/',
				        'dir'=>$dir.'includes/modules/'.$module.'/',
				        'debug'=>$this->debug,
				        'parent_module'=>$this,
				        'global_plugin'=>$this->global_plugin
				    );
				    if(!empty($params)){
				        foreach($params as $key=>$val){
				            if(!isset($options[$key])){
				                $options[$key]=$val;
				            }
				        }
				    }
				    $this->loadModuleClass($module);
				    self::debug("loadSubModule", $module);
				    self::debug("loadSubmoduleOptions", $options);
				    $class=new $info['class']($options);
				    $this->mySubModules[$module]=&$class;
				    return $class;
				    
				}
				/**
				 * Get sub module
				 * @param unknown $module
				 * @return mixed
				 */
				public function getSubmodule($module){
				    if(isset($this->mySubModules[$module])){
				        return $this->mySubModules[$module];    
				    }else {
				        trigger_error(__("Error submodule not exists").$module,E_USER_NOTICE);
				        
				    }
				}
				/**
				 * Get parent module
				 * @return unknown
				 */
				public function getParentModule(){
				    if(isset($this->parent_module)){
				        return $this->parent_module;
				    }else return false;
				}
				/**
				 * Load module class
				 * @param unknown $module
				 */
				public function loadModuleClass($module){
					$dir=$this->getDir('modules');
					$file=$dir.$module.'/class.php';
					if(file_exists($file)){
						require_once $file;
					}else {
						trigger_error(__("Module file not found ","my_support_theme").$file.' '.$module,E_USER_NOTICE);
					}
				}
				/**
				 * Get property
				 * @param unknown $key
				 * @return unknown
				 */
				public function getProperty($key){
					if(!isset($this->$key)){
						trigger_error(__("Property is not set","my_support_theme").' '.$key,E_USER_NOTICE);
					}else {
						return $this->$key;
					}
				}
				/**
				 * Set temnplate vars
				 * @param unknown $key
				 * @param unknown $var
				 */
				public function set_template_vars($key,$var){
					$this->template_vars[$key]=$var;

				}
				/**
				 * 
				 * @param unknown $key
				 * @return unknown|boolean
				 */
				public function get_template_var($key){
				    if(isset($this->template_vars[$key])){
				        return $this->template_vars[$key];
				    }else return false;
				}
				/**
				 * Load view file
				 * @param unknown $file
				 */
				public function loadViewFile($file){
					$file=$this->views_dir.$file;
					if(!empty($this->template_vars))
					extract($this->template_vars);
					if(!file_exists($file)){
						trigger_error(__("View file dont exists","my_support_theme").' '.$file,E_USER_NOTICE);
					}else {
						require $file;
					}
				}
				/**
				 * Get module options
				 * @return NULL[]
				 */
				protected function get_module_options(){
					$options=array();
					$predefined=array(
						'url','dir','use_case','debug'
					);
					foreach($predefined as $key=>$val){
						$options[$val]=$this->$val;
					}
					return $options;

				}
				/**
				 * Get module url
				 * @param string $type
				 * @return unknown|string|boolean
				 */
				public function getUrl($type='css'){
					switch($type){
						case 'plugin':
							return $this->url;
							break;
						case 'css':
							return $this->css_url;
							break;
						case 'images':
							return $this->images_url;
							break;
						case 'modules':
							return $this->modules_url;
						case 'jscript':
							return $this->jscript_url;
							break;
						case 'views':
							return $this->views_url;
						break;
						default:
							return false;
							//throw new Exception(__("Property with key dont exists","my_support_theme").$type);
							trigger_error(__("Property with key dont exists","my_support_theme").$type,E_NOTICE);
							break;
					}

				}
				/**
				 * Get module dir
				 * @param string $type
				 * @return unknown|boolean
				 */
				public function getDir($type='plugin'){
					switch($type){
					    case 'assets':
					        return $this->assets_dir;
					    break;    
						case 'plugin':
						 return $this->dir;
						 break;
						case 'class':
							return $this->class_dir;
							break;
						case 'controllers':
							return $this->controllers_dir;
							break;
						case 'modules':
							return $this->modules_dir;
							break;
						case 'models':
							return $this->models_dir;
							break;
						case 'functions':
							return $this->functions_dir;
							break;
						case 'options':
							return $this->options_dir;
							break;
						case 'views':
							return $this->views_dir;
						break;
						default:
							trigger_error(__("Property with key dont exists","my_support_theme").$type,E_USER_NOTICE);
							return false;
							//throw new Exception(__("Property with key dont exists","my_support_theme").$type);
							break;
					}
				}
                protected function parseIncludes(&$adminPages){
                    
                }
                /**
                 * init module
                 * @param array $options
                 */
				protected function init($options=array()){
					$this->setOptions($options);
					$this->myAddMenu($this,$this->options_dir);
					self::debug('parsedStyles', $this->myParsedStyles);
					/*$ajax_file=$this->options_dir.'ajax.php';
					if(file_exists($ajax_file)){
					    
					}*/
				}
				/**
				 * debug
				 * @param unknown $key
				 * @param unknown $val
				 * @param unknown $all
				 */
				protected function my_debug($key,$val,$all){
					if($this->debug){
						Class_My_Module_Debug::add_section($key, $val,$this->use_case,$all);
					}
				}
				/**
				 * get ajax nonce string
				 * @param unknown $action
				 * @return string|unknown
				 */
				public function get_ajax_nonce_str($action){
					$str=$action;
					if(is_user_logged_in()){
						$str.='_'.get_current_user_id();
					}
					return $str;
				}
				/**
				 * get nonce
				 * @param unknown $action
				 * @return string
				 */
				public function ajax_get_nonce($action){
					$str=$action;
					if(is_user_logged_in()){
					$str.='_'.get_current_user_id();
					}
					return wp_create_nonce($str);
				}
				/**
				 * check ajax nonce
				 * @param unknown $nonce
				 * @param unknown $action
				 * @return false|number
				 */
				public function ajax_check_nonce($nonce,$action){
					$str=$action;
					if(is_user_logged_in()){
						$str.='_'.get_current_user_id();
					}
					return wp_verify_nonce($nonce,$str);
				}
				/**
				 * Route ajax
				 * @param array $options
				 */
				public function routeAjax($options=array()){
					self::debug("module_routre_ajax", $options);
					$action=@$_REQUEST['action'];
					$my_action = @$_REQUEST['my_action'];

					if (! preg_match ( '/^[a-zA-Z_]+$/', $my_action )){
						$ret['error']=1;
						echo json_encode($ret);
						exit();
					}
					if(in_array($my_action,$options['my_actions']) || array_key_exists($my_action, $options['my_actions'])){
						//$action=$options['my_actions'][$my_action];
						$dir=$this->controllers_dir;
						if(isset($action['controller'])){
							$file=$dir.$action['controller']['file'];
							$name=$action['controller']['name'];
						}else {
							$file=$dir.$options['controller_file'];
							$name=$options['controller_name'];

						}
						require_once $file;

						$options1['ajax_actions'] = $options['my_actions'];


						if($this->debug){
							$options1['debug']=1;
						}else {
							$options['debug']=0;
						}
						$my_set_debug=1;
						if($this->debug){
						    $my_set_debug=1;
						}
						$options1['ajax']=1;
						$options1['action'] = $my_action;
						$options1['ajax_nonce']=$this->get_ajax_nonce_str($action);
						$options1['plugin_object']=$options['plugin_object'];
						$options1['module_class']=$options['module_class'];
						$options1['debug']=$my_set_debug;
						$options1['module']=$this;
						if(!empty($options['nonce_str'])){
							$options1['nonce_str']=$options['nonce_str'];
						}
						$this->ajax_controller=new $name($options1);
						$this->ajax_controller->route_ajax();

					}else {
						/*
						$ret['options']=$options;
						//$ret['options1']=$options1;
						$ret['error']=1;
						echo json_encode($ret);
						exit();
						*/
					}

				}
				/**
				 * admin menu
				 */
				protected function addMenu(){
				        
				        if(!empty($this->adminPages)){
				            foreach($this->adminPages as $key=>$val){
				                $parent_slug=$val['parent'];
				                $page_title=$menu_title=$val['title'];
				                $capability=$val['capability'];
				                $menu_slug=$key;
				                if(!empty($parent)){
				                    add_submenu_page($parent_slug, $page_title, $menu_title, $capability, $menu_slug,array($this,'routePage'));
				                }else {
				                    add_menu_page($page_title, $menu_title, $capability, $menu_slug,array($this,'routePage'));
				                }
				            }
				        }
				    
				}
				/**
				 * Function for routing to page controller
				 * every module will have its own 
				 * page controller
				 */
				public function routePage(){
				    self::debug("menu_form", $this->adminPages);
				    $c=$this->traitGetPageController();
				    self::debug("c", $c);
				    $class=$c['class'];
				    $file=$c['file'];
				    $this->global_plugin->loadController('class-my-general-controller.php');
				    $options=array(
				        'is_ajax'=>0,
				        'debug'=>$this->debug,
				        'slug'=>$this->adminPageSlug,
				        'plugin_object'=>&$this->global_plugin,
				        'module'=>&$this,
				        'admin_pages'=>$this->adminPages
				    );
				    $this->loadController($file);
				    $this->activeController=new $class($options);
				    $this->activeController->route();
				}
				protected function showPage(){
				    if(!empty($this->activeController)){
				        echo $this->activeController->get_html();
				    }
				}



	}
}