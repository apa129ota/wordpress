<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Module_Options')){
	class Class_My_Module_Options extends Class_My_General_Module{
		protected $options_name;
		protected $options;
		protected $pre_options;
		protected $options_form;
		private $form_prefix='options';
		private $ajax_action='my_framawork_save_action';
		private $ajax_nonce='my_framework_options';
		private $ajax_actions=array('reset_options','save_options');
		private $autoload=false;
		function __construct($options=array()){
			//$options['url']=plugin_dir_url(__FILE__);
			//$options['dir']=plugin_dir_path(__FILE__);
			$this->options_name=$options['options_name'];
			$this->pre_options=$options['pre_options'];
			$this->options_form=$options['options_form'];
			parent::__construct($options,$not=array('options_name','pre_options','options_form'));
		
		}	
		public function addUpdateNewOption($key,$val,$save=false){
		    $this->options[$key]=$val;
		    if($save){
		        $saveOptions=$this->options;
		        update_option($this->options_name, $saveOptions,$this->autoload);
		
		    }
		}
		
		public function init($options=array()){
			$this->initOptions();
			self::debug("plugin_options_loaded", $this->options);
			add_action('wp_ajax_'.$this->ajax_action, array(&$this,'ajax_save_options'));
		}
		private function reset_options(){
			foreach($this->pre_options as $k=>$v){
				$this->options[$k]=$v;
			}
			$this->update_options();
		}
		private function save_options($arr=array()){
			if(!empty($arr)){
				/*foreach($this->options_form as $key=>$val){
					if(isset($arr[$key]))$this->options[$key]=$arr[$key];
				}*/
				foreach($arr as $key=>$val){
					$this->options[$key]=$val;
				}
			}
			$this->update_options();
			
		}
		private function update_options(){
			update_option($this->options_name, $this->options,$this->autoload);
		}
		public function ajax_save_options(){
			$nonce=@$_POST['nonce'];
			$my_action=@$_POST['my_action'];
			$ret['error']=0;
			if(!$this->ajax_check_nonce($nonce, $this->ajax_action)){
				$ret['error']=1;
				$ret['msg']=__("Error","my_support_theme");
				if($this->debug){
					$ret['debug_msg']='error_nonce';
				}
			}else {
				if(!in_array($my_action,$this->ajax_actions)){
					$ret['error']=1;
					$ret['msg']=__("Error","my_support_theme");
					if($this->debug){
						$ret['debug_msg']='not supported action';
							
					}
					
				}else {
					if($my_action=='reset_options'){
						$this->reset_options();
						if($this->debug){
							$ret['debug']=array(
								$this->options
							);
						}
						$ret['error']=0;
						//$ret['msg']=__("Options has been reset !","my_support_theme");
						
					}else if($my_action=='save_options'){
						$arr_str=@$_POST['form_data'];
						$arr=array();
						parse_str($arr_str,$arr);
						$this->global_plugin->loadModuleFile('new_form','functions.php','includes');
						$arr=my_new_form_clean_data($arr,$this->options_form['elements']);
						if($this->debug){
							$ret['debug']['arr']=$arr;
						}
						$this->save_options($arr);
						if($this->debug){
							$ret['debug']['options']=$this->options;
						}
						$ret['error']=0;
						$ret['msg']=__("Options has been saved","my_support_theme");
					}
					}
			}
			echo json_encode($ret);
			exit();
		}
		private function initOptions(){
			$arr=get_option($this->options_name);
			if(empty($arr)){
				$this->options=$this->pre_options;
			}else {
				foreach($this->pre_options as $k=>$v){
					if(!isset($arr[$k])){
						$arr[$k]=$v;
					}
				}
				$this->options=$arr;
			}
			self::debug("plugin_options", $this->options);
		}
		public function wp_head(){
			$options=$this->global_plugin->loadOptions("ajax_options.php");
			$my_set_debug=0;
			if($this->debug){
				$options['my_debug']=1;
				$my_set_debug=1;
			}
			?>
			<script type="text/javascript">
				jQuery(document).ready(function($){
						var o=<?php echo json_encode($options);?>;
						my_msg_options_saving_option="<?php echo esc_attr(__("Saving options","my_support_theme"));?>";
						my_msg_options_reset_option="<?php echo esc_attr(__("Reset Options","my_support_theme"));?>";
						my_options_ajax_action="<?php echo $this->ajax_action?>";
						myGlobalAjaxClass_inst=new myGlobalAjaxClass(o);
						var o1={};
						myAdminMsgs_inst=new myAdminMsgs(o1);
					});
				
			</script>
			<?php 
		}
		public function scripts(){
			$url=$this->global_plugin->getUrl('jscript').'admin/my_ajax.js';
			wp_enqueue_script('my_framework_ajax',$url);
			$url=$this->global_plugin->getUrl('jscript').'admin/admin_msgs.js';
			wp_enqueue_script("my_framework_msgs",$url);
			$url=$this->css_url.'admin.css';
			wp_enqueue_style('my_framework_options_moduel_css',$url);
			$url=$this->jscript_url.'jscript.js';
			wp_enqueue_script('my_framework_options_module_js',$url);
				
		}
		public function renderForm(){
			add_action('admin_head', array($this,'wp_head'),PHP_INT_MAX);
			add_action('admin_enqueue_scripts',array($this,'scripts'),PHP_INT_MAX);
			$this->global_plugin->loadModuleFile('new_form','functions.php','includes');
			$dir=$this->global_plugin->getDir('modules').'new_form/';
			$url=$this->global_plugin->getUrl('modules').'new_form/';
			$pluginUrl=$this->global_plugin->getProperty('url');
			my_new_form_populate_form_values($this->options_form, $this->options);
			$options=array(
			    'dir'=>$dir,
			    'url'=>$url,
			    'pluginUrl'=>$pluginUrl,
				'id'=>$this->form_prefix,
				'elements'=>$this->options_form['elements'],
				'hidden'=>array(
					'my_nonce'=>$this->ajax_get_nonce($this->ajax_action)
				),
				'my_debug'=>$this->debug			
			);
			$file=$this->views_dir.'actions.php';
			$form_class=$this->global_plugin->instantiateModuleClass('new_form',$options);
			
			ob_start();
			require $file;
			$form_class->render_form();
			$html=ob_get_clean();
			return $html;
			
		}
		public function getOptions(){
			return $this->options;
		}	
		public function getOptionByKey($key){
			if(isset($this->options[$key])){
				return $this->options[$key];
			}else {
				trigger_error(__("Options key don't exist ","my_support_theme").$key,E_USER_NOTICE);
			}
		}
	}
}