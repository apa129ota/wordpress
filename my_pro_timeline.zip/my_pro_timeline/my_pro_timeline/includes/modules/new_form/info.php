<?php
if(!defined('ABSPATH'))die('');
$info=array(
        'name'=>'new_form_module',
		'title'=>'New Form module',
		'description'=>'Form module',
		'class'=>'Class_Wp_My_Module_New_Form',

);
return $info;