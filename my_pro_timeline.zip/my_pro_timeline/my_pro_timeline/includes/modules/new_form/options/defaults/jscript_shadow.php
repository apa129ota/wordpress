<?php
if(!defined('ABSPATH'))die('');
$units=array(
    'px'=>'px',
    '%'=>'%',
    'px'=>'px',
    'cm'=>'cm',
    'mm'=>'mm',
    'in'=>'in',
    'pt'=>'pt',
    'pc'=>'pc',
    'ch'=>'ch',
    'em'=>'em'
);
$units1=array(
    'px'=>'px',
    '%'=>'%',
);
$options=array(
    'type'=>'jscript_shadow',
    'title'=>__('Shadow',"my_support_theme"),
    'tooltip'=>__("Specify element shadow","support_theme"),
    
    'default'=>array(
        array(
        'h_shadow'=>'0px',
        'v_shadow'=>'0px',
        'blur'=>'0px',
        'spread'=>'0px',
        'color'=>'#000000,0.247059',
            )
    ),
    'elements'=>array(
        'h_shadow'=>array(
            'type'=>'jscript_spinner',
            'property'=>'height',
            'default'=>'1',
            'default_unit'=>'px',
            'units'=>$units,
        ),
        'v_shadow'=>array(
            'type'=>'jscript_spinner',
            'property'=>'height',
            'default'=>'1',
            'default_unit'=>'px',
            'units'=>$units,
        ),
        'blur'=>array(
            'type'=>'jscript_spinner',
            'property'=>'height',
            'default'=>'1',
            'default_unit'=>'px',
            'units'=>$units,
        ),
        'spread'=>array(
            'type'=>'jscript_spinner',
            'property'=>'height',
            'default'=>'1',
            'default_unit'=>'px',
            'units'=>$units,
        ),
        
        
        'color'=>array(
            'type'=>'jscript_color_picker',
            'pick_title'=>__("Pick a Color","my_support_theme"),
            'close_title'=>__("Close","my_support_theme"),
            'default'=>'#000000',
            
            'jscript'=>array(
                'pick_title'=>__("Pick a Color","my_support_theme"),
                'close_title'=>__("Close","my_support_theme"),
                'hex_title'=>__("Hex value","my_support_theme"),
                'transp_title'=>__("Transparency","my_support_theme")
            ),
            'transparency'=>true,
        ),
        
        )
    );
return $options;