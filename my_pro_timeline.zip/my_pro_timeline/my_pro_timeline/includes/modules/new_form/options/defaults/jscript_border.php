<?php
$options=array(
    'type'=>'jscript_border',
    'title'=>__('Border',"my_support_theme"),
    'tooltip'=>__("Specify border clicking on rectangle and selecting some top left or right border","support_theme"),
    'default'=>array(
        'width'=>'1px',
        'color'=>'#000000',
        'style'=>'solid'
    ),
    'elements'=>array(
        'border_width'=>array(
            'type'=>'jscript_spinner',
            'property'=>'height',
            'default'=>'1',
            'default_unit'=>'px',
            'units'=>$units,
        ),
        'border_color'=>array(
            'type'=>'jscript_color_picker',
            'pick_title'=>__("Pick a Color","my_support_theme"),
            'close_title'=>__("Close","my_support_theme"),
            'default'=>'#000000',
            
            'jscript'=>array(
                'pick_title'=>__("Pick a Color","my_support_theme"),
                'close_title'=>__("Close","my_support_theme"),
                'hex_title'=>__("Hex value","my_support_theme"),
                'transp_title'=>__("Transparency","my_support_theme")
            ),
            'property'=>array(
                'class'=>'{class}',
                'property'=>'background'
            ),
            'transparency'=>false,
        ),
        'border_type'=>array(
            'type'=>'select',
            'default'=>'solid',
            'values'=>array(
                'dotted'=>__("Dotted","my_support_theme"),
                'dashed'=>__("Dashed","my_support_theme"),
                'solid'=>__("Solid","my_support_theme"),
                'double'=>__("Double","my_support_theme"),
                'groove'=>__("Groove","my_support_theme"),
                'ridge'=>__("Ridge","my_support_theme"),
                'inset'=>__("Inset","my_support_theme"),
                'outset'=>__("Outset","my_support_theme"),
                'none'=>__("None","my_support_theme"),
                'hidden'=>__("Hidden","my_support_theme"),
                
            )
        )
    )
    );
return $options;