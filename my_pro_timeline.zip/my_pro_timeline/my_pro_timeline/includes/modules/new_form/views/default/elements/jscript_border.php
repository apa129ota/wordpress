<?php
if(!defined('ABSPATH'))die('');
$backup_element=$element;
$my_check_border=array('top','left','right','bottom');
foreach($my_check_border as $k12=>$v12){
    unset($$v12);
    if(!empty($element['value'][$v12])){
        $$v12=$element['value'][$v12];
    }
}
if(!empty($element['value']['border'])){
    foreach($my_check_border as $k12=>$v12){
        if(!isset($$v12))
        $$v12=$element['value']['border'];
    }
}
$border_radius_value="";
if(!empty($element['value']['border_radius'])){
    $border_radius_value=$element['value']['border_radius'];
}
//$top='2px solid #aaaaaa';
?>
<div data-default="<?php echo esc_attr($default); ?>" data-base-name="<?php echo $key;?>" data-value="<?php if(!$element_multiple)esc_attr($element_value)?>" id="<?php echo $element_id.'_div';?>" data-type="<?php echo 'jscript_border';?>" data-open="<?php if(!empty($element['open']))echo $element['open']; ?>" data-id="<?php echo $element_id?>" data-name="<?php echo $element_name;?>" <?php if(!empty($element_validate))echo $element_validate;?> class="my_new_module_element jscript_dropdown_div <?php if(!empty($element['div_classes'])){$str=implode(" ",$element['div_classes']);echo $str;}?>">
	<input type="hidden" name="<?php echo $element_name.'_radius'?>" value="<?php echo esc_attr($border_radius_value)?>"/>

	<?php foreach($my_check_border as $k12=>$v12){ 
	   ?>
	   <input type="hidden" name="<?php echo esc_attr($element_name.'_'.$v12)?>" value="<?php if(isset($$v12))echo esc_attr($$v12)?>"/>
	   <?php    
	}
	?>
    <h6><?php echo __("Border",",my_support_theme");?></h6>
	<div id="my_border_<?php echo $element_name?>" class="my_new_form_border_css">
		<div class="my_new_form_border_css_top">
			<div class="my_new_form_border_icons_w my_tooltip" style="top:0px">
				<input data-key="top" class="my_border_check" type="checkbox" <?php if(isset($top)) echo 'checked="checked"'?>/>
							<div class="my_content"><?php echo __("Check this to enable top border. Check one border to define border for that position.","my_support_theme")?></div>
			</div>
			
			<div style="display:none"></div>
		</div>
		<div class="my_new_form_border_css_left" >
			<div class="my_new_form_border_icons_h my_tooltip" style="left:0px">
						<input data-key="left" class="my_border_check" type="checkbox" <?php if(isset($left)) echo 'checked="checked"'?>/>
					
							<div class="my_content"><?php echo __("Check this to enable left border.Check one border to define border for that position.","my_support_theme")?></div>
					
			</div>
			<div style="display:none"></div>
		</div>
		<div class="my_new_form_border_css_right" >
		<div class="my_new_form_border_icons_h my_tooltip" style="right:0px">
						<input data-key="right" class="my_border_check" type="checkbox" <?php if(isset($right)) echo 'checked="checked"'?>/>
							<div class="my_content"><?php echo __("Check this to enable right border.Check one border to define border for that position.","my_support_theme")?></div>
			</div>
			<div style="display:none"></div>
		</div>
		<div class="my_new_form_border_css_bottom" >
			<div class="my_new_form_border_icons_w my_tooltip" style="bottom:0px">
						<input data-key="bottom" class="my_border_check" type="checkbox" <?php if(isset($bottom)) echo 'checked="checked"'?>/>
							<div class="my_content"><?php echo __("Check this to enable bottom border.Check one border to define border for that position.","my_support_theme")?></div>
			</div>
			<div style="display:none"></div>
		</div>
	</div>
	<h6><?php echo __("Border Radius",",my_support_theme");?></h6>
	
	<div id="my_border_radius_<?php echo $element_name?>" class="my_new_form_border_css">
		<div class="my_border_radius_top_left">
			<div class="my_new_form_border_icons_w12 my_tooltip" style="top:0px;left:0px;">
				<input data-key="top_left" class="my_border_radius_check" type="checkbox" <?php if(isset($top_radius)) echo 'checked="checked"'?>/>
							<div class="my_content"><?php echo __("Check this to enable top left border border radius. Change spinners to adjust value.","my_support_theme")?></div>
			</div>
		</div>
		<div class="my_border_radius_top_right">
			<div class="my_new_form_border_icons_w12 my_tooltip" style="top:0px;right:0px;">
				<input data-key="top_right" class="my_border_radius_check" type="checkbox" <?php if(isset($top_radius)) echo 'checked="checked"'?>/>
							<div class="my_content"><?php echo __("Check this to enable top right border border radius. Change spinners to adjust value.","my_support_theme")?></div>
			</div>
		</div>
		<div class="my_border_radius_bottom_right">
			<div class="my_new_form_border_icons_w12 my_tooltip" style="bottom:0px;right:0px;">
				<input data-key="bottom_right" class="my_border_radius_check" type="checkbox" <?php if(isset($top_radius)) echo 'checked="checked"'?>/>
							<div class="my_content"><?php echo __("Check this to enable bottom right border border radius. Change spinners to adjust value.","my_support_theme")?></div>
			</div>
		</div>
		<div class="my_border_radius_bottom_left">
			<div class="my_new_form_border_icons_w12 my_tooltip" style="bottom:0px;left:0px;">
				<input data-key="bottom_left" class="my_border_radius_check" type="checkbox" <?php if(isset($top_radius)) echo 'checked="checked"'?>/>
							<div class="my_content"><?php echo __("Check this to enable bottom right border border radius. Change spinners to adjust value.","my_support_theme")?></div>
			</div>
		</div>
		
		
		
	
	</div>
		<div class="my_new_form_border_preview">
		</div>
	
	<div class="my_new_border_values">
		<style class="my_radius_css" type="text/css">
		  
		</style>
		<span><?php echo __("Preview","my_support_theme")?></span>
		<div></div>
	</div>
</div>
