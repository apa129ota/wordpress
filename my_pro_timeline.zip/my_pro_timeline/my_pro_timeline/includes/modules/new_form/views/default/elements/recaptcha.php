<?php
if(!defined('ABSPATH'))die('');
$public_key=$element['public_key'];
?>
<div data-base-name="<?php echo $key;?>" id="<?php echo $element_id.'_div';?>" data-name="<?php echo $element_name;?>" data-type="<?php echo $type;?>" data-open="<?php if(!empty($element['open']))echo $element['open']; ?>" data-id="<?php echo $element_id?>" data-name="<?php echo $element_name;?>" <?php if(!empty($element_validate))echo $element_validate;?> class="my_new_module_element recaptcha_div <?php if(!empty($element['div_classes'])){$str=implode(" ",$element['div_classes']);echo $str;}?>">
	<div class="recaptcha_div_inner" data-sitekey="<?php echo esc_attr($public_key);?>" data-name="<?php echo $element_name;?>" id="<?php echo $element_id?>"></div>
	<?php 
	/*if(file_exists($element['module_dir'])){
		require_once $element['module_dir'];
	}else {
		trigger_error(__("Module dir class recaptcha not exists","my_support_theme").'-'.$element['module_dir'],E_USER_NOTICE);
	}*/
	//wp_my_recaptcha_show_captcha($public_key,$element_name);
	
	?>
</div>