<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_form_element_outer my_clearfix" data-id="<?php echo $element_id;?>" data-name="<?php echo $element_name;?>">
	<div class="my_form_element_label"><?php echo $title;?><?php if(!empty($element['required'])){?>&nbsp;<span class="my_form_required">*</span><?php }?>
	<?php if(!empty($tooltip)){?>
	<div class="my_help my_tooltip fa fa-info">
		<div class="my_content"><?php echo $tooltip?></div>
	</div>
	<?php }?>
	</div>
	<div class="my_form_element_div">
		<?php if(!empty($element['above_html'])){?>
			<?php echo $element['above_html']?>
		<?php }?>
		<?php echo $my_html;?>
		<?php if(!empty($element['below_html'])){?>
			<?php echo $element['below_html']?>
		<?php }?>
	</div>
	<?php 
	if(!empty($element['below_text'])){
		?>
		<div class="my_form_elemnt_beloe_text">
			<p><?php echo $element['below_text'];?></p>
		</div>
		<?php 
	}
	?>
</div>