<?php
if(!defined('ABSPATH'))die('');
$default='';
if(!empty($element['default'])){
	$default=$element['default'];
}
$value=$default;
if(!empty($element['value'])){
	$value=$element['value'];
}

?>
<div data-default="<?php echo esc_attr($default);?>" data-base-name="<?php echo $key;?>" id="<?php echo $element_id.'_div';?>" data-type="<?php echo $type;?>" data-open="<?php if(!empty($element['open']))echo $element['open']; ?>" data-id="<?php echo $element_id?>" data-name="<?php echo $element_name;?>" <?php if(!empty($element_validate))echo $element_validate;?> class="my_new_module_element my_jscript_stars <?php if(!empty($element['div_classes'])){$str=implode(" ",$element['div_classes']);echo $str;}?>">
	<input type="hidden" id="<?php echo esc_attr($element_id);?>" name="<?php echo esc_attr($element_name);?>" value="<?php if(!empty($element_value))echo esc_attr($element_value)?>"/>
	<?php 
	$i=$element['min'];
	$c=$element['max'];
	?>
	<ul>
	<?php for($f=$i;$f<=$c;$f++){?>
		<li data-i="<?php echo $f;?>">
		<i  class="fa fa-star <?php if($f<=$value)echo 'my_stars_active'?>"></i>
		</li>
	<?php }?>
	</ul>
</div>	