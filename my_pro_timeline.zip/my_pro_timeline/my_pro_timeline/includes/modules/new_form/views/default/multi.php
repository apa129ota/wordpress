<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_multi_element <?php if(!empty($isInline))echo "my_display_inline"?>">
<?php if(!empty($title)){?>
<div class="my_form_element_label"><?php echo $title;?>
<?php }?>
	<?php if(!empty($tooltip)){?>
	<div class="my_help my_tooltip fa fa-info">
		<div class="my_content"><?php echo $tooltip?></div>
	</div>
	<?php }?>
</div>	
	<?php echo $valM?>
</div>	