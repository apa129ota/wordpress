<?php
if(!defined('ABSPATH'))die('');
/**
 * Specific properties
 * open : bottom or top
 * div_classes : array of additional classes
 * ul_classes : array of element classes
 * show_filter: show filter for a combo box
 */
$default='';
?>

<div data-default="<?php echo esc_attr($default); ?>" data-base-name="<?php echo $key;?>" data-value="<?php if(!$element_multiple)echo esc_attr($element_value)?>" id="<?php echo $element_id.'_div';?>" data-type="<?php echo $type;?>" data-open="<?php if(!empty($element['open']))echo $element['open']; ?>" data-id="<?php echo $element_id?>" data-name="<?php echo $element_name;?>" <?php if(!empty($element_validate))echo $element_validate;?> class="my_new_module_element jscript_dropdown_div <?php if(!empty($element['div_classes'])){$str=implode(" ",$element['div_classes']);echo $str;}?>">
<?php if($element_multiple){?>
	<div class="my_dropdown_values">
	<?php if(!empty($element_value)){
		foreach($element_value as $key_new=>$val_new){
			?>
			<input type="hidden" data-name="<?php echo $element_name;?>" name="<?php echo $element_name.'[]';?>" value="<?php echo $val_new?>"/>
			<?php 
		}
	}
	
	?>
	</div>
	<div class="my_btn my_dropdown_multiple_value">
	<?php if(!empty($element_value)){
		foreach($element_value as $key_new=>$val_new){
			$my_val_12=$element['values'][$val_new];
			?>
			<div class="my_dropdow_mulitple_values" data-val="<?php echo $val_new;?>"><?php echo $my_val_12;?><span class="fa fa-close"></span></div>
			<?php 
	}}else {
		?>
		<span class="my_dropdown_empty">
		<?php echo $element['choose_value'];?>
		</span>
		<?php 
	}
	?>
	<span class="fa fa-caret-down my_dropdown_down_span" data-id="<?php echo $element_id?>" data-name="<?php echo $element_name;?>"  id="<?php echo $element_id.'_button';?>" data-toggle="dropdown"></span>	
	</div>
	<ul class="my_dropdown_ul my_dropdown_mulitple_ul <?php  if(!empty($element['ul_classes'])){$str=implode(" ",$element['ul_classes']);echo $str;}?>" data-button-id="<?php echo $element_id."_button"?>" data-id="<?php echo $element_id?>" data-name="<?php echo $element_name;?>">
	<?php if(isset($element['show_filter'])&&$element['show_filter']){?>
		<li class="my_dropdown_filter"><input type="text" value=""/><span class="fa fa-search"></span></li>
	<?php }?>
	<?php if(!empty($element_values)){?>
		<?php foreach($element_values as $k_1=>$v_1){?>
		<li class="<?php if(in_array($k_1, $element_value))echo 'my_dropdown_ul_li_active'?>" data-value="<?php echo esc_attr($k_1)?>"><?php echo $v_1;?></li>
		<?php }?>
	<?php }?>
	
</ul>
<?php }else {?>
<input type="hidden" name="<?php echo $element_name;?>" id="<?php echo $element_id;?>" value="<?php echo $element_value?>"/>
<button data-id="<?php echo $element_id?>" data-name="<?php echo $element_name;?>" class="my_btn my_dropdown <?php if(!empty($element_classes)){$str=implode(" ",$element_classes);echo $str;}?>" type="button" id="<?php echo $element_id.'_button';?>" data-toggle="dropdown">
<span class="my_dropdown_value"><?php echo $element_show_value;?></span>
<span class="fa fa-caret-down"></span>
</button>
<ul class="my_dropdown_ul <?php  if(!empty($element['ul_classes'])){$str=implode(" ",$element['ul_classes']);echo $str;}?>" data-button-id="<?php echo $element_id."_button"?>" data-id="<?php echo $element_id?>" data-name="<?php echo $element_name;?>">
	<?php if(isset($element['show_filter'])&&$element['show_filter']){?>
		<li class="my_dropdown_filter"><input type="text" value=""/><span class="fa fa-search"></span></li>
	<?php }?>
	<?php if(!empty($element_values)){?>
		<?php foreach($element_values as $k_1=>$v_1){?>
		<li class="<?php if($element_value==$k_1)echo 'my_dropdown_ul_li_active'?>" data-value="<?php echo esc_attr($k_1)?>"><?php echo $v_1;?></li>
		<?php }?>
	<?php }?>
	
</ul>
<?php }?>
</div>
