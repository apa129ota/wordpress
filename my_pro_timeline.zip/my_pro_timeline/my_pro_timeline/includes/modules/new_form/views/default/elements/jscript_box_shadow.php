<?php
if(!defined('ABSPATH'))die('');
$backup_element=$element;

if(empty($element['value']))$val1234=$element['default'];
else $val1234=$element['value'];
if(!is_array($val1234)){
    $myNoShadow=true;
}else unset($myNoShadow);
?>
<div data-default="<?php echo esc_attr($default); ?>" data-base-name="<?php echo $key;?>" data-value="<?php if(!$element_multiple)esc_attr($element_value)?>" id="<?php echo $element_id.'_div';?>" data-type="<?php echo 'jscript_box_shadow';?>" data-open="<?php if(!empty($element['open']))echo $element['open']; ?>" data-id="<?php echo $element_id?>" data-name="<?php echo $element_name;?>" <?php if(!empty($element_validate))echo $element_validate;?> class="my_new_module_element jscript_dropdown_div <?php if(!empty($element['div_classes'])){$str=implode(" ",$element['div_classes']);echo $str;}?>">


	<div class="my_box_shadow_hidden">
		<?php if(is_array($val1234)){
	    foreach($val1234 as $kBS=>$vBS){
	     if(is_array($vBS)){
	       foreach($vBS as $kBS1=>$vBS1){
	           ?>
	           <input type="hidden" class="my_hidden_box_shadow_<?php echo esc_attr($element_name.'_'.$kBS1);?>" name="<?php echo esc_attr($element_name.'_'.$kBS1)?>[]" value="<?php echo $vBS1;?>"/>
	   		<?php 
	       }
	     }else {
	   ?>
	   <input type="hidden" name="<?php echo esc_attr($element_name.'_'.$kBS)?>" value="<?php echo $vBS;?>"/>
	   <?php    
	     }
	    }
	}else {
	    ?>
	    <input type="hidden" name="<?php echo esc_attr($element_name).'_no_shadow'?>" value="1"/>
	    <?php 
	    
	}
	?>
	</div>
    
	<div id="my_box_shadow_<?php echo $element_name?>" class="my_box_shadow_css">
		
	</div>
	<div class="my_new_box_shadow_values">
		<span><?php echo __("Preview","my_support_theme")?></span>
		<div></div>
	</div>
		<div class="my_new_box_shadow_added_values">
			<input type="button"  class="my_add_box_shadow_button button button-large" value="<?php echo __("Add new shadow","my_support_theme")?>"/>
		</div>	
			<div class="my_box_shadow_values" style="display:none">
			<ul>
			
			</ul>
			</div>
		
	
	
</div>
