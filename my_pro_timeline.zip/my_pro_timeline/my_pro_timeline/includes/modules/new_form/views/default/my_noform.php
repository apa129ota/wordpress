<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_form_module my_form_module_ul my_clear_after">
<input type="hidden" name="my_form_id" value="<?php echo $id;?>"/>
	<?php if(!empty($hidden_arr)){?>
		<?php foreach($hidden_arr as $key=>$val){?>
		<input type="hidden" name="<?php echo  my_new_form_get_element_name($key,$id);?>" value="<?php echo esc_attr($val)?>"/>
		<?php }?>
	<?php }?>
	<ul>
		<?php echo $element_html;?>
	</ul>
</div>	