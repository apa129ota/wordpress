<?php
if(!defined('ABSPATH'))die('');
//return 'test';
?>
<?php 
$has_thumb=false;
//$thumb=get_post_thumbnail_id($element_value);
if(!empty($element_value)){
	$has_thumb=true;
	$thumb_src=wp_get_attachment_image_src($element_value,'thumbnail');
}
//$has_thumb=false;
?>
<div data-base-name="<?php echo $key;?>" id="<?php echo $element_id.'_div';?>" data-type="<?php echo $type;?>" data-open="<?php if(!empty($element['open']))echo $element['open']; ?>" data-id="<?php echo $element_id?>" data-name="<?php echo $element_name;?>" <?php if(!empty($element_validate))echo $element_validate;?> class="my_new_module_element thumb_div <?php if(!empty($element['div_classes'])){$str=implode(" ",$element['div_classes']);echo $str;}?>">
	<input type="hidden" name="<?php echo esc_attr($element_name)?>" id="<?php echo esc_attr($element_id);?>" value="<?php if($has_thumb)echo esc_attr($element_value)?>"/>
	<div class="my_thumb_val_div">
		<div class="my_thumb_val">
		<?php if($has_thumb){
			?>
			<img src="<?php echo $thumb_src[0];?>"/>
			<?php 	
		}else {?>
		<img src=""/>
		<span><?php echo $element['no_image'];?></span>
		
		<?php }?>
		</div>
		<br/>
		<?php if($element['jscript']['can_remove']){?>	
		<button style="<?php if(!$has_thumb)echo 'display:none;'?>" class="my_btn my_media_button_remove" data-id="<?php echo $element_id;?>" data-name="<?php echo $element_name;?>"><?php echo $element['remove']?></button> 
		<?php }?>
		<button class="my_btn my_media_button" data-id="<?php echo $element_id;?>" data-name="<?php echo $element_name;?>"><?php echo $element['choose_title']?></button> 
	
	</div>
		
</div>