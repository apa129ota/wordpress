<?php
if(!defined('ABSPATH'))die('');
/**
 * Specific properties
 * open : bottom or top
 * div_classes : array of additional classes
 * ul_classes : array of element classes
 * transparency: allow transparency to add to color picker
*/
$transparency=false;
if(isset($element['transparency'])){
	$transparency=$element['transparency'];
}
if($transparency){
	//echo 'Allow transparency';
	$color=$element_value['color'];
	$transp=$element_value['transp'];
	$style='background-color:'.my_new_form_module_rgba_color($color, $transp).';';
	$element_value=$color.','.$transp;
}else {
	//echo 'Color '.$color;
	$color=$element_value;
	$style="background-color:".$color.';';
}
//print_r($element_value);
?>
<div data-base-name="<?php echo $key;?>" data-allow-transp="<?php if($transparency)echo '1';else echo '0';?>" data-color="<?php echo $color?>" data-transp="<?php if($transparency)echo  $transp;?>" id="<?php echo $element_id.'_div';?>" data-type="<?php echo $type;?>" data-open="<?php if(!empty($element['open']))echo $element['open']; ?>" data-id="<?php echo $element_id?>" data-name="<?php echo $element_name;?>" <?php if(!empty($element_validate))echo $element_validate;?> class="my_new_module_element jscript_color_div <?php if(!empty($element['div_classes'])){$str=implode(" ",$element['div_classes']);echo $str;}?>">
	<input type="hidden" name="<?php echo $element_name;?>" id="<?php echo $element_id;?>" value="<?php echo $element_value?>"/>
	<div data-id="<?php echo $element_id;?>" data-name="<?php echo $element_name;?>" class="my_btn my_jscript_color <?php if(!empty($element_classes)){$str=implode(" ",$element_classes);echo $str;}?>" id="<?php echo $element_id.'_button';?>">
		<span class="my_jscript_color_span" style="<?php echo $style;?>">&nbsp;</span>
		<div class="my_jscript_color_span_1" data-open="0">
		<?php if(isset($element['pick_title'])){
			echo $element['pick_title'];
		}?>
		</div>
		<div class="my_color_picker_iris_holder"  data-open="0"></div>
	</div>
	
</div>
