<?php
if(!defined('ABSPATH'))die('');
$value=$element['default'];
if(!empty($element['value'])){
    $value=$element['value'];
}
$is_a=is_array($value);
?>
<div data-base-name="<?php echo $key;?>" id="<?php echo $element_id.'_div';?>" data-type="<?php echo $type;?>" data-open="<?php if(!empty($element['open']))echo $element['open']; ?>" data-id="<?php echo $element_id?>" data-name="<?php echo $element_name;?>" <?php if(!empty($element_validate))echo $element_validate;?> class="my_new_module_element text_div <?php if(!empty($element['div_classes'])){$str=implode(" ",$element['div_classes']);echo $str;}?>">
	<select id="<?php echo esc_attr($element_id);?>" name="<?php echo esc_attr($element_name);?>" <?php if(!empty($element['mulitple']))echo "multiple"?>>
		<?php foreach($element['values'] as $key_new=>$val_new){?>
		<?php 
		$checked=false;
		if($is_a){
		if(in_array($key_new, $value))$checked=true;
		}else {
		    if($key_new==$value)$checked=true;
		}
		?>
		<option value="<?php echo esc_attr($key_new)?>" <?php if($checked)echo 'selected="selected"'?>><?php echo $val_new?></option>
		<?php }?>
	</select>
</div>	