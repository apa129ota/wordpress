<?php
if(!defined('ABSPATH'))die('');
//print_r($my_parent_element);

if(isset($my_jscript_border)){
    require $my_templ_dir.'jscript_border.php';
}else if(isset($my_jscript_box_shadow)){
    require $my_templ_dir.'jscript_box_shadow.php';
    
}
else {
?>

<div style="<?php echo my_new_form_render_css($element);?>" <?php my_new_form_render_jscript_data($element)?> class="<?php /*my_form_element_outer*/ ?> <?php echo 'my_form_element_display_inline'; echo ' my_form_element_inline_'.$element_name?> <?php if(!empty($element['outer_classes'])){if(is_array($element['outer_classes']))implode(" ",$element['outer_classes']);else echo $element['outer_classes'];}?> <?php if(isset($element['layout_class']))echo $element['layout_class']; if(!empty($my_clear))echo ' my_clear_after';?>" data-id="<?php echo $element_id;?>" data-type="<?php echo esc_attr($element['type'])?>" data-name="<?php echo $element_name;?>">
	<?php if(isset($element['title'])){?>
		<h4 class="my_multiple_title"><?php echo $element['title'];?>
			<?php if(isset($element['tooltip'])){?>
			
			<div class="my_help my_tooltip fa fa-info">
				<div class="my_content"><?php echo $element['tooltip'];?></div>
			</div>
			<?php }?>
		</h4>
	<?php }?>
	<div class="my_form_element_div" data-name="<?php echo esc_attr($element_name)?>"><?php echo $my_html;?></div>
	<div class="my_clear"></div>
</div>
<?php }?>
