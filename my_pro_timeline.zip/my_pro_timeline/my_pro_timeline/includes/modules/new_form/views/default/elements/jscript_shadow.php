<?php
if(!defined('ABSPATH'))die('');

$backup_element=$element;
$my_check_values=array('h-shadow','v-shadow','blur','spread','color');
$myValues=$element['values'];


foreach($my_check_values as $k12=>$v12){
    unset($$v12);
    if(!empty($element['value'][$v12])){
        $$v12=$element['value'][$v12];
    }else $$v12='';
}
if(!empty($element['value']['border'])){
    foreach($my_check_border as $k12=>$v12){
        if(!isset($$v12))
            $$v12=$element['value']['border'];
    }
}
?>
<div data-default="<?php echo esc_attr($default); ?>" data-base-name="<?php echo $key;?>" data-value="<?php if(!$element_multiple)esc_attr($element_value)?>" id="<?php echo $element_id.'_div';?>" data-type="<?php echo 'jscript_border';?>" data-open="<?php if(!empty($element['open']))echo $element['open']; ?>" data-id="<?php echo $element_id?>" data-name="<?php echo $element_name;?>" <?php if(!empty($element_validate))echo $element_validate;?> class="my_new_module_element jscript_dropdown_div <?php if(!empty($element['div_classes'])){$str=implode(" ",$element['div_classes']);echo $str;}?>">


	<?php foreach($my_check_border as $k12=>$v12){ 
	   ?>
	   <input type="hidden" name="<?php echo esc_attr($element_name.'_'.$v12)?>[]" value="<?php if(isset($$v12))echo esc_attr($$v12)?>"/>
	   <?php    
	}
	?>
