<?php
if(!defined('ABSPATH'))die('');
?>
<div id="my_form_msgs_<?php echo $id;?>"></div>
<form id="my_form_<?php echo $id;?>" class="my_form_module" action="<?php echo $action;?>" <?php if($upload){echo 'enctype="multipart/form-data"';}?>>
	<input type="hidden" name="my_form_id" value="<?php echo $id;?>"/>
	<?php if(!empty($hidden_arr)){?>
		<?php foreach($hidden_arr as $key=>$val){?>
		<input type="hidden" name="<?php echo  my_new_form_get_element_name($key,$id);?>" value="<?php echo esc_attr($val)?>"/>
		<?php }?>
	<?php }?>	
			<?php echo $element_html;?>
</form>