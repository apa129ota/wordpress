<?php
if(!defined('ABSPATH'))die('');
?>
<div data-base-name="<?php echo $key;?>" id="<?php echo $element_id.'_div';?>" data-type="<?php echo $type;?>" data-open="<?php if(!empty($element['open']))echo $element['open']; ?>" data-id="<?php echo $element_id?>" data-name="<?php echo $element_name;?>" <?php if(!empty($element_validate))echo $element_validate;?> class="my_new_module_element  <?php if(!empty($element['div_classes'])){$str=implode(" ",$element['div_classes']);echo $str;}?>">
	<input type="password" id="<?php echo esc_attr($element_id);?>" name="<?php echo esc_attr($element_name);?>" value="<?php if(!empty($element_value))echo esc_attr($element_value)?>"/>
</div>	