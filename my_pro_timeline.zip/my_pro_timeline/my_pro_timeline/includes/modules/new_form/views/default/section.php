<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_form_section" data-key="<?php echo esc_attr($key1)?>" id="my_form_section_<?php echo esc_attr($key1) ?>" 
data-open="<?php if($open)echo 1;else echo 0;?>">
	<div class="my_form_section_header">
		<h4><i class="fa fa-plus" <?php if($open)echo 'style="display:none"'?>></i><i class="fa fa-minus" <?php if(!$open)echo 'style="display:none"'?>></i>&nbsp;&nbsp;<?php echo $title;?></h4>
		<?php if(!empty($tooltip)){?>
			<div class="my_help my_tooltip fa fa-info">
		<div class="my_content"><?php echo $tooltip?></div>
		</div>
		<?php }?>
	</div>
	<div class="my_form_section_inner" style="<?php if(!$open)echo 'display:none;'?>">
	<ul>
		<?php echo $element_html;?>
	</ul>
	</div>
</div>