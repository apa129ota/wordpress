<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_Wp_My_Module_New_Form_Validate')){
	class Class_Wp_My_Module_New_Form_Validate{
		use MyArrayOptions,MyDebug;
		private $use_case='my_framework';
		private $debug;
		private $msgs;
		private $elements;
		private $data;
		function Class_Wp_My_Module_New_Form_Validate($options=array()){
			/*if(!empty($options)){
				foreach($options as $key=>$val){
					$this->$key=$val;
				}
			}*/
			$this->setOptions($options);
			if($this->debug){
				$this->setDebugOptions($this->use_case);
			}
			
		}
		function validate(){
			/*global $wp_my_related_posts_debug;
			global $wp_my_related_posts_debug_data;
			if($wp_my_related_posts_debug){
				$wp_my_related_posts_debug_data['form_elements']=$this->elements;
			}*/
			$my_form_id=$this->data['my_form_id'];
			$ret['errors']=array();
			$ret['error']=0;
			$ret['form_has_errors']=$this->msgs['form_has_errors'];
			$error=false;
			foreach($this->elements as $key=>$val){
				$has_error=false;
				$value='';
				$name=$key.'_'.$my_form_id;
				$id=$key.'_'.$my_form_id.'_id';
				if(($val['type']=='button')||($val['type']=='submit'))continue;
				if(isset($this->data[$name])){
					$value=$this->data[$name];
				}
				//self::debug('validate_element', array('key'=>$key,'name'=>$name,'value'=>$value,'validate'=>$val['validate']));
				/*if($wp_my_related_posts_debug){
					$wp_my_related_posts_debug_data['data'][$name]=$value;
				}*/
				if(isset($val['multiple']))
				$multiple=$val['multiple'];
				else $multiple=false;
				/**
				 * Check for defined 
				 */
				if(in_array($val['type'],array('jscript_checkbox_list','radio_list','select','checkbox_list','jscript_dropdown','jscript_radio_list'))){
					if(!empty($value)){
					
					if($multiple){
						foreach($value as $key1=>$val1){
							if(!array_key_exists($val1, $val['values'])){
								
								$error=true;
								$has_error=true;
								$ret['errors'][$name]=array('msg'=>$this->msgs['error'],'id'=>$id);
								break;
								
							}	
						}
					}else {
						
						if(!array_key_exists($value, $val['values'])){
							$error=true;
							$has_error=true;
							$ret['errors'][$name]=array('msg'=>$this->msgs['error'],'id'=>$id);
							
							break;
						
						}
					}
					}
				}
				if(!$has_error){
					if(!empty($val['validate'])){
						foreach($val['validate'] as $key1=>$val1){
							switch ($key1){
								case 'email':
									if(!empty($value)){
										if(!is_email($value)){
											$error=true;
											$has_error=true;
											$ret['errors'][$name]=array('msg'=>$this->msgs[$key1],'id'=>$id);
											self::debug("error_element_".$name, $ret['errors'][$name],false);
												
										}
									}
								break;	
								case 'required':
									if(isset($val1['empty'])&&$val1['empty']){
										if(empty($value)){
											$error=true;
											$has_error=true;
											$ret['errors'][$name]=array('msg'=>$this->msgs[$key1],'id'=>$id);
											self::debug("error_element_".$name, $ret['errors'][$name],false);
											
										}
									}else {
									if($multiple){
										if(empty($value)){
											$error=true;
											$has_error=true;
											$ret['errors'][$name]=array('msg'=>$this->msgs[$key1],'id'=>$id);
											//break;
											self::debug("error_element_".$name, $ret['errors'][$name],false);
												
										}
									}
									else if(empty($value)&&!preg_match('/^0$/ims', $value)){
										$error=true;
										$has_error=true;
										$ret['errors'][$name]=array('msg'=>$this->msgs[$key1],'id'=>$id);
										//break;	
										self::debug("error_element_".$name, $ret['errors'][$name],false);
											
									}
									}
									break;
								case 'min_value':
									if($value<$val1){
										$error=true;
										$has_error=true;
										$msg=str_replace('{min_value}', $val1, $msg);
										
										$ret['errors'][$name]=array('msg'=>$msg,'id'=>$id);
										self::debug("error_element_".$name, $ret['errors'][$name],false);
											
									}
								break;			
								case 'max_value':
									if($value>$val1){
										$error=true;
										$has_error=true;
										$msg=$this->msgs[$key1];
										$msg=str_replace('{max_value}', $val1, $msg);
										$ret['errors'][$name]=array('msg'=>$msg,'id'=>$id);
										self::debug("error_element_".$name, $ret['errors'][$name],false);
											
									}
									break;
									case 'max_length':
										if(strlen($value)>$val1){
											$error=true;
											$has_error=true;
											$msg=$this->msgs[$key1];
											$msg=str_replace('{max_length}', $val1, $msg);
											
											$ret['errors'][$name]=array('msg'=>$msg,'id'=>$id);
											self::debug("error_element_".$name, $ret['errors'][$name],false);
												
										}
										break;
							}
						}
					}
				}
			}
			if(!$error)return true;
			else return $ret; 
		}		
	}
}