<?php
if(!defined('ABSPATH'))die('');
if(!class_exists("Class_My_General_Element")){
	class Class_My_General_Element{
		protected $name;
		protected $type;
		protected $element_id;
		protected $element_div_id;
		protected $has_jscript=false;
		protected $layout;
		protected $title;
		protected $tooltip='';
		protected $jscript_options=array();
	}
}