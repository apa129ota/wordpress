<?php
if(!defined('ABSPATH'))die('');
global $my_new_form_layout_class_widths;

$my_new_form_layout_class_widths=array(
		'my_col_100'=>100,
		
		'my_col_33'=>33.3333333333,
		'my_col_50'=>50,
		'my_col_25'=>25,
		'my_col_75'=>75,
		'my_col_16'=>16.6666667
		
);
function my_new_form_render_css($element){
		$css='';
	if(!empty($element['css'])){
		foreach($element['css'] as $key=>$val){
			$css.=$val;
		}
	}
	return $css;
}
function my_new_form_footer(){
	$p=Class_Wp_My_Module_New_Form::$color_pickers;
	if(class_exists('Class_My_Module_Debug'))
	Class_My_Module_Debug::add_section('color_pickers', $p,'new_form_functions',false);
	if(!empty($p)){
	foreach($p as $key=>$val){
		?>
					<div id="<?php echo $key;?>" class="my_color_picker_iris_holder"  data-open="0">
					</div>
					<?php 
				}
	}
}
/**
 * Populate form values by values
 * @param unknown $elements
 * @param unknown $values
 */
function my_new_form_populate_form_values(&$form,$values){
	$elements=array();
	if(isset($form['elements'])){
		$elements=$form['elements'];
	}
	//echo 'Populate form elements ';
	//print_r($elements);
	if(!empty($elements)){
		foreach($elements as $key=>$val){
			if($val['type']=='jscript_color_picker'&&isset($val['transparency'])&&$val['transparency']){
				$arr=explode(",",$values[$key]);
				$form['elements'][$key]['value']=array(
					'color'=>$arr[0],
					'transp'=>$arr[1]	
				);	
			}else {
			if(isset($values[$key])){
				//echo 'Populate value '.$key.' val '.print_r($values[$key],true).'<br/>';
				$val=$values[$key];
				$form['elements'][$key]['value']=$val;
			}else{
				//echo 'Unset value '.$key.' val '.print_r($values[$key],true).'<br/>';
				if($val['type']=='on_off'){
					$form['elements'][$key]['value']=0;
				}
				else unset($form['elements'][$key]['value']);
			}
			}
		}
	}
	$hidden_arr=array();
	if(!empty($form['hidden'])){
		foreach($form['hidden'] as $key=>$val){
			if(isset($values[$key])){
				$val=$values[$key];
				$form['hidden'][$key]=$val;
			}else{
				$form['hidden'][$key]='';
			}
		}
	}
}
/**
 * Get elemwent name 
 * @param unknown $name
 * @param unknown $form_id
 * @return string
 */
function my_new_form_get_element_name($name,$form_id){
	$name=my_new_form_module_clean_key($name);
	$element_name=$name.'_'.$form_id;
	return $element_name;
}

/**
 * Cleand form id from data19b
 * @param unknown $data
 * @param unknown $elements
 * @return multitype:unknown
 */
function my_new_form_clean_data(&$data,$elements,$hidden=array()){
	$form_id=$data['my_form_id'];
	$arr=array();
	foreach($elements as $key=>$val){
		if($val['type']=='button')continue;
		
		$name=my_new_form_module_clean_key($key);
		$element_name=$name.'_'.$form_id;
		if(isset($data[$element_name])){
			$arr[$key]=$data[$element_name];
		}else {
			if($val['type']=='on_off'){
				$arr[$key]=0;
			}
		}
	}
	if(!empty($hidden)){
		foreach ($hidden as $key=>$val){
			$name=my_new_form_module_clean_key($val);
			$element_name=$name.'_'.$form_id;
			if(isset($data[$element_name])){
				$arr[$val]=$data[$element_name];
			}
		}
	}
	
	//print_r($arr);
	return $arr;
}
function my_new_form_get_base_name($elemnt_name){
	//return preg_replace('/\_[\d]+/ims', '', $subject);
}
function my_new_form_module_clean_key($key){
		$key=preg_replace('/[\s]+/', '_', $key);
		return $key;
}
function my_new_form_render_jscript_data($element){
	if(!empty($element['jscript'])){
		foreach ($element['jscript'] as $key=>$val){
			if(is_string($val)){
			$name='data-jscript-'.my_new_form_module_clean_key($key);
			echo ' '.$name.'="'.esc_attr($val).'" ';
			}
		}
	}
}
function my_new_form_render_el_data($data){
	if(!empty($data)){
		foreach ($data as $key=>$val){
			$name='data-'.my_new_form_module_clean_key($key);
			echo ' '.$name.'="'.esc_attr($val).'" ';
		}
	}
}
function my_new_form_render_hidden($hidden_arr=array(),$id){
	//print_r($hidden_arr);
	if(!empty($hidden_arr)){
			foreach($hidden_arr as $key=>$val){
			?>
				<input type="hidden" name="<?php echo  my_new_form_get_element_name($key,$id);?>" value="<?php echo esc_attr($val)?>"/>
			<?php }	
		}
} 
/**
 * Render form elements
 * @param unknown $form_id
 * @param unknown $elements
 * @param unknown $hidden_arr
 * @param string $skin
 * @param string $template
 * @param string $el_templ
 * @return string
 */
function my_new_form_module_render_form_element_layout($form_id,$elements,$hidden_arr,$skin='default',$template="my_form.php",$el_templ='my_li.php'){
	$dir=plugin_dir_path(__FILE__);
	//echo 'Plugin dir path '.$dir;
	$views_dir=realpath($dir.'../views/');
	//echo 'Views dirname '.$views_dir;
	if(!empty($elements)){
		
		foreach($elements as $key=>$element){
		$type=$element['type'];
		$element_classes=array();
		if(!empty($element['classes'])){
			$element_classes=$element['classes'];
		}
		$element_values=array();
		if(!empty($element['values'])){
			$element_values=$element['values'];
		}
		if(!isset($element['multiple']))$element_multiple=false;
		else $element_multiple=$element['multiple'];
		if($element_multiple){
			$element_value=array();
			if(isset($element['value'])){
				$element_value=$element['value'];
			}else if(isset($element['default'])){
				$element_value=$element['default'];
			}
		}
		else {
			$element_value='';
			if(isset($element['value'])){
				$element_value=$element['value'];
			}else if(isset($element['default'])){
				$element_value=$element['default'];
			}
		}
		$name=my_new_form_module_clean_key($key);
		$element_name=$name.'_'.$form_id;
		$element_id=$name.'_'.$form_id.'_id';
		
		$element_file=$views_dir.'/'.$skin.'/elements/'.$type.'.php';///dirname("../views/".$skin.'/elements/'.$type.'.php');
		//echo $element_file;
		ob_start();
		//echo $element_file;
		require $element_file;
		$html=ob_get_clean();
		$elements[$key]['render_html']=$html;
		$elements[$key]['name']=$element_name;
		$elements[$key]['id']=$element_id;
	}
	}
	$templ=$views_dir.'/'.$skin.'/'.$el_templ;
	//$templ="../views/".$skin.'/'.$el_templ;
	//$templ=$this->dir.'views/'.$this->skin.'/'.$this->element_template;
	$element_html='';
	$my_clear=false;
	$w=0;
	global $my_new_form_layout_class_widths;
	if(!empty($elements)){
		foreach($elements as $key=>$val){
			$element=$val;
			$my_html=$val['render_html'];
			$my_layout_class=$val['layout_class'];
			$w+=$my_new_form_layout_class_widths[$my_layout_class];
			$diff=100-$w;
			//echo 'w='.$w.',diff='.$diff.'<br/>';
			if($diff<1){
				//$my_clear=true;
				$w=0;
			}
			unset($title);
			unset($tooltip);
			$title=$val['title'];
			if(isset($val['tooltip']))
				$tooltip=$val['tooltip'];
			$element_name=$elements[$key]['name'];
			$element_id=$elements[$key]['id'];
			ob_start();
			require $templ;
			//echo $templ;	
			$element_html.=ob_get_clean();//$val['render_html'];
			$my_clear=false;			
		}
		
	}
	//$html=ob_get_clean();
	return $element_html;
	
}
/**
 * Convert color transp to rgba color
 * @param unknown $color
 * @param unknown $tr
 * @return string
 */
function my_new_form_module_rgba_color($color,$tr){
	$color_rgba='rgba(';
	if(strpos($color,"#")===0)
		$col=substr($color,1);
	else $col=$color;
	if((strlen($col)!=6)||(strlen($col)!=3)){
		if(strlen($col)>3){
			$start=strlen($col);
			for($i=$start;$i<6;$i++)$col.='0';
		}else if(strlen($col)<3){
			$start=strlen($col);
			for($i=$start;$i<3;$i++)$col.='0';
		}
	}
	if(strlen($col)==6){
		list($r,$g,$b)=array(
				$col[0].$col[1],
				$col[2].$col[3],
				$col[4].$col[5]
		);

	}else if(strlen($col)==3){
		list($r,$g,$b)=array(
				$col[0].$col[0],
				$col[1].$col[1],
				$col[2].$col[2]
		);
	}
	$r_dec=hexdec($r);
	$g_dec=hexdec($g);
	$b_dec=hexdec($b);
	$color_rgba.=$r_dec.','.$g_dec.','.$b_dec.','.$tr.')';
	return $color_rgba;


}
