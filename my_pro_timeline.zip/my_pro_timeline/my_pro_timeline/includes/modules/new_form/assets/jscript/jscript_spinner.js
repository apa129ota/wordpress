(function($) {
	wpMyModuleNewFormSpinner=function(o){
		var self;
		this.debug=true;
		this.options={};
		this.id='';
		this.name='';
		this.div_id='';
		this.my_working=false;
		this.multiple=false;
		this.has_unit=false;
		this.value='';
		this.unit='';
		this.units={};
		self=this;
		this.init=function(o){
			if(typeof o.my_debug!='undefined'){
				if(!o.my_debug){
					self.debug=false;
				}
			}
			self.my_debug("Options",o);
			self.options=o;
			self.id=self.options.id;
			self.name=self.options.name;
			self.div_id=self.options.div_id;
			if($("#"+self.div_id+" select").length>0){
				self.my_debug('Has units');
				self.has_unit=true;
				self.unit=$("#"+self.div_id+" select option:selected").val();
				self.my_debug("Unit",self.unit);
				//$("#"+self.div_id+" select").change(self.change_unit);
				$("#"+self.div_id+" select option").each(function(i,v){
					var val=$(v).val();
					var text=$(v).text();
					self.units[val]=text;
				});
				self.my_debug('Units',self.units);
				$("#"+self.div_id+" select").change(function(e){
					
					self.unit=$("#"+self.div_id+" select").val();
					self.my_debug("Change unit",self.unit);
					self.trigger_change();
				});
			}
			self.value=$("#"+self.div_id+" input[type='text']").val();
			$("#"+self.div_id+" input[type='text']").spinner({
				step:self.options.step,
				min:self.options.min,
				change: function( event, ui ) {
					self.value=$(this).attr('value');//$("#"+self.div_id+" input[type='text']").spinner( "value" );
					
					//self.value=$("#"+self.div_id+" input[type='text']").val();
					self.my_debug("change spinner vaklue",self.value);
					self.trigger_change();
				}
				
			});
			$("#"+self.div_id).data('my-script',this);
		};
		this.get_value=function(){
			var value=self.value;
			if(self.has_unit){
				value+=self.unit;
			}
			return value;
		}
		this.set_value=function(val){
			//if(typeof val=='undefined')val='0px';
			self.my_debug("spinner set value",val);
			if(self.has_unit){
				$.each(self.units,function(i,v){
					if(val.indexOf(i)!==-1){
						self.unit=i;
						self.value=val.replace(i,'');
						$("#"+self.div_id+" select").val(i);
					}
					
				});
			}else
				{
				self.value=val;
				}
			$("#"+self.div_id+" input[type='text']").val(self.value);
			
			self.trigger_change();
		}
		this.change_unit=function(e){
			self.my_debug("Change unit",self.unit);
			self.unit=$("#"+self.div_id+" select option:selected").val();
			self.trigger_change();
			
		};
		this.trigger_change=function(){
			var value=self.value;
			if(self.has_unit){
				value+=self.unit;
			}
			var obj=[self,value,$("#"+self.div_id).data('base-name')];
			self.my_debug("Change jscript color list",obj);
			$("#"+self.div_id).trigger('my_change',obj);
		};
		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log("***ModuleFormMainSCript *** \n"+t,o);
				}
			}
		};
	this.init(o);
	
};
})(jQuery);	
	