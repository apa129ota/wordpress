(function($) {
	wpMyModuleNewFormValidate=function(o){
		var self;
		this.debug=true;
		this.element_div='my_form_element_div';
		this.element_class='my_form_element';
		this.element_error_class='my_element_error';
		this.element_error_div_class='my_form_element_error';
		this.element_error_div='<div class="my_form_element_error"><span class="fa fa-exclamation"></span>&nbsp;&nbsp;<span class="my_error_msg">{msg}</span></div>';
		this.errors={};
		self=this;
		this.init=function(o){
			if(typeof o.my_debug!='undefined'){
				if(!o.my_debug){
					self.debug=false;
				}
			}
			self.options=0;
			
		};
		this.change1=function(e){
			var name=$(this).attr('name');
			var form_id=$(this).parents('form').attr('id');
			self.my_debug('Change',{name:name,form_id:form_id});
			if(val!=''){
				self.remove_error(form_id,name);
				
			}
		};
		this.change=function(e){
			var val=$(this).val();
			var name=$(this).attr('name');
			var form_id=$(this).parents('form').attr('id');
			self.my_debug('Change',{name:name,form_id:form_id});
			if(val!=''){
				self.remove_error(form_id,name);
				
			}
			
		};
		this.show_errors=function(form_id,errors){
			if(typeof errors!='undefined'){
				$.each(errors,function(i,v){
					var element_id=i;
					var msg=v.msg;
					var id=v.id;
					self.show_error(form_id,element_id,msg,id);
				});
			}
		};
		this.show_error=function(form_id,element_id,msg,id){
			var my_focus=false;
			if(typeof self.errors[$form_id]=='undefined'){
				self.errors[form_id]={};
				my_focus=true;
			}
			self.errors[form_id].element_id=element_id;
			self.errors[form_id].id=id;
			var $el=$("#"+form_id+" #"+id);
			var type=$el.attr('id');
			var div_id=element_id+"_div_id";
			self.my_debug('Attr type',id);
			//if(typeof type=='undefined'){
				type=$el.parents(".my_form_element_outer").data('type');
			//}
			self.my_debug('Attr type',type);
			if(typeof type !='undefined'){
				
				if((type=='text') || (type=='date') || (type=='thumb') || type=='tiny_mce'){
					$el.unbind('change',self.change);
					$el.change(self.change);
					/*if(my_focus){
						
						$el.focus();
					}*/
				}else {
					$("#"+div_id).unbind('change',self.change1);
					$("#"+div_id).on('my_change',self.change1);
				}
			}
			self.my_debug('Show error',{form_id:form_id,element_id:element_id,msg:msg});
			//var $el=$("#"+form_id+" ."+self.element_class+"[data-name='"+element_id+"']");
			//$el.addClass(self.element_error_class);
			html=self.element_error_div;
			html=html.replace(/{msg}/g,msg);
			//$("#"+form_id+" ."+self.element_div+"[data-name='"+element_id+"']").parents('li').addClass(self.element_error_class);
			$("#"+form_id+" ."+self.element_div+"[data-name='"+element_id+"']").after(html);
			
		};
		this.remove_error=function(form_id,element_id){
			//self.my_debug('Remove error',form_id,element_id);
			//var $el=$("#"+form_id+" ."+self.element_class+"[data-name='"+element_id+"']");
			//$el.removeClass(self.element_error_class);
			//$el.parents('.'+self.element_div).remove(self.element_error_div_class);
			$("#"+form_id+" ."+self.element_div+"[data-name='"+element_id+"']").parents('li').removeClass('self.element_error_class');
			$("#"+form_id+" ."+self.element_div+"[data-name='"+element_id+"']").parents('li').find("."+self.element_error_div_class).remove();
			
		};
		this.remove_all_errors=function(form_id){
			self.my_debug('Remove all errors');
			$("#"+form_id+" ."+self.element_div).parents('li').removeClass('self.element_error_class');
			$("#"+form_id+" ."+self.element_error_div_class).remove();
			
			//$("#"+form_id+" ."+self.element_class).removeClass(self.element_error_class);
			//$("#"+form_id+" ."+self.element_error_div_class).remove();
		};
		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log("***ModuleFormValidate *** \n"+t,o);
				}
			}
		};
	this.init(o);
	}
})(jQuery);