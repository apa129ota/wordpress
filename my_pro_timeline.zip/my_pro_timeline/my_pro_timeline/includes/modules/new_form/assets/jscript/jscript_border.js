/**
 * Jscript border
 */
(function($) {
	wpMyModuleNewFormBorder=function(o){
		var self;
		this.debug=true;
		this.options={};
		this.id='';
		this.name='';
		this.div_id='';
		this.my_working=false;
		this.multiple=false;
		this.has_unit=false;
		this.value='';
		this.unit='';
		this.units={};
		this.preview_css_sel='';
		this.setBorderSelect={top:1,left:1,right:1,bottom:1};
		this.setBorderRadiusSelect={top_left:0,top_right:0,bottom_right:0,bottom_left:0};
		this.check={};
		this.checkRadius={};
		this.values={};
		this.cssBorderValues={top:"",left:"",right:"",bottom:""};
		this.cssBorderRadiusValues={top_left:"",top_right:"",bottom_left:"",bottom_right:""};
		this.radiusValues={};
		this.sameRadiusValue=true;
		this.borderRadiusCss="";
		this.baseName="";
		this.borderNames=["border_width","border_color","border_type"];
		this.borderSelectName="";
		this.borderSelect;
		this.borderRadius1Name;
		this.borderRadius2Name;
		this.borderRadius1Obj;
		this.borderRadius2Obj;
		this.borderRadiusCheckName;
		this.borderRadiusCheckObj;
		this.myDisableChange=false;
		self=this;
		
		this.init=function(o){
			if(typeof o.my_debug!='undefined'){
				if(!o.my_debug){
					self.debug=false;
				}
			}
			self.debug=true;
			self.my_debug("Border Options",o);
			self.options=o;
			self.id=self.options.id;
			self.name=self.options.name;
			self.div_id=self.options.div_id;
			self.baseName=$("#"+self.div_id).attr('data-base-name');
			self.borderSelectName=self.baseName+"_border_select";
			self.borderSelectRadiusName=self.baseName+"_border_radius_select";
			self.borderRadius1Name=self.baseName+"_border_radius_1";
			self.borderRadius2Name=self.baseName+"_border_radius_2";
			self.borderRadiusCheckName=self.baseName+"_border_bottom_same_value";
			$.each(self.borderNames,function(i,v){
				var str=self.baseName+"_"+v;
				self.borderNames[i]=str;
			});
			self.preview_css_sel="#"+self.div_id+" .my_new_border_values div";
			self.get_values();
			self.my_debug("Border Values",self.values);
			self.borderSelect=$("#"+self.div_id).siblings(".my_form_element_display_inline").find("div[data-base-name='"+self.borderSelectName+"']").find('select');
			self.borderRadiusSelect=$("#"+self.div_id).siblings(".my_form_element_display_inline").find("div[data-base-name='"+self.borderSelectRadiusName+"']").find('select');
			self.borderRadius1Obj=$("#"+self.div_id).siblings(".my_form_element_display_inline").find("div[data-base-name='"+self.borderRadius1Name+"']");
			self.borderRadius2Obj=$("#"+self.div_id).siblings(".my_form_element_display_inline").find("div[data-base-name='"+self.borderRadius2Name+"']");
			self.borderRadiusCheckObj=$("#"+self.div_id).siblings(".my_form_element_display_inline").find("div[data-base-name='"+self.borderRadiusCheckName+"']").find("[type='checkbox']");
			/**
			 * Same top bottom radius
			 * 
			 */
			$(self.borderRadiusCheckObj).on("change",function(e){
				var is=$(this).is(":checked");
				self.my_debug("Border Cahnge sam evalue",is);
				if(is){
					$(self.borderRadius2Obj).parents(".my_form_element_display_inline").hide();
					self.get_el_border_values(true);
				}else {
					$(self.borderRadius2Obj).parents(".my_form_element_display_inline").show();
					self.get_el_border_values(true);
				}
			});
			$(self.borderRadius1Obj).on("my_change",function(e,obj,val,v1){
				self.get_el_border_values(true);
			});
			$(self.borderRadius2Obj).on("my_change",function(e,obj,val,v1){
				self.get_el_border_values(true);
				
			});
			
			/**
			 * select box to set border radius
			 * all top left etc..
			 * borderRadiusSelect[i]
			 */
			$(self.borderRadiusSelect).on('change',function(e){
				self.myDisableChange=true;
				var val=$(this).val();
				self.my_debug("Border Set value border radius select",val);
				$.each(self.setBorderRadiusSelect,function(i,v){
					self.setBorderRadiusSelect[i]=0;
				});
				if(val=='all'){
					$.each(self.setBorderRadiusSelect,function(i,v){
						self.setBorderRadiusSelect[i]=1;
					})
					
				}else {
					self.setBorderRadiusSelect[val]=1;
					self.setBorderRadiusValue(val);
				}
				self.myDisableChange=false;
				self.my_debug("Border set border radius select",self.setBorderRadiusSelect);
			});
			/**
			 * Check box for radius select checnoboxes
			 */
			$(self.borderSelect).on("change",function(e){
				self.myDisableChange=true;
				var val=$(this).val();
				self.my_debug("Border Set value border select",val);
				$.each(self.setBorderSelect,function(i,v){
					self.setBorderSelect[i]=0;
				});
				if(val=='all'){
					$.each(self.setBorderSelect,function(i,v){
						self.setBorderSelect[i]=1;
					})
					
				}else {
					self.setBorderSelect[val]=1;
					self.setBorderValues(val);
				}
				self.myDisableChange=false;
				self.get_el_border_values(true);
				self.my_debug("Border set border select",self.setBorderSelect);
			});
			/**
			 * Check to enable border radius on one 
			 * of corners
			 */
			$("#"+self.div_id+" .my_border_radius_check").change(function(e){
				var key=$(this).data('key');
				self.my_debug("Border Change check radius",key);
				var name=self.name+'_'+$(this).data('key');
				if($(this).is(":checked")){
					self.setBorderRadiusSelect[key]=1;
				}else {
					self.setBorderRadiusSelect[key]=0;
					
				}
				//var css=
					self.get_el_border_values(false,key);
				//self.trigger_change();
			});
			/**
			 * Check to enable border radius
			 * if its set then adjust value else do nothing
			 */
			$("#"+self.div_id+" .my_border_check").change(function(e){
				var key=$(this).data('key');
				self.my_debug("Border Change check",key);
				var name=self.name+'_'+$(this).data('key');
				var css="";
				if($(this).is(":checked")){
					//var css=self.get_el_values();
					if(self.setBorderSelect[key]){
						css=self.get_el_values(false);
						$('input[type="hidden"][name="'+name+'"]').val(css);
						self.cssBorderValues[key]=css;
					}
				}else {
					$('input[type="hidden"][name="'+name+'"]').val('');
					self.cssBorderValues[key]='';
				}
				self.get_values();
				self.trigger_change();
			});
			$("#"+self.div_id).siblings(".my_form_element_display_inline").find(".my_new_module_element ").each(function(i,v){
				var n=$(v).data('base-name');
				//var v=$(v).data('my-script').get_value();
			//	self.my_debug("Get value",{n:n,v:v});
				if(n.indexOf("border_radius_1")!=-1 || n.indexOf("border_radius_2")!=-1 || n.indexOf("border_bottom_same_value")!=-1){
					
				}else {
				 if(n.indexOf('border_type')!=-1){
					$(v).find("select").on('change',function(e){
						if(self.myDisbaleChange)return;
						var css=self.get_el_values();
						self.my_debug('Border css',css);
						$("#"+self.div_id+" .my_border_check").each(function(i,v){
							var key=$(v).data('key');
							var name=self.name+'_'+$(v).data('key');
							self.my_debug("Border Set values",{key:key,name:name});
							
							if($(v).is(':checked')){
								if(self.setBorderSelect[key]){
									$('input[type="hidden"][name="'+name+'"]').val(css);
									self.cssBorderValues[key]=css;
								}
							}else {
								$('input[type="hidden"][name="'+name+'"]').val('');
							}
						});
						self.get_values();
						self.trigger_change();
					});
				 }
				 else $(v).on('my_change',self.my_change);
				}
			});
			$("#"+self.div_id).data('my-script',this);
		};
		this.getBorderRadiusCss=function(){
			self.my_debug("Border Css border radius",self.borderRadiusCss);
			return self.borderRadiusCss;
		};
		/**
		 * Get border values
		 */
		this.getBorderValues=function(){
			var values={};
			$.each(self.borderNames,function(i,v){
				var val="";
				var key="";
				var $obj=$("#"+self.div_id).siblings(".my_form_element_display_inline").find("div[data-base-name='"+v+"']");
				self.my_debug("obj",$obj);
				if(v.indexOf("border_type")!=-1){
					key="type";
				}else if(v.indexOf("border_color")!=-1)key="color";
				else key="width";
				if(v.indexOf("border_type")!=-1){
					key="type";
					val=$($obj).find('select').val();
					//val=$("#"+self.div_id+" div[data-base-name='"+v+"']").find("select").val();
				}else {
					var script=$($obj).data('my-script');
					if(typeof script!="undefined")
					val=script.get_value();
				}
				self.my_debug("Get border values",{i:i,v:v,val:val});
				values[key]=val;
			});
			return values;
		},
		/**
		 * Change border values
		 */
		this.my_change=function(e,obj,val,v1){
			e.preventDefault();
			if(self.myDisbaleChange)return;
			var name=obj.name;
			var css='';
			var values={};
			self.my_debug("Change",{obj:obj,name:name,val:val,v1:v1,borderNames:self.borderNames});
			//if($.inArray(name,self.borderNames)!=-1){
				values=self.getBorderValues();
			
			
			/*
			if(name.indexOf("border_select")!=-1){
				
			}else if(name.indexOf("border_radius_select")!=-1){
				
			}
			else if(name.indexOf("border_radius_1")!=-1){
			
			}else if(name.indexOf("border_radius_2")!=-1){
			
			}
			else {
				self.my_debug("Border names",self.borderNames);
			$("#"+self.div_id).siblings(".my_form_element_display_inline").find(".my_new_module_element").each(function(i,obj){
				var n=$(obj).data('base-name');
				var v;
				if($.inArray(n,self.borderNames)!=-1){
					if(n.indexOf('border_type')!=-1){
						v=$(obj).find("select").val();
					}else {
						v=$(obj).data('my-script').get_value();
					}
					self.my_debug("Get value",{n:n,v:v});
					if(n.indexOf('border_width')!=-1){
						values['width']=v;
					}else if(n.indexOf('border_color')!=-1){
						values['color']=v;
						if(v.indexOf(",")!=-1){
							values['color']='rgba('+v+')';
						}
					}else {
						values['type']=v;
					}
				}
			});
			*/
			css=values['width']+' '+values['type']+' '+values['color'];
			$.each(self.setBorderSelect,function(i,v){
				if(v){
					self.cssBorderValues[i]=css;
				}
			});
			self.my_debug('css',css);
			$("#"+self.div_id+" .my_border_check").each(function(i,v){
				var key=$(v).data('key');
				var name=self.name+'_'+$(v).data('key');
				self.my_debug("Set values",{key:key,name:name});
				if($(v).is(':checked')){
					if(self.setBorderSelect[key]){
						$('input[type="hidden"][name="'+name+'"]').val(css);
					}
				}else {
					$('input[type="hidden"][name="'+name+'"]').val('');
				}
			});
			self.get_values();
			self.trigger_change();
			//}
		};
		this.setBorderRadiusValue=function(key){
			var val=self.cssBorderRadiusValues[key];
			var is=$(self.borderRadiusCheckObj).is(":checked");
			self.my_debug("Border Set value",{key:key,val:val,is:is});
			if(val!=""){
				var arr=val.split("/");
				var top=arr[0];
				var bottom=arr[1];
				self.setTopRadiusVal(top);
				if(!is){
					self.setBorderRadiusValue(bottom);
				}
				
			}
		};
		this.setBorderValues=function(key){
			var css=self.cssBorderValues[key];
			self.my_debug("Border set border css values",{key:key,css:css,all:self.cssBorderValues});
			self.myDisbaleChange=true;
			if(typeof css!="undefined"&&css!=""){
				var arr=css.split(" ");
				var width=arr[0];
				var type=arr[1];
				var color=arr[2];
				var val="";
				$.each(self.borderNames,function(i,v){
					var $obj=$("#"+self.div_id).siblings(".my_form_element_display_inline").find("div[data-base-name='"+v+"']");
					if(v.indexOf("border_type")!=-1){
						$($obj).find('select').val(type);
					}else {
						var script=$($obj).data('my-script');
						if(v.indexOf('border_color')!=-1)val=color;
						else val=width;
						script.set_value(val);
					}
				});
				
			}
			self.myDisbaleChange=false;
		};
		
		this.setTopRadiusVal=function(val){
			var script=$(self.borderRadius1Obj).data('my-script');
			var val=script.set_value(val);
			self.my_debug("Border First radius value set",val);
			
		};
		this.setBottomRadiusVal=function(val){
			var script=$(self.borderRadius2Obj).data('my-script');
			var val=script.set_value(val);
			self.my_debug("Border Second radius value set",val);
			
		};
		
		this.getTopRadiusVal=function(){
			var script=$(self.borderRadius1Obj).data('my-script');
			var val=script.get_value();
			self.my_debug("Border First radius value",val);
			return val;
		};
		this.getBottomRadiusVal=function(){
			var script=$(self.borderRadius2Obj).data('my-script');
			var val=script.get_value();
			self.my_debug("Border Second radius value",val);
			return val;
		};
		this.setBorderRadius=function(val){
			if(val.indexOf("/")!=-1){
				self.setBorderRadiusValues(val);
			
				var arr=val.split("/");
				var topArr=arr[0];
				var bottArr=arr[1];
				//$.each(arr,function(i,v){
					//self.my_debug("Border set radius",{i:i,v:v});
					var arr1=topArr.split(" ");
					var arr2=bottArr.split(" ");
					self.my_debug("Border Top border radius",topArr);
					self.my_debug("Border Bottom border radius",bottArr);
					var a=["top_left","top_right","bottom_left","bottom_right"];
					for(var k=0;k<4;k++){
						var top=arr1[k];
						var bott=arr2[k];
						self.setTopRadiusVal(top);
						self.setBottomRadiusVal(bott);
						self.get_el_border_values(true);
						if(top!="0px" || bott!="0px"){
							var t=a[k];
							$(".my_border_radius_check[data-key='"+t+"']").prop("checked",true);
							//self.setBorderSelect[t]]=1;
							//self.setBorderValues(t);
						}else {
							var t=a[k];
							$(".my_border_radius_check[data-key='"+t+"']").prop("checked",false);
						}
						if(top!=bott){
							$(self.borderRadiusCheckObj).prop("checked",false);
							$(self.borderRadius2Obj).parents(".my_form_element_display_inline").show();
							
						
						}else {
							$(self.borderRadius2Obj).parents(".my_form_element_display_inline").hide();
							
							$(self.borderRadiusCheckObj).prop("checked",true);
						}
					}
				//});
			}
		};
		/**
		 * Get element border values
		 */
		this.get_el_border_values=function(set){
			var v1=self.getTopRadiusVal();
			var is=$(self.borderRadiusCheckObj).is(":checked");
			var v2=self.getBottomRadiusVal();
			if(is)v2=v1;
			var all=$(self.borderRadiusSelect).val();
			var css='';
			var css='';
			var values={};
			var cssRule="{top_left} {top_right} {bottom_right} {bottom_left}";
			var cssRule1=" / {top_left} {top_right} {bottom_right} {bottom_left}";
		
			var v1=self.getTopRadiusVal();
			var is=$(self.borderRadiusCheckObj).is(":checked");
			var v2=self.getBottomRadiusVal();
			if(is)v2=v1;
			var all=$(self.borderRadiusSelect).val();
			self.my_debug("Values",{v1:v1,v2:v2,all:all});
			if(set==false){
				var key=arguments[1];
				if(self.setBorderRadiusSelect[key]){
					self.cssBorderRadiusValues[key]=v1+"/"+v2;
				}else {
					self.cssBorderRadiusValues[key]="";
				}
				
				
			}else {
				
				$.each(self.setBorderRadiusSelect,function(i,v){
					if(v){
						self.cssBorderRadiusValues[i]=v1+"/"+v2;
					}else {
						//self.cssBorderRadiusValues[i]="";
					}
			});
			}
			$.each(self.cssBorderRadiusValues,function(i,v){
				var key=i;
				var val=v;
				key=key.replace("_","-");
				self.my_debug("Set key",key);
				var topVal="";
				var bottVal="";
				if(v.indexOf("/")!=-1){
					var arr=v.split("/");
					topVal=arr[0];
					bottVal=arr[1];
				}
				self.my_debug("Set border valus css",{i:i,key:key,v:v,top:topVal,bott:bottVal});
				if(v!=""){
					//$(self.preview_css_sel).css('border-'+key+"-radius",v);
				}else {
					val="0px";
					topVal=val;
					bottVal=val;
					//$(self.preview_css_sel).css('border-'+key+"-radius","0");
				}
				
					cssRule=cssRule.replace("{"+i+"}",topVal);
					cssRule1=cssRule1.replace("{"+i+"}",bottVal);
				});
				self.my_debug("Css rule",cssRule+" "+cssRule1);
				self.borderRadiusCss=cssRule+" "+cssRule1;
				$("#"+self.div_id+" .my_radius_css").text(".my_new_border_values div{border-radius:"+self.borderRadiusCss+";}");
				$("input[type='hidden'][name='"+self.name+"_radius']").val(self.borderRadiusCss);
				self.trigger_change();
			
		};
		/**
		 * Get border element values
		 */
		this.get_el_values=function(set){
			var css='';
			var values={};
			values=self.getBorderValues();
			/*
			$("#"+self.div_id).siblings(".my_form_element_display_inline").find(".my_new_module_element ").each(function(i,obj){
				var n=$(obj).data('base-name');
				self.my_debug("N",n);
				var v;
				//if((n.indexOf("border_select")==-1)&&(n.indexOf("border_radius_select")) )
				if($.inArray(n,['border_type','border_color','border_width'])!=-1){
					if(n.indexOf('border_type')!=-1){
						v=$(obj).find("select").val();
					}else v=$(obj).data('my-script').get_value();
					self.my_debug("Get value",{n:n,v:v});
					if(n.indexOf('border_width')!=-1){
						values['width']=v;
					}else if(n.indexOf('border_color')!=-1){
						values['color']=v;
						if(v.indexOf(",")!=-1){
							values['color']='rgba('+v+')';
						}
					}else {
						values['type']=v;
					}
				}
			});*/
			css=values['width']+' '+values['type']+' '+values['color'];
			if(set){
				$.each(self.setBorderSelect,function(i,v){
					if(v){
						self.cssBorderValues[i]=css;
					}
				});
			}
			self.my_debug("Border Css Set",{css:css,border:self.BorderSelect});
			//css=values['width']+' '+values['type']+' '+values['color'];
			return css;
		};
		this.set_value=function(value){
			self.my_debug("Border Set border value",value);
			if(typeof value=='undefined'){
				$("#"+self.div_id+" .my_border_check").each(function(i,v){
					var key=$(v).data('key');
					var name=self.name+'_'+$(v).data('key');
					self.my_debug("Border Set values",{key:key,name:name});
					$(v).prop('checked',false);
						$('input[type="hidden"][name="'+name+'"]').val('');
					
				});
			}else {
				var hasAny=false;
				var hasKey="";
				$("#"+self.div_id+" .my_border_check").each(function(i,v){
					var key=$(v).data('key');
					if(typeof value[key]!='undefined')hasAny=true;
				});
				if(typeof value['border']!='undefined'&&!hasAny){
					$.each(self.cssBorderValues,function(i,v){
						value[i]=value['border'];
					});
					
				}
				self.my_debug("Border Value",value);
				$("#"+self.div_id+" .my_border_check").each(function(i,v){
					var key=$(v).data('key');
					var name=self.name+'_'+$(v).data('key');
					self.my_debug("Border Set values",{key:key,name:name});
					var v='';
					self.cssBorderValues[key]="";
					if(typeof value[key]!='undefined'){
						self.cssBorderValues[key]=value[key];
						if(value[key]=='none'){
							$('input[type="hidden"][name="'+name+'"]').val('');
						}
						else {
							
							if(hasKey=="")hasKey=key;
							$('input[type="hidden"][name="'+name+'"]').val(value[key]);
						}
						
					}else {
						$('input[type="hidden"][name="'+name+'"]').val('');
						
					}
				});
				$(self.borderSelect).val('all');
				if(typeof value['border_radius']!="undefined"){
					var val=value['border_radius'];
					$('input[type="hidden"][name="'+self.name+'_radius"]').val(val);
					self.setBorderRadiusValues(val);
				}
				self.my_debug("Border Has key",hasKey);
				self.get_values();
				self.setBorderValues(hasKey);
				$(self.borderSelect).val(hasKey);
			}
			
		};
		this.getBorderValuesFromCss=function(css){
			var arr=css.split(" ");
			var values={};
			if(arr.length==1){
				$.each(self.cssBorderRadiusValues,function(i,v){
					values[i]=arr[0];
				})
			}else if(arr.length==2){
				values['top_left']=arr[0];
				values['bottom_right']=arr[0];
				values['top_right']=arr[1];
				values['bottom_left']=arr[1];
			}else if(arr.length==3){
				values['top_left']=arr[0];
				values['bottom_right']=arr[1];
				values['top_right']=arr[2];
				values['bottom_left']=arr[2];
			}else {
				values['top_left']=arr[0];
				values['bottom_right']=arr[1];
				values['top_right']=arr[2];
				values['bottom_left']=arr[3];
			}
			self.my_debug("Border Get css values",{arr:arr,css:css,values:values});
			return values;
		};
		this.setBorderRadiusValues=function(val){
			if(val!=""){
				self.setBorderRadiusSelect={top_left:1,top_right:1,bottom_right:1,bottom_left:1};
				var topCss=val;
				var bottCss=val;
				if(val.indexOf("/")!=-1){
					var arr=val.split("/");
					bottCss=arr[1];
					topCss=arr[0];
					$(self.borderRadiusCheckObj).prop('checked',false);
					$(self.borderRadiusCheckObj).trigger('change');
				}
				self.my_debug("Border Set values",{top:topCss,bott:bottCss});
				var valuesTop=self.getBorderValuesFromCss(topCss);
				var valuesBott=self.getBorderValuesFromCss(bottCss);
				self.setTopRadiusVal(valuesTop['top_left']);
				self.setBottomRadiusVal(valuesBott['top_left']);
				
				$.each(self.cssBorderRadiusValues,function(i,v){
					self.my_debug("Set values",{i:i,v:v});
					self.cssBorderRadiusValues[i]=valuesTop[i]+"/"+valuesBott[i];
				});
				self.my_debug("Border border radius values",self.cssBorderRadiusValues);
				self.borderRadiusCss=val;
				$("#"+self.div_id+" .my_radius_css").text(".my_new_border_values div{border-radius:"+self.borderRadiusCss+";}");
				
				$("#"+self.div_id+" .my_border_radius_check").each(function(i,v){
					$(v).prop('checked',true);
				});
				
			}else {
				$("#"+self.div_id+" .my_border_radius_check").each(function(i,v){
					$(v).prop('checked',false);
				});
				self.setBorderRadiusSelect={top_left:0,top_right:0,bottom_right:0,bottom_left:0};
				$.each(self.cssBorderRadiusValues,function(i,v){
					
					self.cssBorderRadiusValues[i]="";
				});
			}
			
			
		};
		/**
		 * Set preview border
		 */
		this.get_values=function(i,v){
			/*$.each(self.setBorderSelect,function(i,v){
				var css=self.cssBorderValues[i];
				if(css!=""){
					$(self.preview_css_sel).css('border-'+i,css);
				}else {
					$(self.preview_css_sel).css('border-'+i,'none');
				}
				
			});*/
			$("#"+self.div_id+" .my_border_check").each(function(i,v){
				var key=$(v).data('key');
				var name=self.name+'_'+$(v).data('key');
				
				var val=$('input[type="hidden"][name="'+name+'"]').val();
				self.my_debug("Border Get values",{key:key,name:name,val:val});
				self.cssBorderValues[key]=val;
				if(val!=""){
					$(v).prop('checked',true);
					self.values[key]=val;
				
				$(self.preview_css_sel).css('border-'+key,val);
				}else {
					self.values[key]='none';
					$(self.preview_css_sel).css('border-'+key,'none');
				}
			});
			self.borderRadiusCss=$("input[type='hidden'][name='"+self.name+"_radius']").val();
			self.my_debug("Border border radius",self.borderRadiusCss);
			self.my_debug("Border css border value",self.cssBorderValues);
			
		};
		this.get_value=function(){
			return self.values;
		};
		this.trigger_change=function(){
			var value=self.values;
			var obj=[self,value,$("#"+self.div_id).data('base-name')];
			self.my_debug("Change jscript border ",obj);
			$("#"+self.div_id).trigger('my_change',obj);
		};
		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log("***ModuleFormBorderScript *** \n"+t,o);
				}
			}
		};
	this.init(o);
	
};
})(jQuery);	
	
		