(function($) {
	wpMyModuleNewFormAutocomplete=function(o){
		var self;
		this.debug=true;
		this.options={};
		this.id='';
		this.name='';
		this.div_id='';
		this.my_working=false;
		this.multiple=false;
		this.duration=200;
		this.cache=true;
		this.show_values=false;
		this.my_cache={};
		this.min_length=3;
		this.animation='slideToggle';
		this.input_class='my_autocomplete_input';
		this.val_div='<div class="my_autocomplete_value" data-val="{val}">{text}<span class="fa fa-close"></span></div>';
		this.values_div='my_autocomplete_values';
		this.nonce_class='my_nonce_str';
		this.value_class='my_autocomplete_value';
		this.value={};
		this.val_c=0;
		this.ajax_vars={};
		self=this;
		this.init=function(o){
			if(typeof o.my_debug!='undefined'){
				if(!o.my_debug){
					self.debug=false;
				}
			}
			self.debug=true;
			self.my_debug("Options",o);
			self.options=o;
			self.id=self.options.id;
			self.name=self.options.name;
			self.div_id=self.options.div_id;
			self.multiple=self.options.multiple;
			if(typeof self.options.events=='undefined'){
				self.options.events={};
			}
			
			if(typeof self.options.show_values !='undefined'){
				self.show_values=self.options.show_values;
			}
			if(typeof self.options.min_length!='undefined'){
				self.min_length=self.options.min_length;
			}
			$("#"+self.div_id+" input[type='hidden'][data-name='"+self.name+"']").each(function(){
				var val=$(this).val();
				self.value[val]=1;
				self.val_c++;
			});
			self.my_debug("Values",self.value);
			self.init_autocomplete();
			self.bind_close();
			$("#"+self.div_id).data('my-script',this);
		};
		this.my_remove_vars=function(){
			$("#"+self.div_id+" .my_autocomplete_value").fadeOut(function(){$(this).remove();});
			$("#"+self.div_id).find("input[type='hidden'][data-name='"+self.name+"']").remove();
		};
		this.set_ajax_vars=function(vars){
			self.my_debug('Set ajhax vars',vars);
			$.each(vars,function(i,v){
				self.ajax_vars[i]=v;
			});
			
		};
		this.init_autocomplete=function(){
			var options={
					minLength:self.min_length,
					source:function(request,response){
						self.my_source(request,response);
					},
					select:function(event,ui){
						self.my_select(event,ui);
					}
				
				};
			if(self.options.show_thumb==1){
				options.html=true;
				options.change=function( event, ui ) {
					var item=ui.item;
					self.my_debug("Change",{ui:ui,item:item});
				}
				
				/*options.create=function(event,ui) {
		            //console.log(fixtures);
					var item=ui.item;
					self.my_debug("Create item",{ui:ui,item:item});
					if(typeof item!='undefined')
		            $("#"+self.div_id+" ."+self.input_class).val(item.label);
		        };
		       
		        options.focus=function(event, ui) {
		        	var item=ui.item;
					self.my_debug("Focus",{ui:ui,item:item});
					if(typeof item!='undefined')
					$("#"+self.div_id+" ."+self.input_class).val(ui.item.label);
		            return false;
		        };
		        options.select=function(event, ui) {
		        	var item=ui.item;
					self.my_debug("Focus",{ui:ui,item:item});
					if(typeof item!='undefined')
						$("#"+self.div_id+" ."+self.input_class).val(ui.item.label);
		            self.my_select(event,ui);
					return false;
		        };*/
			}
			
			$("#"+self.div_id+" ."+self.input_class).autocomplete(options);
			
			if(self.options.show_thumb==1){
				self.my_debug('Show thumb');
				
				_renderItem=function( ul, item ) {
					//$("#"+self.div_id+" ."+self.input_class).autocomplete('instance')._renderItem=function( ul, item ) {	
						if((typeof item.thumb!='undefined')&&(item.thumb!='')){
						  var img='<img  src="'+item.thumb+'" width="'+self.options.thumb_w+'" height="'+self.options.thumb_h+'"/>';	
						  //var p_t=(parseInt(self.options.thumb_h)-18)/2;
						  return $( "<li></li>" ).attr('class','ui-menu-item').append('<a>'+img+'<span>'+item.label+'</span></a>').appendTo( ul );
						  /*return $( "<li></li>" ).data( "item.autocomplete", item )
						  	.attr( "data-value", item.label )
						    .append(img+'<span>'+item.label+'</span>' )
						    .appendTo( ul );
						    */
						}else {
							return $( "<li></li>").attr('class','ui-menu-item').append('<a><span>'+item.label+'</span></a>' ).appendTo( ul );
							/*
							  return $( "<li></li>" ).data( "item.autocomplete", item )
							  	.attr( "data-value", item.label )
							    .append('<span>'+ item.label+'</span>' )
							    .appendTo( ul );
							    */
						}
					};
				
			/*if(typeof $("#"+self.div_id+" ."+self.input_class).autocomplete("instance" )!='undefined'){
				$("#"+self.div_id+" ."+self.input_class).autocomplete("instance" )._renderItem=_renderItem;
			}*/
				if(typeof $("#"+self.div_id+" ."+self.input_class).autocomplete().data('ui-autocomplete')!='undefined'){
					$("#"+self.div_id+" ."+self.input_class).autocomplete().data('ui-autocomplete')._renderItem=_renderItem;
				};
				
			}
			
		};
		this.bind_close=function(){
			$("#"+self.div_id+" ."+self.value_class+" .fa").unbind("click",self.my_close);
			$("#"+self.div_id+" ."+self.value_class+" .fa").click(self.my_close);
			
		};
		this.my_close=function(){
			if(self.my_working)return;
			self.my_working=true;
			var val=$(this).parent("."+self.value_class).data('val');
			self.my_debug("Close",val);
			self.my_val=val;
			if(typeof self.value[val]!='undefined'){
				delete self.value[val];
				var setObj=self.value[val];
				self.trigger_remove(setObj);
				$("#"+self.div_id+" input[data-name='"+self.name+"'][value='"+val+"']").remove();
				self.my_debug("New values",self.value);
				//$("#"+self.div_id+" ul li[data-value='"+val+"']").removeClass(self.active_class);
				$(this).parent("."+self.value_class).fadeOut(self.duration,function(){
					$(this).remove();
					self.my_working=false;
					self.val_c--;
					if(typeof self.options.events.close_event=='function'){
						self.options.events.close_event(self,self.my_val);
					}
				});
			}
		};
		this.my_select=function(event,ui){
			var val=ui.item.id;
			//self.value=val;
			var text=ui.item.label;
			var objSel={val:val,text:text};
			
			var value="";
			if(typeof ui.item.value!='undefined'){
				value=ui.item.value;
				self.setValue=value;
			}else self.setValue=val;
			self.my_debug("Select",{val:val,text:text,value:value});
			if(typeof self.value[val]=='undefined'){
				
				if(self.multiple){
					if(self.val_c==self.options.max_c){
						alert(self.options.max_sel);
						return;
					}
				}
				self.value[val]=text;
				var input_html;
				self.my_debug("Select",self.value);
				self.val_c++;
				//triger select
				self.trigger_select(objSel);
				if(self.multiple){
					input_html='<input type="hidden" name="'+self.name+'[]" data-name="'+self.name+'" value="'+val+'"/>';
				}else {
					$("#"+self.div_id+"[type='hidden'][data-name='"+self.name+"']").remove();
					input_html='<input type="hidden" name="'+self.name+'" data-name="'+self.name+'" value="'+val+'"/>';
				}
				$("#"+self.div_id+" ."+self.values_div).append(input_html);
				if(typeof self.options.events.select_event=='function'){
					var item_obj={};
					if(typeof ui.item.obj!='undefined')item_obj=ui.item.obj;
					self.options.events.select_event(self,item_obj,val,text);
					//eval(self.options.select_event);
				}
				if(self.show_values){
					var html=self.val_div;
					html=html.replace(/{val}/g,val);
					html=html.replace(/{text}/g,text);
					$("#"+self.div_id+" ."+self.values_div).append(html);
					self.bind_close();
					
				}
			}else {
				if(typeof self.options.events.select_event=='function'){
					self.options.events.select_event(self,val,text);
					//eval(self.options.select_event);
				}
			}
		};
		this.setAjaxVar=function(key,val){
			self.my_debug("Set ajax var",{key:key,val:val});
			self.ajax_vars[key]=val;
		};
		this.trigger_change=function(){
			var value=self.setValue;
			var obj=[self,value,$("#"+self.div_id).data('base-name')];
			self.my_debug("Change jscript autocomplete",obj);
			$("#"+self.div_id).trigger('my_change',obj);
		};
		this.trigger_remove=function(setObj){
			var value=setObj;
			var obj=[self,value,$("#"+self.div_id).data('base-name')];
			self.my_debug("Change jscript autocomplete",obj);
			$("#"+self.div_id).trigger('my_remove',obj);
		};
		this.trigger_select=function(setObj){
			var obj=[self,setObj,$("#"+self.div_id).data('base-name')];
			self.my_debug("Select jscript autocomplete",obj);
			$("#"+self.div_id).trigger('my_select',obj);
		}
		this.my_source=function(request,response){
			var term=request.term;
			self.my_debug("Term",term);
			self.my_term=term;
			self.my_response=response; 
			var matcher = new RegExp($.ui.autocomplete.escapeRegex(request.term), "i");
	            
	           /* response($.grep(fixtures, function(value) {
	                return matcher.test(value.name);
	            }));*/
			if(term in self.my_cache){
				self.my_debug("From cache",self.my_cache[term]);
				response(self.my_cache[term]);
			}else {
				var nonce=$("#"+self.div_id+" ."+self.nonce_class).val();
				var my_data={
					action:self.options.action,	
					my_nonce:nonce,
					my_action:self.options.my_action,
					term:self.my_term
				};
				$.each(self.ajax_vars,function(i,v){
					my_data[i]=v;
				});
				if(typeof self.options.ajax_data!='undefined'){
					$.each(self.options.ajax_data,function(i,v){
						my_data[i]=v;
					});
				}
				self.my_debug("data",my_data);
				$.ajax({
					url:self.options.url,
					type:'POST',
					dataType:'json',
					data:my_data,
					success:function(data){
						self.my_debug("Return data",data);
						/*if(self.options.show_thumb==1){
							self.my_response($.grep(data.data, function(value) {
				                return matcher.test(value.label);
				            }));
						}
						else*/ 
						self.my_response(data.data);
						self.my_cache[self.my_term]=data.data;
					},
					error:function(){
						}
					});
				
			}
		};
		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log("***ModuleFormMainSCript *** \n"+t,o);
				}
			}
		};
	this.init(o);
	
};
})(jQuery);			