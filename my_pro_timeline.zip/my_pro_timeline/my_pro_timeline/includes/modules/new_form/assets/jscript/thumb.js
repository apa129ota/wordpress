(function($) {
	wpMyModuleNewFormThumb=function(o){
		var self;
		this.debug=true;
		this.options={};
		this.id='';
		this.name='';
		this.div_id='';
		this.my_working=false;
		this.value='';
		this.filter=false;
		this.duration=400;
		this.active_class='my_radio_list_ul_li_active';
		this.check_class='my_radio_list_check';
		this.button_class='my_media_button';
		this.val_area='my_thumb_val';
		this.remove_button_class='my_media_button_remove';
		this.sizes={};
		this.values={};
		self=this;
		this.init=function(o){
			if(typeof o.my_debug!='undefined'){
				if(!o.my_debug){
					self.debug=false;
				}
			}
			self.my_debug("Options",o);
			self.options=o;
			self.id=self.options.id;
			self.name=self.options.name;
			self.div_id=self.options.div_id;
			self.value=$("#"+self.div_id+" input[type='hidden']").val();
			var options={
					title:self.options.media_title,
					multiple:self.options.multiple,
					frame:self.frame,
					button:{text:self.options.button_text}
				};
			if(self.options.filter_type!='undefined'){
				options.library={};
				options.library.type=self.options.filter_type;
			}
			if(typeof self.options.can_remove && self.options.can_remove){
				$("#"+self.div_id+" ."+self.remove_button_class).click(self.my_remove);
			}
			self.media=new wp.media(options);	
			self.my_debug("Value",self.value);
			self.media.on('select',self.my_send_attachment);
			$("#"+self.div_id).data('my-object',self);
			$("#"+self.div_id+" ."+self.button_class).click(self.my_open_media);
			$("#"+self.div_id+" #"+self.id).change(self.my_change);
			$("#"+self.div_id).data('my-script',this);
			//$("#"+self.div_id+" ."+self.check_class).click(self.my_change);
			//$("#"+self.div_id+" label").click(self.my_change);
		};
		this.trigger_change=function(){
			var value=self.thumb;
			var obj=[self,value,$("#"+self.div_id).data('base-name')];
			self.my_debug("Change jscript color list",obj);
			$("#"+self.div_id).trigger('my_change',obj);
		};
		this.my_remove_image=function(){
			//self.my_debug('Chnage');
			var val=$("#"+self.div_id+" #"+self.id).val();
			self.my_debug('Remove thumb value',val);
			var $obj=$("#"+self.div_id);
				$($obj).find("."+self.val_area+" span").show();
				$($obj).find("."+self.val_area+" img").fadeOut();
				self.value='';
				self.thumb='';
			
		};
		this.my_open_media=function(e){
			e.preventDefault();
			if(typeof wp.media.editor.send.attachment!='undefined'){
				self.prev_send=wp.media.editor.send.attachment;
			}
			if(typeof wp.media.editor.insert!='undefined'){
				self.prev_insert=wp.media.editor.insert;
			}
			self.media.open();
		};
		this.my_remove=function(e){
			e.preventDefault();
			self.my_debug("Remove image");
			if(self.value!=''){
				$("#"+self.div_id+" #"+self.id).val('');
				$("."+self.val_area+" img").fadeOut();
				self.value='';
				self.thumb='';
				$("#"+self.div_id).find("."+self.val_area+" span").show();
				$("#"+self.div_id+" ."+self.remove_button_class).fadeOut();
				$("#"+self.div_id+" #"+self.id).trigger('change');
			}
			self.trigger_change();
		};
		this.getSizesUrl=function(size){
			if(typeof self.sizes[size]!='undefined'){
				return self.sizes[size];
			}else if(self.thumb!='')return self.thumb;
			else return '';
		};
		this.getObjectValue=function(){
			var o={};
			o.thumb=self.thumb;
			o.sizes=self.sizes;
			o.value=self.value;
			self.values[self.value]=o;
			return self.value;
		};
		this.my_send_attachment=function(){
			
			var att=self.media.state().get('selection').toJSON();
			self.my_debug('Att',att);
			var att_new=att[0];
			var thumb=att_new.sizes.thumbnail.url;
			self.sizes=att_new.sizes;
			self.thumb=thumb;
			self.value=att_new.id;
			self.my_debug("New att",{thumb:self.thumb,val:self.value});
			$("#"+self.div_id+" #"+self.id).val(att_new.id);
			$("#"+self.div_id+" #"+self.id).trigger('change');
			$("."+self.val_area+" img").attr('src',self.thumb);
			$("."+self.val_area+" span").hide();
			if(typeof self.options.can_remove && self.options.can_remove){
				$("#"+self.div_id+" ."+self.remove_button_class).fadeIn();
			}
			self.trigger_change();
			
		};
		this.get_value=function(){
			return self.value;
		};
		this.set_value=function(v){
			//self.value=v;
			if(typeof self.values[v]!='undefined'){
				self.sizes=self.values[v].sizes;
				self.value=v;
				self.thumb=self.values[v].thumb;
				self.my_debug("New att",{thumb:self.thumb,val:self.value});
				$("#"+self.div_id+" #"+self.id).val(att_new.id);
				$("#"+self.div_id+" #"+self.id).trigger('change');
				$("."+self.val_area+" img").attr('src',self.thumb);
				$("."+self.val_area+" span").hide();
				return true;
				
			}else if(v==''){
				$("#"+self.div_id+" ."+self.remove_button_class).trigger('click');
			}
		};
		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log("***ModuleFormMainSCript *** \n"+t,o);
				}
			}
		};
	this.init(o);
	
};
})(jQuery);		