(function($) {
	wpMyModuleNewFormColorPicker=function(o){
		var self;
		this.debug=true;
		this.options={};
		this.id='';
		this.name='';
		this.div_id='';
		this.my_working=false;
		this.transp='';
		this.color='';
		this.allow_transp=false;
		this.color_class='my_jscript_color_span';
		this.picker_class='my_jscript_color_span_1';
		this.picker_holder='my_color_picker_iris_holder';
		this.height=200;
		this.rgba='';
		this.out_picker=true;
		this.default_value='';
		self=this;
		this.init=function(o){
			if(typeof o.my_debug!='undefined'){
				if(!o.my_debug){
					self.debug=false;
				}
			}
			self.debug=true;
			self.my_debug("Options",o);
			self.options=o;
			self.id=self.options.id;
			self.name=self.options.name;
			self.div_id=self.options.div_id;
			if(typeof self.options.height!='undefined'){
				self.height=self.options.height;
			}

			var p=$("#"+self.div_id).data('allow-transp');
			//p=parseint(p);
			if(p==1)self.allow_transp=true;
			self.color=$("#"+self.div_id).data('color');
			self.transp=$("#"+self.div_id).data('transp');
			self.my_debug("Values",{color:self.color,transp:self.transp});
			self.default_value=self.color;
			if(self.allow_transp){
				self.default_value+=","+self.transp;
			}
			var sel="#"+self.div_id+" ."+self.picker_holder;
			if(self.out_picker){
				sel='#'+self.div_id+"_picker."+self.picker_holder;
			}
			self.div_picker_id=sel;
			self.sel=sel;
			$(sel).iris({
				height:self.heght,
				color:self.color,
				change: function(event, ui) {

                    var color=ui.color.toString();
                    self.color=color;
                    self.change_ui();
                    $(self.div_picker_id+" .my_change_color_input_12").val(color);
                    self.my_debug("change color",color);
                    //var name=$(this).attr('my_name');
                   // $(this).siblings(".my_color_picker_color").css('background-color',color);
                    //$("input[type='hidden'][name='"+name+"']").val(color);
                    //self.my_debug("Color",color);
                    //$(this).find(".iris-picker-inner .my_change_color_input_12").val(color);
                    //$(this).css( 'background-color', ui.color.toString());
                }
			});
			$(sel+" .iris-picker").each(function(i,v){
				if($(this).find(".iris-picker-inner .my_change_color_input_12").length==0){
					var h=$(this).height();
					h+=60;
					$(this).height(h);
					var color="";
					color=self.color;
					self.my_debug("Init color text field",color);
				//var color=$(this).iris("option",true);
					$(this).find(".iris-picker-inner").parents(".my_color_picker_iris_holder").append('<div class="my_close_picker_div"><i class="my_close_picker fa fa-close"></i></div>')
					
					$(this).find(".iris-picker-inner").append('<div class="clear"></div><div style="margin-top:10px">'+self.options.hex_title+'<br/><input type="text" class="my_change_color_input_12" value="'+color+'"/></div>');
					/*setTimeout(function(){
					self.$closeButton=$(this).parents(".my_color_picker_iris_holder").find(".my_close_picker_div");
					$(this).parents(".my_color_picker_iris_holder").find(".my_close_picker_div").click(function(e){
						self.my_debug("Close picker");
						$("#"+self.div_id+" ."+self.picker_class).text(self.options.pick_title);

						$(self.selector_picker_holder).find('.iris-picker').fadeOut(self.duration,function(){
							$(this).parent("."+self.picker_holder).attr('data-open',0);
						});
					});
					},300);*/
					setTimeout(function(){
						$(self.sel+" .iris-picker").find(".my_change_color_input_12").keyup(self.key_up);
						$(self.sel+" .iris-picker").find(".my_change_color_input_12").change(self.my_input_change);
					},300);
					if(self.allow_transp){
						var h=$(sel+" .iris-picker").height();
						h+=60;
						$(sel+" .iris-picker").height(h);
						$(sel+" .iris-picker").find(".iris-picker-inner").append('<br/><div class="clear"></div>'+self.options.transp_title+'<div class="my_color_slider"></div>');
						//setTimeout(function(){
							 $(sel+" .my_color_slider").slider({
								 min:0,
								 max:1,
								 step:0.05,
								 value:self.transp,
								 stop:self.my_change
							 });
						//});
					}
				}
			});
			
			$(sel+" .my_change_color_input_12").click(function(e){
				e.stopPropagation();
			});
			$("#"+self.div_id+" .my_jscript_color_span_1").click(self.my_open_picker);
			$("#"+self.div_id).data('my-script',this);
			self.selector_picker_holder=sel;
			$('#'+self.div_id+"_picker").find(".my_close_picker_div").click(function(e){
				self.my_debug("Close picker");
				$("#"+self.div_id+" ."+self.picker_class).text(self.options.pick_title);
				$("#"+self.div_id+"_picker").find(".my_close_picker_div").animate({opacity:0},self.duration);
				
				$(self.selector_picker_holder).find('.iris-picker').fadeOut(self.duration,function(){
					$(this).parent("."+self.picker_holder).attr('data-open',0);
				});
			});
		},
		this.get_value=function(){
			var value=self.color;
			if(self.allow_transp){
				 var tr=$(self.selector_picker_holder+" .my_color_slider").slider("option","value");
				 value=self.color+","+tr;
			}
			return value;
		};
		this.set_default=function(){
			var value=self.default_value;
			if(value.indexOf(",")!==-1){
				var arr=value.split(",");
				var color=arr[0];
				var transp=arr[1];
				 $(self.selector_picker_holder+" .my_color_slider").slider("option","value",transp);
			}else {
				var color=value;
			}
			$(self.selector_picker_holder).iris('color', color);
			self.trigger_change();
		};
		this.trigger_change=function(){
			var value=self.color;
			var input_val=self.color;
			if(self.allow_transp){
			value=self.rgba;
			input_val+=","+self.transp;
			}
			var obj=[self,value,input_val,$("#"+self.div_id).data('base-name')];
			self.my_debug("Change jscript color list",obj);
			$("#"+self.div_id).trigger('my_change',obj);
		};
		this.set_value=function(value){
			self.my_debug('Set Value',value);
			if(value.indexOf(",")!=-1){
				var arr=value.split(",");
				var color=arr[0];
				var transp=arr[1];
				 $(self.selector_picker_holder+" .my_color_slider").slider("option","value",transp);
			}else {
				var color=value;
			}
			$(self.selector_picker_holder).iris('color', color);
			self.trigger_change();
		};
		this.change_ui=function(){
			if(self.allow_transp){
				var t=$(self.selector_picker_holder+" .my_color_slider").slider("value");
				self.transp=t;
				var color=self.color;
				self.my_debug("Slider change",{t:t,color:color});
				var rgba=self.gen_rgba(color,t);
				self.rgba=rgba;
				$("#"+self.div_id+" ."+self.color_class).css('background-color',rgba);
			}else {
				$("#"+self.div_id+" ."+self.color_class).css('background-color',self.color);

			}
			self.change_hidden_value();
		};
		this.hexdoc=function(ch){
			ch=ch.toLowerCase();
			var l=ch.length-1;
			var p=0;
			var total=0;
			self.my_debug("Hexdoc",ch);
			for(var s=l;s>=0;s--){
				var c=ch.substr(l,1);
				var val=parseInt(c);
				self.my_debug('C',c);
				switch(c){
					case 'f':
						val=15;
					break;
					case 'e':
						val=14;
					break;
					case 'd':
						val=13;
					break;
					case 'c':
						val=12;
					break;
					case 'b':
						val=11;
					break;
					case 'a':
						val=10;
					break;
				}
				self.my_debug('Value',val);
				if(p==0){
					total+=val;
					p=16;
				}else {
					total+=val*p;
					p=p*16;
				}
				self.my_debug('Value',total);
			}
			self.my_debug("Dec hex",{hex:ch,total:total});
			return total;
		};
		this.gen_rgba=function(color,t){
			if(color.indexOf('#')===0){
				color=color.substr(1);
			}
			var hex=color;
			var l=color.length;
			if(l==6){
				var ch1=color.substr(0,2);
				var ch2=color.substr(2,2);
				var ch3=color.substr(4,2);
				/*var s1=self.hexdoc(ch1);
				var s2=self.hexdoc(ch2);
				var s3=self.hexdoc(ch3);
				*/
				var s1 = parseInt(hex.substring(0,2), 16);
				var s2= parseInt(hex.substring(2,4), 16);
				var s3= parseInt(hex.substring(4,6), 16);
				var s='rgba('+s1+','+s2+','+s3+','+t+')';
				self.my_debug("s",s);
				return s;
			}else if(l==3){
				var ch1=color.substr(0,1);
				var ch2=color.substr(1,1);
				var ch3=color.substr(2,1);
				var ch11=ch1+ch1;
				var ch22=ch2+ch2;
				var ch33=ch3+ch3;
				//var s1=self.hexdoc(ch11);
				//var s2=self.hexdoc(ch22);
				//var s3=self.hexdoc(ch33);
				var hex=ch11+ch22+ch33;
				var s1 = parseInt(hex.substring(0,2), 16);
				var s2= parseInt(hex.substring(2,4), 16);
				var s3= parseInt(hex.substring(4,6), 16);

				var s='rgba('+s1+','+s2+','+s3+','+t+')';
				self.my_debug("s",s);
				return s;
			}
			else return 'rgba(0,0,0,'+t+')';

		};
		this.change_hidden_value=function(e){
			var val=self.color;
			if(self.allow_transp){
				val+=','+self.transp;
			}
			self.my_debug("Save value",val);
			$("#"+self.div_id+" #"+self.id).val(val);
			self.trigger_change();
		};
		this.my_change=function(e,ui){
			var val=ui.value;
			self.transp=val;
			self.my_debug("change transp",{t:val,color:self.color});
			var color=self.color;
			var rgba=self.gen_rgba(color,val);
			self.rgba=rgba;
			$("#"+self.div_id+" ."+self.color_class).css('background-color',rgba);
			self.change_hidden_value();
		};
		this.my_open_picker=function(e){
			e.stopPropagation();
			var open=$(self.selector_picker_holder).attr('data-open');//$(this).siblings("."+self.picker_holder).attr('data-open');
			self.my_debug("Open colort picker",open);
			self.my_debug("Close button",self.$closeButton);
			if(open==0){
				//var pos=$("#"+self.div_id).position();
				var scroll=$(window).scrollTop();
				var pos=$("#"+self.div_id).offset();
				var h=$(window).height();
				var moff=$(".my_options_form_inner").find(".mCSB_container").css('top');
				moff=Math.abs(parseInt(moff));
				self.my_debug('Find position ',{s:scroll,pos:pos,moff:moff});
				$("#"+self.div_id+"_picker").find(".my_close_picker_div").animate({opacity:1},self.duration);
				
				/*if(self.options.mc){

				}*/
				var w=$("#"+self.div_id).width();
				var h=$("#"+self.div_id).height();
				var top=pos.top-150;
				var left=pos.left;
				left=left-220;
				self.my_debug("Position",pos);
				$(self.selector_picker_holder).css({top:top+'px',left:left+'px'});
				$(self.selector_picker_holder).find('.iris-picker').fadeIn(self.duration,function(){
					$(this).parent("."+self.picker_holder).attr('data-open',1);
				});
				$("#"+self.div_id+" ."+self.picker_class).text(self.options.close_title);
					
			}else {
				//$(self.$closeButton).animate({opacity:0},self.duration);
				$('#'+self.div_id+"_picker").find(".my_close_picker_div").animate({opacity:0},self.duration);
				
				$("#"+self.div_id+" ."+self.picker_class).text(self.options.pick_title);

				$(self.selector_picker_holder).find('.iris-picker').fadeOut(self.duration,function(){
					$(this).parent("."+self.picker_holder).attr('data-open',0);
				});
			}
		};
		this.my_input_change=function(e){
			var val=$(this).val();
			if(val.length==0){
				$(this).val('#');
				val='#';
			}
			if(val.length==7){
				$(this).parents("."+self.picker_holder).iris("color",val);
			}

		};
		this.key_up=function(e){

				var keycode=e.which;
				self.my_debug("Key code",keycode);
				var val=$(this).val();
				/*var l=val.length-1;
				if((keycode<48)||(keycode>57&&keycode<65)||(keycode>70)){

					val=val.substr(0,l);
					$(this).val(val);
					return;
				}*/

				if(val.length==0){
					$(this).val('#');
					val='#';
				}
				/*if(val.length>=8){
					val=val.substr(0,7);
					$(this).val(val);
				}*/
				self.my_debug("Change input text",val);
				if(val.length>1){
					/*if(!val.match(/^\#[0-9]+[a-f]+[A-F]+$/)){
						alert(my_admin_woo_msgs.wrong_color_hex);
						return;
					}else
					*/
					//$(this).parents(".my_color_picker_title").iris("color",val);
				}
				/*if(val.length==4){
					$(this).parents("."+self.picker_holder).iris("color",val);
				}
				else*/
				if(val.length==7){
					$(this).parents("."+self.picker_holder).iris("color",val);
				}

		},

		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log("***ModuleFormMainSCript *** \n"+t,o);
				}
			}
		};
	this.init(o);

};
})(jQuery);