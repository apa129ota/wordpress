(function($) {
	wpMyModuleNewFormStars=function(o){
		var self;
		this.debug=true;
		this.options={};
		this.id='';
		this.name='';
		this.div_id='';
		this.my_working=false;
		this.value='';
		this.default_value='';
		self=this;
		this.init=function(o){
			if(typeof o.my_debug!='undefined'){
				if(!o.my_debug){
					self.debug=false;
				}
			}
			self.my_debug("Options",o);
			self.options=o;
			self.id=self.options.id;
			self.name=self.options.name;
			self.div_id=self.options.div_id;
			self.value=$("#"+self.div_id).data('value');
			$("#"+self.div_id+" ul li").mouseover(self.my_check);
			
		};
		this.my_check=function(e){
			var i=$(this).data('i');
			i=parseInt(i);
			var c;
			self.my_debug("Check", {i:i,o:self.options,max:max});
			var max=parseInt(self.options.max);
			if(i<max){
				self.my_debug("Uncheck fa",{form:(i+1),max:max});
				for(c=(i+1);c<=max;c++){
					$("#"+self.div_id+" ul li[data-i='"+c+"'] .fa").removeClass('my_stars_active');
				}
			}
			for(c=1;c<=i;c++){
				$("#"+self.div_id+" ul li[data-i='"+c+"'] .fa").addClass('my_stars_active');
			}
			self.set_value(i);
			
		};
		this.trigger_change=function(){
			var value=self.value;
			var obj=[self,value,$("#"+self.div_id).data('base-name')];
			self.my_debug("Change jscript color list",obj);
			$("#"+self.div_id).trigger('my_change',obj);
		};
		this.set_default=function(){
			var v=self.default_value;
			//self.my_debug("Set default value",v);
			self.value=v;
		};
		this.set_value=function(value){
			self.my_debug('Set value',value);
			$("#"+self.id).val(value);
			self.trigger_change();
			//$("#"+self.div_id+" .my_dropdown").trigger('click');
			//setTimeout(function(){
			//$("#"+self.div_id).data('showed',1);
			//$("#"+self.div_id).find(".my_dropdown_ul li[data-value='"+value+"']").trigger('click');
			//$("#"+self.div_id+" ."+self.value_class+" .fa").trigger('click');
			///self.my_close();
			
			//},300);
		};
		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log("***ModuleFormMainSCript *** \n"+t,o);
				}
			}
		};
	this.init(o);
	
};
})(jQuery);	