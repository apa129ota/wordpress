(function($) {
	wpMyModuleNewFormComboBox=function(o){
		var self;
		this.debug=true;
		this.options={};
		this.id='';
		this.name='';
		this.div_id='';
		this.my_working=false;
		this.multiple=false;
		this.duration=200;
		this.animation='slideToggle';
		this.filter=false;
		this.active_class='my_dropdown_ul_li_active';
		this.multiple_values_class='my_dropdow_mulitple_values';
		this.val_div='<div class="my_dropdow_mulitple_values" data-val="{val}">{text}<span class="fa fa-close"></span></div>';
		this.values_class="my_dropdown_multiple_value";
		this.value_class='my_dropdow_mulitple_values';
		this.val_c=0;
		this.text='';
		this.value='';
		this.default_value='';
		self=this;
		this.init=function(o){
			if(typeof o.my_debug!='undefined'){
				if(!o.my_debug){
					self.debug=false;
				}
			}
			self.my_debug("Options",o);
			self.options=o;
			self.id=self.options.id;
			self.name=self.options.name;
			self.div_id=self.options.div_id;
			self.multiple=self.options.multiple;
			if(typeof self.options.duration!='undefined')self.duration=self.options.duration;
			if(typeof self.options.animation!='undefined')self.animation=self.options.animation;
			if(typeof self.options.val_div!='undefined')self.val_div=self.options.val_div;
			if($("#"+self.div_id+" .my_dropdown_filter").length>0){
				self.filter=true;
				self.my_debug("Filter");
				$("#"+self.div_id+" .my_dropdown_filter input").on('keyup',self.my_filter);
			}
			if(self.multiple){
				self.value={};
				$("#"+self.div_id+" .my_dropdow_mulitple_values").each(function(i,v){
					self.val_c++;
					var val=$(v).data('val');
					self.value[val]=$(v).text();
				});
			}else {
				self.value=$("#"+self.div_id).data('value');
				self.text=$("#"+self.div_id+" .my_dropdown_ul li[data-value='"+self.value+"']").text();
			}
			self.default_value=self.value;
			self.my_debug("Value",self.value);
			$("#"+self.div_id).data('showed',0);
			$("#"+self.div_id+" .my_dropdown_ul ").mCustomScrollbar();
			if(self.multiple){
				$("#"+self.div_id+" .my_dropdown_down_span").click(self.my_show);
			}
			else $("#"+self.div_id+" .my_dropdown").click(self.my_show);
			$("#"+self.div_id+" .my_dropdown_ul li").click(self.my_click);
			if(typeof self.keys=='undefined'){
				self.keys=true;
				self.my_debug("Added keyup");
				$(document).keyup(self.general_key_up);
			}
			$("#"+self.div_id).data('my-script',this);
			self.bind_close();
		};
		this.set_default=function(){
			var v=self.default_value;
			self.my_debug("Set default value",v);
			if(self.multiple){
				self.value={};
				$.each(self.value,function(i,v){
					$("#"+self.div_id+" .my_dropdown_ul li[data-value='"+i+"']").trigger('click');
				});
				$.each(v,function(i,v){
					$("#"+self.div_id+" .my_dropdown_ul li[data-value='"+i+"']").trigger('click');
				});
			}else {
				//$("#"+self.div_id+" .my_dropdown_ul li[data-value='"+self.value+"']").trigger('click');
				$("#"+self.div_id+" .my_dropdown_ul li[data-value='"+self.default_value+"']").trigger('click');
			}
		}
		this.get_value=function(){
			var value=self.value;
			return value;
		};
		this.set_value=function(value){
			self.my_set_value12=1;
			self.my_debug('Set value',value);
			/*if(self.multiple){
			$("#"+self.div_id+" .my_dropdown_down_span").trigger('click');
			}else {
				$("#"+self.div_id+" button .fa").trigger('click');
			}*/
			//setTimeout(function(){
			//$("#"+self.div_id).data('showed',1);
			$("#"+self.div_id).find(".my_dropdown_ul li[data-value='"+value+"']").trigger('click');
			self.my_debug('Set value after',value);
			delete self.my_set_value12;
			/*if(self.multiple){
				$("#"+self.div_id+" .my_dropdown_down_span").trigger('click');
			}else {
				$("#"+self.div_id+" button .fa").trigger('click');
			}*/
			///self.my_close();

			//},300);
		};
		this.trigger_change=function(){
			var value=self.value;
			var obj=[self,value,$("#"+self.div_id).data('base-name')];
			self.my_debug("Change jscript color list",obj);
			$("#"+self.div_id).trigger('my_change',obj);
		};
		this.general_key_up=function(e){
			self.$elem='';
			var c=0;
			var sh;
			self.my_debug("Code",e.keyCode);
			if(e.keyCode==27){
				$(".jscript_dropdown_div").each(function(i,v){
					sh=$(v).data('showed');
					self.my_debug('Sh',sh);
					if(sh==1){
						if(self.$elem=='')self.$elem=$(v);
						c++;
						//$(v).find(".my_dropdown").trigger('click');
					}
				});
				$(".jscript_dropdown_div").each(function(i,v){
					sh=$(v).data('showed');
					self.my_debug('Sh',sh);
					if(sh==1){
						if(self.$elem=='')self.$elem=$(v);
						c++;
						//$(v).find(".my_dropdown").trigger('click');
					}
				});
				self.my_debug("Esc",{c:c});
				if(c==1){
					e.preventDefault();
					self.$elem.find(".my_dropdown").trigger('click');
				}
			}
			else if (e.keyCode == 13) {

				$(".jscript_dropdown_div").each(function(i,v){
					sh=$(v).data('showed');
					self.my_debug('Sh',sh);
					if(sh==1){
						if(self.$elem=='')self.$elem=$(v);
						c++;
						//$(v).find(".my_dropdown").trigger('click');
					}
				});
				self.my_debug("ESC",{c:c});
				if(c==1){
					e.preventDefault();
					self.$elem.find(".my_dropdown").trigger('click');
				}
			}else if (e.keyCode == '38') {

				$(".jscript_dropdown_div").each(function(i,v){
					sh=$(v).data('showed');

					if(sh==1){
						if(self.$elem=='')self.$elem=$(v);
						c++;
						//$(v).find(".my_dropdown").trigger('click');
					}
				});
				self.my_debug("Up",{c:c});
				if(c==1){
					//$("#"+self.id+" .my_dropdown_ul").mCustomScrollbar("update");
					if(!$("#"+self.div_id+" .my_dropdown_ul li[data-value='"+self.value+"']").is(":visible")){
						self.my_debug("Not visible");
						return;
					}

					var $next=$("#"+self.div_id+" .my_dropdown_ul li[data-value='"+self.value+"']").prevAll('li:visible').first();
					//if($next.hasClass(".my_dropdown_filter"))return;
					if(self.filter){

						if($next.hasClass("my_dropdown_filter")){
							return;
						}
					}

					self.my_debug("Prev c",$next.length);
					if($next.length==1){
						e.preventDefault();
						var w=$($next).outerHeight();
						self.my_debug('H',w);

						$("#"+self.id+" .my_dropdown_ul").mCustomScrollbar("scrollTo",$next);

						$("#"+self.div_id+" .my_dropdown_ul li[data-value='"+self.value+"']").removeClass(self.active_class);
						var value=$next.data('value');
						self.my_debug("Values ",{value:value,text:self.text});
						self.value=value;
						$("#"+self.div_id+" .my_dropdown_ul li[data-value='"+self.value+"']").addClass(self.active_class);
						self.text=$("#"+self.div_id+" .my_dropdown_ul li[data-value='"+self.value+"']").text();
						$("#"+self.div_id+" .my_dropdown_value").text(self.text);
					}

				}
		        // up arrow
		    }
		    else if (e.keyCode == '40') {
		    	if(!$("#"+self.div_id+" .my_dropdown_ul li[data-value='"+self.value+"']").is(":visible")){
					self.my_debug("Not visible");
					return;
				}


		    	$(".jscript_dropdown_div").each(function(i,v){
					sh=$(v).data('showed');
					if(sh==1){
						if(self.$elem=='')self.$elem=$(v);
						c++;
						//$(v).find(".my_dropdown").trigger('click');
					}
				});
		    	self.my_debug("Down",{c:c});
		    	if(c==1){


		    		if(!$("#"+self.div_id+" .my_dropdown_ul li[data-value='"+self.value+"']").is(":visible"))return;

					var $next=$("#"+self.div_id+" .my_dropdown_ul li[data-value='"+self.value+"']").nextAll('li:visible').first();


					self.my_debug("Next c",$next.length);
					if($next.length==1){
						e.preventDefault();
						//var w=$($next).outerHeight();
						//self.my_debug('H',w);

						$("#"+self.id+" .my_dropdown_ul").mCustomScrollbar("scrollTo",$next);

						$("#"+self.div_id+" .my_dropdown_ul li[data-value='"+self.value+"']").removeClass(self.active_class);
						var value=$next.data('value');

						self.value=value;
						$("#"+self.div_id+" .my_dropdown_ul li[data-value='"+self.value+"']").addClass(self.active_class);
						self.text=$("#"+self.div_id+" .my_dropdown_ul li[data-value='"+self.value+"']").text();
						self.my_debug("Values ",{value:value,text:self.text});
						$("#"+self.div_id+" .my_dropdown_value").text(self.text);
					}

				}
		        // down arrow
		    }
		};
		this.my_filter=function(e){
			var val=$(this).val();
			self.my_debug("filter show",val);
			val=val.toLowerCase();
			if(val==''){
				$("#"+self.div_id+" .my_dropdown_ul li").show();
			}else {
				$("#"+self.div_id+" .my_dropdown_ul li").each(function(i,v){
					if(!$(v).hasClass('my_dropdown_filter')){

					var text=$(this).text();
					text=text.toLowerCase();
					if(text.indexOf(val)===0){
						$(this).show();
					}else {
						$(this).hide();
					}
					}
				});
			}
		};
		this.bind_close=function(){
			$("#"+self.div_id+" ."+self.value_class+" .fa").unbind('click',self.my_close);
			$("#"+self.div_id+" ."+self.value_class+" .fa").click(self.my_close);
		};
		this.my_close=function(e){
			if(self.my_working)return;
			self.my_working=true;
			var val=$(this).parent("."+self.value_class).data('val');
			self.my_debug("Close",val);
			if(typeof self.value[val]!='undefined'){
				delete self.value[val];
				$("#"+self.div_id+" input[data-name='"+self.name+"'][value='"+val+"']").remove();
				self.my_debug("New values",self.value);
				$("#"+self.div_id+" ul li[data-value='"+val+"']").removeClass(self.active_class);
				$(this).parent("."+self.value_class).fadeOut(self.duration,function(){
					$(this).remove();
					self.my_working=false;
					self.val_c--;
					if(self.val_c==0){
						$("#"+self.div_id+" .my_dropdown_empty").fadeIn();
						//$("#"+self.div_id+" ."+self.value_class).html(self.options.choose_value);
					}
				});
			}
		};
		this.my_click=function(e){
			if(self.my_working)return;
			self.my_working=true;
			if($(this).hasClass('my_dropdown_filter')){
				self.my_working=false;
				return;
			}
			if(self.multiple){
				if(self.options.max_c!='')
				if(self.val_c==self.options.max_c){
					self.my_working=false;
					alert(self.options.max_sel);
					return;
				}
				var text=$(this).text();
				var val=$(this).data('value');
				self.my_debug("Click",{text:text,val:val});
				if(typeof self.value[val]!='undefined'){
					self.my_debug("Already selected");
					self.my_working=false;
					return;
				}
				$(this).addClass(self.active_class);
				self.value[val]=text;
				var input_html='<input type="hidden" name="'+self.name+'[]" data-name="'+self.name+'" value="'+val+'"/>';
				$("#"+self.div_id+" .my_dropdown_values").append(input_html);
				var html=self.val_div;
				html=html.replace(/{val}/g,val);
				html=html.replace(/{text}/g,text);
				if(self.val_c==0){
					$("#"+self.div_id+" .my_dropdown_empty").hide();
					$("#"+self.div_id+" ."+self.values_class).append(html);
				}else {
					$("#"+self.div_id+" ."+self.values_class).append(html);
				}
				self.bind_close();
				self.val_c++;
				self.my_working=false;
				if(typeof self.my_set_value12=='undefined')
				$("#"+self.div_id+" .my_dropdown_down_span").trigger('click');
			}else {
				var text=$(this).text();
				var val=$(this).data('value');
				var html=$(this).html();
				self.text=text;
				self.value=val;
				if(self.options.icon==1){

					$("#"+self.div_id+" .my_dropdown_value").html(html);
				}
				else $("#"+self.div_id+" .my_dropdown_value").text(text);
				$("#"+self.id).val(val);
				self.my_debug("select element",{text:text,val:val});
				$("#"+self.div_id+" .my_dropdown_ul li").removeClass(self.active_class);
				$(this).addClass(self.active_class);
				self.my_working=false;
				//if($(this).parents("."))
				if(typeof self.my_set_value12=='undefined')
					$("#"+self.div_id+" button .fa").trigger('click');
			}
			self.trigger_change();
		};
		this.my_show=function(){
			if(self.my_working)return;
			self.my_working=true;
			var this_id=$(this).attr('id');
			$(".jscript_dropdown_div").each(function(i,v){
				var sh=$(v).data('showed');
				var id=$(v).attr('id');
				if((id!=this_id)&&sh==1){
					$(v).find(".my_dropdown").trigger('click');
				}
			});
			var sh=$("#"+self.div_id).data('showed');
			self.my_debug("sh",sh);
			if(self.animation=='fadein'){

				if(sh==0){
				$("#"+self.div_id+" .my_dropdown_ul").fadeIn(self.duration,function(){
					self.my_working=false;
						sh=1;

						var w=$("#"+self.div_id+" .my_dropdown_ul ").width();
						$("#"+self.div_id+" .my_dropdown_ul ").width(w);

					$("#"+self.div_id).data('showed',sh);
				});
				} else {
					$("#"+self.div_id+" .my_dropdown_ul").fadeOut(self.duration,function(){
						self.my_working=false;
							sh=0;

						$("#"+self.div_id).data('showed',sh);
					});

				}
			}else if(self.animation=='slideToggle'){

					$("#"+self.div_id+" .my_dropdown_ul").slideToggle(self.duration,function(){
						self.my_working=false;
							if(sh==0)sh=1;
							else sh=0;
							var w=$("#"+self.div_id+" .my_dropdown_ul ").width();
							$("#"+self.div_id+" .my_dropdown_ul ").width(w);

						$("#"+self.div_id).data('showed',sh);
					});
			}



		};

		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log("***ModuleFormMainSCript *** \n"+t,o);
				}
			}
		};
	this.init(o);

};
})(jQuery);