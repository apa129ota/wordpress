(function($) {
	wpMyModuleNewFormMedia=function(o){
		var self;
		this.debug=true;
		this.options={};
		this.id='';
		this.name='';
		this.div_id='';
		this.my_working=false;
		this.values={};
		this.duration=400;
		this.active_class='my_radio_list_ul_li_active';
		this.button_class='my_media_button';
		this.prev_send='';
		this.prev_insert='';
		this.media;
		this.frame='select';
		this.values={};
		this.pre_options={
			short_div:'<div data-id="{id}" data-type="{type}" class="my_jscript_media_div"><i class="fa {fa}"></i></a><span>{title}</span><i data-id="{id}" class="fa fa-times"></i></div>',
			mediaNew_div:'<div data-id="{id}" data-type="{type}" class="my_jscript_media_div attachment-preview js--select-attachment type-video subtype-mp4 landscape"><div class="thumbnail"><div class="centered"><img src="{src}" class="icon" draggable="false" alt=""></div><div class="filename"><div>{file}</div></div></div></div>',
			values_class:'.my_media_values',
			item_class:'.my_jscript_media_div',
			add_html:1
		};
		self=this;
		this.init=function(o){
			if(typeof o.my_debug!='undefined'){
				if(!o.my_debug){
					self.debug=false;
				}
			}
			self.debug=true;
			self.my_debug("Options",o);
			self.options=o;
			self.id=self.options.id;
			self.name=self.options.name;
			self.div_id=self.options.div_id;
			self.options=$.extend( self.pre_options,self.options);
			var options={
					title:self.options.media_title,
					multiple:self.options.multiple,
					frame:self.frame,
					button:{text:self.options.button_text}
				};
			if(self.options.filter_type!='undefined'){
				options.library={};
				options.library.type=self.options.filter_type;
			}
			self.media=new wp.media(options);
			self.media.on('select',self.my_send_attachment);
			$("#"+self.div_id+" ."+self.button_class).click(self.my_open_media);
			$(document).on('click','#'+self.div_id+' .fa-times',self.my_remove);
		};
		this.my_remove=function(e){
			var id=$(this).attr('data-id');
			self.my_debug("Remove",id);
			if(typeof self.values[id] !=undefined){
				delete self.values[id];
				$("#"+self.div_id+" input[type='hidden'][value='"+id+"']").remove();
				$("#"+self.div_id+" "+self.options.item_class+"[data-id='"+id+"']").remove();

			self.trigger_change();
			}
		}
		this.my_open_media=function(e){
			e.preventDefault();
			if(typeof wp.media.editor.send.attachment!='undefined'){
				self.prev_send=wp.media.editor.send.attachment;

			}
			if(typeof wp.media.editor.insert!='undefined'){
				self.prev_insert=wp.media.editor.insert;
			}

			//wp.media.editor.send.attachment=self.my_send_attachment;
			self.media.open();
		};
		this.my_send_attachment=function(){

			var att=self.media.state().get('selection').toJSON();
			self.my_debug('Att',att);
			if(!self.options.multiple){
				$("#"+self.div_id+" "+self.options.values_class).html('');
				self.values={};
			}
			$.each(att,function(i,v){
				var title=v.title;
				var id=v.id;
				self.values[id]=v;
				//if(self.options.add_html==1){
					var icon=v.icon;
					var html=self.options.short_div;
					html=html.replace(/\{id\}/g,id);
					html=html.replace(/\{title\}/g,title);
					html=html.replace(/\{type\}/g,v.type);
					html=html.replace(/\{src\}/g,icon);
					var type="video-camera";
					if(v.type=="video"){
						
					}
					html=html.replace(/\{fa\}/g,'fa-'+type);
					$("#"+self.div_id+" "+self.options.values_class).append(html);
				//}
				var input='<input type="hidden" name="'+self.name+'[]" value="'+id+'"/>';
				$("#"+self.div_id+" "+self.options.values_class).append(input);


			});

			self.trigger_change();
			if(self.prev_send!=''){
				wp.media.editor.send.attachment=self.prev;
			}
		};
		this.trigger_change=function(){
			var value=self.values;
			var obj=[self,value,$("#"+self.div_id).data('base-name')];
			self.my_debug("Change media",obj);
			$("#"+self.div_id).trigger('my_change',obj);
		};
		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log("***ModuleFormMainSCript *** \n"+t,o);
				}
			}
		};
	this.init(o);

};
})(jQuery);