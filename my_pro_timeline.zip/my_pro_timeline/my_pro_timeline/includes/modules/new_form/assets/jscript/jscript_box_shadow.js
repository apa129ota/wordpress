/**
 * Box shadow jscript
 */
/**
 * Jscript border
 */
(function($) {
	wpMyModuleNewFormBoxShadow=function(o){
		var self;
		this.debug=true;
		this.options={};
		this.id='';
		this.name='';
		this.div_id='';
		this.my_working=false;
		this.multiple=false;
		this.has_unit=false;
		this.baseName="";
		this.value='';
		this.unit='';
		this.units={};
		this.preview_css_sel='';
		this.check={};
		this.values={};
		this.onHover=false;
		this.myElements={};
		this.myHiddenElements;
		this.cssValues=[];
		this.allCss="";
		this.allCssArr=[];
		this.myDisableChange=false;
		this.myEditId="";
		this.suffixName="";
		this.cssPrefix=["","-webkit-","-moz-"];
		self=this;
		
		this.init=function(o){
			if(typeof o.my_debug!='undefined'){
				if(!o.my_debug){
					self.debug=false;
				}
			}
			self.debug=true;
			self.my_debug("Box shadow Options",o);
			self.options=o;
			self.id=self.options.id;
			self.name=self.options.name;
			self.div_id=self.options.div_id;
			self.baseName=$("#"+self.div_id).data('name');
			self.baseNameNew=$("#"+self.div_id).data('base-name');
			var name=self.baseName;
			self.suffixName=name.replace(self.baseNameNew,"");
			self.my_debug("Box shadow Sufix name",self.suffixName);
			self.my_debug("Box shadow Name",self.baseName);
			self.my_debug("Box shadow Base name",self.baseNameNew);
			self.preview_css_sel="#"+self.div_id+" .my_new_box_shadow_values div";
			self.myHiddenElements={
					type:self.baseName+"_type",
					h_shadow:self.baseName+"_h_shadow[]",
					v_shadow:self.baseName+"_v_shadow[]",
					blur:self.baseName+"_blur[]",
					spread:self.baseName+"_spread[]",
					color:self.baseName+"_color[]",
					inset:self.baseName+"_inset[]"
					
			}
			self.get_values();
			self.renderValues();
			$("#"+self.div_id+" .my_box_shadow_values").show();
			self.my_debug("Box shadow Border Values",self.values);
			self.idHover=self.nameBaseNew+'_myOnHover_'+self.suffixName+'_id';
			self.idInset=self.nameBaseNew+'_inset_'+self.suffixName+'_id';
			$("#"+self.div_id+" #"+self.idInset).change(function(e){
				if(self.myDisableChange)return;
					if($(this).is(":checked")){
					 self.value[self.myEditId].inset=1;
					 self.my_debug("Box shadow On inset");
					}else {
					self.my_debug("Box shadow off inset");	
						self.value[self.myEditId].inset=0;	
					}
					self.generate_css();
					self.trigger_change();
				}
			);
			$("#"+self.div_id+" .my_add_box_shadow_button").on('click',function(){
				var obj={};
				if($("#"+self.div_id+" #"+self.idInset).is("checked")){
					obj.inset=1;
				}else obj.inset=0;
				var val='';
				$.each(self.myElements,function(i,v){
					if(i!='inset'&&i!='myOnHover'){
						var objEl=self.myElements[i];
						var scr=$(objEl).data('my-script');
						self.my_debug("Box shadow Get value of object",{i:i,v:v});
							if(typeof scr!='undefined'){
								val=scr.get_value();
								self.my_debug("Box shadow Val",val);
							}else val='';
							obj[i]=val;
							self.trigger_change();
					}
				});
				self.my_debug("Box shadow Obj",obj);
				var i=self.value.length;
				self.value[self.value.length]=obj;
				self.my_debug("Box shadow Values",self.value);
				self.myEditId=i;
				self.generate_css();
				self.renderValues();
				self.trigger_change();
			});
			$("#"+self.div_id+" #"+self.idHover).change(function(e){
				if(self.myDisableChange)return;
				if($(this).is(":checked")){
					self.my_debug("Box shadow On hover");
					self.onHover=1;
				}else {
					self.my_debug("Box shadow Off hover");
					self.onHover=0;
				}
				self.mySetHiddenValues();
				self.generate_css();
				self.trigger_change();
			});
			$("#"+self.div_id).siblings(".my_form_element_display_inline").find(".my_new_module_element ").each(function(i,v){
				var n=$(v).data('base-name');
				n=n.replace(self.baseNameNew+"_","");
				 $(v).on('my_change',self.my_change);
				 self.myElements[n]=v;
			});
			self.my_debug("Box shadow Elements",self.myElements);
			$("#"+self.div_id).data('my-script',this);
			$(document).on('click','#'+self.div_id+" .my_edit_box_shadow",function(e){
				var i=$(this).parent('li').data('i');
				i=parseInt(i);
				var val=self.value[i];
				self.my_debug("Edit i",{i:i,val:val});
				self.myEditId=i;
				self.mySelectValue(i);
				//self.mySetHiddenValues();
				
			});
			$(document).on('click','#'+self.div_id+" .my_delete_box_shadow",function(e){
				var i=$(this).parent('li').data('i');
				i=parseInt(i);
				var val=self.value[i];
				self.my_debug("Box shadow Delete i",{i:i,val:val});
				var tmpArr=[];
				$.each(self.value,function(i1,v1){
					if(i1!=i)tmpArr[tmpArr.length]=v1;
				});
				
				self.my_debug("Box shadow New arr",tmpArr);
				self.value=tmpArr;
				self.generate_css();
				self.renderValues();
				self.mySetHiddenValues();
				$(this).parent('li').remove();
			});
			$("#"+self.div_id).data('my-script',this);	
		},
		this.mySetHiddenValues=function(){
			var html="";
			if(self.onHover){
				html+='<input type="hidden" name="'+self.myHiddenElements.type+'" value="hover"/>';
			}
			$.each(self.value,function(i,v){
				$.each(v,function(i1,v1){
					var n=self.myHiddenElements[i1];
					html+='<input type="hidden" name="'+n+'" value="'+v1+'"/>';
				});
				});
			
			$(".my_box_shadow_hidden").html(html);
		},
		this.mySelectValue=function(i){
			self.myDisableChange=true;
			var val=self.value[i];
			$.each(val,function(i,v){
				var obj=self.myElements[i];
				var scr=$(obj).data('my-script');
				self.my_debug("Box shadow set value",{i:i,v:v});
				if(i=="inset"){
					if(v==1){
						$("#"+self.div_id+" #"+self.nameBaseNew+"_inset"+self.suffixName+"_id").prop("checked",true);
						
					}
				}else {
					if(typeof scr!='undefined'){
						scr.set_value(v);
					}
				}
			});
			self.myDisableChange=false;
		},
		this.my_change=function(e,obj,val,v1){
			if(self.myDisableChange)return;
			e.preventDefault();
			var div_id=self.div_id;
			//var baseName=$("#"+div_id).data('name');
			var name=v1.replace(self.baseNameNew+"_","");
			self.my_debug("Box shadow Change",{obj:obj,val:val,v1:v1,name:name,baseName:self.baseNameNew});
			//var name=obj.name;
			var css='';
			var values={};
			self.my_debug("Box shadow Edit id",{id:self.myEditId,val:self.value[self.myEditId]});
			if(self.myEditId!==""){
				//if(typeof self.value[self.myEditId][name]!='undefined'){
					self.value[self.myEditId][name]=val;
				
				var $el=$("#"+self.div_id+" input[type='hidden'][name='"+self.myHiddenElements[name]+"[]']");
				$.each($el,function(i1,v1){
					if(i1==self.myEditId){
						$(v1).val(val);
					}
				});
				//self.mySetHiddenValues();
				self.generate_css();
				self.trigger_change();
				}
			//}
			
			/*$("#"+self.div_id).siblings(".my_form_element_display_inline").find(".my_new_module_element").each(function(i,obj){
				
			});*/
			
			//self.get_values();
			//self.generate_css();
			//self.trigger_change();
		};
		this.get_el_values=function(){
			var css='';
			var values={};
			
			$("#"+self.div_id).siblings(".my_form_element_display_inline").find(".my_new_module_element ").each(function(i,obj){
				var n=$(obj).data('base-name');
				var v;
				self.myElements[n]=v;
				if(n.indexOf('border_type')!=-1){
					v=$(obj).find("select").val();
				}else v=$(obj).data('my-script').get_value();
				self.my_debug("Box shadow Get value",{n:n,v:v});
				if(n.indexOf('border_width')!=-1){
					values['width']=v;
				}else if(n.indexOf('border_color')!=-1){
					values['color']=v;
					if(v.indexOf(",")!=-1){
						values['color']='rgba('+v+')';
					}
				}else {
					values['type']=v;
				}
			});
			self.my_debug("Box shadow elements",self.myEelements);
			css=values['width']+' '+values['type']+' '+values['color'];
			return css;
		};
		this.set_value=function(value){
			if(value=="none"){
				self.value=[];
				self.generate_css();
				self.renderValues();
				self.mySetHiddenValues();
					
			}else {
			var values= $.map(value, function(val, ind) {
				if(ind!='type')
			    return [val];
			});
			self.my_debug('jscript box shadow set value',{value:value,values:values});
			self.value=values;
			var is=$("#"+self.div_id+" #"+self.idHover).find('checkbox').is(":checked");
			if(typeof value.type!='undefined'){
				self.onHover=1;
				if(!is){
					$("#"+self.div_id+" #"+self.idHover).find('checkbox').prop("checked",true);
					//$("#"+self.div_id+" #"+self.idHover).find('checkbox').is(":checked");
					
				}
				
			}else {
				if(is){
					$("#"+self.div_id+" #"+self.idHover).find('checkbox').prop("checked",false);
				}
			}
			self.generate_css();
			self.renderValues();
			self.mySetHiddenValues();
			}
			/*if(typeof value=='undefined'){
				$("#"+self.div_id+" .my_border_check").each(function(i,v){
					var key=$(v).data('key');
					var name=self.name+'_'+$(v).data('key');
					self.my_debug("Set values",{key:key,name:name});
					$(v).prop('checked',false);
						$('input[type="hidden"][name="'+name+'"]').val('');
					
				});
			}else {
				$("#"+self.div_id+" .my_border_check").each(function(i,v){
					var key=$(v).data('key');
					var name=self.name+'_'+$(v).data('key');
					self.my_debug("Set values",{key:key,name:name});
					var v='';
					if(typeof value[key]!='undefined'){
						if(value[key]=='none'){
							$('input[type="hidden"][name="'+name+'"]').val('');
						}
						else $('input[type="hidden"][name="'+name+'"]').val(value[key]);
						
					}else {
						$('input[type="hidden"][name="'+name+'"]').val('');
						
					}
				})
			}
			self.get_values();
			*/
		};
		this.gen_rgba=function(color,t){
			if(color.indexOf('#')===0){
				color=color.substr(1);
			}
			var hex=color;
			var l=color.length;
			if(l==6){
				var ch1=color.substr(0,2);
				var ch2=color.substr(2,2);
				var ch3=color.substr(4,2);
				/*var s1=self.hexdoc(ch1);
				var s2=self.hexdoc(ch2);
				var s3=self.hexdoc(ch3);
				*/
				var s1 = parseInt(hex.substring(0,2), 16);
				var s2= parseInt(hex.substring(2,4), 16);
				var s3= parseInt(hex.substring(4,6), 16);
				var s='rgba('+s1+','+s2+','+s3+','+t+')';
				self.my_debug("s",s);
				return s;
			}else if(l==3){
				var ch1=color.substr(0,1);
				var ch2=color.substr(1,1);
				var ch3=color.substr(2,1);
				var ch11=ch1+ch1;
				var ch22=ch2+ch2;
				var ch33=ch3+ch3;
				//var s1=self.hexdoc(ch11);
				//var s2=self.hexdoc(ch22);
				//var s3=self.hexdoc(ch33);
				var hex=ch11+ch22+ch33;
				var s1 = parseInt(hex.substring(0,2), 16);
				var s2= parseInt(hex.substring(2,4), 16);
				var s3= parseInt(hex.substring(4,6), 16);

				var s='rgba('+s1+','+s2+','+s3+','+t+')';
				self.my_debug("s",s);
				return s;
			}
			else return 'rgba(0,0,0,'+t+')';

		};
		this.generate_css=function(itemClass){
			if(typeof itemClass=='undefined'){
				itemClass="";
			}
			var css="{h_shadow} {v_shadow} {blur} {spread} {color} {inset}";
			var cssValues=[];
			
			$.each(self.value,function(i,v){
				self.my_debug("Box shadow Values",{i:i,v:v});
				var cssValue=css;
				var h_shadow=v.h_shadow;
				var v_shadow=v.h_shadow;
				var blur=v.blur;
				var spread=v.spread;
				var color=v.color;
				var c;
				var colorRgba;
				if(color.indexOf(",")!=-1){
				c=color.split(",");
				
				colorRgba=self.gen_rgba(c[0],c[1]);
				}else colorRgba=color;
				var inset="";
				if(v.inset==1){
				inset="inset";	
				}
				cssValue=cssValue.replace("{inset}",inset);
				
				cssValue=cssValue.replace("{h_shadow}",h_shadow);
				cssValue=cssValue.replace("{v_shadow}",v_shadow);
				cssValue=cssValue.replace("{blur}",blur);
				cssValue=cssValue.replace("{spread}",spread);
				cssValue=cssValue.replace("{color}",colorRgba);
				self.my_debug("Box shadow Css value "+i,cssValue);
				self.cssValues[i]=cssValue;
				
			});
			var allCss=itemClass+" ";
			var sT=0;
			if(self.onHover)self.allClss=":hover\n{";
			else self.allCss="";
			
			allCss+="\n{";
			if(self.cssValues.length>0){
			$.each(self.cssPrefix,function(i1,v1){
				
				$.each(self.cssValues,function(i,v){
					if(i>0){
						allCss+=",";
						allCss+=v;
					}
					else allCss+=v1+"box-shadow:"+v+"";
				});
				allCss+=";\n";
			});
			}
			allCss+="\n}";
			if(itemClass==""){
				$("#"+self.div_id+" .my_box_shadow_css").html('<style type="text/css">'+self.preview_css_sel+allCss+"</style>");
				self.my_debug("Box shadow allCss",allCss);
				self.allCss+=allCss;
			}
			return allCss;
		},
		/*this.set_value=function(o){
			self.my_debug("Value",o);
			self.value=o;
			if(o.type!='undeifned'){
				self.onHover=1;
			}
			self.render_css();
			self.renderValues();
			self.mySetHiddenValues();
		},*/
		this.renderValues=function(){
			var msg=self.options.shadowText;
			var t=1;
			var html="";
			$.each(self.value,function(i,v){
				
				html+='<li data-i="'+i+'">'+msg+":"+t+'<a href="#javascript" class="my_delete_box_shadow">&nbsp;<i class="fa fa-trash"></i>&nbsp;</a>';
				html+='<a href="#javascript" class="my_edit_box_shadow">'+self.options.myEdit+"</a>";
				html+='</li>';
				t++;
			});
			if(html!=""){
				$("#"+self.div_id+" .my_box_shadow_values ul").html(html);
			}
		},
		this.get_values=function(){
			var $elHidden=$("#"+self.div_id+" .my_box_shadow_hidden");
			var valuesObj={};
			self.value=[];
			$.each(self.myHiddenElements,function(i,v){
				if(i=='type'){
					self.onHover=1;
					self.my_debug("On hover");
					$("#"+self.div_id+" input[type='checkbox']").prop('checked',true);
				}else {
					var $el=$("#"+self.div_id+" input[type='hidden'][name='"+v+"']");
					var t=0;
					$.each($el,function(i1,v1){
						var val=$(v1).val();
						self.my_debug("Value",{i:i,val:val});
						if(typeof self.value[t]=='undefined'){
							self.value[t]={};
						}
						self.value[t][i]=val;
						t++;
					});
				}
				
			});
			
			self.my_debug("Box shadow Value",self.value);
			self.generate_css();
			
		};
		this.get_value=function(){
			return self.values;
		};
		this.trigger_change=function(){
			var value=self.values;
			var obj=[self,value,$("#"+self.div_id).data('base-name')];
			self.my_debug("Box shadow Change jscript bx shadow ",obj);
			$("#"+self.div_id).trigger('my_change',obj);
		};
		this.getCss=function(){
			var css=self.allCss;
			return css;
		},
		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log("***ModuleFormBorderScript *** \n"+t,o);
				}
			}
		};
	this.init(o);
	
};
})(jQuery);	
	
		