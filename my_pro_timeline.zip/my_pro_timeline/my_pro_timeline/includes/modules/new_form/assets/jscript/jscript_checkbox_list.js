(function($) {
	wpMyModuleNewFormCheckboxList=function(o){
		var self;
		this.debug=true;
		this.options={};
		this.id='';
		this.name='';
		this.div_id='';
		this.my_working=false;
		this.values={};
		this.filter=false;
		this.duration=400;
		this.active_class='my_checkbox_list_ul_li_active';
		this.check_class='my_checkbox_list_check';
		self=this;
		this.init=function(o){
			if(typeof o.my_debug!='undefined'){
				if(!o.my_debug){
					self.debug=false;
				}
			}
			self.my_debug("Options",o);
			self.options=o;
			self.id=self.options.id;
			self.name=self.options.name;
			self.div_id=self.options.div_id;
			
			$("#"+self.div_id+" input[type='checkbox'][name='"+self.name+"']").each(function(i,v){
				var ch=$(v).is(":checked");
				var val=$(v).val();
				var id=$(v).attr('id');
				var l=$("label[data-id='"+id+"']").text();
				self.my_debug("Init values",{ch:ch,id:id,l:l,v:v});
				if(ch){
					self.values[val]=l;
				}
			});
			self.my_debug("Values",self.values);
			$("#"+self.div_id+" ."+self.check_class).click(self.my_check);
			$("#"+self.div_id+" label ").click(self.my_check);
		};
		this.get_value=function(){
			return self.values;
		};
		this.trigger_change=function(){
			var value=self.values;
			var obj=[self,value,$("#"+self.div_id).data('base-name')];
			self.my_debug("Change jscript checkbox list ",obj);
			$("#"+self.div_id).trigger('my_change',obj);
		};
		this.my_check=function(e){
			if(self.my_working)return;
			self.my_working=true;
			var id=$(this).data('id');
			self.my_debug("Click check",id);
			var ch=$("#"+self.div_id+" #"+id).is(":checked");
			self.my_val=$("#"+self.div_id+" #"+id).val();
			self.my_text=$("label[data-id='"+id+"']").text();
			self.my_debug("Ch values text",{ch:ch,my_val:self.my_val,my_text:self.my_text});
			self.my_id=id;
			if(ch){
				//$("#"+self.div_id+" #"+id).removeAttr('checked');
				$("#"+self.div_id+" #"+id).prop("checked",false);
				$("."+self.check_class+"[data-id='"+id+"']").parents('li').removeClass(self.active_class);
				
				$("."+self.check_class+"[data-id='"+id+"'] i.fa").animate({opacity:0},self.duration,function(){
						delete self.values[self.my_val];
						self.my_debug("Values",self.values);
						self.my_working=false;
						var ch1=$("#"+self.div_id+" #"+self.my_id).is(":checked");
						self.my_debug("Checked after",ch1);
						if(typeof self.options.events!='undefined'){
							
							if(typeof self.options.events.check=='function'){
								self.options.events.check(self,ch,self.my_val);
							}
						}	
						
				});
				//$("."+self.check_class+" i.fa").removeClass('fa');
				
			}else {
				//$("#"+self.div_id+" #"+id).removeAttr('checked');
				//$("#"+self.div_id+" #"+id).attr('checked','checked');
				self.values[self.my_val]=self.my_text;
				$("#"+self.div_id+" #"+id).prop("checked",true);
				$("."+self.check_class+"[data-id='"+id+"'] i.fa").animate({opacity:1},self.duration,function(){
						//delete self.values[my_val];
						//self.my_debug("Values",self.my_values);
					    self.my_debug("Values",self.values);
						$("."+self.check_class+"[data-id='"+id+"']").parents('li').addClass(self.active_class);
						self.my_working=false;
						var ch1=$("#"+self.div_id+" #"+self.my_id).is(":checked");
						self.my_debug("Checked after",ch1);
						if(typeof self.options.events!='undefined'){
							if(typeof self.options.events.check=='function'){
								self.options.events.check(self,ch,self.my_val);
							}
						}
				});
			}
			self.trigger_change();
		};
		/**
		 * Set value
		 */
		this.set_value=function(value){
			self.my_debug("Set value",value);
			if(typeof value!='undefined'){
				$("#"+self.div_id+" .my_checkbox_list_ul").find('li').each(function(i,v){
					var val=$(v).find("input[type='checkbox']").val();
					var ch=$(v).find("input[type='checkbox']").is(":checked");
					if(typeof value[val]!='undefined'){
						if(!ch){
							$(v).find("."+self.check_class).trigger('click');
						}
					}else {
						if(ch){
							$(v).find("."+self.check_class).trigger('click');
						}
					}
				});
			}
			self.my_debug("values",self.values);
		},	
		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log("***ModuleFormMainSCript *** \n"+t,o);
				}
			}
		};
	this.init(o);
	
};
})(jQuery);			