<?php
if(!defined('ABSPATH'))die('');
global $wp_my_google_fonts_fonts;
global $wp_my_google_fonts_fonts_full;
global $wp_my_google_fonts_option_name;
global $wp_my_google_fonts_full_optons_name;
$wp_my_google_fonts_option_name='_my_timeline_google_fonts';
$wp_my_google_fonts_full_optons_name='_my_timeline_google_fonts_full';
if(!function_exists('wp_my_google_fonts_get_fonts_arr')){
	function wp_my_google_fonts_get_fonts_arr(){
		$dir=plugin_dir_path(__FILE__).'webfonts.txt';
		$json=file_get_contents($dir);
		$arr=json_decode($json);
		$small_arr=array();
		$full_arr=array();
		$small_arr['default']=__("Default","my_support_theme");
		foreach($arr->items as $key=>$val){
			$small_arr[$val->family]=$val->family;
			$full_arr[$val->family]=$val;
		}
		return $small_arr;	
	}
}
/**
 * Save fonts
 */
if(!function_exists('wp_my_google_fonts_save_fonts')){
function wp_my_google_fonts_save_fonts(){
	global $wp_my_google_fonts_fonts;
	global $wp_my_google_fonts_fonts_full;
	global $wp_my_google_fonts_option_name;
	global $wp_my_google_fonts_full_optons_name;
	
	$dir=plugin_dir_path(__FILE__).'webfonts.txt';
	$json=file_get_contents($dir);
	$arr=json_decode($json);
	$small_arr=array();
	$full_arr=array();
	foreach($arr->items as $key=>$val){
		$small_arr[$val->family]=$val->family;
		$full_arr[$val->family]=$val;	
	}
	update_option($wp_my_google_fonts_option_name,$small_arr);
	update_option($wp_my_google_fonts_full_optons_name,$full_arr);
}}
if(!function_exists('wp_my_google_fonts_get_fonts')){
function wp_my_google_fonts_get_fonts(){
	global $wp_my_google_fonts_fonts;
	global $wp_my_google_fonts_fonts_full;
	global $wp_my_google_fonts_option_name;
	global $wp_my_google_fonts_full_optons_name;
	$wp_my_google_fonts_fonts=get_option($wp_my_google_fonts_option_name);
	$wp_my_google_fonts_fonts_full=get_option($wp_my_google_fonts_full_optons_name);
	
}
}
if(!function_exists('wp_my_goolge_fonts_include_fonts')){
	function wp_my_goolge_fonts_include_fonts($font){
		//$incl=array();
					if(!empty($font)){
					$val=$font;
					$url='http://fonts.googleapis.com/css?family='.urldecode($val);
					wp_enqueue_style('my_google_fonts_'.$val,$url);
					}
		
	}
}