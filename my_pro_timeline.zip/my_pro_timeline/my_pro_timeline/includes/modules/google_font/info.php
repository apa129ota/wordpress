<?php
if(!defined('ABSPATH'))die('');
$info=array(
		'title'=>'Google module',
		'description'=>'Google Font module',
		'class'=>'',

);
return $info;