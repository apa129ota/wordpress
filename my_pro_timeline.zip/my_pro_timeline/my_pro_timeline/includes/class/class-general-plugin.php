<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Framework_Plugin_Class')){
	class Class_My_Framework_Plugin_Class{
		use MyArrayOptions,MyModules,MyLoadFiles,MyWordpressMenu;
		protected $is_admin=false;
		protected $dir;
		protected $url;
		protected $version='1.0';
		protected $css_url;
		protected $images_url;
		protected $jscript_url;
		protected $modules_dir;
		protected $modules_url;
		protected $class_dir;
		protected $controllers_dir;
		protected $models_dir;
		protected $options_dir;
		protected $functions_dir;
		protected $tmp_dir;
		protected $views_dir;
		protected $debug=0;
		protected $backed_class_file;
		protected $backend_class_name;
		protected $admin_pages;
		protected $use_case='my_framework';
		public $scripts_class;
		protected $framework_options;
		protected $loaddedModules;
		protected $options;
		protected $activeController='';
		function __construct($options=array()){
			$this->setOptions($options);
			$this->css_url=$this->url.'assets/css/';
			$this->images_url=$this->url.'assets/images/';
			$this->modules_url=$this->url.'includes/modules/';
			$this->jscript_url=$this->url.'assets/jscript/';
			$this->modules_dir=$this->dir.'includes/modules/';
			$this->class_dir=$this->dir.'includes/class/';
			$this->functions_dir=$this->dir.'includes/functions/';
			$this->options_dir=$this->dir.'includes/options/';
			$this->views_dir=$this->dir.'includes/views/';
			$this->models_dir=$this->dir.'includes/models/';
			$this->controllers_dir=$this->dir.'includes/controllers/';
			$this->tmp_dir=$this->dir.'tmp/';
		}
		/**
		 * Load class depends
		 * @param array $a
		 * @return boolean
		 */
		protected function myLoadDepend($a=array()){
		    $ret=true;
		    if(empty($a)){
		        $array=$this->loadOptions('myDependFile.php');
		    }else $array=$a;
		    if(!empty($array)){
		        foreach($array as $k=>$v){
		            $type=$v['type'];
		            $file=$v['file'];
		            switch($type){
		                case 'class':
		                    $file=$this->getDir('class').$file;
		                    break;
		                case 'model':
		                    $file=$this->getDir('models').$file;
		                    break;
		                    
		            }
		            if(file_exists($file)){
		                
		                require_once $file;
		            }else {
		                $ret=false;
		            }
		        }
		    }
		    return $ret;
		}
		public function getUrl($type='css'){
			switch($type){
			   
				case 'plugin':
					return $this->url;
				break;
				case 'css':
					return $this->css_url;
				break;
				case 'images':
					return $this->images_url;
				break;
				case 'modules':
					return $this->modules_url;
				case 'jscript':
					return $this->jscript_url;
				break;
				default:
					return false;
					//throw new Exception(__("Property with key dont exists","my_support_theme").$type);
					trigger_error(__("Property with key dont exists","my_support_theme").$type,E_NOTICE);
				break;
			}				
						
		}
		public function getDir($type='plugin'){
			switch($type){
				case 'tmp':
					return $this->tmp_dir;
				break;	
				case 'plugin':
				 return $this->dir;
				break;
				case 'class':
					return $this->class_dir;
				break;	 	
				case 'controllers':
					return $this->controllers_dir;
				break;
				case 'modules':
					return $this->modules_dir;
				break;
				case 'models':
					return $this->models_dir;
				break;
				case 'functions':
					return $this->functions_dir;
				break;
				case 'views':
					return $this->views_dir;
				break;	
				case 'options':
					return $this->options_dir;
				break;
				default:
					trigger_error(__("Property with key dont exists","my_support_theme").$type,E_NOTICE);
					return false;
					//throw new Exception(__("Property with key dont exists","my_support_theme").$type);
				break;						
			}
		}
		/**
		 * Init class when plugin is created
		 * @param array $options
		 */
		protected function init($options=array()){
		    if(!empty($options['debug'])){
		        $this->debug=1;
		    }
		    $this->getModules($this->modules_dir);
		    $this->loadPluginOptions();
		    
		    $this->myAddMenu($this, $this->options_dir,true);
		    $this->loadModules();
		    
			
		}
		/**
		 * Load enabled options this is set
		 * in the array key enabled_modules in
		 * plugin_options.php
		 */
		protected function loadModules(){
		    $enabled_modules=$this->loaddedModules['options']->getOptionByKey('enabled_modules');
		    self::debug1("enabled_modules",$enabled_modules);
		    if(!empty($enabled_modules)){
		        foreach($enabled_modules as $key=>$val){
		            $this->createModule($val);
		        }
		    }
		    
		}
		protected function createModule($key){
		    $val=$key;
		    if(!isset($this->modules[$key])){
		        trigger_error(__("Module is not instantiate","my_support_theme").$key,E_USER_NOTICE);
		        return '';
		    }
		    $module_options=array(
		        'dir'=>$this->getDir('modules').$val.'/',
		        'url'=>$this->getUrl('modules').$val.'/',
		        'debug'=>$this->debug,
		        'global_plugin'=>$this
		    );
		    
		    self::debug1("load_module",$val);
		    self::debug1("load_module_options", $module_options,false);
		    $this->loaddedModules[$val]=$this->instantiateModuleClass($val,$module_options);
		    $this->loaddedModules[$val]->init();
		    
		}
		public function getModule($key,$inst=false){
		    if(!$inst){
		        if(!isset($this->loaddedModules[$key])){
		            trigger_error(__("Module is not instantiate : ","my_support_theme").$key,E_USER_NOTICE);
		            return false;
		        }else return $this->loaddedModules[$key];
		    }else {
		        $this->createModule($key);
		        return $this->loaddedModules[$key];
		        
		    }
		}
		protected function my_debug($key,$val,$all){
			if($this->debug){
				Class_My_Module_Debug::add_section($key, $val,$this->use_case,$all);
			}
		}
		protected function initBackend(){
			if(is_admin()){
				
				$file=$this->options_dir.'options.php';
				$this->framework_options=require $file;
				if(empty($this->framework_options['controllers_dir'])){
					$this->framework_options['controllers_dir']=$this->controllers_dir;
				}
				/*if($this->debug){
					Class_My_Module_Debug::add_section('framework_options', $this->framework_options,'my_framework');
				}*/
				$this->my_debug('framework_options', $this->framework_options, false);
				foreach($this->framework_options as $key=>$val){
					if(property_exists($this, $key)){
						$this->$key=$val;
					}
				}
				if(!empty($this->backed_class_file)){
				
					$file=$this->class_dir.$this->backed_class_file;
					require_once $file;
					$options['debug']=$this->debug;
					$options['plugin_object']=&$this;
					foreach($this->framework_options as $key=>$val){
						$options[$key]=$val;
					}
					$this->backend_class=call_user_func($this->backend_class_name.'::singleton',$options);//$this->backend_class_name::singleton($this->framework_options);
					$this->backend_class->init();
				}
				
			}
		}
		public function debug_footer(){
			if($this->debug){
			$debug=Class_My_Module_Debug::get_debug_source($this->use_case);
			?>
			<script type="text/javascript">
				jQuery(document).ready(function($){
					var my_debug_<?php echo $this->use_case?>=<?php echo json_encode($debug);?>;
					if(window.console){
						console.log("Global Debug <?php echo $this->use_case;?>",my_debug_<?php echo $this->use_case?>);
						}
					});
			</script>
			<?php 
			}
		}
		
		private static function debug1($key,$values,$use='my_framework'){
		    if(class_exists('Class_My_Module_Debug')){
		        Class_My_Module_Debug::add_section($key,$values,$use);
    	   }
		}
		/**
		 * Load plugin options
		 * plugin options are loadded when
		 * in options is instantiated plugin options
		 */
		protected function loadPluginOptions(){
		    $file=$this->options_dir.'plugin_options.php';
		    //echo $file;
		    if(file_exists($file)){
		      $module_options=array(
		          'dir'=>$this->getDir('modules').'options/',
		          'url'=>$this->getUrl('modules').'options/',
		          'debug'=>$this->debug,
		          'global_plugin'=>$this,
		          'myIsPlugin'=>$this->myIsPlugin
		      );
		      $options=$this->loadOptions("plugin_options.php");
		      $module_options=array_merge($module_options,$options);
		      self::debug1("module_options", $module_options,false);
		      $this->loaddedModules['options']=$this->instantiateModuleClass('options',$module_options);
		      $this->loaddedModules['options']->init();
		      
		    }
		}
		/**
		 * Get plugin options
		 * @return boolean
		 */
		public function getOptions(){
		  if(isset($this->loaddedModules['options'])){
		      return $this->loaddedModules['options']->getOptions();
		  }else {
		      $msg=__("Options module is not instantiated","my_support_theme");
		      trigger_error($msg,E_USER_NOTICE);
		      return false;
		  
		  }
		}
		/**
		 * get options by key
		 * @param unknown $key
		 * @return boolean
		 */
		public function getOptionByKey($key){
		    if(isset($this->loaddedModules['options'])){
		        return $this->loaddedModules['options']->getOptionByKey($key);
		    }else {
		        $msg=__("Options module is not instantiated","my_support_theme");
		        trigger_error($msg,E_USER_NOTICE);
		        return false;
		    
		    }
		}
		public function addUpdateNewOption($key,$val,$save=false){
		    if(isset($this->loaddedModules['options'])){
		        return $this->loaddedModules['options']->addUpdateNewOption($key,$val,$save);
		    }else {
		        $msg=__("Options module is not instantiated","my_support_theme");
		        trigger_error($msg,E_USER_NOTICE);
		        return false;
		    
		    }
		}
		protected function routePage(){
		    //self::debug("menu_form", $this->adminPages);
		    $c=$this->traitGetPageController();
		    //self::debug("c", $c);
		    $class=$c['class'];
		    $file=$c['file'];
		    $this->loadController('class-my-general-controller.php');
		    $options=array(
		        'is_ajax'=>0,
		        'debug'=>$this->debug,
		        'slug'=>$this->adminPageSlug,
		        'plugin_object'=>&$this,
		        'module'=>$this,
		        'admin_pages'=>$this->adminPages
		    );
		    $this->loadController($file);
		    $this->activeController=new $class($options);
		    $this->activeController->route();
		}
		protected function showPage(){
		 if(!empty($this->activeController)){
		      echo $this->activeController->get_html();
		 }
		}
		public function getProperty($key){
		    if(!isset($this->$key)){
		        trigger_error(__("Property of plugin object is not deifned : ","my_support_theme").$key,E_USER_NOTICE);
		    }else return $this->$key;  
		}
}
}