<?php
if(!trait_exists('MyTraitRecaptcha')){
    trait MyTraitRecaptcha{
        protected $myRecapcthaPubKey;
        protected $myRecapcthaPriKey;
        protected $myRecaptchaVerifyUrl="https://www.google.com/recaptcha/api/siteverify";
        function myTraitSetRecaptchaKeys($pub,$pri){
            $this->myRecapcthaPubKey=$pub;
            $this->myRecapcthaPriKey=$pri;
            
        }
        public function checkRecaptcha($response){
            $params['body']=array(
                'secret'=>$this->myRecapcthaPriKey,
                'response'=>$response
            );
            $ret=wp_remote_post($this->myRecaptchaVerifyUrl,$params);
            if(is_wp_error($ret)){
                $errStr=__("General Error","my_support_theme");
                
                return false;
            }else {
                if($ret['response']['code']==200){
                    $obj=json_decode($ret['body']);
                    self::debug("obj",$obj);
                    if(isset($obj->success)){
                        return $obj->success;
                    }else if(isset($obj['success'])){
                        return $obj['success'];
                    }
                    return false;
                }else return false;
            }
        }
    }
}
        
if(!trait_exists('MyTraitFormDataValidate')){
    trait MyTraitFormDataValidate{
    protected $traitFormDataSent;
    protected $traitFormHasError=false;
    protected $traitFormRules;
    protected $traitFormErrors=array();
    protected $traitFormOnlyFirst=true;
    protected $traitFormErrorsMsgs;
    protected function traitFormGetErrors(){
        if($this->traitFormOnlyFirst){
            return $this->traitFormErrors[0];
        }else return $this->traitFormErrors;
    }
    private function traitFormAddError($msg){
        $this->traitFormHasError=true;
        $this->traitFormErrors[]=$msg;
        
    }
    protected function setTraitRules($rules=array()){
        $this->traitRules=$rules;
        $this->traitHasError=false;
    }
    protected function traitFormCheckData($data=array(),$filter=true){
       $retData=array();
       $this->traitFormErrorsMsgs==array(
           'required'=>__("Field {1} is required !","my_support_theme"),
           'maxLength'=>__("Field {1} maximum lenght is {2} !","my_support_theme"),
       );
       foreach($this->traitRules as $k=>$v){
           $error=false;
           $val='';
           $label="";
           if(!empty($v['label']))$label=$v['label'];
           if(!empty($data[$k]))$val=$data[$k];
           if(!empty($v['required'])){
               if($val===""){
                   $error=true;
                   $msg=$this->traitFormErrorsMsgs['required'];
                   $msg=str_replace('{1}', $label, $msg);
                   $this->traitFormAddError($msg);
                   if($this->traitFormOnlyFirst){
                       return true;
                   }
               }
           }
           
           if(!empty($v['maxLength'])){
               if(strlen($val)>$v['maxLength']){
                   $msg=$this->traitFormErrorsMsgs['maxLength'];
                   $msg=str_replace('{1}', $label, $msg);
                   $msg=str_replace('{2}', $v['maxLength'], $msg);
                   $this->traitFormAddError($msg);
                   if($this->traitFormOnlyFirst){
                       return true;
                   }
               }
           }
       }
       return $this->traitFormHasError;
        
    }
    }
}
    
if(!trait_exists('MyTraitDebug')){
    trait MyTraitDebug{
        static function myTraitDebug($key,$val,$class=''){
            $use='myTrait'.$class;
            if(class_exists('Class_My_Module_Debug')){
                Class_My_Module_Debug::add_section($key, $val,$use);
            }
        }
    }
}
if(!trait_exists('MyOtherWordpressTraits')){
    trait MyOtherWordpressTraits{
        use MyTraitDebug;
        //protected $post_types=array()l
        private $myTraitName='MyOtherWordpressTraits';
        public function getPostTypes(){
            $this->post_types=array(
                'post'=>__("Post","my_support_theme")
            );
            $args = array(
                'public'   => true,
                '_builtin' => false
            );
            
            $output = 'objects'; // names or objects, note names is the default
            $operator = 'and'; // 'and' or 'or'
            
            $post_types = get_post_types( $args, $output, $operator );
            foreach($post_types as $k=>$v){
                $post_types[$k]=$v;
                
            }
            self::myTraitDebug("post_types", $post_types,$this->myTraitName);
            return $post_types;
        }
    }
    
}
if(!trait_exists('MyWordpressAssets')){
    /**
     * Wordpress Assets
     * include assets from the module specifynig array of scripts
     * @author tiw126itwa
     *
     */
    trait MyWordpressAssets{
        use MyTraitDebug;
        //use MyTraitDebug;
        protected $assetsIsAdmin;
        protected $assets;
        private $myTraitName='MyWordpressAssets';
        /**
         * called from module to set assets
         * @param string $admin
         * @param array $assets
         * head scripts footer
         * head callback
         */
        protected function addAssets($admin=true,$assets=array()){
            $this->assetsIsAdmin=$admin;
            $this->assets=$assets;
            self::myTraitDebug('assets', $assets,$this->myTraitName);
            if($this->assetsIsAdmin){
                add_action('admin_head', array(&$this,'myTraitHead'));
                add_action('admin_footer', array(&$this,'myTraitFooter'));
                add_action('admin_enqueue_scripts',array($this,'myTraitScripts'));
            }else {
                add_action('wp_head', array(&$this,'myTraitHead'));
                add_action('wp_footer', array(&$this,'myTraitFooter'));
                add_action('wp_enqueue_scripts',array($this,'myTraitScripts'));
            }
        }
        /**
         * trait is empty
         */
        private function myTraitIsEmpty($key,$val,$ret=""){
            if(!empty($val[$key])){
                return $val[$key];
            }
            return $ret;
        }
        /**
         * 
         * @param unknown $key
         * @param unknown $val
         * @param string $isFooter
         */
        private function myTraitInclude($key,$val,$isFooter=false){
            if(!isset($val['type'])){
                self::myTraitDebug('error_include_trait_assets', $val);
                trigger_error(__("Error myWordpressAssets type is not specified"),E_USER_NOTICE);
                return false;
            }
            $id='';
            $class='';
            $id=$this->myTraitIsEmpty('id',$val);
            $class=$this->myTraitIsEmpty('class',$val);
            $value=$this->myTraitIsEmpty('value',$val);
            $file=$this->myTraitIsEmpty('file',$val);
            $func=$this->myTraitIsEmpty('callback', $val);
            $action=$this->myTraitIsEmpty('actions', $val);
            if(!empty($func)){
                $value=call_user_func($func);
            }else if(!empty($action)){
                $args=$this->myTraitIsEmpty('args', $val,array());
                ob_start();
                do_action($action,$args);
                $value=ob_get_clean();
            }
            else if(!empty($file)){
                    if(file_exists($file)){
                        ob_start();
                        require $file;
                        $value=ob_get_clean();
                    }else {
                        trigger_error(__("Error myWordpressAssets file not exists").$file,E_USER_NOTICE);
                        self::myTraitDebug('file_dont_exists', $file,$this->myTraitName);
                    }
                }
            switch($val['type']){
                case 'url':
                    $subtype=$val['subtype'];
                    $url=$this->myTraitIsEmpty('url', $val);
                    
                    switch($subtype){
                        case 'css':
                            $media=$this->myTraitIsEmpty('media', $val);
                            ?>
                       			<link rel="stylesheet" href="<?php echo $url;?>" type="text/css" class="<?php echo $class;?>" id="<?php echo $id?>" media="<?php echo $media;?>"/>
                            <?php 
                        break;    
                        case 'script':
                            ?>
                        		<script type="text/javascript" src="<?php echo $url;?>"></script>    
                            <?php 
                        break;    
                        
                    }
                break;    
                case 'css':
                    ?>
                    <style type="text/css" class="<?php echo $class;?>" id="<?php echo $id?>">
                        <?php echo $value;?>
                    </style>
                    <?php 
                break; 
                case 'script':
                    ?>
                    <script type="text/javascript" class="<?php echo $class;?>" id="<?php echo $id?>">
                    <?php echo $value;?>
                    </script>
                    <?php 
                break;
            }
            
            
            
        }
        /**
         * enqueue scripts
         */
        public function myTraitScripts(){
            if(!empty($this->assets['scripts'])){
                if(!empty($this->assets['scripts']['wordpress'])){
                    foreach($this->assets['scripts']['wordpress'] as $key=>$val){
                        if(is_array($val)){
                            
                        }else wp_enqueue_script($val);
                    }
                }
                if(!empty($this->assets['scripts']['other'])){
                    foreach($this->assets['scripts']['other'] as $key=>$val){
                        if(is_array($val)){
                        }    
                        else wp_enqueue_script($key,$val);
                    }
                }
            }
            if(!empty($this->assets['styles'])){
                if(!empty($this->assets['styles']['wordpress'])){
                    foreach($this->assets['sstyles']['wordpress'] as $key=>$val){
                        if(is_array($val)){
                            
                        }else wp_enqueue_style($val);
                    }
                }
                if(!empty($this->assets['styles']['other'])){
                    foreach($this->assets['styles']['other'] as $key=>$val){
                        if(is_array($val)){
                        }
                        else wp_enqueue_style($key,$val);
                    }
                }
            }
            if($this->assetsIsAdmin){
                if(method_exists($this, 'adminScripts')){
                    $this->adminScripts();
                }
            }else {
                if(method_exists($this, 'frontScripts')){
                    $this->frontScripts();
                }
            }
            if(!empty($this->assets['scripts']['actions'])){
                if(is_array($this->assets['scripts']['actions'])){
                    foreach($this->assets['scripts']['actions'] as $key=>$val){
                        $args=$this->myTraitIsEmpty('args', $val,array());
                        $action=$this->myTraitIsEmpty('action', $val);
                        do_action($action,$args);
                        
                    }
                        
                }else {
                    do_action($this->assets['scripts']['actions']);
                }
            }
                
        }
        /**
         * trait to display footer
         */
        public function myTraitFooter(){
            if(!empty($this->assets['footer'])){
                foreach($this->assets['footer'] as $key=>$val){
                    $this->myTraitInclude($key, $val);
                }
            }
            if($this->assetsIsAdmin){
                if(method_exists($this, 'adminFooter')){
                    $this->adminFooter();
                }
            }else {
                if(method_exists($this, 'frontFooter')){
                    $this->frontFooter();
                }
            }
        }
        /**
         * Add header to page or forntend
         */
        public function myTraitHead(){
            if(!empty($this->assets['head'])){
                foreach($this->assets['head'] as $key=>$val){
                            $this->myTraitInclude($key, $val);
                }
            }
            if($this->assetsIsAdmin){
                if(method_exists($this, 'adminHead')){
                    $this->adminHead();
                }
            }else {
                if(method_exists($this, 'frontHead')){
                    $this->frontHead();
                }
            }
        }
        
    }
}
        
if(!trait_exists('MyWordpressMenu')){
    /**
     * Wordpress menu
     * @author tiw126itwa
     *
     */
    trait MyWordpressMenu{
        protected $adminPages;
        protected $frontPages;
        
        protected $isAdminPage=false;
        protected $adminPageSlug='';
        protected $myModule='';
        protected $isPlugin='';
        protected $myObject='';
        protected $myOptionsDir;
        protected $myPageController=array(   
        );
        protected $myParsedStyles=array();
        protected $myParsedScripts=array();
        
        protected function myAdjustIncludes(){
            if($this->isAdminPage){
                $page=$this->adminPages[$this->adminPageSlug];
                //self::debug('parseStyles',$page['styles']);
                if(!empty($this->global_plugin)){
                    $global=$this->global_plugin;      
                }else $global=$this;
                $check=array('styles','scripts');
                foreach($check as $k1=>$v1){
                if(!empty($page[$v1])){
                   foreach($page[$v1] as $key=>$val){
                      // echo $key.'='.$val.'<br/>';
                       if(preg_match('/\{.*\}/ims', $val,$matches)){
                           // print_r($matches);
                            $keyU=$matches[0];
                            
                           // echo 'key='.$keyU;
                            switch($keyU){
                               case '{modules_url}':
                                    $url=$global->getUrl('modules');
                               break;
                               case '{css_url}':
                                    $url=$global->getUrl('css');
                               break;
                               case '{jscript_url}':
                                   $url=$global->getUrl('jscript');
                               break;    
                               default:
                                   $url='';
                               break;    
                            }
                            //echo 'url='.$url.'<br/>';
                            if(!empty($url)){
                                $url=str_replace($keyU, $url, $val);
                                if($v1=='styles'){
                                    $this->myParsedStyles[$key]=$url;
                                }else if($v1=='scripts'){
                                    $this->myParsedScripts[$key]=$url;
                                }
                            }
                       }
                   }
                }
                }
            }
        }
        /**
         * Looks obejct for menu.php in files where will find menu items
         * in array with index for menus
         * 'my_form'=>array()
         * 'my_form_child'=>array('parent'=>'my_form');
         * @param unknown $object
         * @param unknown $options_dir
         * @param string $isPlugin
         */
        function myAddMenu(&$object,$options_dir,$isPlugin=false){
            $this->myOptionsDir=$options_dir;
            $this->myObject=$object;
            $this->isPlugin=$isPlugin;
            
            $file=$this->myOptionsDir.'menu.php';
            if(file_exists($file)){
                $menu=require $file;
                if(!empty($menu['admin_pages'])){
                   $this->myPageController=$menu['admin_pages']['controller']; 
                  // $this->adminPages=$menu['admin_pages'];
                   foreach($menu['admin_pages'] as $key=>$val){
                       if($key=='controller')continue;
                       else $this->adminPages[$key]=$val;
                   }
                   $this->myAdjustIncludes();
                   if(method_exists($this, 'parseAdminMenu')){
                       $this->parseAdminMenu();
                   }
                   
                   add_action('admin_menu',array(&$this,'trait_admin_menu'));
                   add_action('admin_head',array(&$this,'trait_admin_head'));
                   add_action('admin_enqueue_scripts', array (&$this,'trait_admin_scripts'));
                   add_action('admin_footer',array(&$this,'trait_admin_footer'));
                   add_action('admin_init',array(&$this,'trait_route'));  
                }
                if(!empty($menu['front_pages'])){
                    $this->frontPages=$menu['front_pages'];
                    if(method_exists($this, 'parseFrontMenu')){
                        $this->parseFrontMenu();
                    }
                    
                    add_action('wp_init',array(&$this,'trait_front_route'));
                    add_action('wp_head',array(&$this,'trait_wp_head'));
                    add_action('wp_enqueue_scripts', array (&$this,'trait_wp_scripts'));
                    add_action('wp_footer',array(&$this,'trait_wp_footer'));
                }
            }
            if(is_admin()){
                $this->myCheckIsAdminPage();
                $this->myAdjustIncludes();
            }else {
                
            }
        }
        protected function myCheckIsAdminPage(){
            if(is_admin()){
                if(!empty($_GET['page'])){
                    $this->adminPageSlug=$_GET['page'];
                    if(isset($this->adminPages[$this->adminPageSlug])){
                        $this->isAdminPage=true;
                    }
                }
            }
            return $this->isAdminPage;
        }
        private function myTraitCheckMethos($method_name){
            if(method_exists($this, $method_name)){
                $this->$method_name();
                return true;
            }
            return false;
        }
        protected function traitGetPageController(){
            return $this->myPageController;
        }
        protected function isEmptyArraySet(&$val,$key,$arr){
            if(!empty($arr[$key])){
                $val=$arr[$key];
            }
        }
        public function trait_front_route(){
            
        }
        public function trait_route(){
            if($this->isAdminPage){
                
                $this->myTraitCheckMethos('routePage');
            }
            
        }
        public function trait_show(){
            $this->myTraitCheckMethos('showPage');
        }
        public function trait_wp_head(){
            
        }
        public function trait_wp_scripts(){
            
        }
        public function trait_wp_footer(){
            
        }
        public function trait_admin_head(){
            if($this->isAdminPage)
            $this->myTraitCheckMethos('admin_head');
        }
        public function trait_admin_scripts(){
            if($this->isAdminPage){
                
                if(!empty($this->myParsedStyles)){
                    foreach($this->myParsedStyles as $k=>$v){
                        wp_enqueue_style($k,$v);
                    }
                }
                if(!empty($this->myParsedScripts)){
                    foreach($this->myParsedScripts as $k=>$v){
                        wp_enqueue_script($k,$v);
                    }
                }
                $this->myTraitCheckMethos('admin_scripts');
            }
        }
        public function trait_admin_footer(){
            if($this->isAdminPage)
            $this->myTraitCheckMethos('admin_footer');
            
        }
        public function trait_admin_menu(){
            $this->myTraitCheckMethos('admin_menu');
            foreach($this->adminPages as $key=>$val){
                $parent='';
                if(!empty($val['parent'])){
                    $parent=$val['parent'];
                }
                $menu_title=$page_title=$val['page_title'];
                $icon='';
                $position=null;
                if(!empty($val['icon']))$icon=$val['icon'];
                if(!empty($val['position']))$position=$val['position'];
                if(!empty($val['menu_title'])){
                    $menu_title=$val['menu_title'];
                }
                $cap=$val['capability'];
                if(strpos($cap,'my_plugin_options_')===0){
                    $opt=str_replace('my_plugin_options_', '', $cap);
                    $cap=$this->global_plugin->getOptionByKey($opt);
                }
                if(empty($parent)){
                    add_menu_page($page_title, $menu_title, $cap, $key,array($this,'trait_show'),$icon,$position);
                }else{
                    add_submenu_page($parent, $page_title, $menu_title, $cap, $key,array($this,'trait_show'));
                }
                
            }
        }
    }
}
if(!trait_exists('MySessions')){
    /**
     * Sesssions
     * @author tiw126itwa
     *
     */
	trait MySessions{
		protected $test_cookie_name='my_test';
		protected $sesssion_vars=array();
		protected $cookie_enabled=true;
		protected $session_name;
		public function startSession(){
			session_start();
		}
		public function setSessionName($name){
			$this->session_name=$name;
			if(!isset($_SESSION[$this->session_name])){
				$_SESSION[$this->session_name]=array();
				$this->sesssion_vars=array();
			}else {
				$this->sesssion_vars=$_SESSION[$this->sesssion_name];
			}
				
		}
		public function setSessionVariable($key,$val,$force=false){
			
			if(!isset($_SESSION[$this->session_name])){
				$_SESSION[$this->session_name]=array();
				$this->sesssion_vars=array();
			}
			if(!isset($_SESSION[$this->session_name][$key])){
				$_SESSION[$this->session_name][$key]=$val;
				$this->sesssion_vars[$key]=$val;
			}else if($force){
				$_SESSION[$this->session_name][$key]=$val;
				$this->sesssion_vars[$key]=$val;
			}
		}
		public function getSessionVar($key){
			if(isset($_SESSION[$this->session_name][$key])){
				return $_SESSION[$this->session_name][$key];
			}else return false;
		}
		public function setTestCookie(){
			if(isset($_COOKIE[$this->test_cookie_name])){
				
				//setcookie($this->test_cookie_name,2,0,'/');
			}else {
				setcookie($this->test_cookie_name,1,0,'/');
			}
		}
		public function setCookie($name,$val){
			setcookie($name,$val,0,'/');
		}
		public function getCookie($name){
			if(isset($_COOKIE[$name])){
				return $_COOKIE[$name];
			}else return false;
		}
		public function isCookiesEnabled(){
			$name=$this->test_cookie_name;
			
			if(isset($_COOKIE[$name])){
				$val=$_COOKIE[$name];
				return true;
				//if($val==2)return true;
			}
			return false;
		}
		public function removeTestCookie(){
			$name=$this->test_cookie_name;
			if(isset($_COOKIE[$name])){
				unset($_COOKIE[$name]);
				setcookie($name,null,-1);
			}	
		}
		
	}
	
}
if(!trait_exists('MyLoadFiles')){
	trait MyLoadFiles{
		public function loadClass($file=''){
			$f=$this->class_dir.$file;
			$this->myLoadFile($f);
		}
		public function loadController($file){
			$f=$this->controllers_dir.$file;
			$this->myLoadFile($f);
			
		}
		public function loadFile($dir,$file){
			$f=$dir.$file;
			$this->myLoadFile($f);
			
		}
		public function loadModel($file){
			$f=$this->models_dir.$file;
			$this->myLoadFile($f);
		}
		
		public function loadOptions($file){
			$f=$this->options_dir.$file;
			//$this->myLoadFile($f);
			if(file_exists($f)){
				return require $f;
			}else {
				$msg=__("File dont exists in dir","my_support_theme").' '.$f;
				trigger_error($msg,E_USER_NOTICE);
			}
		}
		public function loadFunctions($file){
			$f=$this->functions_dir.$file;
			$this->myLoadFile($f);
		}
		private function myLoadFile($f){
			if(file_exists($f)){
				require_once $f;
			}else {
				$msg=__("File dont exists in dir","my_support_theme").' '.$f;
				trigger_error($msg,E_USER_NOTICE);
			}
		}
	}
}
/**
 * Trait singleton
 * @author awa292opa
 *
 */
if(!trait_exists('MySingleton')){
	trait MySingleton
	{
		private static $instance = null;

		public static function singleton($options=array())
		{
			if( self::$instance == null )
			{
				self::$instance = new self($options);
			}
			return self::$instance;
		}
	}
}
if(!trait_exists('MyTraitSingleton')){
	trait MyTraitSingleton
	{
		private static $trait_instance = null;

		public static function singleton()
		{
			if( self::$trait_instance == null )
			{
				self::$trait_instance = new self();
			}
			return self::$trait_instance;
		}
	}
}
/*if(!trait_exists('MyWordpressAdminPageClass')){
	trait MyWordpressAdminPageClass{
		protected $title;
		protected $menu_title;
		protected $capability;
		protected $is_logged;
		protected $styles;
		protected $scripts;
		protected $subpages;
		function __construct($options=array())
	}
}
*/
if(!trait_exists('MyDebug')){
	trait MyDebug{
		static $trait_debug=false;
		static $trait_use_case="";
		static function debug($key,$val,$arr=true){
			if(self::$trait_debug){
			    if(class_exists('Class_My_Module_Debug')){
				    Class_My_Module_Debug::add_section($key, $val,self::$trait_use_case,$arr);
			    }
			    }
		}
		static function setDebugOptions($use_case){
			self::$trait_debug=true;
			self::$trait_use_case=$use_case;
		}
		static function debugFile($key,$title,$var){
			if(self::$trait_debug){
			    if(class_exists('Class_My_Module_Debug')){
			    
				Class_My_Module_Debug::debug_file($key, $title, $var);
			    }
			    }
		}
		static function debugFileClose($key){
			if(self::$trait_debug){
			    if(class_exists('Class_My_Module_Debug')){
			    
			    Class_My_Module_Debug::debug_file_close($key);
			    }
			    }
		}
	}
}
/*
if(!trait_exists('MyGlobalScripts')){
	trait MyGlobalScripts{
		use MySingleton,MyDebug;
		protected $objects;
		protected $includes;
		protected $styles;
		protected $scripts;
		protected $wpscripts=array();
		protected $wpstyles=array();
		protected $wphead=array();
		protected $wpfooter=array();
		protected $keys;
		protected $min=false;
		protected $my_debug=false;
		protected $assets_url;
		//static $debug=false;
		function callOnce($options=array()){
			
			
			$this->objects['fontawesome']=array(
				'css'=>'font-awesome.css',
				'css_min'=>'font-awesome.min.css'	
			);
			$this->objects['fotorama']=array(
				'css'=>'fotorama.css',
				'jscript'=>'fotorama.js'
			);
			$this->objects['flexslider']=array(
				'css'=>'flexslider.css',
				'jscript'=>'jquery.flexslider.js'	
			);
			$this->styles['mCustomScrollBar']='jquery.mCustomScrollbar.css';
			$this->scripts['mCustomScrollBar']='jquery.mCustomScrollbar.js';
			$this->styles['jqueryUi']='jquery-ui.css';
			$this->styles['prettyPhoto']='prettyPhoto.css';
			$this->scripts['prettyPhoto']='jquery.prettyPhoto.js';
			if(is_admin()){
				add_action ( 'admin_head', array (&$this,'admin_head'),PHP_INT_MAX );
				add_action ( 'admin_enqueue_scripts', array (&$this,'admin_scripts'),PHP_INT_MAX );
				add_action('admin_footer',array(&$this,'admin_footer'),PHP_INT_MAX);
			}else {
				add_action ( 'wp_head', array (&$this,'admin_head'),PHP_INT_MAX );
				add_action ( 'wp_enqueue_scripts', array (&$this,'admin_scripts'),PHP_INT_MAX );
				add_action('wp_footer',array(&$this,'admin_footer'),PHP_INT_MAX);
			}
		}
		private function setScriptOptions($options=array()){
			if(!empty($options['min'])){
				$this->min=true;
			}
			if(!empty($options['debug'])){
				//self::$trait_debug=true;
				//self::$trait_use_case=$options['use_case'];
				self::setDebugOptions($options['use_case']);
			}
			if(!empty($options['assets_url'])){
				$this->assets_url=$options['assets_url'];
			}
			//self::debug("instantiate_options",$options,false);
			$this->callOnce();
		}
		
		private function addIncludesObj($include=array()){
			self::debug('add_includes', $include,true);
			if(is_array($include)){
			if(!empty($include)){
				foreach($include as $key=>$val){
					if(!isset($this->includes[$val])){
						$this->includes[$val]=1;
					}
				}
			}
			}else {
				$this->includes[$include]=1;
			}
			self::debug("after_adding", $this->includes,false);
		}
		public function addItem($array){
			if($array['type']=='script'){
				$this->wpscripts[]=$array['handle'];
			}else if($array['type']=='style'){
				$this->wpstyles[]=$array['handle'];
			}else if($array['type']=='head'){
				$this->wphead[]=$array['head'];
			}else if($array['type']=='footer'){
				$this->wpfooter[]=$array['head'];
			}
		}
		static function addWordpressFooter($head){
			$instance=self::singleton();
			$instance->addItem(array('head'=>$head,'type'=>'footer'));
		
		}
		static function addWordpressHead($head){
			$instance=self::singleton();
			$instance->addItem(array('head'=>$head,'type'=>'head'));
				
		}
		static function addWordpressScript($script){
			$instance=self::singleton();
			$instance->addItem(array('handle'=>$script,'type'=>'script'));
			
		}
		static function addWordpressStyle($style){
			$instance=self::singleton();
			$instance->addItem(array('handle'=>$style,'type'=>'style'));
		}
		static function addIncludes($includes=array()){
			$instance=self::singleton();
			$instance->addIncludesObj($includes);
		}
		public function admin_scripts(){
			if(!empty($this->wpscripts)){
				foreach($this->wpscripts as $key=>$val){
					wp_enqueue_script($val);
				}
			}
			if(!empty($this->wpstyles)){
				foreach($this->wpstyles as $key=>$val){
					wp_enqueue_style($val);
				}
			}
			//Class_My_Module_Debug::add_section('includes', $this->includes,$this->use_case,false);
			self::debug('includes', $this->includes,true);
			if(!empty($this->includes)){
				foreach($this->includes as $key=>$val){
					$my_found=false;
					if(array_key_exists($key, $this->objects)){
						$obj=$this->objects[$key];
						$css='';
						$script='';
						if($this->min){
							if(!empty($val['css_min'])){
								$css=$val['css_min'];
							}
						}
						if(empty($css)){
							if(!empty($val['css'])){
								$css=$val['css'];
							}
						}
						$url=$this->getUrl($key, $css);
						$key1=$this->genKey($key,true);
						wp_enqueue_style($key1,$url);
						if(!empty($obj['jscript'])){
							$jscript=$obj['jscript'];
							$url=$this->getUrl($key, $jscript);
							$key1=$this->genKey($key,false);
							wp_enqueue_script($key1,$url);
						}
					}else {
						if(array_key_exists($key, $this->styles)){
							$file=$this->styles[$key];
							$url=$this->getUrl($key, $file,true,false);
							$key1=$this->genKey($key);
							wp_enqueue_style($key1,$url);
						}
						if(array_key_exists($key, $this->scripts)){
							$file=$this->styles[$key];
							$url=$this->getUrl($key, $file,false,false);
							$key1=$this->genKey($key,false);
							wp_enqueue_script($key1,$url);
						}
					}
				}
			}
		}
		private function genKey($key,$style=true){
			if($style){
					$key='my_'.$key.'_style';
			}else {
					$key='my_'.$key.'_script';
			}
			return $key;
		}
		private function getUrl($key,$file,$css=false,$isObject=true){
			$url=$this->assets_url;
			if($isObject){
				$url.='/'.$key.'/';
				$url.=$file;
			}else {
				if($css)
				$url.='css/';
				else $url.='jscript/';
				$url.=$file;
			}
			return $url;
		}
		private function renderItem($val){
			$type=$val['type'];
			if($type=='css'){
				?>
				<style type="text/css"><?php echo $val['value']?></style>
				<?php
			}else if($type='script'){
				?>
				<script type="text/javascript"><?php echo $val['value']; ?></script>
				<?php
			}
									
		}
		public function admin_head(){
			if(!empty($this->wphead)){
				foreach($this->wphead as $key=>$val){
					$this->renderItem($val);
				}
			}
		}
		public function admin_footer(){
			if(!empty($this->wpfooter)){
				foreach($this->wpfooter as $key=>$val){
					$this->renderItem($val);
				}
			}
		}
		
	}
}
*/
if(!trait_exists('MyFiles')){
	trait MyFiles{
		protected $upload_dir;
		protected $base_name;
		protected $upload_name;
		protected $file_name_size=20;
		protected $allowed;
		public function checkUploadFile($name=''){
			if(empty($name))$name=$this->upload_name;
			$file=@$_FILES[$name];
			$tmp_name=$file['tmp_name'];
			if(!empty($allowed['size'])){
				$t=$this->checkSize($tmp_name, $allowed['size']);
				$max_size=$this->fileSizeConvert($allowed['size']);
				if(!$t){
					return __("Maximum Allowed File Size Is ","my_support_theme").' : '.$max_size;
				}
			}
			if(!empty($allowed['types'])){
				//$ext=$this->getFileExt($tmp_name);
				$t=$this->checkExtension($tmp_name,$allowed['types']);
				if(!$t){
					return __("Allowed file extensions are :","my_support_theme").' : '.implode(",",$allowed['types']);
					
				}
			}
			if(!empty($allowed['image'])){
				$t=$this->checkImage($tmp_name);
				if(!$t){
					return __("Allowed file extensions are :","my_support_theme").' : '.implode(",",$allowed['types']);
						
				}
			}
			return true;
			
		}
		public function moveTmpFile($name='',$t_dir=''){
			$tmp_dir=$t_dir;
			if(empty($tmp_dir)){
				$tmp_dir=$this->upload_dir;
			}
			if(empty($name))$name=$this->upload_name;
			$file=@$_FILES[$name];
			$tmp_name=$file['tmp_name'];
			$name=$file['name'];
			$file_name=$this->randomFileName($name);
			$file_full=$tmp_dir.$file_name;
			while(file_exists($file_full)){
				$file_name=$this->randomFileName($name);
				$file_full=$tmp_dir.$file_name;
					
			}	
			self::debug("full_name",$fle_full,false);
			if(!move_uploaded_file($tmp_name, $file_full)){
				return false;
			}
			return $file_name;
			
		}
		function fileSizeConvert($bytes)
		{
			$bytes = floatval($bytes);
			$arBytes = array(
					0 => array(
							"UNIT" => "TB",
							"VALUE" => pow(1024, 4)
					),
					1 => array(
							"UNIT" => "GB",
							"VALUE" => pow(1024, 3)
					),
					2 => array(
							"UNIT" => "MB",
							"VALUE" => pow(1024, 2)
					),
					3 => array(
							"UNIT" => "KB",
							"VALUE" => 1024
					),
					4 => array(
							"UNIT" => "B",
							"VALUE" => 1
					),
			);
		
			foreach($arBytes as $arItem)
			{
				if($bytes >= $arItem["VALUE"])
				{
					$result = $bytes / $arItem["VALUE"];
					$result = str_replace(".", "," , strval(round($result, 2)))." ".$arItem["UNIT"];
					break;
				}
			}
			return $result;
		}
		public function checkSize($file,$size){
			$sizet=filesize($file);
			if($sizet>$size){
				return false;
			}
			return true;
		}
		public function checkExtension($file,$allowed=array()){
			$ext=$this->getFileExt($file);
			if(!in_array($ext, $allowed))return false;
			return true;
		}
		public function checkImage($file){
			if(function_exists('getimagesize')){
				if(@is_array(getimagesize($file))){				
					$image = true;
				} else {
					$image = false;
				}
		}else $image=false;
			return $image;
		}
		
		private function getFileExt($file){
			$this->base_name=basename($file);
			$ext=pathinfo($file,PATHINFO_EXTENSION);
			$ext=strtolower($ext);
			return $ext;
		}
		private function randomFileName($file){
			$ext=$this->getFileExt($file);
			$str=rand(1,9);
			for($i=0;$i<$this->file_name_size;$i++){
				$str.=rand(0,9);
			}
			return $str.'.'.$ext;
		}
	}
}

if(!trait_exists('MyDirectoriesFiles')){
	trait MyDirectoriesFiles{
		static function readDirs($dir){
			$dirs=array();
			if (is_dir($dir)) {
				if ($dh = opendir($dir)) {
					while (($file = readdir($dh)) !== false) {
				
						if(in_array($file,array(".","..")))continue;
						$new_file=$dir.$file;
						if(is_dir($new_file)){
							$dirs[]=$file;
						}	
					}
					closedir($dh);
				}
			}
			return $dirs;		
		}
		static function readFiles($dir,$include=array()){
			$patterns=array();
			$extensions=array();
			foreach($include as $key=>$val){
				if(preg_match_all('/^\*\.([.]+)$/ims', $val,$matches)){
					//print_r($matches);
					$extensions=$matches[1][0];
					//$patterns[]='/[.]*\.'.
				}else {
					$paterns[]=$val;
				}
			}
			//print_r($extensions);
		}
		static function getFileExt($file){
			$arr=explode(".",$file);
			$ext=false;
			if(!empty($arr)){
				foreach($arr as $key=>$val){
					if(!empty($val)){
						$ext=$val;
					}
				}
			}
			return $ext;
		}
	}
}
/**
 * Get all modules traits
 */
if(!trait_exists('MyModules')){
	trait MyModules{
		use MyDirectoriesFiles;
		protected $modules;
		protected $instances;
		static $instance_count=array();
		/**
		 * Get all modules
		 * @param unknown $dir
		 * @throws Exception
		 */
		function getModules($dir){
			$dirs=self::readDirs($dir);
			$file=self::readFiles($dir,array("*.php"));
			//print_r($dirs);
			foreach($dirs as $key=>$val){
				$file=$dir.$val.'/info.php';
				$class_file=$dir.$val.'/class.php';
				$this->modules[$val]['info']=require $file;
				$this->modules[$val]['dir']=$dir.$val.'/';
				if(file_exists($class_file)){
					$this->modules[$val]['class']=$class_file;
				}else {
					//throw new Exception(__("Module has no class.php","my_support_theme").'-'.$val);
					trigger_error(__("Module has no class.php","my_support_theme").'-'.$val,E_USER_NOTICE);
				}
			}
			
		}
		/**
		 * Load module class
		 * @param string $module
		 * @throws Exception
		 */
		function loadModuleClass($module=''){
			if(!empty($this->modules[$module])){
				$file=$this->modules[$module]['class'];
				require_once $file;
			}else {
				//throw new Exception(__("Module has no class.php","my_support_theme").'-'.$module);
				trigger_error(__("Module has no class.php","my_support_theme").'-'.$module,E_USER_NOTICE);
			}
		}
		function loadModuleFile($module,$file,$subdir=''){
			if(!empty($this->modules[$module])){
				$dir=$this->modules[$module]['dir'];
				if(!empty($subdir)){
					$dir.=$subdir.'/';
					
				}	
				$dir.=$file;
				if(file_exists($dir)){
					require_once $dir;
					
				}else {
					trigger_error(__("Module has no file ","my_support_theme").'-'.$module.' '.$dir,E_USER_NOTICE);
						
				}
				
			}
		}
		/**
		 * Get module Class
		 * @param unknown $module
		 */
		private function getModuleClass($module){
			$class='Class_My_Module_'.ucfirst($module);
			return $class;
		}
		/**
		 * instantiate module class
		 * @param string $module
		 * @param unknown $options
		 * @return unknown
		 */
		function instantiateModuleClass($module='',$options=array()){
			$this->loadModuleClass($module);
			$module_class=$this->modules[$module]['info']['class'];
			if(empty($module_class)){
				$module_class=$this->getModuleClass($module);
			}
			$instance=new $module_class($options);
			if(!isset(self::$instance_count[$module])){
				self::$instance_count[$module]=1;
			}else self::$instance_count[$module]++;
			$i=self::$instance_count[$module];
			$this->instances[$module][$i]=&$instance;
			return $instance;
			
		}
	}
}


/**
 * Trat array options to function
 * @author awa292opa
 *
 */
if(!trait_exists('MyArrayOptions')){
	trait MyArrayOptions{
		
		public function setOptions($options=array()){
			$class=get_class();
		//echo 'Class '.$class;
			if(!empty($options)){
				foreach($options as $key=>$val){
					if(!property_exists($class, $key)){
						$msg=__("Class has no defined property ","my_support_theme").' '.$key.' - '.$class;
						//throw new \Exception($msg,8000);
						//trigger_error($msg,E_USER_NOTICE);
					}
					$this->$key=$val;
				}
			}
		}
		public function __toString(){
			ob_start();
			foreach($this as $key=>$val){
			?>
				<h4><?php echo $key;?></h4>
				<pre><?php print_r($val);?></pre>
				<?php 
			}
			$html=ob_get_clean();
			return $html;
		}
		public function myDebug($key,$var,$arr=true){
			if(!isset($this->debug_arr[$key])){
				if($arr)$this->debug_arr[$key]=array();
			}
			if($arr){
				$this->debug_arr[$key][]=$var;
			}else {
				$this->debug_arr[$key]=$var;
			}
		}
	}
}
if(!trait_exists("MyBaseModel")){
	trait MyBaseModel{
		use MyArrayOptions,MySingleton;
		// INSERT_REPLACE=1,DELETE_UPDATE=2,SELECT=3,OTHER=4;
		private $table_name;
		private $queries=array();
		private $errors=array();
		function __construct($options=array()){
			$this->set_options($options);
		}
		private function prepare_query($query,$params){
			global $wpdb;
			$query=$wpdb->prepare($query, $params);
			return $query;
		}
		private function micro_time(){
			return microtime(true);
		}
		private function get_query_type($query){
			if(preg_match( '/^\s*(insert|replace)\s/i', $query )){
				return self::INSERT_REPLACE;
			}else if(preg_match( '/^\s*(delete|update)\s/i', $query )){
				return self::DELETE_UPDATE;
			}else if(preg_match('/^\s*(select)\s/i', $query)){
				return self::SELECT;
			}else return self::OTHER;
		}
		public function query($query,$params=array()){
			global $wpdb;
			if($this->debug){
				$wpdb->show_errors(true);
			}	
			if($this->debug){
				ob_start();
			}
			if(!empty($params)){
				$query=$this->prepare_query($query, $params);
			}
			$query_type=$this->get_query_type($query);
			$start=$this->micro_time();
			$wpdb->query($query);
			$end=$this->micro_time();
			if($query_type==self::SELECT){
				$res=$wpdb->get_results();
				return $res;
			}
			
			if($this->debug){
				$wpdb->show_errors(false);
			}
		}
	}
}
/**
 * Trait db class for debuging queries
 */
if(!trait_exists('MyDatabaseClass')){
    trait MyDatabaseClass{
        use MyTraitDebug;
        private $wpdb;
        private $startTimer;
        private $endTimer;
        private $elapsedTime=0;
        static protected $queries=array();
        protected $totalTime=0;
        protected $myDbDebug=1;
        protected $show_errors=1;
        protected $tmpQueryData=array();
        protected $tableColumns;
        static protected $numQueries=0;
        function traitSetDb(){
            global $wpdb;
            $this->wpdb=$wpdb;
            
        }
        /**
         * 
         * @param unknown $id
         * @param unknown $table
         * @return boolean
         */
        protected function getFromModelByID($id,$table){
            $query=$this->prepare("SELECT * FROM ".$table." WHERE ID=%d", $id);
            $res=$this->get_results($query,ARRAY_A);
            if(!empty($res)){
                $this->setProps($res);
                return true;
                
            }
            return false;
            
        }
        protected function formatArr($id=false,$include=array()){
            $arr=array();
            if(empty($include)){
                foreach($include as $key=>$val){
                    $value="";
                    if(isset($this->$val)){
                        $value=$this->$val;
                    }
                    if($val=="ID"&&!$id)continue;
                    $arr[$value]=$val;
                }
            }else {
            foreach($this->tableColumns as $key=>$val){
                $value="";
                if(isset($this->$val)){
                    $value=$this->$val;
                }
                if($val=="ID"&&!$id)continue;
                $arr[$value]=$val;
            }
            }
            return $arr;
        }
        
        /**
         * get model property
         * @param unknown $key
         * @return boolean|unknown
         */
        protected function getModelProp($key){
            if(!in_array($key,$this->tableColumns)){
                trigger_error(__("Model don't have column ","my_support_theme").$key,E_USER_NOTICE);
                return false;
            }else {
                return $this->$key;
            }
        }
        /**
         * set props to model
         * tableColums is model table
         * @param array $arr
         */
        protected function setProps($arr=array()){
            if(!empty($arr)){
                foreach ($arr as $key=>$val){
                    if(in_array($key,$this->tableColumns)){
                        $this->$key=$val;
                    }else trigger_error(__("Error key is not in the model","my_support_theme")." ".$key,E_USER_NOTICE);
                }
            }
        }
        /**
         * get arr
         * @return NULL[]
         */
        protected function getArr(){
            $arr=array();
            foreach($this->tableColumns as $key=>$val){
                $arr[$key]=$this->$key;
            }
            return $arr;
        }
        /**
         * Show errors
         */
        protected function show_errors(){
            if($this->show_errors){
                $this->wpdb->show_errors();
            }
        }
        
        /**
         * End show errors
         * only allow for class that
         * has show_erors flag
         */
        protected function end_show_errors(){
            if($this->show_errors){
                $this->wpdb->show_errors(false);
            }
        }
        /**
         * Store query
         * @param unknown $query
         * @param unknown $type
         */
        protected function storeQuery($query,$type,$table=""){
            $hash=$this->getQueryHash($query, $type,$table);
             $c=count(self::$queries);
            $this->queryHash[$hash]=$c;
            $this->tmpQueryData=array(
                'i'=>self::$numQueries,
                'query'=>$query,
                'class'=>get_class($this),
                'time'=>0,
                'type'=>$type,
                'table'=>$table
            );
        }
        /**
         * Store query data
         * @param unknown $query
         * @param unknown $key
         * @param unknown $val
         * @param string $force
         * @return boolean
         */
        protected function storeQueryData($key,$val,$force=false){
            if(!$force&&isset($this->tmpQueryData[$key])){
                //trigger_error(__("MyDatabaseClass Key already exists","my_support_theme").':'.$key,E_USER_NOTICE);
                return false;
            }
            $this->tmpQueryData[$key]=$val;
            if($this->myDbDebug){
                self::myTraitDebug($key, $val,"my_model");            
            }
            return true;
        }
        /**
         * Save query data
         * and output debug data of the query
         */
        protected function saveQueryData(){
            $i=$this->tmpQueryData['i'];
            self::$queries[$i]=$this->tmpQueryData;
            if($this->myDbDebug){
                if(class_exists('Class_My_Module_Debug')){
                    Class_My_Module_Debug::add_section('query_'.$i, $this->tmpQueryData,'my_model');
                }
            }
        }
        /**
         * Generate query hash
         * @param unknown $query
         * @param unknown $type
         * @param string $table
         * @return string
         */
        private function getQueryHash($query,$type,$table=""){
            if(!empty($table)){
                $str=$table.'_'.$type;
            }else $str=$query;
            $hash=hash('sha256',$str);
            return $hash;
        }
        /**
         * Start query timer
         */
        private function startTimer(){
            $this->startTimer=microtime(true);
        }
        /**
         * Read query timer
         * @return unknown
         */
        private function readStopTimer(){
            $this->endTimer=microtime(true);
            $this->elapsedTime=$this->endTimer-$this->startTimer;
            return $this->elapsedTime;
        }
        /**
         * return stati queries
         * @return array
         */
        static public function getQueries(){
            return self::$queries;
        }
        /**
         * start transaction
         */
        protected function startTransaction(){
            $this->wpdb->query("START TRANASACTION");
        }
        /**
         * commit transaction
         */
        protected function commitTransaction(){
            $this->wpdb->query("COMMIT");
        }
        /**
         * rollback transaction
         */
        protected function rollbackTransaction(){
            $this->wpdb->query("ROLLBACK");
        }
        /**
         * Generate like query but format has to be in
         * prepare statement
         * @param unknown $query
         * @param unknown $term
         * @param string $first
         * @param string $second
         */
        protected function getLikeQuery($query,$term,$second=true,$first=false){
            $w="%";
            $like="";
            if($first){
                $like.=$w.$term;
            }else $like.=$term;
            if($second){
                $like.=$w;
            }
            $like_str=$this->wpdb->esc_like($like);
            $query=$this->prepare($query, $like);
            return $query;
        }
        /**
         * Preapre query
         * @param unknown $query
         * @param unknown $args
         * @return string|void
         */
        public function prepare($query,$args){
            return $this->wpdb->prepare($query, $args);
        }
        /**
         * Lock in share mode
         * @param unknown $query
         * @return number|false
         */
        public function selectLockInShareMode($query){
            $query.=" LOCK IN SHARE MODE ";
            $results=$this->get_results($query);
            return $results;
        }
        /**
         * Lock for update
         * @param unknown $query
         * @return number|false
         */
        public function selectLockForUpdate($query){
            $query.=" FOR UPDATE ";
            $results=$this->get_results($query);
            return $results;
        }
        /**
         * 
         * @param unknown $table
         * @param unknown $where
         * @param array $args
         * @param array $columns
         * @param string $limit
         * @param string $order
         * @return number|false
         */
        public function mySelect($table,$where,$args=array(),$columns=array(),$limit="",$order=""){
            if(empty($columns)){
                $query="SELECT * ";
            }else {
               $query_cols=array();
               foreach($columns as $key=>$val){
                   $query_cols[]="`".$val."`";
               }
               $query="SELECT ".implode(" ",$query_cols)." ";
            }
            if(!empty($where)){
                $query.=" WHERE ".$where;
            }
            $query=$this->prepare($query, $args);
            if(!empty($order)){
                $query.=" ORDER BY ".$order;
            }
            if(!empty($limit)){
                $query.=" LIMIT ".$limit;
            }
            $r=$this->get_results($query);
            return $r;
            
        }
        /**
         * get var
         * @param unknown $query
         * @param number $col
         * @param number $row
         * @return unknown
         */
        public function get_var($query,$col=0,$row=0){
            self::$numQueries++;
            ob_start();
            $this->show_errors();
            $this->storeQuery($query, 'query');
            $this->startTimer();
            $result=$this->wpdb->get_var($query,$col,$row);
            $this->readStopTimer();
            $error_str=strip_tags(ob_get_clean());
            $this->storeQueryData('error', $error_str);
            $this->storeQueryData('result', $result);
            $this->storeQueryData('time', $this->elapsedTime);
            $this->saveQueryData();
            return $result;
        }
        /**
         * Query
         * @param unknown $query
         * @return number|false
         */
        public function query($query){
            self::$numQueries++;
            ob_start();
            $this->show_errors();
            $this->storeQuery($query, 'query');
            $this->startTimer();
            $results=$this->wpdb->query($query);
            $this->readStopTimer();
            $error_str=strip_tags(ob_get_clean());
            $this->storeQueryData('error', $error_str);
            $this->storeQueryData('results', $results);
            $this->storeQueryData('time', $this->elapsedTime);
            $this->saveQueryData();
            //$this->myDbDebug($query);
            return $results;
            
        }
        public function get_row($query,$type=OBJECT){
            self::$numQueries++;
            ob_start();
            $this->show_errors();
            $this->storeQuery($query, 'select');
            $this->startTimer();
            $results=$this->wpdb->get_row($query,$type);
            $this->readStopTimer();
            $error_str=strip_tags(ob_get_clean());
            $this->storeQueryData('error', $error_str);
            $this->storeQueryData('results', $results);
            $this->storeQueryData('time', $this->elapsedTime);
            $this->saveQueryData();
            //$this->myDbDebug($query);
            return $results;
            
        }
        /**
         * get query results
         * @param unknown $query
         * @param string $type
         * @return number|false
         */
        public function get_results($query,$type=OBJECT){
            self::$numQueries++;
            ob_start();
            $this->show_errors();
            $this->storeQuery($query, 'select');
            $this->startTimer();
            $results=$this->wpdb->get_results($query,$type);
            $this->readStopTimer();
            $error_str=strip_tags(ob_get_clean());
            $this->storeQueryData('error', $error_str);
            $this->storeQueryData('results', $results);
            $this->storeQueryData('time', $this->elapsedTime);
            $this->saveQueryData();
            //$this->myDbDebug($query);
            return $results;
            
        }
        /**
         * Insert into table
         * @param unknown $table
         * @param unknown $data
         * @param array $format
         * @return number|false
         */
        public function insert($table,$data,$format=NULL){
            self::$numQueries++;
            ob_start();
            $this->show_errors();
            $this->storeQuery("", "insert",$table);
            $this->startTimer();
            $ret=$this->wpdb->insert($table, $data,$format);
            
            $this->readStopTimer();
            $error_str=strip_tags(ob_get_clean());
            $this->storeQueryData('data', $data);
            $this->storeQueryData('mysqliErr', $this->wpdb->last_error);
            
            $this->storeQueryData('error', $error_str);
            $this->storeQueryData('ret', $ret);
            $this->storeQueryData('time', $this->elapsedTime);
            $insert_id=$this->wpdb->insert_id;
            $this->storeQueryData('insert_id', $insert_id);
            
            $this->saveQueryData();
            
            if(empty($ret))return false;
            return $insert_id;
            
            
        }
        /**
         * Replace insert or replace
         * @param unknown $table
         * @param unknown $data
         * @param array $format
         * @return boolean|number
         */
        public function replace($table,$data,$format=array()){
            self::$numQueries++;
            ob_start();
            $this->show_errors();
            $this->storeQuery("", "replace",$table);
            $this->startTimer();
            $ret=$this->wpdb->replace($table, $data,$format);
            $this->readStopTimer();
            $error_str=strip_tags(ob_get_clean());
            
            $this->storeQueryData('error', $error_str);
            $this->storeQueryData('ret', $ret);
            $this->storeQueryData('time', $this->elapsedTime);
            $this->saveQueryData();
            if(empty($ret))return false;
            return $this->wpdb->insert_id;
            
        }
        /**
         * Update table
         * @param unknown $table
         * @param unknown $data
         * @param unknown $where
         * @param unknown $format
         * @param unknown $where_format
         * @return boolean|number
         */
        public function update( $table, $data, $where, $format = null, $where_format = null ){
            self::$numQueries++;
            ob_start();
            $this->show_errors();
            $this->storeQuery("", "update",$table);
            $this->startTimer();
            $ret=$this->wpdb->update($table, $data,$where,$format,$where_format);
            $this->readStopTimer();
            $error_str=strip_tags(ob_get_clean());
            
            $this->storeQueryData('error', $error_str);
            $this->storeQueryData('ret', $ret);
            $this->storeQueryData('time', $this->elapsedTime);
            $this->saveQueryData();
            if(empty($ret))return false;
            return $this->wpdb->insert_id;
        }
        public function getPrefix(){
            return $this->wpdb->prefix;
        }
    }
}