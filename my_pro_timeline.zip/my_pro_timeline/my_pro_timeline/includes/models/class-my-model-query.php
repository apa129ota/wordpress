<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_General_Model_Query')){
    class Class_My_General_Model_Query{
        use MyDebug,MyArrayOptions;
        protected $debug;
        protected $use_case="model_query";
        protected $postType;
        protected $postTerms=array();
        protected $myQuery;
        protected $count=0;
        protected $pages=0;
        protected $searchTerm="";
        protected $orderBy="";
        protected $offset;
        protected $postStatus=array('publish');
        protected $metaQuery=array();
        protected $limit=10;
        protected $paged=1;
        protected $dateQuery=array();
        protected $posts=array();
        protected $postsModel=array();
        protected $postModel="";
        protected $postMetaPrefix;
        protected $metaKeys;
        protected $firstPost="";
        function __construct($options=array()){
            $this->setOptions($options);
            self::debug("options", $options);
            if(!empty($options['debug'])){
                $this->setDebugOptions($this->use_case);
            }
        }
       /**
        * Set post terms
        * @param array $array
        */
        function setPostTerms($array=array()){
            $this->postTerms=$array;
            self::debug("postTerms", $this->postTerms);
        }
        /**
         * 
         * @param unknown $term
         */
        function setSearch($term){
            $this->searchTerm=$term;
            self::debug("searchTerm", $this->searchTerm);
        }
        /**
         * 
         * @param unknown $status
         */
        function setStatus($status){
            $this->postStatus=$status;
            self::debug("postStaatus", $this->postStatus);
        }
        /**
         * 
         * @param unknown $dateQ
         */
        function setDateQuery($dateQ){
            $this->dateQuery=$dateQ;
            self::debug("dateQuery", $this->dateQuery);
        }
        /**
         * 
         * @param unknown $limit
         */
        function setLimit($limit){
            $this->limit=$limit;
            self::debug("postLimit", $this->limit);
        }
        /**
         * 
         * @param number $page
         */
        function setPage($page=1){
            $this->paged=$page;
        }
        /**
         * 
         * @param unknown $order
         */
        function setOrder($order){
            $this->orderBy=$order;
            self::debug("order", $this->orderBy);
        }
        function setMetaQuery($meta){
            $this->metaQuery=$meta;
            self::debug("metaaQuery", $this->metaQuery);
        }
        /**
         * 
         * @return array
         */
        public function getPostsInModel(){
            return $this->postsModel;
        }
        /**
         * create args
         */
        protected function createArgs(){
            $args=array();
            $args['post_status']=$this->postStatus;
            if(!empty($this->offset)){
                $args['offset']=$this->offset;
            }
            if(!empty($this->limit)){
                //echo $this->limit;
                $args['posts_per_page']=$this->limit;
            }
            if(!empty($this->searchTerm)){
                $args['s']=$this->searchTerm;
            }
            if(!empty($this->paged)){
                $args['paged']=$this->paged;
            }
            if(!empty($this->metaQuery)){
               // print_r($this->metaQuery);
                $args['meta_query']=$this->metaQuery;
            }
            if(!empty($this->dateQuery)){
                $args['date_query']=$this->dateQuery;
            }
            if(!empty($this->orderBy)){
                if(!empty($this->orderBy['meta_key'])){
                    $meta_key=$this->orderBy['meta_key'];
                }
                if(isset($meta_key)){
                    $args['meta_key']=$meta_key;
                }
                $order=$this->orderBy['order'];
                $args['orderby']=$order;
                
                
                
            }
            $args['post_type']=$this->postType;
            if(!empty($this->postTerms)){
                $args['tax_query']=$this->postTerms;
            }
            self::debug("queryArgs", $args);
            return $args;
            
        }
        public function getFirstPost(){
            return $this->firstPost;
        }
        public function getTotalPages(){
            return $this->myQuery->max_num_pages;
        }
        function query(){
            $args=$this->createArgs();
           // print_r($args);
            $this->myQuery=new WP_Query($args);
            $this->posts=$this->myQuery->get_posts();
            self::debug("foundPosts", $this->posts);
            
            if(!empty($this->posts)){
                if(!empty($this->postModel)&&class_exists($this->postModel)){
                    foreach($this->posts as $k=>$v){
                        $id=$v->ID;
                        $opts=array(
                            'post_type'=>$this->postType,
                            'debug'=>$this->debug,
                            'metaKeys'=>$this->metaKeys,
                            'postMetaPrefix'=>$this->postMetaPrefix,
                           
                        );
                        //$this->postsModel[$id]=
                        $postClassModel=new $this->postModel($opts);
                        $postClassModel->init($this->posts[$k]);
                        if(empty($this->firstPost)){
                            $this->firstPost=$postClassModel;
                        }
                        $postDate=$postClassModel->getPostMetaByKeyStored('postDate');
                        $dI=$postClassModel->getPostMetaByKeyStored('postDateInt');
                        $this->postsModel[]=$postClassModel;
                        self::debug("post".$id, $postClassModel->toArray());
                        //self::debug("post", array('date'=>$postDate,'dateInt'=>$dI));
                    }
                    self::debug('postsModel', $this->postsModel);
                }
            }
        }
        
    }
    
}
            
        