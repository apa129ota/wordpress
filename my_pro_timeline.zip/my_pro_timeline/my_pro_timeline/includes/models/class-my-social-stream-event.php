<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Social_Event')){
    class Class_My_Module_Social_Event {
        use MyArrayOptions,MyDebug,MyDatabaseClass;
        protected $debug;
        protected $use_case='social_events_model';
        protected $tableEvents;
        function __construct($options=array()){
            $this->setOptions($options);
            if($this->debug){
               self::setDebugOptions($this->use_case);
             }
        }
    }
}