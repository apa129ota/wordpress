<?php
if(!defined('ABSPATH'))die('');
if(!class_exists("Class_My_Model_Registry")){
    class Class_My_Model_Registry{
        use MyArrayOptions,MyDebug,MyDatabaseClass;
        protected $debug;
        protected $wordpressOptionsTable;
        protected $eventsTable;
        protected $tablePrefix;
        protected $optionsPrefix;
        protected $use_case="model_registry";
        protected $sharedValues=array();
        protected $sharedObjects=array();
        protected $pluginDir;
        protected $plugin_object;
        protected $pluginsErrors=array();
        static protected $myInstance;
        static protected $alreadyStartedTransaction=false;
        function __construct($options=array()){
            if(isset(self::$instance)){
                return self::$myInstance;
            }else {
                $this->setOptions($options);
                if($options['debug']){
                    self::setDebugOptions($this->use_case);
                }
                self::$myInstance=$this;
                self::debug('network_class',$options);
                $this->traitSetDb();
                $this->wordpressOptionsTable=$this->wpdb->options;
                $this->eventsTable=$this->wpdb->prefix.$this->tablePrefix.'EventsTable';
                self::createEventsTable();
                //set_error_handler(array('Class_My_Model_Registry','errorHandler'),E_ALL);
            }
        }
        /**
         * create events table
         */
        private static function createEventsTable(){
            $var=self::getOption('createdTableEvents');
            if(!empty($var))return;
            $table_name=self::$myInstance->eventsTable;
            echo $table_name;
            self::$myInstance->wpdb->show_errors();
            ob_start();
            if (self::$myInstance->wpdb->get_var ( "SHOW TABLES LIKE '$table_name'" ) != $table_name) {
                $sql = "CREATE TABLE IF NOT EXISTS " . $table_name . "
									(	ID 				bigint(20) NOT NULL AUTO_INCREMENT,
										date			datetime NOT NULL,
										title           char(255) NOT NULL COLLATE utf8_general_ci,  
                                        type 			char(255) NOT NULL COLLATE utf8_general_ci,
										msg   			longtext	NOT NULL COLLATE utf8_general_ci,
                                        value           double,
                                        vars            longtext	NOT NULL COLLATE utf8_general_ci,
										PRIMARY KEY (ID),
										KEY type(type)
										)";
                self::$myInstance->wpdb->query ( $sql );
            }
            $str=ob_get_clean();
            $str=strip_tags($str);
            //echo $str;
           // self::myDebug("dbErrorEvents", $str);
            self::$myInstance->wpdb->show_errors(false);
            self::addOption('createdTableEvents', 1);
        }
        static function getInitSetting($key){
            $var=ini_get($key);
            if(empty($var))return false;
            else {
                $this->sharedValues['ini_'.$key]=$var;
                return $var;
            }
        }
        /**
         * 
         * @param unknown $name
         * @return boolean
         */
        static function isExistsOption($name){
            if(isset(self::$myInstance->sharedValues[$name])){
                return true;
            }
            $option_name=self::$myInstance->getOptionKey($name);
            $var=get_option($option_name);
            if($var===false)return false;
            else {
                self::$myInstance->sharedValues[$name]=$var;
                return true;
            }
        }
        /**
         * 
         * @param unknown $name
         * @param unknown $value
         */
        static function addOption($name,$value){
            $name=self::$myInstance->getOptionKey($name);
            $val=maybe_serialize($value);
            update_option($name, $val,false);
            
        }
        /**
         * get option by name
         * @param unknown $name
         * @return mixed|boolean|mixed|string
         */
        static function getOption($name){
            if(isset(self::$myInstance->sharedValues[$name])){
                return self::$myInstance->sharedValues[$name];
            }
            $option_name=self::$myInstance->getOptionKey($name);
            $val=get_option($option_name);
            if($val===false)return false;
            $val=maybe_unserialize($val);
            self::$myInstance->sharedValues[$name]=$val;
            return $val;
        }
        /**
         * add shared value
         * @param unknown $key
         * @param unknown $value
         */
        static function addSharedValue($key,$value){
            self::$myInstance->sharedValues[$key]=$value;
        }
        /**
         * Get shared value
         * @param unknown $key
         * @return mixed
         */
        static function getSharedValue($key){
            if(isset(self::$myInstance->sharedValues[$key])){
                return self::$myInstance->sharedValues[$key];
            }
        }
        /**
         * 
         * @param unknown $table
         * @return unknown
         */
        static function getTableSize($table){
            $query="SELECT table_schema `$table`,sum( data_length + index_length )/1024/1024 size_in_mb,
            sum(data_free)/1024/1024 free_size
            FROM information_schema.TABLES
            WHERE TABLE_NAME='$table'
            GROUP BY table_schema ;";
            $row=self::$myInstance->get_row($query);
            return $row->size_in_mb;
        }
        public function getPluginProperty($key){
            return $this->plugin_object->getProperty($key);
        }
        /**
         * 
         * @param unknown $key
         * @return unknown|boolean
         */
        public function get($key){
            if(isset($this->$key)){
                return $this->$key;
            }else return false;
        }
       /* static function debug($key,$val){
            if(class_exists('Class_My_Module_Debug')){
                $use_case=self::$myInstance->get('use_case');
               // Class_My_Module_Debug::add_section($key, $val,$use_case);
            }
        }*/
        /**
         * Error handler
         * @param unknown $errno
         * @param unknown $errstr
         * @param unknown $errfile
         * @param unknown $errline
         * @param unknown $errc
         */
        static function errorHandler($errno,$errstr,$errfile,$errline,$errc){
            if(strpos($errfile,self::$instance->get('pluginDir'))!==false){
                if(class_exists('Class_My_Module_Debug')){
                    $type='';
                    $string='';
                    switch($errno){
                        case E_USER_ERROR:
                            $type='E_USER_ERROR';
                            break;
                        case E_USER_NOTICE:
                            $type='E_USER_NOTICE';
                            break;
                        default:
                            $type='E_OTHER';
                            break;
                    }
                    $trace=debug_backtrace();
                    $arr=array(
                        'date'=>date('Y/m/d H:i:s'),
                        'errono'=>$errno,
                        'errstr'=>$errstr,
                        'errfile'=>$errfile,
                        'errline'=>$errline,
                        'trace'=>$trace
                    );
                        Class_My_Module_Debug::add_section($type, $arr,'errors');
                    
                }else {
                    
                }
            }else return false;
        }
        /**
         * 
         * 
         * @param unknown $name
         */
        protected function getOptionKey($name){
            $key=$this->optionsPrefix.'_'.$name;
            return $key;
            
        }
        /**
         * Ins dec option
         * @param unknown $val
         * @param number $inc
         * @param string $op
         */
        static function incDecOption($val,$inc=1,$op="+"){
            if($op=='+'){
                $val+=$inc;
            }else if($op=='-'){
                $val-=$inc;
            }
            return $val;
        }
        static function updateOption($name,$val){
            $option_name=self::$myInstance->getOptionKey($name);
            $val=maybe_unserialize($val);
            update_option($option_name, $val,false);
            
        }
        /**
         * 
         * @param unknown $name
         * @param unknown $val
         */
        static function updateOptionUnblock($name,$val){
            $option_name=self::$myInstance->getOptionKey($name);
            $val=maybe_unserialize($val);
            update_option($option_name, $val,false);
            self::$myInstance->query("commit");
        }
        /**
         * 
         * @param unknown $name
         */
        static function getOptionBlock($name){
            $option_name=self::$myInstance->getOptionKey($name);
            self::debug("option_name", $option_name);
            global $wpdb;
            $wpdb->show_errors();
            ob_start();
            $table=$wpdb->options;
            if(!self::$alreadyStartedTransaction){
                $wpdb->query('START TRANSACTION');
            }
            $query="SELECT option_value FROM ".$table." WHERE ";
            $query.=" option_name=%s FOR UPDATE ";
            $query=$wpdb->prepare($query, $option_name);
            $var=$wpdb->get_var($query);
            $error_str=ob_get_clean();
            if(!empty($error_str)){
                self::debug("dbOptionBlock", $error_str);
            }
            $var=maybe_unserialize($var);
            self::$myInstance->sharedValues[$name]=$var;
            return $var;
        }
        /**
         * Call statically function
         * @param unknown $name
         * @param unknown $params
         * @return unknown
         */
        static function callFunction($name,$params){
            self::debug("callFunction", array("name"=>$name,"params"=>$params));
            if(isset(self::$myInstance)){
                $inst=self::$myInstance;
                if(method_exists($inst, $name)){
                    $ret=$inst->$name($params);
                    return $ret;
                }else {
                    $exc=new Class_My_Exception(__("Class method not exists","my_support_theme")." : ".$name,1000);
                    
                    
                    throw new $exc;
                }
            }
        }
        /**
         * Add shared value
         * @param unknown $key
         * @param unknown $val
         * @param string $isObject
         * @return boolean
         */
       
       
        /**
         * get instance
         * @return Class_My_Model_Registry
         */
        static function getInstance(){
            if(isset(self::$instance)){
                return self::$instance;
            }else {
                return false;
            }
        }
        
    }
}
        