<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_General_Terms_Model')){
    class Class_My_General_Terms_Model{
        use MyDebug,MyArrayOptions;
        protected $taxonomy;
        protected $postType;
        protected $use_case;
        protected $data;
        protected $lastError="";
        function __construct($options){
            $options['use_case']="model_terms";
            $this->setOptions($options);
            if(!empty($options['debug'])){
                $this->setDebugOptions($this->use_case);
            }
            
        }
        protected function setLastError($msg){
            $this->lastError=$msg;
        }
        /**
         * 
         * @param unknown $term
         * @param number $limit
         * @return boolean|array|number|WP_Error
         */
        function likeTerms($term,$limit=15){
            $args=array(
                'taxonomy'=>$this->taxonomy,
                'number'=>$limit,
                'name__like'=>$term,
                'hide_empty'=>0
            );
            $res=get_terms($args);
            self::debug("likeTerm", array('term'=>$term,'res'=>$res));
            if(is_wp_error($res)){
                $code=$res->get_error_code();
                $msg=$res->get_error_message($code);
                $this->setLastError($msg);
                return false;
            }
            return $res;
        }
    }
}