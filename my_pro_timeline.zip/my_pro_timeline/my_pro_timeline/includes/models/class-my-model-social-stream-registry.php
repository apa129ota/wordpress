<?php
if(!defined('ABSPATH'))die('');
if(!class_exists("Class_My_Model_Pro_Timeline_Registry")){
    class Class_My_Model_Pro_Timeline_Registry extends Class_My_Model_Registry{
        
        function __construct($options){
            parent::__construct($options);
           
        }
       
        /**
         * After saving posts commit transactions
         */
        static function commitDbUpdate(){
            //if(self::$alreadyStartedTransaction){
                self::$myInstance->commitTransaction();
            //}
            self::updateTablesMeta();
        }
        /**
         * check to see if
         * we have db limit for saving posts
         * @return boolean
         */
        
        /**
         * 
         */
        static function updateTablesMeta(){
            $query="SELECT count(*) FROM ".self::$myInstance->wpdb->posts." WHERE post_type='my_timeline'";
            
            $var=self::$myInstance->get_var($query);
            self::debug("totalPosts", $var);
            //self::addOption('totalPosts', $var);
            self::getOptionBlock('totalPosts');
            self::updateOptionUnblock('totalPosts', $var);
               
        }
        /**
         * update cache size
         * @param unknown $size
         */
      
       function init(){
           
           if(!self::isExistsOption('totalPosts')){
               $query="SELECT count(*) FROM ".$this->wpdb->posts." WHERE post_type='my_timeline'";
               $var=$this->get_var($query);
               self::debug("totalPosts", $var);
               self::addOption('totalPosts', $var);
           }else {
               $totalP=self::getOption('totalPosts');
               //self::addOption('totalPosts', $totalP);
           }
          
           
       }
    }
}