<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Social_Options_Model')){
    class Class_My_Module_Social_Social_Model {
        use MyArrayOptions,MyDebug,MyDatabaseClass;
        protected $debug;
        protected $use_case='social_options_model';
        protected $metaPrefix="_my_social_stream_1234_options_";
        function __construct($options=array()){
            $this->setOptions($options);
            if($this->debug){
                self::setDebugOptions($this->use_case);
            }
        }
        public function blockOption($key){
            //$this->startTransaction();
            
        }
    }
}
        