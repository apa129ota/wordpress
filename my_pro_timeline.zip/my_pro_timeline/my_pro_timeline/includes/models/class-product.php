<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_General_Post_Woo_Model')){
    /**
     * Model for Woocomerce products 
     * get al data from products
     * @author tiw126itwa
     *
     */
    class Class_My_General_Post_Woo_Model extends Class_My_Module_Post_Templates_Post_Model{
		protected $is_woo=1;
		protected $post_type='product';
        protected $filter_taxs=array(
			'product_cat','product_tag'
		);
        /**
         * Constructor
         * @param array $options
         */
		function __construct($options=array()){
			parent::__construct($options);

		}
		/**
		 * Init
		 * {@inheritDoc}
		 * @see Class_My_Module_Post_Templates_Post_Model::init()
		 */
		public function init(){
			parent::init();

			$this->getTaxonomies($this->filter_taxs);

			$this->getPostTerms();

		}
	}
}