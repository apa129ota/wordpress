<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_General_Post_Model')){
    class Class_My_General_Post_Model{
		use MyDebug,MyArrayOptions;
		protected $metaKeys=array();
		protected $is_woo=0;
		protected $post_type='post';
		protected $post_id;
		protected $ID;
		protected $post_thumb_id;
		protected $post_author;
		protected $post_date_gmt;
		protected $post_modified;
		protected $post_modified_gmt;
		protected $post_status;
		protected $post_date;
		protected $post_password;
		protected $post_name;
		protected $post_parent;
		protected $comment_status;
		protected $ping_status;
		protected $post_title;
		protected $post_content;
		protected $post_excerpt;
		protected $post_categories;
		protected $post_terms=array();
		protected $post_url;
		protected $permalink;
		protected $use_loop=false;
		protected $has_comments=true;
		protected $post;
		protected $get_post_meta=array();
		protected $post_meta;
		protected $defined_meta;
		protected $defined_taxonomies;
		protected $post_thumbs=array();
		protected $comment_num=0;
		protected $currency_simbol;
		protected $currency;
		protected $regular_price;
		protected $sale_price;
		protected $has_gallery;
		protected $galleries;
		protected $gallery_thumbs;
		protected $gallery_text;
		protected $selected_gallery=0;
		protected $get_gallery=true;
		protected $use_case='post_model';
		protected $image_sizes=array('thumbnail','medium','medium_large','large','full');
		protected $admin_tmpl=false;
		/**
		 * Used to get real post gal;lery templates
		 * @var string
		 */
		protected $gallery_post_meta='_wp_my_post_templates_gallery';
		protected $gallery_selected_post_meta='_wp_my_post_templates_gallery_selected';
		protected $model_vars=array(
			'comment_num',
			'post_title','post_content','post_excerpt','post_categories','post_terms','post_url',
			'post_author','ID','post_date','post_date_gmt','post_status','post_password','post_name',
			'comment_status','ping_status','post_modified','post_modified_gmt','post_parent'		
		);
		protected $post_meta_key;
		protected $postMetaPrefix;
		protected $filter_taxs=array();
		
		function __construct($options=array()){
			$this->setOptions($options);
			if($this->debug){
				$this->setDebugOptions($this->use_case);
			}
		    
			
		}
		/**
		 * get post meta by key
		 * @param unknown $key
		 * @return unknown
		 */
		public function getPostMetaByKeyStored($key){
		    $meta_key=$this->postMetaPrefix.$key;
		    if(isset($this->post_meta[$meta_key])){
		        return $this->post_meta[$meta_key];
		    }else return false;
		}
		/**
		 * 
		 * @return unknown
		 */
		public function getPostTitle(){
		    return $this->post_title;
		}
		
		/**
		 * 
		 * @return string
		 */
		public function getContentText(){
		    $c=$this->post_content;
		    $c=strip_shortcodes($c);
		    $c=strip_tags($c);
		    return $c;
		}
		public function getFullThumb(){
			if(!empty($this->post_thumbs['full'])){
				return $this->post_thumbs['full'][0];
			}else return false;
		}
		public function getThumbWidthHeight($w,$h){
			if(!empty($this->post_thumbs)){
				$has=false;
				foreach($this->post_thumbs as $k=>$v){
					if($v[1]>$w && $v[2]>$h){
						return $v[0];
					}
				}
				return $this->post_thumbs['full'];
			}else return false;
			
		}
		/**
		 * 
		 * @param string $key
		 * @return boolean|mixed|boolean|string|array|unknown
		 */
		public function getPostMetaByKey($key=''){
			$key=$this->post_meta_key.'_'.$key;
			$p=get_post_meta($this->post_id,$key,true);
			if($p===false || $p===''){
				return false;
			}else {
				return $p;
			}
		}
		private function queryDbPost($status='publish',$order='ASC'){
			global $wpdb;
			$query="SELECT ID FROM ".$wpdb->posts." WHERE post_status=%s ";
			$query.=" AND post_type=%s ORDER BY post_date $order limit 0,1 ";
			$query=$wpdb->prepare($query, $status,$this->post_type);
			self::debug("post_model_query", $query);
			$wpdb->show_errors();
			ob_start();
			$res=$wpdb->get_results($query);
			$error=ob_get_clean();
			if(!empty($error)){
				self::debug("post_model__query_error", $error);
			}
			if(!empty($res)){
				return $res[0]->ID;
			}else return false;
		
		}
		
		private function getPostOne($order='ASC'){
			if(empty($this->post_id)){
				$has=false;
				$check=array('publish','draft');
				foreach($check as $k=>$v){
					$id=$this->queryDbPost($v,$order);
					if(!empty($id))break;
				}
				if(!empty($id)){
					$this->post_id=$id;
				}
			}
		}
		/**
		 * Get post var
		 * @param unknown $name
		 */
		public function getVar($name){
		    if($name=='permalink'){
		        //echo 'Name '.$name.' '.$this->$name.'<br/>';
		      self::debug('my_permalink', $this->$name);
		    }
			if(isset($this->$name)){
				return $this->$name;
			}else {
				$msg=__("Model Post has no this varr","my_support_theme").' '.$name;
				trigger_error($msg,E_USER_NOTICE);
			}
		}
		public function getPostVar($name){
			if(!in_array($name,$this->model_vars) || !isset($this->$name)){
				//$msg=__("Model Post has no this varr","my_support_theme").' '.$name;
				//trigger_error($msg,E_USER_NOTICE);
			}else {
				return $this->$name;
			}
		}
		/**
		 * 
		 * @param unknown $key
		 * @return boolean
		 */
		public function getPostMeta($key){
			if(!in_array($this->get_post_meta)){
				$msg=__("Model Post has no this posdt meta","my_support_theme").' '.$key;
				trigger_error($msg,E_USER_NOTICE);
			}else {
				if(isset($this->post_meta[$key]))
				return $this->post_meta[$key];
				else return false;
			}
		}
		protected function getThumbData($id){
		    if(!empty($id)){
		      $v1=$id;
		      $thumb_post=get_post($v1);
		      $this->gallery_text[$v1]=array(
		         'title'=>'',
		         'full'=>'',
		         'small'=>''
		      );
		      if(!empty($thumb_post->post_title)){
		            $this->gallery_text[$v1]['title']=$thumb_post->post_title;
		      }
		      else if(!empty($thumb_post->post_content)){
		            $this->gallery_text[$v1]['full']=$thumb_post->post_excerpt;
		        
		      }
		       else if(!empty($thumb_post->post_excerpt)){
		            $this->gallery_text[$v1]['full']=$thumb_post->post_excerpt;
		    
		    
		      }else {
		            $this->gallery_text[$v1]['full']=$thumb_post->post_title;
		          $this->gallery_text[$v1]['small']=$thumb_post->post_title;
		      }
		      if(!isset($this->gallery_text[$v1]['small'])){
		          $l=100;
		          $post_content=$this->gallery_text[$v1]['full'];
		          $html=substr($post_content,0,$l).'...';
		          $this->gallery_text[$v1]['small']=$html;
		      }
		    }
		}
		public function getThumbTexts($id){
		    return $this->gallery_text[$id];
		}
		public function getGalleryThumbsFront($id='',$includeText=true){
		    if($this->admin_tmpl){
		        $id=0;
		        $thumbs=$this->gallery_thumbs[$id]; 
		        if($includeText){
		            foreach($thumbs as $k=>$v){
		                $text=$this->getThumbTexts($v['my_id']);
		                if(!empty($text)){
		                  foreach($text as $k1=>$v1){
		                     $thumbs[$k][$k1]=$v1;
		                  }
		                }
		            }
		        }
 		    }
		    return $thumbs;
		}
		protected function getGalleryThumbs(){
		    if($this->has_gallery){
		        foreach($this->galleries as $k2=>$v2){
		           // echo 'Gallery '.$k2.' '.print_r($v2);
		            foreach($v2 as $k1=>$v1){
		                
		                $thumbs=array();
		                if(!isset($this->gallery_text[$v1]))
		                $this->getThumbData($v1);
		               foreach($this->image_sizes as $k3=>$v3){
		                   $thumbs[$v3]=wp_get_attachment_image_src($v1,$v3);
		               }
		                if(!isset($thumbs['full'])){
		                    $thumbs['full']=wp_get_attachment_image_src($v1,'full');
		                }
		                $thumbs['my_id']=$v1;
		                //$this->post_thumbs=$thumbs;
		                if(!isset($this->gallery_thumbs[$k2]['thumbs']))
		                $this->gallery_thumbs[$k2]['thumbs']=array();
		                $this->gallery_thumbs[$k2]['thumbs'][$k1]=$thumbs;
		                
		                
		            }
		        }
		    }		    
		    self::debug("gallery thumbs", $this->gallery_thumbs);
		}
		protected function getThumb(){
			self::debug("image_sizes", $this->image_sizes);
			$this->post_thumb_id=get_post_thumbnail_id($this->post_id);
			self::debug("post_thumb", $this->post_thumb_id);
			if(!empty($this->post_thumb_id)){
				$thumbs=array();
				foreach($this->image_sizes as $k=>$v){
					$thumb=wp_get_attachment_image_src($this->post_thumb_id,$v);
					if(!empty($thumb)){
						$thumbs[$v]=$thumb;
					}
				}
				if(!isset($thumbs['full'])){
					$thumbs['full']=wp_get_attachment_image_src($this->post_thumb_id,'full');
				}
				$this->post_thumbs=$thumbs;
				self::debug("post_thumbs", $this->post_thumbs);
			}
		}
		protected function getCategeories(){
			$post_categories=wp_get_post_categories($this->post_id);
			$cats=array();
			if(!empty($post_categories)){
				foreach($post_categories as $key=>$val){
					$cats[]=get_category($val,'object');
				}
			}
			$this->post_categories=$cats;
			self::debug("post_categories", $this->post_categories);
		}
		protected function getTerms(){
			$this->post_terms=wp_get_post_terms($this->post_id);
			self::debug("post_terms", $this->post_terms);
			
		}
		protected function getTaxonomies($filter=array()){
			$this->defined_taxonomies= get_object_taxonomies( $this->post_type, 'objects' );
			self::debug('defined_taxonomies',$this->defined_taxonomies);
			$filter_taxs=array();
			$filter_taxs=array(
					'product_cat','product_tag'
			);
			
			if(!empty($filter)){
				foreach($this->defined_taxonomies as $k=>$v){
					if(!in_array($k,$filter)){
						unset($this->defined_taxonomies[$k]);
					}
				}
			}
			self::debug('filter_taxonomies',$this->defined_taxonomies);
		}
		protected function getPostTerms(){
			$args = array('orderby' => 'name', 'order' => 'ASC', 'fields' => 'all');
			if(!empty($this->defined_taxonomies)){
				foreach($this->defined_taxonomies as $k=>$obj){
					/*if(!empty($obj->public)){
						$terms=wp_get_object_terms($this->post_id,$k, $args);
						if(!is_wp_error($terms) && !empty($terms)){
							$this->post_terms[$k]=$terms;
						}
					}*/
					$terms=wp_get_object_terms($this->post_id,$k, $args);
					if(!is_wp_error($terms) && !empty($terms)){
						$this->post_terms[$k]=$terms;
					}
						
				}
			}
			self::debug("post_terms", $this->post_terms);
		}
		protected function getObjectTaxonomies($name){
			$arr=array(
				'public'=>true,
				'object_type'=>$this->post_type	
			);
			$this->defined_taxonomies=array();
			$objs=get_object_taxonomies($this->post_type,'objects');//_taxonomies($arr,'objects');
			if(!empty($objs)){
				if(!empty($this->filter_taxs)){
					foreach($objs as $k=>$v){
						if(in_array($k, $this->filter_taxs)&&$v->public){
							$check=array(
								'label'
							);
							$label='';
							foreach($check as $k1=>$v1){
								if(!empty($v->$v1)){
									$label=$v->$v1;
								}
							}
							$this->defined_taxonomies[$k]=$label;
						}
					}
				}else {
					foreach($objs as $k=>$v){
						if(in_array($k, $this->filter_taxs)&&$v->public){
							$check=array(
									'label'
							);
							$label='';
							foreach($check as $k1=>$v1){
								if(!empty($v->$v1)){
									$label=$v->$v1;
								}
							}
							$this->defined_taxonomies[$k]=$label;
						}
					}
				}
				
				
			}
			//$this->defined_taxonomies[$name]=$obj;
			self::debug('taxonomies', $objs);
			self::debug("defined_tax", $this->defined_taxonomies);
		}
		public function getPost(){
		    return $this->post;
		}
		public function toArray(){
		    $arr=array();
		    foreach($this as $k=>$v){
		        $arr[$k]=$v;
		    }
		    self::debug("postArr", $arr);
		    return $arr;
		}
		public function init($post=""){
		    
			$image_sizes=get_intermediate_image_sizes();
			/*if(!empty($image_sizes)){
				$this->image_sizes=array_merge($this->image_sizes,$image_sizes);
			}*/
			self::debug("post", $post);
			self::debug("post_id",$post->ID);
			$this->image_sizes=$image_sizes;
			self::debug("get_image_sizes", $image_sizes);
			if(empty($this->post_id)&&empty($post)){
				$this->getPostOne();
			}
			if(empty($post)){
			$this->post=get_post($this->post_id);
			}else {
			    $this->post_id=$post->ID;
			    $this->post=$post;
			}
			if($this->post_type=='product'){
				if(class_exists( 'WooCommerce' )){
					$this->filter_taxs=array('product_cat','product_tag');
					$is_woo=1;
					$this->is_woo=1;
					$this->post_currency=get_woocommerce_currency_symbol();
					
				}
			}
			if($this->is_woo){
			    $g12=get_post_meta($this->post_id,'_product_image_gallery',true);
			    self::debug("g12", $g12);
			    if(!empty($g12)){
			       
			        $this->has_gallery=true;
			        if(strpos($g12,",")!==false){
			            $gall12=explode(",", $g12);
			        }else $gall12=array($g12);
			        $this->galleries=array($gall12);
			    }
			}else {
			    if($this->get_gallery){
			    $content=$this->post->post_content;
			    if(preg_match_all('/\[gallery([^\]]*)\]/ims', $content,$m)){
			        self::debug("gallery match",$m);
			        //print_r($m);
			        $this->has_gallery=true;
			        $this->galleries=array();
			        if(!empty($m[1])){
			            foreach($m[1] as $k123=>$v123){
			                $str=str_replace('ids="','',$v123);
			                $str=str_replace('"', '', $str);
			                $g12=$str;
			                //echo 'str='.$str;
			                if(strpos($g12,",")!==false){
			                    $gall12=explode(",", $g12);
			                }else $gall12=array($g12);
			                //print_r($gall12);
			                self::debug("g12", $g12);
			                self::debug("gall12", $gall12);
			                $this->galleries[]=$gall12;
			            }
			        }
			    }
			    }
			}
			if($this->get_gallery){
			if($this->admin_tmpl&&!$this->has_gallery){
			    $this->has_gallery=true;
			    $this->galleries=array();
			     $this->galleries[0]=array($this->post_thumb_id,$this->post_thumb_id,$this->post_thumb_id,$this->post_thumb_id,$this->post_thumb_id);
			}
			if(!$this->admin_tmpl){
			    $gall=get_post_meta($this->post_id,$this->gallery_post_meta,true);
			    $gall_sel=get_post_meta($this->post_id,$this->gallery_selected_post_meta,true);
			    if(!empty($gall)){
			        $this->has_gallery=true;
			        $oldGalls=$this->galleries;
			        unset($this->galleries);
			        $this->galleries[0]=$gall;
			        $this->galleries=array_merge(array($gall,$this->galleries));
			        
			    }else {
			     if(!empty($gall_sel)){
			         $this->selected_gallery=$gall_sel;
			     }
			    }
			}
			}
			if(post_type_supports($this->post_type, 'comments')){
				$this->comment_num=get_comments_number( $this->post_id);
				self::debug("comment_num", $this->comment_num);
			}else {
			    $this->has_comments=false;
			    $this->comment_num=0;
			}
			if($this->is_woo){
				$this->currency=get_woocommerce_currency();
				$this->currency_simbol=get_woocommerce_currency_symbol($this->currency);
				$this->regular_price=get_post_meta($this->post_id,"_regular_price",true);
				$this->sale_price=get_post_meta($this->post_id,"_sale_price",true);
			}
			$this->permalink=get_permalink($this->post_id);
			self::debug("post_url", $this->permalink);
			self::debug("post", $this->post);
			$this->post_type=$this->post->post_type;
			self::debug("post_type", $this->post_type);
			if(!empty($this->post)){
				foreach($this->model_vars as $k=>$v){
					self::debug("post_".$v, $this->post->$v);
					if(isset($this->post->$v)){
						$this->$v=$this->post->$v;
					}else $this->$v='';
					self::debug("post_v_".$v, $this->$v);
				}
			}
			$this->getThumb();
			if($this->get_gallery){
			     $this->getGalleryThumbs();
			}
			if($this->post_type=='post'){
				$this->getCategeories();
				$this->getTerms();
			}else {
				$this->getObjectTaxonomies($this->post_type);
				$this->getPostTerms();
			}
			$this->getPostMetaDefined();
			$this->toArray();
		}
		protected function getPostMetaDefined(){
			$this->defined_meta=get_post_custom_keys($this->post_id);
			self::debug("defined_meta", $this->defined_meta);
			if(!empty($this->defined_meta)){
				foreach($this->defined_meta as $k=>$v){
					$meta=get_post_meta($this->post_id,$v);;
					$c=count($meta);
					self::debug("count_meta_".$v, $c);
					if($c==1){
						$this->post_meta[$v]=$meta[0];
					}else {
						$this->post_meta[$v]=$meta;
					}
				}
			}
			self::debug("post_meta", $this->post_meta);
				
		}
	}
}
