<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Social_Events_Model')){
    class Class_My_Module_Social_Events_Model {
        use MyArrayOptions,MyDebug,MyDatabaseClass;
        protected $debug;
        protected $use_case='social_events_model';
        protected $tableEvents;
        protected $global_dir;
        protected $events;
        function __construct($options=array()){
            $this->setOptions($options);
            if($this->debug){
                
            }
            
        }
    }
}