<?php
if(!defined('ABSPATH'))die('');
if(!class_exists("Class_My_Model_Stars")){
    class Class_My_Model_Stars{
        use MyArrayOptions,MyDebug,MyDatabaseClass,MyTraitFormDataValidate;
        protected $debug;
        protected $fields;
        protected $tableComments;
        protected $tableIps;
        protected static $myInstance="";
        protected $enableStars;
        protected $timeDiff;
        protected $prefix;
        function __construct($options=array()){
            if(self::$myInstance!==""){
                return self::$myInstance;
            }
            $this->setOptions($options);
            if($this->debug){
                $this->setDebugOptions("model_stars");
            }
            self::$myInstance=$this;
            $this->timeDiff=24*3600;
            $this->traitSetDb();
            $this->tableIps=$this->wpdb->prefix.'my_pro_timeline_ips';
            $this->tableComments=$this->wpdb->prefix.'my_pro_timeline_comments';
            $this->enableStars=wp_my_pro_timeline_get_option('enable_stars_comments');
            
            $option=get_option("_my_pro_timeline_last_del_1234");
            $myDo=false;
            $t=time()-$this->timeDiff;
            if(empty($option)|| $option<$t){
                $myDo=true;
            }
            self::debug("timeInt", $t);
            self::debug("option", $option);
            self::debug("myDo",$myDo);
            if(is_admin()&&$myDo){
                $dateInt1=time();
                update_option("_my_pro_timeline_last_del_1234", $dateInt1,false);
                $dateInt=time()-$this->timeDiff-3600;
                $dateDel=date("Y/m/d H:i:s",$dateInt);
                $query="DELETE FROM ".$this->tableIps." WHERE created<%s";
                $query=$this->prepare($query, array($dateDel));
                $this->query($query);
                self::debug("query", $query);
            }
        }
        /**
         * count comments
         * @param unknown $post_id
         * @return mixed|boolean|string|array|unknown
         */
        public function getCountComments($post_id){
            $key=$this->prefix.'starsCount';
            return get_post_meta($post_id,$key,true);
        }
        /***
         * Query comments to display on the site
         * @param number $limit
         * @param number $page
         */
        public function queryComm($post_id,$limit=10,$page=1){
            $query="SELECT * FROM ".$this->tableComments." WHERE ";
            $query.=" postID=%d order by created desc ";
            $poc=($page-1)*limit;
            $query.=" limit $poc,$limit ";
            $query=$this->prepare($query, array($post_id));
            $res=$this->get_results($query);
            return $res;
        }
        /**
         * 
         * @param unknown $postID
         */
        public function likePost($postID){
           $query="START TRANSACTION";
           $this->query($query);
           $meta_key=$this->prefix.'hearts';
           $query="SELECT meta_value FROM ".$this->wpdb->postmeta;
           $query.=" WHERE post_id=%d AND meta_key=%s FOR UPDATE";
           $query=$this->prepare($query, array($postID,$meta_key));
           $var=$this->get_var($query);
           if(empty($var))$var=0;
           $var++;
           update_post_meta($postID, $meta_key, $var);
           $query="commit";
           $this->query($query);
           return $var;
           //update_option($option, $value)
           
        }
        /**
         * 
         * @param unknown $stars
         * @param unknown $comm
         */
        public function saveComm($post_id,$stars,$comm){
           $user_id=0;
           if(is_user_logged_in()){
               $user_id=get_current_user_id();
           }
            $arr=array(
                'postID'=>$post_id,
                'userID'=>$user_id,
                'created'=>date('Y/m/d H:i:s'),
                'text'=>$comm,
                'stars'=>$stars
           );
            $key=$this->prefix.'stars';
            $key1=$this->prefix.'starsCount';
            $this->query("START TRANSACTION");
            $query="SELECT meta_value FROM ".$this->wpdb->postmeta." WHERE ";
            $query.=" post_id=%d AND meta_key=%s FOR UPDATE";
            $query=$this->prepare($query,array($post_id,$key));
            $var=$this->get_var($query);
            $new_var=0;
            if(empty($var)){
                $new_var=$stars;
                update_post_meta($post_id, $key, $stars);
                update_post_meta($post_id, $key1, 1);
            }else {
                $total=get_post_meta($post_id,$key1,true);
                $new_var=((float)($total*$var+$stars)/($total+1));
                $new_var=round($new_var,1);
                update_post_meta($post_id, $key, $new_var);
                $total++;
                update_post_meta($post_id, $key1, $total);
                
            }
            $this->insert($this->tableComments, $arr);
            $this->query("commit");
        }
        /**
         * Can post comment
         * if user is logged then
         * @param unknown $postID
         */
        public function canPostComm($postID){
            if(is_user_logged_in()){
                $user_id=get_current_user_id();
                $query="SELECT count(*) FROM ".$this->tableComments." WHERE ";
                $query.=" postID=%d and userID=%d";
                $query=$this->prepare($query, array($postID,$user_id));
                $var=$this->get_var($query);
                if(empty($var))return true;
                else return false;
                
            }else {
                $time=time()-$this->timeDiff;
                $date=date('Y/m/d H:i:s',$time);
                $ip=$_SERVER['REMOTE_ADDR'];
                $query="SELECT count(*) FROM ".$this->tableIps." WHERE ";
                $query.=" ip=%s AND object_type=%s AND postID=%d AND created > %s ";
                $query=$this->prepare($query, array($ip,"comments",$postID,$date));
                $var=$this->get_var($query);
                if(!empty($var))return false;
                else return true;
            }
            
        }
        /**
         * 
         * @param unknown $postID
         * @return boolean
         */
        public function canLikePost($postID){
            $time=time()-$this->timeDiff;
            $date=date('Y/m/d H:i:s',$time);
            $ip=$_SERVER['REMOTE_ADDR'];
            $query="SELECT count(*) FROM ".$this->tableIps." WHERE ";
            $query.=" ip=%s AND object_type=%s AND postID=%d AND created > %s ";
            $query=$this->prepare($query, array($ip,"likes",$postID,$date));
            $var=$this->get_var($query);
            if(!empty($var))return false;
            else return true;
        }
        /**
         * 
         * @param unknown $postID
         * @param string $type
         */
        public function saveIp($postID,$type="likes"){
            $date=date('Y/m/d H:i:s');
            $ip=$_SERVER['REMOTE_ADDR'];
            $data=array(
              'object_type'=>$type,
              'postID'=>$postID,
              'ip'=>$ip,  
              'created'=>$date 
           );
           $this->insert($this->tableIps, $data); 
        }
        
        
    }
}