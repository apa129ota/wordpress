<?php
if(!defined('ABSPATH'))die();
$options=array(
    array(
        'type'=>'class',
        'file'=>'class-my-exception.php'
    ),
    array(
        'type'=>'model',
        'file'=>'class-my-model-registry.php'
    ),
    array(
        'type'=>'model',
        'file'=>'class-my-model-social-stream-registry.php'
        
    )
    
    );
return $options;