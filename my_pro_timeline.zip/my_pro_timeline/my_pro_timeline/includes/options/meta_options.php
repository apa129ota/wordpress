<?php
if(!defined('ABSPATH'))die('');
$meta_options=array(
		'table_objects'=>MY_PRO_TIMELINE_TABLE_OBJECTS,
		'tables_objects_meta'=>MY_PRO_TIMELINE_TABLE_OBJECTS_META,
		'has_dates'=>1,
		'debug'=>1
	
);
return $meta_options;