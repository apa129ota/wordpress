<?php
if(!defined('ABSPATH'))die('');
$menu=array(
    'admin_pages'=>array(
        'controller'=>array(
            'file'=>'class-my-page-controller.php',
            'class'=>'Class_My_Pro_Timeline_Page_Controller'
        ),
        'my_pro_timeline'=>array(
            'page_title'=>__("My Pro Timeline","my_support_theme"),
            'menu_title'=>__("My Pro Timeline","my_support_theme"),
            'capability'=>'manage_options',
            'is_logged'=>true,
            'template'=>'',
            'parent'=>'',//specify parent menu if you want
            'styles'=>array(
                'my_table_view_css'=>'{modules_url}tableview/assets/css/admin.css',
                'my_admin_css'=>'{css_url)admin.css',
                'my_admin_menu_css'=>'{css_url}admin_menu.css',
                'my_jquery_ui'=>'{css_url}jquery-ui.css'
            ),
            'scripts'=>array(
                'my_general_js'=>'{jscript_url}admin/my_general.js'
            ),
            
        ),
        'my_pro_timeline_preview'=>array(
            'page_title'=>__("Preview","my_support_theme"),
            'menu_title'=>__("Preview","my_support_theme"),
            'capability'=>'manage_options',
            'is_logged'=>true,
            'template'=>'',
            'parent'=>'my_pro_timeline',//specify parent menu if you want
            'styles'=>array(
                'my_table_view_css'=>'{modules_url}tableview/assets/css/admin.css',
                'my_admin_css'=>'{css_url)admin.css',
                'my_social_admin_css'=>'{css_url}social-admin.css',
                
                'my_admin_menu_css'=>'{css_url}admin_menu.css',
                'my_jquery_ui'=>'{css_url}jquery-ui.css'
            ),
            'scripts'=>array(
                'my_general_js'=>'{jscript_url}admin/my_general.js'
            ),
            
        ),
        'my_pro_timeline_add_new'=>array(
            'page_title'=>__("Add new","my_support_theme"),
            'menu_title'=>__("Add new","my_support_theme"),
            'capability'=>'manage_options',
            'is_logged'=>true,
            'template'=>'',
            'parent'=>'my_pro_timeline',//specify parent menu if you want
            'styles'=>array(
                'my_table_view_css'=>'{modules_url}tableview/assets/css/admin.css',
                'my_admin_css'=>'{css_url)admin.css',
                'my_social_admin_css'=>'{css_url}social-admin.css',
                
                'my_admin_menu_css'=>'{css_url}admin_menu.css',
                'my_jquery_ui'=>'{css_url}jquery-ui.css'
            ),
            'scripts'=>array(
                'my_general_js'=>'{jscript_url}admin/my_general.js'
            ),
            
        ),
        'my_pro_timeline_options'=>array(
            'page_title'=>__("Options","my_support_theme"),
            'menu_title'=>__("Options","my_support_theme"),
            'capability'=>'administrator',
            'is_logged'=>true,
            'template'=>'',
            'parent'=>'my_pro_timeline',//specify parent menu if you want
            'styles'=>array(
                'my_social_admin_css'=>'{css_url}social-admin.css',
                
                'my_table_view_css'=>'{modules_url}tableview/assets/css/admin.css',
                'my_admin_css'=>'{css_url)admin.css',
                'my_admin_menu_css'=>'{css_url}admin_menu.css',
                'my_jquery_ui'=>'{css_url}jquery-ui.css'
            ),
            'scripts'=>array(
                'my_general_js'=>'{jscript_url}admin/my_general.js'
            ),
            
        )
        
    ),
    /*'front_pages'=>array(
     'my_front_forms'=>array(
     'title'=>__("Form Builder","my_support_theme"),
     'capability'=>'manage_options',
     'is_logged'=>true,
     'template'=>'',
     'parent'=>'',//specify parent menu if you want
         
     )
     ) */
);
return $menu;