<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Front_Controller')){
	class Class_My_Front_Controller{
		use MyArrayOptions,MyDebug;
		private $is_ajax;
		private $is_module=false;
		private $controller_name;
		private $controller_dir;
		private $controller_action;
		private $controller_file;
		private $capability;
		private $use_case='my_framework';
		function __construct($options=array()){
			if(!empty($options['debug'])){
				$this->setDebugOptions($this->use_case);
			}
			self::debug("front_controller", $options,false);
		}
		public function init(){
			
		}
		function route(){
			
		}
	}
	
}
