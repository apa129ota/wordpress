<?php
if(!defined('ABSPATH'))die('');
if(!class_exists("Class_My_Pro_Timeline_Page_Controller")){
    class Class_My_Pro_Timeline_Page_Controller extends Class_My_General_Controller{
        function __construct($options=array()){
            $options['isPageContr']=1;
            parent::__construct($options);
            
        }
        function init(){
            
        }
        function my_pro_timeline_preview(){
            $timelineClass=$this->plugin_object->getModule('timeline');
            $html=$timelineClass->renderPreviewPage();
            $this->add_template_var('html', $html);
            $file=$this->plugin_object->getDir('views');
            $file.='pages/preview.php';
            $this->loadFile($file);
            
        }
        /**
         * Add new
         */
        function my_pro_timeline_add_new(){
            $timelineClass=$this->plugin_object->getModule('timeline');
            $html=$timelineClass->renderShortcodesPage();
            $this->add_template_var('html', $html);
            $file=$this->plugin_object->getDir('views');
            $file.='pages/shortcodes.php';
            $this->loadFile($file);
            
            
        }
        /**
         * 
         */
        function my_pro_timeline(){
            $timelineClass=$this->plugin_object->getModule('timeline');
            $html=$timelineClass->renderHomePage();
            $this->add_template_var('html', $html);
            $file=$this->plugin_object->getDir('views');
            $file.='pages/home.php';
            $this->loadFile($file);
            
            
        }
        /**
         * Global plugin options
         */
        function my_pro_timeline_options(){
            $optionsClass=$this->plugin_object->getModule('options');
            $html=$optionsClass->renderForm();
            $this->add_template_var('html', $html);
            $file=$this->plugin_object->getDir('views');
            $file.='pages/options.php';
            $this->loadFile($file);
            
            
        }
    }
}