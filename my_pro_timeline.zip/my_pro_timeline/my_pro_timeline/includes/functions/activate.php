<?php
if(!defined('ABSPATH'))die('');
function wp_my_pro_timeline_activate(){
    global $wpdb;
    $table_name = $wpdb->prefix . 'my_pro_timeline_ips';
    
    if ($wpdb->get_var ( "SHOW TABLES LIKE '$table_name'" ) != $table_name) {
        $sql = "CREATE TABLE IF NOT EXISTS " . $table_name . "
									(	ID bigint(20) NOT NULL AUTO_INCREMENT,
										object_type char(255) NOT NULL,
                                        ip char(255) NOT NULL,
                                        postID  bigint(20) NOT NULL,
										created DATETIME,
                                        PRIMARY KEY (ID),
										KEY postID(postID)
										)";
        $wpdb->query ( $sql );
    }
    
    $table_name = $wpdb->prefix . 'my_pro_timeline_comments';
    
    if ($wpdb->get_var ( "SHOW TABLES LIKE '$table_name'" ) != $table_name) {
        $sql = "CREATE TABLE IF NOT EXISTS " . $table_name . "
									(	ID bigint(20) NOT NULL AUTO_INCREMENT,
										postID  bigint(20) NOT NULL,
										userID  bigint(20) NOT NULL,
                                        created DATETIME,
                                        text    longtext COLLATE utf8_general_ci,
										stars   tinyint,  
                                        PRIMARY KEY (ID),
										KEY postID(postID)
										)";
        $wpdb->query ( $sql );
    }
    $table_name = $wpdb->prefix . 'my_pro_timeline_objects';
    
    if ($wpdb->get_var ( "SHOW TABLES LIKE '$table_name'" ) != $table_name) {
        $sql = "CREATE TABLE IF NOT EXISTS " . $table_name . "
									(	ID bigint(20) NOT NULL AUTO_INCREMENT,
										title tinytext NOT NULL COLLATE utf8_general_ci,
										object_type char(255) NOT NULL,
                                        created DATETIME,
                                        updated DATETIME,
										PRIMARY KEY (ID),
										KEY object_type(object_type)
										)";
        $wpdb->query ( $sql );
    }
    $table_name = $wpdb->prefix . 'my_pro_timeline_object_meta';
    if ($wpdb->get_var ( "SHOW TABLES LIKE '$table_name'" ) != $table_name) {
        $sql = "CREATE TABLE IF NOT EXISTS " . $table_name . " (
  									meta_id bigint(20) unsigned NOT NULL auto_increment,
  									object_id bigint(20) unsigned NOT NULL default '0' COLLATE utf8_general_ci,
  									meta_key varchar(255) default NULL COLLATE utf8_general_ci,
  									meta_value longtext COLLATE utf8_general_ci,
  									PRIMARY KEY  (meta_id),
  									KEY object_id (object_id),
  									KEY meta_key (meta_key)
					)";
        $wpdb->query ( $sql );
    }
}

