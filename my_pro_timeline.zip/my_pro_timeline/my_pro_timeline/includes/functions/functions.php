<?php
if(!defined('ABSPATH'))die('');
if(!function_exists('wp_my_pro_timeline_date_line')){
    function wp_my_pro_timeline_date_pretty($date,$strings,$long=true){
        $date=explode("/",$date);
        if(count($date)==3){
            $year=$date[0];
            $month=$date[1];
            $day=$date[2];
        }else {
            $year=date('Y');
            $month=date('m');
            $day=date('d');
        }
        $str=$year.", ";
        $m=$month-1;
        if($long){
            $month=$strings['monthsFull'][$m];
        }else {
            $month=$strings['monthsShort'][$m];
        }
        $str.=$month.' '.$day;
        return $str;
        
    }
}
        
if(!function_exists('wp_my_pro_timeline_date_line')){
    function wp_my_pro_timeline_date_line($year,$month,$strings,$long=true){
            $dateStr=$year.'/';
            $m=$month-1;
            if($long){
                $month=$strings['monthsFull'][$m];
            }else {
                $month=$strings['monthsShort'][$m];
            }
            $dateStr.=$month;
            return $dateStr;
    }
}
        
if(!function_exists('wp_my_general_error_my_pro_timeline')){
    function wp_my_general_error_my_pro_timeline($errno,$errstr,$errfile,$errline,$errc){
        //echo  $errfile;
        if(strpos($errfile,'my_pro_timeline')!==false){
            if(class_exists('Class_My_Module_Debug')){
                $type='';
                $string='';
                switch($errno){
                    case E_USER_ERROR:
                        $type='E_USER_ERROR';
                        break;
                    case E_USER_NOTICE:
                        $type='E_USER_NOTICE';
                        break;
                    default:
                        $type='E_OTHER';
                        break;
                }
                $arr=array(
                    'dateTime'=>date('Y/m/d H:i:s'),
                    'type'=>$type,
                    'errno'=>$errno,
                    'file'=>$errfile,
                    'line'=>$errline,
                    'errstr'=>$errstr,
                    'errc'=>$errc,
                    'debugTrace'=>debug_backtrace()
                );
                Class_My_Module_Debug::add_section($errfile, $arr,'errors');
                return true;
            }else {
                return false;   
            }
        }else return false;
    }
    set_error_handler('wp_my_general_error_my_pro_timeline',E_ALL);
}

if(!function_exists('wp_my_my_pro_timeline_format_number')){
    function wp_my_my_pro_timeline_format_number($n){
        if($n<1000){
            return $n;
        }else if($n>1000){
            $m=floor((double)$n/1000000);
            if($m>0){
                $k=round(($n-$m*1000000)/100000,0);
                if($k!=0)$str=$m.'.'.$k;
                else $str=$m;
                return $str.__("M","my_support_theme");
            }else {
                $k=floor((double)$n/1000);
                $s=round(($n-($k*1000))/100,0);
                //echo 'n='.$n.' k='.$k.' s='.$s;
                if($s!=0)$str=$k.'.'.$s;
                else $str=$k;
                return $str.__("K","my_support_theme");
            }
        }
    }
}


if(!function_exists('wp_my_pro_timeline_error_msg')){
    function wp_my_pro_timeline_error_msg($msg,$type='generalError'){
        ob_start();
        ?>
       <div class="my_module_error" data-type="<?php echo esc_attr($type);?>">
    				<i class="fa fa-exclamation-circle"></i>&nbsp;&nbsp;<?php echo $msg;?>
    				</div>
    	<?php 
    	$html=ob_get_clean();
    	return $html;
    }
}
if(!function_exists('wp_my_pro_timeline_ok_msg')){
    function wp_my_pro_timeline_ok_msg($msg,$type='generalOK'){
        ob_start();
        ?>
         <div class="my_module_ok" data-type="<?php echo esc_attr($type);?>">
    				<i class="fa fa-thumbs-o-up"></i>&nbsp;&nbsp;<?php echo $msg?>
    				</div>
                    
        <?php 
        $html=ob_get_clean();
        return $html;
    }
}

/**
 * Save option
 */
if(!function_exists('wp_my_pro_timeline_save_option')){
    function wp_my_pro_timeline_save_option($key,$val){
        global $Class_My_Pro_Timeline_Main_Class;
        $Class_My_Pro_Timeline_Main_Class->addUpdateNewOption($key, $val,true);
    }
}
/**
 * get options
 */
if(!function_exists('wp_my_pro_timeline_get_option')){
    function wp_my_pro_timeline_get_option($key){
        global $Class_My_Pro_Timeline_Main_Class;
        return $Class_My_Pro_Timeline_Main_Class->getOptionByKey($key);
    }
}
if(!function_exists('wp_my_general_error_my_pro_testimonials')){
    function wp_my_general_error_my_pro_testimonials($errno,$errstr,$errfile,$errline,$errc){
        //echo  $errfile;
        if(strpos($errfile,'plugins/my_pro_timeline')!==false){
            if(class_exists('Class_My_Module_Debug')){
                $type='';
                $string='';
                switch($errno){
                    case E_USER_ERROR:
                        $type='E_USER_ERROR';
                        break;
                    case E_USER_NOTICE:
                        $type='E_USER_NOTICE';
                        break;
                    default:
                        $type='E_OTHER';
                        break;
                }
                //$string.=$errno.':'.$errstr.' in '.$errfile.':'.$errline."\nDate=".date('Y/m/d H:i:s');
                $db=debug_backtrace();
                $arr=array(
                    'errno'=>$errno,
                    'errline'=>$errline,
                    'errstr'=>$errstr,
                    'date'=>date('Y/m/d H:i:s'),
                    'db'=>$db
                );
                Class_My_Module_Debug::add_section($errfile, $arr,'errors');
                return true;
            }else {
                
            }
        }else return false;
    }
    //set_error_handler('wp_my_general_error_my_pro_testimonials',E_ALL);
}