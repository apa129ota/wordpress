<?php
if(!defined('ABSPATH'))die('');
$my_header_msg=__("Add new/Edit Social Stream Templates","my_support_theme");
//wp_my_loto_komb();

?>
<div class="wrap">

	
<?php
	$file=$my_views_dirname.'elements/my_header.php';
	require $file;
	?>
	<div class="my_container_inner">
		<div class="my_image_mapper_tmpl_data my_clearfix">
		<p>
	<?php echo __("Create new templates, edit predefined styles , show remove elements from view and many many more.","my_support_theme");?>
	</p>
<?php echo $html;?>
</div>
</div>
</div>