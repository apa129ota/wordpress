<?php
if(!defined('ABSPATH'))die('');
$my_header_msg=__("About","my_support_theme");
//wp_my_loto_komb();
?>
<div class="wrap">	
<?php 
	$file=$my_views_dirname.'elements/my_header.php';
	require $file;
	?>
	<div class="my_container_inner">
		<div class="my_image_mapper_tmpl_data my_clearfix">
		<?php echo $html;?>
		</div>
	</div>
</div>		
	