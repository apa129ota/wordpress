<?php
if(!defined('ABSPATH'))die('');
$my_header_msg=__("Plugin Shortcodes","my_support_theme");
?>

<div class="wrap">

	<?php 
	$file=$my_views_dirname.'elements/my_header.php';
	require $file;
	?>
	<div class="my_container_inner">
	
	
	<?php echo $html;?>
	</div>
</div>	