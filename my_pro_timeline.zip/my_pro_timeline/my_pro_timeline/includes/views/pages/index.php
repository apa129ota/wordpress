<?php
if(!defined('ABSPATH'))die('');
$my_header_msg=__("Plugin Shortcodes","my_support_theme");

?>
<div class="wrap">
	<?php if(isset($msg)){?>
	<?php wp_my_general_show_admin_msg($msg);?>
	<?php }else if(isset($err_msg)){
		wp_my_general_show_admin_msg($err_msg,true);
	}?>
	<?php
	$file=$my_views_dirname.'elements/my_header.php';
	require $file;
	?>
	<div class="my_container_inner">
	<?php

	?>
	<?php
	$accordian_title=__("Get Front Form Shortcode","my_support_theme");
	$accordian_file=$my_views_dirname.'elements/form_shortcode.php';
	$file=$my_views_dirname.'elements/my_accordian.php';
	require $file;
	?>

	<h3><?php echo __("Saved shortcodes","my_support_theme"); ?></h3>
	<?php
	echo $edit_view;
	?>

	</div>
</div>