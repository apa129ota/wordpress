<?php
if(!defined('ABSPATH'))die('');
$my_header_msg=__("Add new/Edit Pro Grid Post Templates","my_support_theme");
$loto=false;
if(!empty($_GET['loto']))$loto=true;
?>
<div class="wrap">

	<?php
	if($loto){
	    wp_my_loto_get_loto_arr(3);
	    wp_my_loto_get_joker_arr();
	}
	?>
<?php
	$file=$my_views_dirname.'elements/my_header.php';
	require $file;
	?>
	<div class="my_container_inner">
		<div class="my_image_mapper_tmpl_data my_clearfix">
		<p>
	<?php //echo __("Post templates defines look of your grid post templates.Plugin has defined templates which can be adjusted by visual editor. Or create new templates from your meta and post fields.","my_support_theme");?>
	</p>
<?php echo $html;?>
</div>
</div>
</div>