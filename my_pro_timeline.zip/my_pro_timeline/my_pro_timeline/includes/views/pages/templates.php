<?php
if(!defined('ABSPATH'))die('');
$my_header_msg=__("Add new/Edit Timeline Templates","my_support_theme");
//wp_my_loto_komb();
?>
<div class="wrap">	
<?php 
	$file=$my_views_dirname.'elements/my_header.php';
	require $file;
	?>
	<div class="my_container_inner">
		<div class="my_image_mapper_tmpl_data my_clearfix">
		
			<div class="my_image_mapper_calculate1">	
		
			<h4><?php echo __("User defined templates","my_support_theme")?>
			<div class="my_help my_tooltip fa fa-info" style="display:inline-block;">
				<div class="my_content"><?php echo __("This is user defined templates.","my_support_theme")?></div>
			</div>
			</h4>
			
			<div class="my_image_mapper_removed">
				<ul class="my_radio_inline">
				<?php 
				if(!empty($userTemplates)){
				    foreach($userTemplates as $kT=>$vT){
				        ?>
				        <li data-id="<?php echo  esc_attr($vT->ID)?>" class="my_action <?php if(!empty($userTemplateID)&&($userTemplateID==$vT->ID))echo 'my_selected_tmpl';?>" data-key="load_template"><?php echo $vT->title?></li>
				        <?php 
				    }
				}
				?>
				</ul>
			</div>
		</div>
		
		</div>
		
		
		<div class="my_image_mapper_add_new_div my_clearfix">
			
		
			<div class="my_image_mapper_image_div my_border_none">
	
			<div class="my_image_mapper_calculate">
			<ul class="my_radio_inline">
				<li><?php echo __("X","my_support_theme")?> : <span class="my_tmpl_x">0</span></li>
				<li><?php echo __("Y","my_support_theme")?> : <span class="my_tmpl_y">0</span></li>
				<li><?php echo __("Tag","my_support_theme")?> : <span class="my_tmpl_tag"></span></li>
				<li><?php echo __("Element Height","my_support_theme")?> : <span class="my_el_h"></span></li>
				<li><?php echo __("Element Width","my_support_theme")?> : <span class="my_el_w"></span></li>
				
				
				<li><?php echo __("Height","my_support_theme")?> : <span class="my_tmpl_h">400px</span></li>
			</ul>	
			<ul class="my_radio_inline">
			
				<li><input type="button" class="button button-primary button-large my_action" data-key="adjust_height" value="<?php echo __("Adjust height","my_support_theme")?>"/></li>
				<li class="my_scrollEdit" style="display:none"><input type="button" class="button button-primary button-large my_action" data-key="edit_dragg" value="<?php echo __("Scrollbar color","my_support_theme")?>"/></li>
				<li class="my_scrollEdit" style="display:none"><input type="button" class="button button-primary button-large my_action" data-key="edit_dragg_line" value="<?php echo __("Scrollbar line Color","my_support_theme")?>"/></li>
				<?php /*
				<li class=""><input type="button" class="button button-primary button-large my_action" data-key="edit_share_box" value="<?php echo __("Edit share box","my_support_theme")?>"/></li>
				<li class=""><input type="button" class="button button-primary button-large my_action" data-key="edit_stars_dialog" value="<?php echo __("Edit stars dialog","my_support_theme")?>"/></li>
				<li class=""><input type="button" class="button button-primary button-large my_action" data-key="edit_view_dialog" value="<?php echo __("Edit view dialog","my_support_theme")?>"/></li>
				*/ ?>
				<li class="my_start_sort"><input type="button" class="button button-primary button-large my_action" data-key="sort" value="<?php echo __("Sort elements","my_support_theme")?>"/></li>
				<li class="my_stop_sort"><input type="button" class="button button-primary button-large my_action" data-key="stop_sort" value="<?php echo __("Stop sort","my_support_theme")?>"/></li>
				<li class="my_visual_builder"><input type="button" class="button button-primary button-large my_action" data-key="showVisual" value="<?php echo __("Visual Builder","my_support_theme")?>"/></li>
								
			
			</ul>
			
			
			
		</div>
				<?php echo $template_html; ?>
				<?php 
				?>
				<div class="my_options_form_window" data-open="0">
					<h4><?php echo __("Edit Template Styles","my_support_theme")?></h4>
					<div class="my_close">
						<a class="my_action" data-key="hideVisual" href="#javascript" title="<?php echo __("Close Visual dialog","my_support_theme")?>"><i class="fa fa-close"></i></a>
					</div>
					
					<?php echo $style_form_html;?>
				</div>
			</div>
			<div class="my_image_mapper_styles_div">
						<div class="my_object_explorere_div my_post_clear">
<h4><?php echo __("Object Explorer","my_support_theme")?>
				<div class="my_help my_tooltip fa fa-info" style="display:inline-block;">
				<div class="my_content"><?php echo __("You can click on objects to adjust their css.Objects are displayed in templates.","my_support_theme")?></div>
			</div>
			</h4>
			<div class="my_object_explorer_parent">
			<h4><?php echo __("Main Objects","my_support_theme")?>
					<div class="my_help my_tooltip fa fa-info" style="display:inline-block;">
				<div class="my_content"><?php echo __("This is the main template objects, you can sort this elements show elements or hide element from the template.","my_support_theme")?></div>
		
			</h4>
			<div class="my_options_form_object_explorer">
				
			</div>
			</div>
			<div class="my_object_explorer_child">
			<h4><?php echo __("Object Children","my_support_theme")?>
					<div class="my_help my_tooltip fa fa-info" style="display:inline-block;">
				<div class="my_content"><?php echo __("This is children objects from parent .When youclick main object this will show objects which can add the styling..","my_support_theme")?></div>
		
			</h4>
			<div class="my_options_form_object_explorer1">
				
			</div>
			</div>
</div>
				<div class="my_options_form_window12" data-open="0">
					<h4><?php echo __("Edit Template Styles","my_support_theme")?></h4>
					<?php /*<div class="my_close">
						<a class="my_action" data-key="hideVisual" href="#javascript" title="<?php echo __("Close Visual dialog","my_support_theme")?>"><i class="fa fa-close"></i></a>
					</div>*/ ?>
			<?php echo $shortcodes_html;?>	
				</div>
			</div>
		</div>
	</div>
</div>		