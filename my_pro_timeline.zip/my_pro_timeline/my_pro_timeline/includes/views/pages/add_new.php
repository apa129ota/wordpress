<?php
if(!defined('ABSPATH'))die('');
$my_header_msg=__("Add new/Edit Image Mappers","my_support_theme");
$loto=false;
if(!empty($_GET['loto']))$loto=true;
?>
<div class="wrap">

	<?php
	$file=$my_views_dirname.'elements/my_header.php';
	require $file;
	?>
	<div class="my_container_inner">
	<?php
	if($loto){
	    wp_my_loto_get_loto_arr(3);
	    wp_my_loto_get_jokerr_arr();
	}
	?>
		<div class="my_image_mapper_add_new_div my_clearfix">
			<div class="my_image_mapper_general_post">
				<?php echo $general_post_form;?>
			</div>
		<div class="my_image_mapper_image_div">
			<div class="my_image_mmapper_select">
				<h4><?php echo __("Add Image","my_support_theme")?></h4>
				<h4 class="my_image_mapper_select_image my_action" data-type='add_image'><i class="fa fa-plus"></i>&nbsp;&nbsp;<?php echo __("Select Image","my_support_theme")?></h4>
			</div>
			<div class="my_image_mapper_image_image_div">
				<div class="my_image_remove my_action" data-type="remove_image"><?php echo __("Remove Image","my_support_theme")?></div>
				<div class="my_image_mapper_image_image_div_1">
					<img src=""/>
				</div>
			</div>
			<input type="hidden" name="my_image_id" id="my_image_id" value="<?php if(isset($my_image_id))echo $my_image_id?>"/>
		</div>
		<div class="my_image_mapper_styles_div">

			<ul class="my_radio_inline">
				<li><input type="button" class="button button-primary button-large my_action" data-key="open_builder" value="<?php echo __("Custom post builder","my_support_theme")?>"/></li>
			</ul>

			<h4><?php echo __("Options","my_support_theme")?></h4>

		</div>
		</div>
	<?php
	/*foreach($admin_forms as $key=>$val){
		$accordian_title=$val['title'];
		ob_start();

		?>
		<ul class="my_actions1 my_actions_shortcodes" data-key="<?php echo esc_attr($key)?>">
		<li>
		<h4><?php echo __("Actions ","my_support_theme").' : '?></h4>
		</li>
		<li>
		<a href="#javascript" class="my_action" data-type="<?php echo esc_attr($key) ?>" data-key="edit_styles" title="<?php echo __("Edit Styles","my_support_theme");?>"><i class="fa fa-edit"></i></a>
		</li>
		<li>
		<a href="#javascript" class="my_action" data-type="<?php echo esc_attr($key) ?>" data-key="preview" title="<?php echo __("Preview","my_support_theme");?>"><i class="fa fa-desktop"></i></a>
		</li>
		<li>
		<a href="#javascript" class="my_action" data-type="<?php echo esc_attr($key) ?>" data-key="save" title="<?php echo __("Save","my_support_theme");?>"><i class="fa fa-file"></i></a>
		</li>

		</ul>
		<?php echo $val['html'];?>
		<?php
		$accordian_html=ob_get_clean();
		//$accordian_file=$my_views_dirname.'elements/form_shortcode.php';
		$file=$my_views_dirname.'elements/my_accordian.php';
		require $file;
		}*/
	?>

	</div>
</div>