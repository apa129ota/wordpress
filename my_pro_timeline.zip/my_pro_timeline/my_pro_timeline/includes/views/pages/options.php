<?php
if(!defined('ABSPATH'))die('');
$my_header_msg=__("General Plugin Options","my_support_theme");
?>

<div class="wrap">

	<?php 
	$file=$my_views_dirname.'elements/my_header.php';
	require $file;
	?>
	<div class="my_container_inner">
	<p><?php echo __("Set Global Plugin Options","my_support_theme");?></p>
	<p class="alert-blue">
	<?php echo __("Plugin uses invisible recapctha to protect comments form.","my_support_theme");?><br/>
	<?php echo __("Please register your site and save public and private key at recaptcha fields.","my_support_theme");?><br/>
	<?php echo __("Visit Google recaptcha site","my_support_theme");?> : <a href="https://www.google.com/recaptcha" target="_blank"><?php echo __("Google recapctha site","my_support_theme");?></a>
	</p>
	<?php echo $html;?>
	</div>
</div>	