<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_accordian" data-on="0">
		<div class="my_accordian_header"><h4><i class="fa fa-plus"></i><i class="fa fa-minus" style="display:none"></i>&nbsp;&nbsp;<?php echo $accordian_title?></h4></div>
	<div class="my_accordian_inner">
	<?php 
	if(isset($accordian_file)){
		if(file_exists($accordian_file)){
			require $accordian_file;	
		}
	}else {
		echo $accordian_html;	
	}
	?>
	</div>
</div>
		