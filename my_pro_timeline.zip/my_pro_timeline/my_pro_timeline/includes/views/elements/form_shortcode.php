<?php
if(!defined('ABSPATH'))die('');
?>
<ul class="my_actions_1 my_clear_after">
	<li>
	<label for="my_category_id"><?php echo __("Testimonial Category","my_support_theme") ?></label>
	
		<select name="my_category" id="my_category_id">
		<option value=""><?php echo __("---Select Category---","my_support_theme")?></option>
		<?php foreach($terms as $k=>$v){?>
		<option value="<?php echo $v->term_id?>"><?php echo $v->name;?></option>
		<?php }?>
	</select>
	</li>
	<li>
	<input type="button" class="button my_action" data-key="my_generate_shortcode" value="<?php echo __("Generate Shortcode","my_support_theme") ?>"/>
	</li>
</ul>
<br/>
<br/>
<h3><?php echo __("Front form shortcode","my_support_theme")?></h3>
<p>
<?php 
echo __("Add this shortcode to page, if you want to limit submission to category select testimonials category from top","my_support_theme")
?>

</p>
<div class="my_shortcode_content" data-key="<?php echo $shortcode; ?>">
	<?php 
	echo '['.$shortcode.']';
	?>
</div>