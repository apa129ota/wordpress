<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_container my_container_2">
	<div class="my_header">
		<h4><?php echo __("My Pro Timeline","my_support_theme")?>&nbsp;&nbsp;<span><?php echo __("version","my_support_theme");echo ' 1.0';?></span></h4>
	</div>
	<div class="my_header_intro">
		<h4><?php echo $my_header_msg;//echo __("Use this setion to update sliders/add new sliders !","my_support_theme")?></h4>
	</div>
</div>