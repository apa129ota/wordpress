(function($) { 
	myAdminSocialPostsGetPosts=function(o){
		var self;
		this.my_working=false;
		this.debug=true;
		this.options=o;
		this.network='';
		this.network_ids='';
		this.my_pre_open_post_id='';
		this.search_ids={};
		this.my_get_all=false;
		this.my_save_all=false;
		self=this;
		this.init=function(o){
			if(typeof self.options.my_debug!='undefined'){
				if(!self.options.my_debug){
					self.debug=false;
				}
			}
			self.my_debug("Options",self.options);
			$(".my_tooltip").tooltip({
				items:"div",
				
				content:function(){
					var html=$(this).children(".my_content").html();
					///console.log('Html '+html);
					return html;
				}
				});
			$("#my_form_inner_1 .my_social_networks li").click(self.my_choose_network);
			$(".my_timeline_modal_load .my_social_networks li").click(self.my_choose_ids_network);
			$(".my_social_ids").click(function(e){
				myAdminDialog_inst.open_dialog();
			});
			$(document).on("click",".my_get_ids_action",self.my_get_ids);
			$(document).on("click",".my_load_more",self.load_more);
			$("#my_get_social_posts").click(self.get_social_posts);
			$("#my_get_info").click(self.get_info);
			$("#my_save_social_ids").click(self.save_ids);
			//$(document).on('click',"#my_get_social_posts",self.my_get_social_posts);
			$(document).on('click',".my_open_post",function(e){
				e.preventDefault();
				var same_post=false;
				var pre_id=self.my_pre_open_post_id;
				var id=$(this).parents('.my_post_single').attr('id');
				self.my_debug('Show',id);
				self.my_debug('Pre id',pre_id);
				self.my_pre_open_post_id=id;
				$(this).parents('.my_post_single').css('z-index',1000000);
				if($(this).parents('.my_post_single').find(".my_post_inside").is(":visible")){
					$(this).find('.fa-arrow-right').show();
					$(this).find('.fa-arrow-down').hide();
					same_post=true;
					$(this).parents('.my_post_single').css('z-index','');
				}else {
					$(this).find('.fa-arrow-right').hide();
					$(this).find('.fa-arrow-down').show();
					
				}
				self.my_debug('Same post',same_post);
				if(!same_post){
					$(this).find(".my_post_inside").filter(":visible").slideToggle(500);
					$(this).find(".my_post_inside").filter(":visible").parents('.my_post_single').css('z-index','');
				}
					$(this).parents('.my_post_single').find(".my_post_inside").slideToggle(500);
				
			});
			$(document).on('click',".my_load_more_posts",function(e){
				self.my_debug("Load more posts");
				$("#my_get_social_posts").trigger('click');
			});
			$(document).on('click',".my_post_single .my_save_posts",self.save_posts);
			$(document).on('click',"#my_get_social_all",self.get_all_posts);
			$(document).on('click',"#my_save_social_all",self.save_all);
			$(document).on("my_saved",".my_post_single",self.save_all);
			$(document).on('click',"#my_stop_getting_all_12",function(e){
				e.preventDefault();
				self.my_get_all=false;
				self.my_debug("Stop getting all");
				delete self.my_set_msg_12;
			});
			$(document).on('click',"#my_get_social_cache",self.get_cache);
			$(document).on('click',".my_get_access_token",self.get_access_token);
			$(document).on('change',"#youtube_name_1 , input[name='my_serach_type']",function(){
				self.my_debug("Clean youtube cursor");
				$("#youtube_cursor_next").val('');
			});
			$(document).on('change',"#facebook_id",function(){
				self.my_debug("Clean facebook cursor");
				$("#facebook_cursor_next").val('');
			});
			$(document).on('change',"#google_name",function(){
				self.my_debug("Clean google cursor");
				$("#google_cursor_next").val('');
			});
			$(document).on('click',".my_delete_posts",self.my_delete_social_id);
			$(document).on('click',".my_update_posts",self.update_metadata);
		};
		this.update_metadata=function(e){
			e.preventDefault();
			var msg=self.options.msgs.my_update_posts_metadata;
			var id=$(this).data('id');
			self.my_debug("Update social id",id);
			self.my_a_123=$(this);
			var page=1;
			if(typeof self.my_id_1234!='undefined'){
				if(self.my_id_1234==id){
					page=self.my_page_1234;
				}
			}
			self.my_id_1234=id;
				var data={
						action:'my_update_metadata',
						my_action:'my_update_metadata',
						id:id,
						page:page
					};
				self.my_debug("Ajax data",data);
					//var msg=self.options.msgs.my_delete_social_id;
					if(page==1)myAdminMsgs_inst.my_show_working_window(msg);
					$.ajax({
						url:self.options.ajax_url,
						dataType:'json',
						data:data,
						cache:false,
						timeout:self.options.ajax_timeout,
						type:'POST',
						success:function(data,status,jq){
							self.my_debug('data',data);
							
							if(data.error==0){
								//$("."+self.network+"_dont_have_access").hide();
								//$("."+self.network+"_have_access").show();
								//myAdminMsgs_inst.my_show_success_window(data.msg);
								//$(self.my_a_12).parents('tr').remove();
								self.my_page_1234=data.page;	
							}else {
								myAdminMsgs_inst.my_remove_window();
								myAdminMsgs_inst.my_show_error_window(data.msg);
							}
							if(!data.has_more){
								if(data.error==0){
									myAdminMsgs_inst.my_remove_window();
									myAdminMsgs_inst.my_show_success_window(data.msg);
									delete self.my_id_1234;
								}
								setTimeout(function(){
									myAdminMsgs_inst.my_remove_window();
								//self.my_working=false;
								},self.options.msg_window_timeout);
							}else {
								$(self.my_a_123).trigger('click');
							}
						},
						error:function(jq,status){
						self.my_working=false;
						var msg=self.options.msgs.network_error;
						myAdminMsgs_inst.my_show_error_window(msg);
						
						setTimeout(function(){
							myAdminMsgs_inst.my_remove_window();
							//self.my_working=false;
						},self.options.msg_window_timeout);
					}
					});
			
		};
		this.my_delete_social_id=function(e){
			e.preventDefault();
			var msg=self.options.msgs.my_delete_social_id_yes;
			var id=$(this).data('id');
			self.my_debug("Delete social id",id);
			self.my_a_12=$(this);
			if(confirm(msg)){
				var data={
						action:'my_delete_social_id',
						my_action:'my_delete_social_id',
						id:id
					};
				if(self.my_working)return;
				self.my_working=true;
				self.my_debug("Ajax data",data);
					var msg=self.options.msgs.my_delete_social_id;
					myAdminMsgs_inst.my_show_working_window(msg);
					$.ajax({
						url:self.options.ajax_url,
						dataType:'json',
						data:data,
						cache:false,
						timeout:self.options.ajax_timeout,
						type:'POST',
						success:function(data,status,jq){
							self.my_working=false;
							self.my_debug('data',data);
							myAdminMsgs_inst.my_remove_window();
							if(data.error==0){
								//$("."+self.network+"_dont_have_access").hide();
								//$("."+self.network+"_have_access").show();
								myAdminMsgs_inst.my_show_success_window(data.msg);
								$(self.my_a_12).parents('tr').remove();
							}else {
								myAdminMsgs_inst.my_show_error_window(data.msg);
							}
							setTimeout(function(){
								myAdminMsgs_inst.my_remove_window();
								//self.my_working=false;
							},self.options.msg_window_timeout);
						},
						error:function(jq,status){
						self.my_working=false;
						var msg=self.options.msgs.network_error;
						myAdminMsgs_inst.my_show_error_window(msg);
						
						setTimeout(function(){
							myAdminMsgs_inst.my_remove_window();
							//self.my_working=false;
						},self.options.msg_window_timeout);
					}
					});
			}
		};
		this.get_access_token=function(e){
			e.preventDefault();
			var network=self.network;
			self.my_debug('Network',network);
			self.my_debug('save All');
			if(typeof network=='undefined' || network==''){
				var msg=self.options.msgs.select_network;
				myAdminMsgs_inst.my_show_error_window(msg);
				setTimeout(function(){
					myAdminMsgs_inst.my_remove_window();
					//self.my_working=false;
				},self.options.msg_window_timeout);
				return;
			}
			var data={
					action:'my_get_access_token',
					my_action:'my_get_access_token',
					network:network
				};
			self.my_debug("Ajax data",data);
				var msg=self.options.msgs.my_get_access_token;
				myAdminMsgs_inst.my_show_working_window(msg);
				$.ajax({
					url:self.options.ajax_url,
					dataType:'json',
					data:data,
					cache:false,
					timeout:self.options.ajax_timeout,
					type:'POST',
					success:function(data,status,jq){
						self.my_debug('data',data);
						myAdminMsgs_inst.my_remove_window();
						if(data.error==0){
							//$("."+self.network+"_dont_have_access").hide();
							//$("."+self.network+"_have_access").show();
						}else {
							myAdminMsgs_inst.my_show_error_window(data.msg);
						}
						setTimeout(function(){
							myAdminMsgs_inst.my_remove_window();
							//self.my_working=false;
						},self.options.msg_window_timeout);
					},
					error:function(jq,status){
					self.my_working=false;
					var msg=self.options.msgs.network_error;
					myAdminMsgs_inst.my_show_error_window(msg);
					
					setTimeout(function(){
						myAdminMsgs_inst.my_remove_window();
						//self.my_working=false;
					},self.options.msg_window_timeout);
				}
				});
			
			
		};
		this.init_pretty_photo=function(){
			var network=self.network;
			var div="my_form_"+network;
			$("."+div).find("a.my_pretty_photo[data-is='0']").prettyPhoto();
			$("."+div).find("a.my_pretty_photo[data-is='0']").attr('data-is',1);
		};
		this.autocomplete_social_id=function(obj,data,id,title){
			//var data=obj.data;
			self.my_debug("Autocomplete social id",{data:data,id:id,title:title});
			$(".my_social_networks li[data-type='"+data.network+"']").trigger('click');
			
			var form=".my_form_"+self.network+" form";
			var form_id=$(form).find("input[name='my_form_id']").val();
			
			var check={page:'page_'+form_id+'_id',next:'next_'+form_id,prev:'prev_'+form_id};
			$.each(check,function(i,v){
					var sel="input[type='hidden'][name='"+v+"']";
					if(i=='page')$(sel).val(1);
					else $(sel).val('');
				});
			$(".my_form_"+self.network+" .my_load_more_posts ").hide();
			$(".my_form_"+self.network+" .my_social_posts_inner .my_post_single ").remove();
			$("#title_"+form_id+"_id").val(data.title);
			if(data.network=='facebook'){
				if(data.subtype=='album_posts'){
					$("#id_"+form_id+"_id").val("/"+data.idstr);
				}else $("#id_"+form_id+"_id").val(data.idstr);
			}else {
				$("#id_"+form_id+"_id").val(data.idstr);
			}
			var cron_limit=100;
			if(typeof data.add_options.cron_limit!='undefined')cron_limit=data.add_options.cron_limit;
				
			$("#cron_limit_"+form_id+'_id').val(cron_limit);
			if(data.network=='twitter'){
				
				if(data.add_options.exclude_replies){
					$("#exclude_replies_"+form_id+"_id_div").find(".imapper-checkbox-on").trigger('click');
				}else {
					$("#exclude_replies_"+form_id+"_id_div").find(".imapper-checkbox-off").trigger('click');
				}
				if(typeof data.lang!='undefined' && data.lang!=''){
					$("#lang_"+form_id+"_id_div").data('my-script').set_value(data.lang);
				}
				
			}
			if(data.run_cron==1){
				$("#auto_get_"+form_id+"_id_div .imapper-checkbox-on").trigger('click');
			}else {
				$("#auto_get_"+form_id+"_id_div .imapper-checkbox-off").trigger('click');
			}
			
			//$("#category_"+form_id+"_id_button").trigger('click');
			$("#category_"+form_id+"_id_div").data('my-script').set_value(data.cat_id);
			
			
			$("#title_"+form_id+"_id").focus();
		};
		this.get_cache=function(e){
			e.preventDefault();
			var network=self.network;
			self.my_debug('Network',network);
			self.my_debug('save All');
			if(typeof network=='undefined' || network==''){
				var msg=self.options.msgs.select_network;
				myAdminMsgs_inst.my_show_error_window(msg);
				setTimeout(function(){
					myAdminMsgs_inst.my_remove_window();
					//self.my_working=false;
				},self.options.msg_window_timeout);
				return;
			}
			
			var form=".my_form_"+network+" form";
			var form_data=$(form).serialize();
			var data={
					action:'my_get_social_cache',
					my_action:'my_get_social_cache',
					data:form_data,
					network:network
				};
			self.my_debug("Ajax data",data);
				var msg=self.options.msgs.my_get_cache;
				myAdminMsgs_inst.my_show_working_window(msg);
				
				$.ajax({
					url:self.options.ajax_url,
					dataType:'json',
					data:data,
					cache:false,
					timeout:self.options.ajax_timeout,
					type:'POST',
					success:function(data,status,jq){
						self.my_debug('data',data);
						self.my_working=false;
						var form='my_form_'+self.network;
						var form_id=$("."+form+" form input[type='hidden'][name='my_form_id']").val();
						self.my_debug("Form id",form_id);
						var page=$("."+form+" input[name='page_"+form_id+"']").val();
						if(!self.my_get_all){
							myAdminMsgs_inst.my_remove_window();
						}
						if(data.error==0){
							
							if(typeof data.has_more!='undefined' && data.has_more){
								$("."+form+" .my_load_more_posts ").show();
								
							}else {
								
								$("."+form+" .my_load_more_posts ").hide();
							}
								if(self.network=='facebook'){
									$("."+form+" input[name='page_"+form_id+"']").val(data.page);
									$("."+form+" input[name='next_"+form_id+"']").val(data.next);
									$("."+form+" input[name='prev_"+form_id+"']").val(data.prev);
									
								}
								if(self.network=='pinterest'){
									$("."+form+" input[name='page_"+form_id+"']").val(data.page);
									$("."+form+" input[name='next_"+form_id+"']").val(data.next);
									//$("."+form+" input[name='prev_"+form_id+"']").val(data.prev);
									
								}
								if(self.network=='google'){
									$("."+form+" input[name='page_"+form_id+"']").val(data.page);
									$("."+form+" input[name='next_"+form_id+"']").val(data.next);
							
								}
								if(self.network=='youtube'){
									$("."+form+" input[name='page_"+form_id+"']").val(data.page);
									$("."+form+" input[name='next_"+form_id+"']").val(data.next);
							
								}
								if(self.network=='instagram'){
									$("."+form+" input[name='page_"+form_id+"']").val(data.page);
									$("."+form+" input[name='next_"+form_id+"']").val(data.next);
							
								}
								self.search_ids[self.network]=data.my_id;
							//}
							//if(page==1)
							$("."+form+" .my_social_posts_inner").html(data.stat);
							
								myAdminMsgs_inst.my_show_success_window(data.msg);
							
						}else {
							myAdminMsgs_inst.my_show_error_window(data.msg);
						}
						setTimeout(function(){
							self.init_pretty_photo();
						},500);
						setTimeout(function(){
							myAdminMsgs_inst.my_remove_window();
							//self.my_working=false;
						},self.options.msg_window_timeout);
						
					},
					error:function(jq,status){
					self.my_working=false;
					var msg=self.options.msgs.network_error;
					myAdminMsgs_inst.my_show_error_window(msg);
					
					setTimeout(function(){
						myAdminMsgs_inst.my_remove_window();
						//self.my_working=false;
					},self.options.msg_window_timeout);
				}
				});
		};
		this.save_all=function(e){
			e.preventDefault();
			var network=self.network;
			self.my_debug('Network',network);
			self.my_debug('save All');
			if(typeof network=='undefined' || network==''){
				var msg=self.options.msgs.select_network;
				myAdminMsgs_inst.my_show_error_window(msg);
				setTimeout(function(){
					myAdminMsgs_inst.my_remove_window();
					//self.my_working=false;
				},self.options.msg_window_timeout);
				return;
			}
			self.my_save_all=true;
			var form=".my_form_"+network+"";
			//$.each()
			if($(form).find(".my_post_single[data-saved='0']:first").length>0){
				$(form).find(".my_post_single[data-saved='0']:first").find(".my_save_posts").trigger('click');
				
			}
		};
		this.get_all_posts=function(e){
			e.preventDefault();
			var network=self.network;
			self.my_debug('Network',network);
			if(typeof network=='undefined' || network==''){
				var msg=self.options.msgs.select_network;
				myAdminMsgs_inst.my_show_error_window(msg);
				setTimeout(function(){
					myAdminMsgs_inst.my_remove_window();
					//self.my_working=false;
				},self.options.msg_window_timeout);
				return;
			}
			var form=".my_form_"+network+" form";
			var form_id=$(form).find("input[name='my_form_id']").val();
			var id_id="#id_"+form_id+"_id";
			var check={page:'page_'+form_id,next:'next_'+form_id,prev:'prev_'+form_id};
			var id=$(id_id).val();
			self.my_debug("Form id id",{form_id:form_id,id:id});
			
			if(typeof self.search_ids[network]=='undefined'){
				self.search_ids[network]='';
			}
			if(self.search_ids[network]!=id ){
				$.each(check,function(i,v){
					var sel="input[type='hidden'][name='"+v+"']";
					if(i=='page')$(sel).val(1);
					else $(sel).val('');
				});
				$(".my_form_"+self.network+" .my_load_more_posts ").hide();
				$(".my_form_"+self.network+" .my_social_posts_inner .my_post_single ").remove();
				
				self.my_debug("New search");
			}else self.my_debug("Old search",{id:id});
			self.my_get_all=true;
			$("#my_get_social_posts").trigger('click');
			//self.my_get_all=false;
		};
		this.save_posts=function(e){
			e.preventDefault();
			var network=self.network;
			self.my_debug('Network',network);
			if(typeof network=='undefined' || network==''){
				var msg=self.options.msgs.select_network;
				myAdminMsgs_inst.my_show_error_window(msg);
				setTimeout(function(){
					myAdminMsgs_inst.my_remove_window();
					//self.my_working=false;
				},self.options.msg_window_timeout);
				return;
			}
			if(self.my_working)return;
			self.my_working=true;
			var form=".my_form_"+network+" form";
			var form_data=$(form).serialize();
			var social_data=[];
			$(this).parents(".my_post_single").find("form .my_save_posts_check").filter(":checked").each(function(i,v){
				social_data[social_data.length]=$(v).val();
			});
			self.my_post_single=$(this).parents(".my_post_single");
			var page=$(this).parents(".my_post_single").attr('data-page');
			var data={
					action:'my_save_posts',
					my_action:'my_save_posts',
					data:form_data,
					social:social_data,
					network:network,
					page:page
				};
			self.my_social_button=$(this);
			self.my_debug("Ajax data",data);
				var msg=self.options.msgs.my_save_posts;
				myAdminMsgs_inst.my_show_working_window(msg);
				$.ajax({
					url:self.options.ajax_url,
					dataType:'json',
					data:data,
					cache:false,
					timeout:self.options.ajax_timeout,
					type:'POST',
					success:function(data,status,jq){
						self.my_debug('data',data);
						self.my_working=false;
							myAdminMsgs_inst.my_remove_window();
						
						if(data.error==0){
							//$(self.my_social_button).parents(".my_post_single").fadeOut(function(){$(this).remove()});
							$(self.my_social_button).parents(".my_post_single").find(".my_status").html(data.stat);
							
							myAdminMsgs_inst.my_show_success_window(data.msg);
							if(self.my_save_all){
								$(self.my_post_single).trigger("my_saved");
							}
							$(self.my_post_single).attr('data-saved',1);
						}else {
							myAdminMsgs_inst.my_show_error_window(data.msg);
						}
						setTimeout(function(){
							myAdminMsgs_inst.my_remove_window();
							//self.my_working=false;
						},self.options.msg_window_timeout);
					},
					error:function(jq,status){
					self.my_working=false;
					var msg=self.options.msgs.network_error;
					myAdminMsgs_inst.my_show_error_window(msg);
					
					setTimeout(function(){
						myAdminMsgs_inst.my_remove_window();
						//self.my_working=false;
					},self.options.msg_window_timeout);
				}
				});
			
		};
		this.save_ids=function(e){
			e.preventDefault();
			var network=self.network;
			self.my_debug('Network',network);
			if(typeof network=='undefined' || network==''){
				var msg=self.options.msgs.select_network;
				myAdminMsgs_inst.my_show_error_window(msg);
				setTimeout(function(){
					myAdminMsgs_inst.my_remove_window();
					//self.my_working=false;
				},self.options.msg_window_timeout);
				return;
			}
			if(self.my_working)return;
			self.my_working=true;
			var form=".my_form_"+network+" form";
			var form_data=$(form).serialize();
			self.my_debug("Form data",form_data);
			var data={
					action:'my_save_ids',
					my_action:'my_save_ids',
					data:form_data,
					network:network
				};
			self.my_debug("Ajax data",data);
				var msg=self.options.msgs.my_save_ids;
				myAdminMsgs_inst.my_show_working_window(msg);
				$.ajax({
					url:self.options.ajax_url,
					dataType:'json',
					data:data,
					cache:false,
					timeout:self.options.ajax_timeout,
					type:'POST',
					success:function(data,status,jq){
						self.my_debug('data',data);
						self.my_working=false;
						myAdminMsgs_inst.my_remove_window();
						if(data.error==0){
							
							myAdminMsgs_inst.my_show_success_window(data.msg);
						}else {
							myAdminMsgs_inst.my_show_error_window(data.msg);
						}
						setTimeout(function(){
							myAdminMsgs_inst.my_remove_window();
							//self.my_working=false;
						},self.options.msg_window_timeout);
					},
					error:function(jq,status){
					self.my_working=false;
					var msg=self.options.msgs.network_error;
					myAdminMsgs_inst.my_show_error_window(msg);
					
					setTimeout(function(){
						myAdminMsgs_inst.my_remove_window();
						//self.my_working=false;
					},self.options.msg_window_timeout);
				}
				});
			
		};
		this.get_info=function(e){
			e.preventDefault();
			var network=self.network;
			self.my_debug('Network',network);
			if(typeof network=='undefined' || network==''){
				var msg=self.options.msgs.select_network;
				myAdminMsgs_inst.my_show_error_window(msg);
				setTimeout(function(){
					myAdminMsgs_inst.my_remove_window();
					//self.my_working=false;
				},self.options.msg_window_timeout);
				return;
			}
			if(self.my_working)return;
			self.my_working=true;
			var form=".my_form_"+network+" form";
			var form_data=$(form).serialize();
			self.my_debug("Form data",form_data);
			var data={
					action:'my_get_info',
					my_action:'my_get_info',
					data:form_data,
					network:network
				};
			self.my_debug("Ajax data",data);
				var msg=self.options.msgs.my_get_info;
				myAdminMsgs_inst.my_show_working_window(msg);
				$.ajax({
					url:self.options.ajax_url,
					dataType:'json',
					data:data,
					cache:false,
					timeout:self.options.ajax_timeout,
					type:'POST',
					success:function(data,status,jq){
						self.my_debug('data',data);
						self.my_working=false;
						var form='my_form_'+self.network;
						myAdminMsgs_inst.my_remove_window();
						if(data.error==0){
							$("."+form+" .my_info_request ul").append(data.stat);
							myAdminMsgs_inst.my_show_success_window(data.msg);
						}else {
							myAdminMsgs_inst.my_show_error_window(data.msg);
						}
						setTimeout(function(){
							myAdminMsgs_inst.my_remove_window();
							//self.my_working=false;
						},self.options.msg_window_timeout);
					},
					error:function(jq,status){
					self.my_working=false;
					var msg=self.options.msgs.network_error;
					myAdminMsgs_inst.my_show_error_window(msg);
					
					setTimeout(function(){
						myAdminMsgs_inst.my_remove_window();
						//self.my_working=false;
					},self.options.msg_window_timeout);
				}
				});
			
		};
		
		this.get_social_posts=function(e){
			e.preventDefault();
			var network=self.network;
			self.my_debug('Network',network);
			if(typeof network=='undefined' || network==''){
				var msg=self.options.msgs.select_network;
				myAdminMsgs_inst.my_show_error_window(msg);
				setTimeout(function(){
					myAdminMsgs_inst.my_remove_window();
					//self.my_working=false;
				},self.options.msg_window_timeout);
				return;
			}
			
			if(self.my_working)return;
			self.my_working=true;
			var form=".my_form_"+network+" form";
			var form_data=$(form).serialize();
			var form_id=$(form).find("input[name='my_form_id']").val();
			var id_id="#id_"+form_id+"_id";
			
			var check={page:'page_'+form_id,next:'next_'+form_id,prev:'prev_'+form_id};
			var id=$(id_id).val();
			self.my_debug("Form id id",{form_id:form_id,id:id});
			
			if(typeof self.search_ids[network]=='undefined'){
				self.search_ids[network]='';
			}
			if(self.search_ids[network]!=id ){
				$.each(check,function(i,v){
					var sel="input[type='hidden'][name='"+v+"']";
					if(i=='page')$(sel).val('1');
					else $(sel).val('');
				});
				$(".my_form_"+self.network+" .my_load_more_posts ").hide();
				$(".my_form_"+self.network+" .my_social_posts_inner .my_post_single ").remove();
				
				self.my_debug("New search");
			}else self.my_debug("Old search",{id:id});
			var page=$("input[name='page_"+form_id+"']").val();
			self.search_ids[network]=id;
			self.my_debug("Form data",form_data);
			var data={
					action:'my_get_social_posts',
					my_action:'my_get_social_posts',
					data:form_data,
					network:network
				};
			self.my_debug("Ajax data",data);
				var msg=self.options.msgs.my_get_social_posts;
				if(self.my_get_all&&(typeof self.my_set_msg_12=='undefined') || !self.my_get_all){
					if(self.my_get_all){
						self.my_set_msg_12=1;
						var stop_msg=self.options.msgs.my_stop;
						var page_msg=self.options.msgs.my_page;
						var my_html=msg+'<input type="button" id="my_stop_getting_all_12" value="'+stop_msg+'"/><span>'+page_msg+':'+'</span><span class="my_win_page_123">'+page+'</span>'
						myAdminMsgs_inst.my_show_working_window(my_html);
					}
					else myAdminMsgs_inst.my_show_working_window(msg);
				}
				$.ajax({
					url:self.options.ajax_url,
					dataType:'json',
					data:data,
					cache:false,
					timeout:self.options.ajax_timeout,
					type:'POST',
					success:function(data,status,jq){
						self.my_debug('data',data);
						self.my_working=false;
						var form='my_form_'+self.network;
						var form_id=$("."+form+" form input[type='hidden'][name='my_form_id']").val();
						self.my_debug("Form id",form_id);
						var page=$("."+form+" input[name='page_"+form_id+"']").val();
						if(!self.my_get_all){
							myAdminMsgs_inst.my_remove_window();
						}
						if(data.error==0){
							
							if(typeof data.has_more!='undefined' && data.has_more){
								$("."+form+" .my_load_more_posts ").show();
								if(self.my_get_all){
									setTimeout(function(){
										$("#my_get_social_posts").trigger('click');
									},1000);
									$(".my_win_page_123").text(data.page);
								}
							}else {
								self.my_get_all=false;
								myAdminMsgs_inst.my_remove_window();
								myAdminMsgs_inst.my_show_success_window(data.msg);
								$("."+form+" .my_load_more_posts ").hide();
							}
								if(self.network=='facebook'){
									$("."+form+" input[name='page_"+form_id+"']").val(data.page);
									$("."+form+" input[name='next_"+form_id+"']").val(data.next);
									$("."+form+" input[name='prev_"+form_id+"']").val(data.prev);
									
								}else if(self.network=='google'){
									$("."+form+" input[name='page_"+form_id+"']").val(data.page);
									$("."+form+" input[name='next_"+form_id+"']").val(data.next);
									
								}else if(self.network=='twitter'){
									$("."+form+" input[name='page_"+form_id+"']").val(data.page);
									$("."+form+" input[name='next_"+form_id+"']").val(data.next);
								}else if(self.network=='pinterest'){
									$("."+form+" input[name='page_"+form_id+"']").val(data.page);
									$("."+form+" input[name='next_"+form_id+"']").val(data.next);
								
									
								}else if(self.network=='youtube'){
									$("."+form+" input[name='page_"+form_id+"']").val(data.page);
									$("."+form+" input[name='next_"+form_id+"']").val(data.next);
								
									
								}else if(self.network=='instagram'){
									$("."+form+" input[name='page_"+form_id+"']").val(data.page);
									$("."+form+" input[name='next_"+form_id+"']").val(data.next);
							
								}
							//}
							//if(page==1)
							if(data.count>0){	
								$("."+form+" .my_social_posts_inner").append(data.stat);
								setTimeout(function(){
									self.init_pretty_photo();
								},500);
							}
								if(!self.my_get_all){
								myAdminMsgs_inst.my_show_success_window(data.msg);
							}else {
								
							}
						}else {
							myAdminMsgs_inst.my_show_error_window(data.msg);
						}
						if(!self.my_get_all){
						setTimeout(function(){
							myAdminMsgs_inst.my_remove_window();
							//self.my_working=false;
						},self.options.msg_window_timeout);
						}
					},
					error:function(jq,status){
					self.my_working=false;
					var msg=self.options.msgs.network_error;
					myAdminMsgs_inst.my_show_error_window(msg);
					
					setTimeout(function(){
						myAdminMsgs_inst.my_remove_window();
						//self.my_working=false;
					},self.options.msg_window_timeout);
				}
				});
			
		};
		this.load_more=function(e){
			e.preventDefault();
			self.my_load_more=1;
			if(self.network_ids=='facebook'){
				
				$("#facebook_get_albums_button_id").trigger('click');
				//self.my_load_more=0;
			}else if(self.network_ids=='google'){
				$("#my_google_get_ids").trigger('click');
			}else if(self.network_ids=='youtube'){
				$("#my_youtube_get_ids_1").trigger('click');
			}
		};
		this.my_get_ids=function(e){
			e.preventDefault();
			$form=$(this).parents('form');
			var formdata=$($form).serialize();
			var data={
				action:'my_get_ids',
				my_action:'my_get_ids',
				data:formdata
			};
			var msg=self.options.msgs.my_get_ids;
			myAdminMsgs_inst.my_show_working_window(msg);
			self.my_debug("Data",data);
			$.ajax({
				url:self.options.ajax_url,
				dataType:'json',
				data:data,
				cache:false,
				timeout:self.options.ajax_timeout,
				type:'POST',
				success:function(data,status,jq){
					self.my_debug('data',data);
					self.my_working=false;
					self.my_debug("Data",data);
					var div='my_form_ids_'+self.network_ids;
					myAdminMsgs_inst.my_remove_window();
					if(data.error==0){
						myAdminMsgs_inst.my_show_success_window(data.msg);
						if(self.my_load_more==1){
							$("."+div+" .my_response_data").append(data.html);
							//$("."+div+" .my_response_data").html(data.html);
							self.my_load_more=0;
						}else 
						$("."+div+" .my_response_data").html(data.html);
						if(self.network_ids=='facebook'){
							if(typeof data.facebook_next !='undefined'){
								$("#facebook_cursor_next").val(data.facebook_next);
								$(".my_load_more").show();
							}else {
								$(".my_load_more").hide();
								$("#facebook_cursor_next").val('');
							}
						}else if(self.network_ids=='google'){
							if(data.google_next!='undefined'){
								if(data.google_next!=''){
									$(".my_load_more").show();
								}else $(".my_load_more").hide();
								$("#google_cursor_next").val(data.google_next);
								
							}
						}else if(self.network_ids=='youtube'){
							if(data.youtube_next!='undefined'){
								if(data.youtube_next!=''){
									$(".my_load_more").show();
								}else $(".my_load_more").hide();
								$("#youtube_cursor_next").val(data.youtube_next);
								
							}
						}
						
					}else {
						myAdminMsgs_inst.my_show_error_window(data.msg);
						
					}
					setTimeout(function(){
						myAdminMsgs_inst.my_remove_window();
						//self.my_working=false;
					},self.options.msg_window_timeout);
				},
				error:function(jq,status){
					self.my_working=false;
					var msg=self.options.msgs.network_error;
					myAdminMsgs_inst.my_show_error_window(msg);
					
					setTimeout(function(){
						myAdminMsgs_inst.my_remove_window();
						//self.my_working=false;
					},self.options.msg_window_timeout);
				}
				});
		};
		this.my_choose_ids_network=function(e){
			if(self.my_working)return;
			self.my_working=true;
			
			e.preventDefault();
			var type=$(this).data('type');
			self.my_debug("Open network",type);
			var form_prefix='my_form_ids_';
			if(type==self.network_ids){
				return;
			}
			$(".my_timeline_modal_load .my_social_networks li").removeClass('my_selected');
			$(this).addClass('my_selected');
			var my_form_new_class=form_prefix+type;
			if(self.network_ids!=''){
				var my_form_pre_class=form_prefix+self.network_ids;
				self.network_ids=type;
				$("."+my_form_pre_class).fadeOut(function(){
					$("."+my_form_new_class).fadeIn(function(){
						self.my_working=false;
					});
				}
						
				);
			}else {
				self.network_ids=type;
				$("."+my_form_new_class).fadeIn(function(){
						self.my_working=false;
					});
			}
		};
		
		this.my_choose_network=function(e){
			if(self.my_working)return;
			self.my_working=true;
			
			e.preventDefault();
			var type=$(this).data('type');
			self.my_debug("Open network",type);
			var form_prefix='my_form_';
			if(type==self.network){
				self.my_working=false;
				
				return;
			}
			$("#my_form_inner_1 .my_social_networks li").removeClass('my_selected');
			$(this).addClass('my_selected');
			var my_form_new_class=form_prefix+type;
			if(self.network!=''){
				var my_form_pre_class=form_prefix+self.network;
				self.network=type;
				$("."+my_form_pre_class).fadeOut(function(){
					$("."+my_form_new_class).fadeIn(function(){
						
						self.my_working=false;
					});
				}
						
				);
			}else {
				self.network=type;
				$("."+my_form_new_class).fadeIn(function(){
						self.my_working=false;
					});
			}
		};
		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log('Get Social Posts \n'+t,o);
				}
			}
		};
			this.init();
			
	}
})(jQuery);		