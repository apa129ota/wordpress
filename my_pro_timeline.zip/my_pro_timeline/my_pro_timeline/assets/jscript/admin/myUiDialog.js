(function($) { 
	myVusualBuilderDialog=function(o){
		var self;
		this.pre_options={
				dw:600,
				dh:400,
				diff:20,
				modal:false,
				resizable:false,
				hideOverflow:false,
				initScroll:true
			};
		
		this.options=o;
		this.debug=true;
		self=this;
		this.init=function(o){
			if(typeof self.options.debug!='undefined'){
				if(!self.options.debug){
					self.debug=false;
				}
			}
			self.options=$.extend( self.pre_options,self.options);
			
			self.my_debug("options", self.options);
			//var ww=$(window).width();
			//var wh=$(window).height();
			var ww = window.innerWidth;
			var wh = window.innerHeight;
			var dw=self.options.dw;
			var dh=self.options.dh;
			if(self.options.dw>ww)dw=ww-self.options.diff;
			if(self.options.dh>wh)dh=wh-self.options.diff;
			if(self.options.dh=='100%'){
				dh=wh;
			}
			if(self.options.dw=='100%'){
				dw=ww;
			}
			self.my_class=".my_dialog_"+self.options.key;
			$(self.my_class).find(".my_timeline_modal_close_1").on("click",function(e){
				e.preventDefault();
				self.my_debug("Dialog close");
				$(self.my_class).dialog("close");
			});
			$(self.my_class).dialog({
				dialogClass:"my_dialog_"+self.options.key+"_ui",
				autoOpen: false,
				width:dw,
				height:dh,
				modal:self.options.modal,
				draggable:false,
				resizable:self.options.resizable,
				open:function(e,ui){
					self.show=true;
					if(self.options.hideOverflow){
						self.cssOff=$("body").css("overflow");
						self.my_debug("Css overflow",self.cssOff);
						$("body").css("overflow","hidden");
					}
					self.my_resize();
					if(self.options.initScroll){
						var is=$(self.my_class).attr('data-my-is');
						if(typeof is=="undefined"){
							$(self.my_class).attr('data-my-is',1);
							$(self.my_class).find(".my_shortcode_content").mCustomScrollbar(
				    				{axis:'y',
				        				advanced:{
				        					updateOnContentResize:true
				        					}});
							
						}
					}
					
					var obj=[self,self.options.key];
					self.my_debug("Open dialog",obj);
					$('body').trigger('my_open_dialog',obj);
					$(".my_shortcodes_dialog_overlay").show();
					//self.my_resize();
				},
				close:function(e,ui){
					$(".my_shortcodes_dialog_overlay").hide();
					self.show=false;
					var obj=[self,self.options.key];
					self.my_debug("Close dialog",obj);
					$('body').trigger('my_close_dialog',obj);
					if(self.options.hideOverflow){
						var o=self.cssOff;
						if(typeof o=='undefined'){
							o="";
						}
						//$("body").css("overflow","hidden");
						$("body").css("overflow",o);
					}
				}
			});
			$(window).resize(self.my_resize);	
		};
		this.setHeight=function(){
			var view=self.getViewportSize();
			var ww = view.w;
			var wh = view.h;
			
			if(self.options.hideOverflow){
				self.cssOff=$("body").css("overflow");
				self.my_debug("Css overflow",self.cssOff);
				$("body").css("overflow","hidden");
			}
			var h=$(self.my_class+" .my_header_dialog").outerHeight(true);
			var th=self.options.dh;//$(self.my_class).height();
			if(th=='100%'){
				th=wh;
			}
			if(th>(wh+15)){
				th=wh;
			}
			var pd=$(self.my_class+" .my_shortcode_content").css('padding-top');
			pd=parseInt(pd);
			var h1=th-h-2*pd-10;
			$(self.my_class+" .my_shortcode_content").height(h1);
			self.my_debug("Adjust window size",{h:h,th:th,pd:pd});
			
		};
		this.getViewportSize=function() {

	        // Use the specified window or the current window if no argument
	    	var w=window;
	    	/*if(my_slider.vars.preview){
	    		var iframes = window.frames
	        	w=iframes[0].window;
	        }*/
	    	

	        // This works for all browsers except IE8 and before
	        if (w.innerWidth != null) return { w: w.innerWidth, h: w.innerHeight };

	        // For IE (or any browser) in Standards mode
	        var d = w.document;
	        if (document.compatMode == "CSS1Compat")
	            return { w: d.documentElement.clientWidth,
	               h: d.documentElement.clientHeight };

	        // For browsers in Quirks mode
	        return { w: d.body.clientWidth, h: d.body.clientHeight };

	    };
		this.my_open=function(){
			//self.resize();
			$(self.my_class).dialog('open');
		};
		this.my_close=function(){
			$(self.my_class).dialog('close');
		};
		/**
		 * Resize window
		 */
		this.my_resize=function(e){
			if(self.show){
				//var ww=$(window).width();
				//var wh=$(window).height();
				var view=self.getViewportSize();
				var ww = view.w;
				var wh = view.h;
				
				var dw=self.options.dw;
				var dh=self.options.dh;
				//if(self.options.dw>ww)dw=ww-self.options.diff;
				//if(self.options.dh>wh)dh=wh-self.options.diff;
				if(self.options.dw=='100%'){
					dw=ww;//-self.options.diff*2;;
				}
				if(self.options.dh=='100%'){
					
					dh=wh;//-self.options.diff*2;;
				}
				if(self.options.dw!='100%'&&dw>(ww-self.options.diff)){
					dw=ww-self.options.diff*2;
				}
				var heightBigger=false;
				if(self.options.dh!='100%'&&dh>(wh-self.options.diff)){
					dh=wh-self.options.diff*2;
					heightBigger=true;
				}
				var left=(ww-dw)/2;
				var top=(wh-dh)/2;
				top+=$(window).scrollTop();
				/*if(window.console){
					console.log("Width",{left:left,top:top,dw:dw,dh:dh});
				}*/
				$(self.my_class).parents('.ui-dialog').width(dw);
				$(self.my_class).parents('.ui-dialog').height(dh);
				$(self.my_class).parents('.ui-dialog').css('top',top+'px');
				$(self.my_class).parents('.ui-dialog').css('left',left+'px');
				var h=$(self.my_class+" .my_header_dialog").outerHeight(true);
				var th=self.options.dh;//$(self.my_class).height();
				if(th=='100%'){
					th=wh;
				}else if(heightBigger){
					th=dh;
				}
				var pd=$(self.my_class+" .my_shortcode_content").css('padding-top');
				pd=parseInt(pd);
				var h1=th-h-2*pd-10;
				$(self.my_class+" .my_shortcode_content").height(h1);
				self.my_debug("Adjust window size",{h:h,h1:h1,th:th,pd:pd});
				
				
			}
		};
		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log('Dialog \n'+t,o);
				}
			}
		};
		this.init();
		
};
})(jQuery);				
