(function($) { 
	myDialog=function(o){
		var self;
		this.my_working=false;
		this.debug=true;
		self=this;		
		self.resize=false;
		this.init=function(o){
			self.options=o;
			if(typeof self.options.my_debug!='undefined'){
				if(!self.options.my_debug){
					self.debug=false;
				}
			}
			self.has_transition();
			$(document).on("click",".my_timeline_modal_close",self.my_close_preview);
			if(!self.resize){
				$(window).resize(function(e){
					self.update_height();
				});
				$(".my_timeline_modal").find(".my_timeline_modal_content").mCustomScrollbar({
					
				});
			}
		};
		this.my_close_preview=function(e){
			   
	    	e.preventDefault();
	    	if(self.transitions && self.options.animation=='scale'){
				
				//$(".my_timeline_modal").css(my_slider.prop+'-transform','scale(0)');
				
	    		//$(".my_timeline_modal").css(my_slider.prop+'-transition-duration','1s;');
				//$(".my_timeline_modal").css(my_slider.prop+'-transform','scale(0)');
				/*setTimeout(function(){
					$(".my_timeline_modal").show();
					$("body").css('overflow',my_slider.overflow_css);
	    			
				},1200);*/
	    		$(".my_timeline_modal").animate({
					my_scale:0,
					opacity:0
				},{
					step:function(now,fx){
						//fx.start=0;
						if(fx.prop=='my_scale'){
							//my_admin_debug("Now",now);
							my_trans=self.prop;
							$(this).css(my_trans,'scale('+now+')');	
						}
					}
				,duration:1000,complete:function(){
					//$(".my_timeline_modal").find(".my_timeline_modal_loading").show();
					//$(".my_timeline_modal").find(".my_timeline_modal_load").hide();
					
					$(".my_timeline_modal").find(".my_timeline_modal_load").css('width','');
				}
	    	}
	    		);
				
				
			}else {
				$(".my_timeline_modal").fadeOut(self.options.duration,function(){
					//$(".my_timeline_modal").find(".my_timeline_modal_loading").show();
					//$(".my_timeline_modal").find(".my_timeline_modal_load").hide();
					$(".my_timeline_modal").find(".my_timeline_modal_load").css('width','');
				});
			}
	    	$("body").trigger("my_close_dialog");
	   
	};
	this.open_dialog=function(e){
		if(self.transitions && self.options.animation=='scale'){
			$(".my_timeline_modal").css(self.prop,'center center');
					
			$(".my_timeline_modal").css(self.prop,'scale(0)');
			$(".my_timeline_modal").css('opacity',0);
			$(".my_timeline_modal").show();
			//$(".my_timeline_modal").css(my_slider.prop+'-transform','scale(1)');
			
			//$(".my_timeline_modal").css(my_slider.prop+'-transition-duration','1s;');
			$(".my_timeline_modal").animate({
				my_scale:1,
				opacity:1
			},{
				step:function(now,fx){
					//fx.start=0;
					if(fx.prop=='my_scale'){
						//my_admin_debug("Now",now);
						my_trans=self.prop;
						$(this).css(my_trans,'scale('+now+')');	
					}
				}
			,duration:1000,complete:function(){
				self.update_height();
				self.my_working=false;}});
			
		}else {
			$(".my_timeline_modal").fadeIn(self.options.duration,function(){
				self.update_height();
				self.my_working=false;}
			);
		}
	};
	this.update_height=function(){
		//return;
		var h=$(window).height();
		var h1=$(".my_timeline_modal").find(".my_header").outerHeight();
		var h2=h-h1;
		$(".my_timeline_modal").find(".my_timeline_modal_content").height(h2);
		//$(".my_timeline_modal").find(".my_sidebar").height(h2);
	}
	this.has_transition=function(){
			 self.transitions=function() {
          var obj = document.createElement('div'),
              props = ['perspectiveProperty', 'WebkitPerspective', 'MozPerspective', 'OPerspective', 'msPerspective'];
          for (var i in props) {
            if ( obj.style[ props[i] ] !== undefined ) {
              self.pfx = props[i].replace('Perspective','').toLowerCase();
              self.prop = "-" + self.pfx + "-transform";
              return true;
            }
          }
          return false;
        }();
		};
		
		this.init(o);
			
	};
	this.my_debug=function(t,o){
		if(self.debug){
			if(window.console){
				console.log('My Dialog \n'+t,o);
			}
		}
	};
})(jQuery);	