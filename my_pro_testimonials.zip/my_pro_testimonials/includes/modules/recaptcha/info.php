<?php
if(!defined('ABSPATH'))die('');
$info=array(
		'title'=>'Recaptcha module',
		'description'=>'Recaptcha module',
		'class'=>'Class_My_Module_Form',

);
return $info;