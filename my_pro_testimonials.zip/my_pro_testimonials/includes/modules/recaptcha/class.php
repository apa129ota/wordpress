<?php
use ReCaptcha\ReCaptcha;
if(!defined('ABSPATH'))die('');
require_once __DIR__ . '/libs/autoload.php';
global $wp_my_custom_recaptcha_class;
global $wp_my_custom_capctha_public_key;
global $wp_my_custom_capctha_private_key;
	
//$wp_my_custom_capctha_public_key=wp_my_custom_plugin_get_option_by_key('my_recaptcha_public_key');
//$wp_my_custom_capctha_private_key=wp_my_custom_plugin_get_option_by_key('my_recaptcha_private_key');

/**
 * Function recapctha check response
 * @param unknown $value
 * @return boolean|number
 */
function wp_my_recaptcha_check_response($value,$private_key){
	global $wp_my_custom_recaptcha_class;
	global $wp_my_custom_capctha_public_key;
	global $wp_my_custom_capctha_private_key;
	if(!empty($private_key)){
		$wp_my_custom_recaptcha_class=new \ReCaptcha\ReCaptcha($private_key);
	}
	else $wp_my_custom_recaptcha_class=new \ReCaptcha\ReCaptcha($wp_my_custom_capctha_private_key);
	$resp=$wp_my_custom_recaptcha_class->verify($value,$_SERVER['REMOTE_ADDR']);
	if($resp->isSuccess()){
		return true;
	}else {
		$ret['error']=1;
		return $ret;
	}
}
/**
 * Function showing recapctcha
 */
function wp_my_recaptcha_show_captcha($site_key_f='',$element_name){
	$lang='en';
	if(defined('ICL_LANGUAGE_CODE'))
	$lang=ICL_LANGUAGE_CODE;
	
	if(!empty($site_key_f)){
		$site_key=$site_key_f;
	}else {
		global $wp_my_custom_capctha_public_key;
		$site_key=$wp_my_custom_capctha_public_key;
	}
	?>
	 <div class="g-recaptcha" id="<?php echo $element_name.'_div'?>" data-sitekey="<?php echo $site_key; ?>"></div>
           <?php /*
            <script type="text/javascript"
                    src="https://www.google.com/recaptcha/api.js?hl=<?php echo $lang; ?>">
            </script>
            */ ?>
    <?php 
            
}



