<?php
if (basename ( __FILE__ ) == basename ( $_SERVER ['SCRIPT_FILENAME'] ))
	die ( 'This page cannot be called directly.' );
?>

<div id="my_outter_container" class="wrap">
	<div id="my_container">
		<div id="my_header">
			<div class="my_logo">
				<span class="my_theme_name"><?php echo $plugin_name?></span>
				<span><?php echo $plugin_version_label.' '.$plugin_version;?></span>
				
			</div>
		</div>
		<?php /*
		<div id="my_save">
			<div class="my_row" id="my_save_div">
				<div class="my_float_left">
					<!--  <label class="my_label_save my_float_left my_margin_right_10"><?php echo __("Save options to new skin","my_clear_theme_doamin")?></label>-->
					<div class="my_float_left my_margin_right my_margin_right_10"><input id="my_button_activate_skins" type="button" class=" my_button_actionbutton button-primary button-large" value="<?php echo __("Activate Skins","my_clear_theme_doamin")?>"></div>
					<div class="my_float_left my_margin_right_10"><label><?php echo __("Skins","my_clear_theme_doamin")?>&nbsp;&nbsp;</label><select name="my_skins"></select></div>
					<div class="my_float_left"><input type="button" id="my_button_save_skin" class="my_button_action button button-primary button-large" value="<?php echo __("Export settings","my_clear_theme_doamin")?>"></div>
				</div>
				<div class="my_float_right">
					<input type="button" id="my_button_save_options" class="my_button_action button button-primary button-large" value="<?php echo __("Save options","my_clear_theme_doamin")?>">
				</div>
			</div>
		</div>
		*/ ?>
		<div id="my_main">
			
			
			<div id="my_options_tabs">
				<ul>
				<?php
				/* 
					foreach($options_tabs as $k=>$v){
						?>
						<li <?php if($k=='my_general')echo 'class="my_current_tab"';?> id="my_options_<?php echo $k?>"><label><?php echo $v['title']?></label></li>
						<?php 
					}
					*/
				foreach($tabs as $k=>$v){
					?>
					<?php 
					/*if($my_tab==$k){
					?>
					<li class="<?php if($my_tab==$k)echo 'my_current_tab'?>">
						<label><?php echo $v['title'];?></label>
					</li>	
					<?php 
					}else {
					*/
					?>
					<li class="<?php if($my_tab==$k)echo 'my_current_tab'?>">
						<a href="#javascript;<?php //echo $admin_url.'&my_tab='.$k;?>"><?php echo $v['title'];?></a>
						<?php 
						/**
						 * Display tooltip
						 */
						//wp_my_pro_events_display_tooltip_help($v['description']);
						
						?>
						<div class="my_help my_tooltip">
							<div class="my_content"><?php echo $v['descr']?></div>
						</div>
					</li>	
					<?php 
					//}
				}
				?>
				</ul>
			</div>
			<div id="my_form">
				<div id="my_form_inner">
					<div id="my_form_inner_1">	
					<?php
					$page=$v['page'];
					$filename=$pages_dir.$page;
					//echo $filename.'<br/>'; 
					if(file_exists($filename)){
						require_once $filename;
					}
					
					?>
					</div>
				</div>	
			</div>
			<div class="my_clear"></div>
		</div>
		<div id="my_about">
			<div class="my_row" id="my_about_div">
				<a href="#"><?php __("Online documentation","my_clear_theme_doamin")?></a>
			</div>
		
		</div>
	</div>





</div>
