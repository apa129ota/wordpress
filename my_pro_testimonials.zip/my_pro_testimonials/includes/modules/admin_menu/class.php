<?php
if (! defined ( 'ABSPATH' ))
	die ( '' );
if (! class_exists ( 'Class_Wp_My_Module_Admin_Menu' )) {
	class Class_Wp_My_Module_Admin_Menu {
		private $tabs;
		private $options;
		private $admin_url;
		function Class_Wp_My_Module_Admin_Menu($options = array()) {
			if (! empty ( $options )) {
				foreach ( $options as $key => $val ) {
					$this->$key = $val;
				}
			}
			$this->admin_url=plugin_dir_url(__FILE__);
		}
		public function init(){
			add_action('admin_head',array($this,'admin_head'));
			add_action('admin_enqueue_scripts',array(&$this,'admin_scripts'));
		}
		public function admin_head(){
			?>
			<script type="text/javascript">
				jQuery(document).ready(function($){
					var obj={};
					obj.test='test';
					obj.ajax_action='my_reletaed_posts_admin_ajax';
					obj.ajax_url="<?php echo admin_url('admin-ajax.php');?>";
					obj.msg_window_timeout=3000;
					obj.msgs=<?php $msgs=wp_my_social_posts_get_msgs();echo json_encode($msgs);?>;
					
					myAdminRelatedPosts_inst=new myAdminRelatedPosts(obj);
					});
			</script> 
			<?php 
		}
		public function admin_scripts(){
			$css_url=$this->admin_url.'assets/css/';
			$jscript_url=$this->admin_url.'assets/jscript/';
			wp_enqueue_style('wp_my_module_admin_menu_admin_css',$css_url.'admin.css');
			
			wp_enqueue_script('jquery');
			wp_enqueue_script('jquery');
			wp_enqueue_script("jquery-touch-pounch");
			wp_enqueue_script('jquery-ui-core');
			wp_enqueue_script('jquery-ui-widget');
			wp_enqueue_script('jquery-ui-dialog');
			wp_enqueue_script('jquery-ui-tooltip');
				
			wp_enqueue_script('wp_my_module_admin_menu_general_js',$jscript_url.'general.js');
			wp_enqueue_script('wp_my_module_admin_menu_admin_js',$jscript_url.'admin.js');
		}
		function render(){
			extract($this->options);
			$file=plugin_dir_path(__FILE__).'views/index.php';
			ob_start();
			require $file;
			$html=ob_get_clean();
			return $html;
		}
	}
}