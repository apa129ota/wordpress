jQuery(document).ready(function($){
	var width=$("#my_main").width();
	var main_width=parseFloat(width)-205;
	$("#my_form").width(main_width);
	$(window).resize(function(e){
		var width=$("#my_main").width();
			
		var main_width=parseFloat(width)-205;
		$("#my_form").width(main_width);
		
	});
	$(".my_tooltip").tooltip({
		items:"div",
		
		content:function(){
			var html=$(this).children(".my_content").html();
			///console.log('Html '+html);
			return html;
		}
		});
});