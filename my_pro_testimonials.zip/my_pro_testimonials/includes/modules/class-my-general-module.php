<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_General_Module')){
	class Class_My_General_Module{
				use MyArrayOptions,MyLoadFiles,MyDebug;
				protected $is_admin=false;
				protected $dir;
				protected $url;
				protected $version='1.0';
				protected $css_url;
				protected $images_url;
				protected $jscript_url;
				protected $modules_dir;
				protected $modules_url;
				protected $class_dir;
				protected $controllers_dir;
				protected $models_dir;
				protected $options_dir;
				protected $functions_dir;
				protected $views_dir;
				protected $debug=0;
				protected $use_case='my_framework';
				protected $scripts_class;
				protected $module_options;
				protected $global_plugin;
				protected $template_vars;
				protected $ajax_controller;
				protected $views_url;
				function __construct($options=array(),$not=array()){
					//print_r($options);
					if(!empty($not)){
						foreach ($not as $k=>$v){
							unset($options[$v]);
						}
					}
					$this->setOptions($options);
					if($this->debug){
						self::setDebugOptions($this->use_case);
					}
					self::debug("create_module_class", $options);
					$this->css_url=$this->url.'assets/css/';
					$this->images_url=$this->url.'assets/images/';
					$this->modules_url=$this->url.'includes/modules/';
					$this->jscript_url=$this->url.'assets/jscript/';
					$this->modules_dir=$this->dir.'includes/modules/';
					$this->class_dir=$this->dir.'includes/class/';
					$this->functions_dir=$this->dir.'includes/functions/';
					$this->options_dir=$this->dir.'includes/options/';
					$this->views_dir=$this->dir.'includes/views/';
					$this->models_dir=$this->dir.'includes/models/';
					$this->controllers_dir=$this->dir.'includes/controllers/';
				    $this->views_url=$this->url.'includes/views/';	
				}
				public function loadModuleClass($module){
					$dir=$this->getDir('modules');
					$file=$dir.$module.'/class.php';
					if(file_exists($file)){
						require_once $file;
					}else {
						trigger_error(__("Module file not found ","my_support_theme").$file.' '.$module,E_USER_NOTICE);
					}
				}
				public function getProperty($key){
					if(!isset($this->$key)){
						trigger_error(__("Property is not set","my_support_theme").' '.$key,E_USER_NOTICE);
					}else {
						return $this->$key;
					}
				}
				public function set_template_vars($key,$var){
					$this->template_vars[$key]=$var;
					
				}
				public function loadViewFile($file){
					$file=$this->views_dir.$file;
					if(!empty($this->template_vars))
					extract($this->template_vars);
					if(!file_exists($file)){
						trigger_error(__("View file dont exists","my_support_theme").' '.$file,E_USER_NOTICE);
					}else {
						require $file;
					}
				}
				protected function get_module_options(){
					$options=array();
					$predefined=array(
						'url','dir','use_case','debug'
					);
					foreach($predefined as $key=>$val){
						$options[$val]=$this->$val;
					}
					return $options;
					
				}
				public function getUrl($type='css'){
					switch($type){
						case 'plugin':
							return $this->url;
							break;
						case 'css':
							return $this->css_url;
							break;
						case 'images':
							return $this->images_url;
							break;
						case 'modules':
							return $this->modules_url;
						case 'jscript':
							return $this->jscript_url;
							break;
						case 'views':
							return $this->views_url;
						break;		
						default:
							return false;
							//throw new Exception(__("Property with key dont exists","my_support_theme").$type);
							trigger_error(__("Property with key dont exists","my_support_theme").$type,E_NOTICE);
							break;
					}
		
				}
				public function getDir($type='plugin'){
					switch($type){
						case 'plugin':
						 return $this->dir;
						 break;
						case 'class':
							return $this->class_dir;
							break;
						case 'controllers':
							return $this->controllers_dir;
							break;
						case 'modules':
							return $this->modules_dir;
							break;
						case 'models':
							return $this->models_dir;
							break;
						case 'functions':
							return $this->functions_dir;
							break;
						case 'options':
							return $this->options_dir;
							break;
						case 'views':
							return $this->views_dir;
						break;		
						default:
							trigger_error(__("Property with key dont exists","my_support_theme").$type,E_USER_NOTICE);
							return false;
							//throw new Exception(__("Property with key dont exists","my_support_theme").$type);
							break;
					}
				}
		
				protected function init($options=array()){
						
					$this->setOptions($options);
						
						
						
				
						
						
				}
				protected function my_debug($key,$val,$all){
					if($this->debug){
						Class_My_Module_Debug::add_section($key, $val,$this->use_case,$all);
					}
				}
				public function get_ajax_nonce_str($action){
					$str=$action;
					if(is_user_logged_in()){
						$str.='_'.get_current_user_id();
					}
					return $str;
				}
				public function ajax_get_nonce($action){
					$str=$action;
					if(is_user_logged_in()){
					$str.='_'.get_current_user_id();
					}
					return wp_create_nonce($str);
				}
				public function ajax_check_nonce($nonce,$action){
					$str=$action;
					if(is_user_logged_in()){
						$str.='_'.get_current_user_id();
					}
					return wp_verify_nonce($nonce,$str);
				}
				public function routeAjax($options=array()){
					self::debug("module_routre_ajax", $options);
					$action=@$_REQUEST['action'];
					$my_action = @$_REQUEST['my_action'];
					
					if (! preg_match ( '/^[a-zA-Z_]+$/', $my_action )){
						$ret['error']=1;
						echo json_encode($ret);
						exit();
					}
					if(in_array($my_action,$options['my_actions']) || array_key_exists($my_action, $options['my_actions'])){
						//$action=$options['my_actions'][$my_action];
						$dir=$this->controllers_dir;
						if(isset($action['controller'])){
							$file=$dir.$action['controller']['file'];
							$name=$action['controller']['name'];
						}else {
							$file=$dir.$options['controller_file'];
							$name=$options['controller_name'];
							
						}
						require_once $file;
						
						$options1['ajax_actions'] = $options['my_actions'];
							
						
						if($this->debug){
							$options1['debug']=1;
						}else {
							$options['debug']=0;
						}
						$options1['ajax']=1;
						$options1['action'] = $my_action;
						$options1['ajax_nonce']=$this->get_ajax_nonce_str($action);
						$options1['plugin_object']=$options['plugin_object'];
						$options1['module_class']=$options['module_class'];
						if(!empty($options['nonce_str'])){
							$options1['nonce_str']=$options['nonce_str'];
						}
						$this->ajax_controller=new $name($options1);
						$this->ajax_controller->route_ajax();
						
					}else {
						/*
						$ret['options']=$options;
						//$ret['options1']=$options1;
						$ret['error']=1;
						echo json_encode($ret);
						exit();
						*/
					}
					
				}
				
				
		
	}
}