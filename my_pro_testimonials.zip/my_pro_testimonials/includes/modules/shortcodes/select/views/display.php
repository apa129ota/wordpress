<?php
if(!defined('ABSPATH'));
?>
<div class="my_shortcode_select_div">
<?php foreach($arr as $k1=>$v1){?>	
	<div class="my_accordian" data-on="0">
		<div class="my_accordian_header"><h4><i class="fa fa-plus"></i><i class="fa fa-minus" style="display:none"></i>&nbsp;&nbsp;<?php echo $v1['title']?></h4></div>
		<div class="my_accordian_inner">
			<ul class="my_shortcode_select_ul my_clearfix">
				<?php if(!empty($v1['elements'])){
					foreach($v1['elements'] as $k2=>$v2){
					?>
					<li data-name="<?php echo esc_attr($k2)?>" class="my_background_color my_shortcodes_select_action" data-key="add_shortcode">
						<h4><?php echo $v2['title'].' dddddddddddddddddd';?></h4>
						<span><i class="fa <?php echo $v2['icon']?>"></i></span>
					</li>
					<?php 
					}
				}
					?>
			</ul>
		</div>
	</div>
<?php }?>	
</div>		
