(function($) { 
	myVusualBuilderShortcodesSelect=function(o){
		var self;
		this.my_working=false;
		this.debug=true;
		this.options=o;
		this.dialog='';
		this.tmpl='';
		this.index=1;
		this.content='';
		this.pre_options={
				dw:800,
				dh:400,
				diff:20,
				open_class:".my_shortcodes_rows_add h4",
				action_class:".my_shortcodes_select_action",
				item_add_class:".my_shortcode_added_html",
					item_class:".my_shortcode_item",
				row_class:".my_shortcode_row_row"	
			};
			self=this;
			this.init=function(o){
				if(typeof self.options.debug!='undefined'){
					if(!self.options.debug){
						self.debug=false;
					}
				}
				self.options=$.extend( self.pre_options,self.options);
				
				self.my_debug("options", self.options);
				var o={
					key:self.options.key,
					debug:self.debug,
					dw:self.options.dw,
					dh:self.options.dh,
					diff:self.options.diff
				};
				self.dialog=new myVusualBuilderDialog(o);
				$(document).on("click",self.options.open_class,function(e){
					self.my_debug("Open shortcode",self.options.open_class);
					var id=$(this).parents(self.options.item_class).attr('id');
					self.my_debug("Id",id);
					self.my_add_id=id;
					self.dialog.my_open();
				});
				$(document).on("click",self.options.action_class,self.my_action);
			};
			this.my_action=function(e){
				var key=$(this).data('key');
				self.my_debug("Action",key);
				switch(key){
					case 'add_shortcode' :
						
						var name=$(this).data('name');
						self.my_debug("Add shortcode",name);
						self.my_add_shortcode(name,'');
					break;
				}
			};
			this.my_add_shortcode=function(data_key,content){
				var content='';
				var s_tmpl_1=myVusualBuilderMain_inst.my_show(data_key,content);
				if(s_tmpl_1!==false){
					var s_tmpl=s_tmpl_1.tmpl;
					//var id=s_tmpl_1.id;
					
					var id="my_added_object_"+self.my_add_id+"_"+self.index;
					self.index++;
					//self.my_debug("Add object",id);
					//s_tmpl=s_tmpl.replace('{id}',id);
					//s_tmpl=s_tmpl.replace('{key}',data_key);
					
					s_tmpl=s_tmpl.replace('{object_id}',self.my_add_id);
					var tmpl=$("script.my_shortcode_element_object").html();
					//self.my_debug('Tmpl',tmpl);
					tmpl=tmpl.replace('{content}',s_tmpl);
					tmpl=tmpl.replace('{id}',id);
					tmpl=tmpl.replace('{key}',data_key);
					//self.my_debug('Tmpl',{tmpl:tmpl,id:self.my_add_id});
					$("#"+self.my_add_id+" "+self.options.item_add_class).append(tmpl);
					
					setTimeout(function(){
						var max=0;
						var height=$("#"+self.my_add_id).css('height');
						self.my_debug('height',height);
						var row_id=$("#"+self.my_add_id).parents(self.options.row_class).attr('id');
						self.my_debug('Row id',row_id);
						var objects=myVusualBuilderShortcodesRow_inst.objects;
						self.my_debug("Objects",objects);
						var object=objects[row_id];
						if(typeof object.box=='undefined' || typeof object.box.height=='undefined'){
						
						//if(height=='auto'){
						$("#"+row_id).find(self.options.item_class).each(function(i,v){
							var h=$(v).height();
							if(h>max)max=h;
						});
						self.my_debug("Max heiught",max);
						myVusualBuilderMain_inst.adjust_element(id,data_key,self.my_top,self.my_diff);
						//$("#"+self.my_add_id).parents(self.options.row_class).height(max);
						}
						//}
						//myVusualBuilderMain_inst.adjust_element(id,data_key,self.my_top,self.my_diff);
						//self.my_top+=$(".my_slide_image_inner").find("#"+id).height()+10;
						//self.my_working=false;
					},100);
					}
					self.dialog.my_close();
					
			};
			this.my_edit=function(content,id){
				self.my_edit_id=id;
				self.dialog.my_open();
				self.my_debug('content',content);
				tinyMCE.get('my_editor_1').setContent(content);
					
			};
			this.get_content=function(){
				var id=self.my_edit_id;
				var content=tinyMCE.get('my_editor_1').getContent();
				return content;
			}
			this.my_show=function(obj){
				//$(self.my_class).dialog('open');
				//self.dialog.my_open(obj);
				var id=obj.id;
				var is=$("#"+id).length;
				if(is){
					self.dialog.my_open();
				}
				
				else return self.my_get_content(obj);
			};
			this.my_get_content=function(obj){
				var tmpl=$("script.my_shortcode_html").html();
				var id='my_shortcode_'+self.options.key+'_'+self.index;
				var is=$("#"+id).length;
				if(is)return false;
				self.my_debug("Is",is);
				var content;
				content=$("script.my_shortcode_html_default").text();
				tmpl=tmpl.replace('{id}',id);
				tmpl=tmpl.replace('{i}',self.index);
				tmpl=tmpl.replace('{content}',content);
				self.index++;
				self.my_debug('tmpl',tmpl);
				return {id:id,tmpl:tmpl};
			};
			this.my_clone_object=function(content){
				var tmpl=$("script.my_shortcode_html").html();
				var id='my_shortcode_'+self.options.key+'_'+self.index;
				var is=$("#"+id).length;
				if(is)return false;
				self.my_debug("Is",is);
				//var content;
				//content=$("script.my_shortcode_html_default").text();
				tmpl=tmpl.replace('{id}',id);
				tmpl=tmpl.replace('{i}',self.index);
				tmpl=tmpl.replace('{content}',content);
				self.index++;
				self.my_debug('tmpl',tmpl);
				return {id:id,tmpl:tmpl};
			};
			this.my_debug=function(t,o){
				if(self.debug){
					if(window.console){
						console.log('Visual builder Main \n'+t,o);
					}
				}
			};
			this.init();
			
	};
	})(jQuery);				
