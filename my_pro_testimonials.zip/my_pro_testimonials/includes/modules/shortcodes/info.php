<?php
if(!defined('ABSPATH'))die('');
$info=array(
		'title'=>'Shortcodes',
		'description'=>'Module creates evnets post type on worpdress admin',
		'class'=>'Class_My_Module_Events',
		
);
return $info;