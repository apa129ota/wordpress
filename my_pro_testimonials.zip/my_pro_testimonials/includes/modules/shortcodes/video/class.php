<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Module_Shortcodes_Video')){
	class Class_My_Module_Shortcodes_Video extends Class_My_Module_Shortcodes_General{
		function Class_My_Module_Shortcodes_Video($options=array()){
			parent::Class_My_Module_Shortcodes_General($options);
		}
		public function display_element(){
		}
		public function display_content(){
				}
	}
}