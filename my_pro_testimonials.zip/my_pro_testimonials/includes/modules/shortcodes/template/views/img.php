<?php
if(!defined('ABSPATH'))die('');
?>
<img class="my_img_slide_inner" src="{src}"/>