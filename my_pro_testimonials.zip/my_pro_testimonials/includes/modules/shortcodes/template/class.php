<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Module_Shortcodes_Template')){
	class Class_My_Module_Shortcodes_Template extends Class_My_Module_Shortcodes_General{
		function Class_My_Module_Shortcodes_Template($options=array()){
			parent::Class_My_Module_Shortcodes_General($options);
		}
		public function display_element(){
			
		}
		public function display_content(){
			
		}
	}
}