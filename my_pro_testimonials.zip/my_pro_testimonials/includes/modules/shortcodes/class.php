<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Module_Shortcodes_Main')){
	class Class_My_Module_Shortcodes_Main{
		private $debug=true;
		private $module_dir='';
		private $module_url='';
		private $shortcodes=array();
		private $shortcode_class=array();
		private $shortcode_options=array();
		private $msgs;
		private $global_modules;
		private $dialog_header;
		private $shortcode_actions=array();
		private $shortcode_translate_options=array();
		protected $use_case='module_shortcodes_main';
		private $global_actions;
		private $is_visual=false;
		function Class_My_Module_Shortcodes_Main($options=array()){
			if(!empty($options)){
				foreach($options as $key=>$val){
					$this->$key=$val;
				}
			}
			if(empty($this->module_dir)){
				$this->module_dir=plugin_dir_path(__FILE__);
			}
			if(empty($this->module_url)){
				$this->module_url=plugin_dir_url(__FILE__);
			}
			if(!empty($_GET['my_visual'])){
				$this->is_visual=true;
			}
			if(empty($this->global_actions)){
				$this->global_actions=array(
					'my_save'=>array(
						'icon'=>'fa-hdd',
						'title'=>__("Save","my_support_theme")
					)
				);
			}
			if(empty($this->shortcode_actions)){
				$this->shortcode_actions=array(
					'my_edit'=>array(
							'icon'=>'fa-edit',
							'title'=>__("Edit item","my_support_theme")
					),
					'my_copy'=>array(
								'icon'=>'fa-copy',
								'title'=>__("Copy item","my_support_theme")
					),
					'my_delete'=>array(
								'icon'=>'fa-eraser',
								'title'=>__("Delete item","my_support_theme")
					),
					'my_box'=>array(
								'icon'=>'fa-columns',
								'title'=>__("Box propertie","my_support_theme")
					),
					'my_style'=>array(
								'icon'=>'fa-adjust',
								'title'=>__("Color Properties","my_support_theme")
					),
					'my_small'=>array(
							'icon'=>'fa-mobile',
							'title'=>__("Small devices","my_support_theme")
					)			
					/*'my_move'=>array(
								'icon'=>'fa-arrows',
								'title'=>__("Move item","my_support_theme")
					)*/
						
				);
			}
			if($this->debug){
				Class_My_Module_Debug::add_section('init_module_shortcodes', $options,$this->use_case,false);
			}
			wp_my_general_load_module_function($this->global_modules, 'google_font', 'functions.php');
			global $wp_my_module_shortcode_google_fonts;
			$wp_my_module_shortcode_google_fonts=wp_my_google_fonts_get_fonts_arr();
		}
		public function render_options(){
			$my_set_debug=1;
			if(!$this->debug){
				$my_set_debug=0;
			}
			$file=$this->module_dir.'options.php';
			$options_arr=require $file;
			$forms=array();
			wp_my_general_load_module($this->global_modules, 'new_form');
			foreach($options_arr as $key=>$val){
				$options=array(
							
						'hidden'=>array(
								'my_nonce'=>wp_create_nonce("shortcodes_module"),
								'my_section'=>$key
						),
						'id'=>$key,
						'my_debug'=>$my_set_debug,
						'elements'=>$val['elements'],
						'element_template'=>'my_li_1.php',
						'form_template'=>'my_form_1.php'
				);
				$class=new Class_Wp_My_Module_New_Form($options);
				ob_start();
				echo '<h4>'.$val['section_title'].'</h4>';
				$class->render_form();
				$forms[$key]=ob_get_clean();
			}
			foreach($this->shortcodes as $key=>$val){
				$class_12=$this->shortcode_class[$key];
				$shortcode_options=$class_12->get_options();
				if(!empty($shortcode_options['elements'])){
					$key1=$key.'_style';
					$options=array(
							
						'hidden'=>array(
								'my_nonce'=>wp_create_nonce("shortcodes_module"),
								'my_section'=>$key1
						),
						'id'=>$key.'_style',
						'my_debug'=>$my_set_debug,
						'elements'=>$shortcode_options['elements'],
						'element_template'=>'my_li_1.php',
						'form_template'=>'my_form_1.php'
					);
					$class=new Class_Wp_My_Module_New_Form($options);
					ob_start();
					echo '<h4>'.$shortcode_options['section_title'].'</h4>';
					$key2=$key.'_style';
					$class->render_form();
					$forms[$key2]=ob_get_clean();
					foreach($shortcode_options['elements'] as $k1=>$v1){
						if(!empty($v1['translate'])){
							$this->shortcode_translate_options[$key2][$k1]=$v1['translate'];
						}
					}
				}
			}
			return $forms;
		}
		function init(){	
			if(is_admin()){	
			add_action ( 'admin_head', array (&$this,'admin_head') );
			add_action ( 'admin_enqueue_scripts', array (&$this,'admin_scripts') );
			add_action('admin_footer',array(&$this,'admin_footer'));
			/*add_action('wp_head', array($this,'wp_head'),PHP_INT_MAX);
			add_action('wp_enqueue_scripts',array($this,'scripts'),PHP_INT_MAX);
			*/
			}else {
				
			add_action ( 'wp_head', array (&$this,'admin_head') );
			add_action ( 'wp_enqueue_scripts', array (&$this,'admin_scripts') );
			add_action('wp_footer',array(&$this,'admin_footer'));
			}
			$file=$this->module_dir.'includes/functions/functions.php';
			require_once $file;
			$file=$this->module_dir.'options.php';
			$options_arr=require $file;
			
			foreach($options_arr as $key=>$val){
				$el=$val['elements'];
				if(!empty($el['sections'])){
					foreach($el['sections'] as $key1=>$val1){
						$el1=$val1['elements'];
						foreach($el1 as $key2=>$val2){
							if(!empty($val2['translate']))
							$this->shortcode_translate_options[$key][$key2]=$val2['translate'];
						}
					}
				}else {
				foreach($el as $key1=>$val1){
					if(!empty($val1['translate']))
					$this->shortcode_translate_options[$key][$key1]=$val1['translate'];
				}
				}
			}
			add_filter('the_content',array(&$this,'my_visual_shortcode'),PHP_INT_MAX);
			
			$file=$this->module_dir.'modules.php';
			$this->shortcodes=require $file;
			$this->shortcodes=apply_filters('my_module_shortcodes_add_shortcodes', $this->shortcodes);
			$file=$this->module_dir.'msgs.php';
			$this->msgs=require $file;
			$file=$this->module_dir.'class_general.php';
			require_once $file;
			$file=$this->module_dir.'views/dialog_header.php';
			$this->dialog_header=require $file;
				
			foreach($this->shortcodes as $key=>$val){
				if(isset($val['file'])){
					$file=$val['file'];
				}else $file=$this->module_dir.$key.'/class.php';
				require_once $file;
				$class='Class_My_Module_Shortcodes_'.ucfirst($key);
				$options=array(
					'key'=>$key
				);
				$str=$this->dialog_header;
				$str=str_replace('{dialog_title}', $val['title'], $str);
				$options['dialog_header']=$str;
				if(!empty($this->shortcode_options[$key])){
					$options=$this->shortcode_options[$key];
				}
				$this->shortcode_class[$key]=new $class($options);
			}
		}
		public function my_visual_shortcode($content){
			if($this->is_visual){
			$file=$this->module_dir.'views/rows.php';
			ob_start();
			require $file;
			$html=ob_get_clean();
			$content.=$html;
			return $content;
			}else return $content;
		}
		public function admin_head(){
			$my_set_debug=1;
			if(!$this->debug){
				$my_set_debug=0;
			}
			?>
			<script type="text/javascript">
				jQuery(document).ready(function($){
					var o={};
					o.debug=<?php echo $my_set_debug;?>;
					o.msgs=<?php if(!empty($this->msgs)){echo json_encode($this->msgs);}else echo '{}'?>;
					o.modules=<?php echo json_encode($this->shortcodes); ?>;
					o.translate=<?php echo json_encode($this->shortcode_translate_options);?>;
					myVusualBuilderMain_inst=new myVusualBuilderMain(o);
					<?php foreach ($this->shortcodes as $key=>$val){
						$j_class='myVusualBuilderShortcodes'.ucfirst($key);
						?>
						var o_<?php echo $key?>={};
						o_<?php echo $key?>.key="<?php echo $key;?>";
						o_<?php echo $key?>.main_class="";
						o_<?php echo $key?>.debug=<?php echo $my_set_debug;?>;
						<?php echo $j_class.'_inst'?>=new <?php echo $j_class.'(o_'.$key.')';?>;
						<?php 
					}?>
					});
			</script>
			<?php 
			
		}
		public function admin_scripts(){
			//echo 'Admin scripts';

			wp_enqueue_script('jquery');
			wp_enqueue_script("jquery-touch-pounch");
			wp_enqueue_script("jquery-ui-core");
			wp_enqueue_script("jquery-ui-widget");
			wp_enqueue_script("jquery-ui-dialog");
			wp_enqueue_script("jquery-ui-tooltip");
			wp_enqueue_script("jquery-ui-resizable");
			wp_enqueue_script("jquery-ui-draggable");
			wp_enqueue_script("jquery-ui-droppable");
				
				
			$url=$this->module_url.'assets/css/admin.css';
			wp_enqueue_style('my_module_shortcodes_main_css',$url);	
			$url=$this->module_url.'assets/css/elements.css';
			wp_enqueue_style('my_module_shortcodes_element_css',$url);
				
			$url=$this->module_url.'assets/jscript/main.js';
			wp_enqueue_script('my_module_shortcodes_main_js',$url);
			$url=$this->module_url.'assets/jscript/my_dialog.js';
			wp_enqueue_script('my_module_shortcodes_my_dialog_js',$url);
			wp_enqueue_media();
			foreach($this->shortcodes as $key=>$val){
				if(isset($val['url'])){
					$url=$val['url'].$key.'/assets/jscript.js';	
					$css_file=$val['dir'].$key.'/assets/admin.css';
					$css_url=$val['url'].$key.'/assets/admin.css';
					
					}else {
					$url=$this->module_url.$key.'/assets/jscript.js';
					$css_url=$this->module_url.$key.'/assets/admin.css';
					$css_file=$this->module_dir.$key.'/assets/admin.css';
				}
				wp_enqueue_script('my_module_shortcodes_'.$key.'_js',$url);
				if(file_exists($css_file)){
					wp_enqueue_style('my_module_shortcodes_'.$key.'_css',$css_url);
				}
			}
			
		}
		public function admin_footer(){
			$is_visual=@$_GET['my_visual'];
			if(isset($is_visual)){
				?>
				<div class="my_form_options_div">
		<div class="my_options_form">
			<div class="my_slide_in_out">
				<i class="fa fa-angle-double-left" style="display:none"></i>
				<i class="fa fa-angle-double-right"></i> 
			</div>
			<div class="my_options_form_inner">
			<?php global $wp_my_module_forms;
			$c12=0;
			foreach($wp_my_module_forms as $key=>$val){
				?>
				<div class="my_module_shortcodes_form" data-key="<?php echo esc_attr($key)?>" style="<?php if($c12>0)echo 'display:none';?>">
					<?php echo $val;?>
				</div>
				<?php 
				$c12++;
			}	
			?>
			</div>
		</div>
		</div>
		<?php /*
		<div class="my_elemenet_section">
					<h4><a href="#javascript" class="my_transition my_open_section"><i class="fa fa-plus"></i><span><?php echo __("Add Element","my_support_theme") ?></span></a></h4>
				
				<div class="my_section_inside">
				<ul class="my_window_actions">
							<li style="text-align:center"><span><?php echo __("Select Element","my_support_theme")?></span></li>
							<?php 
							global $my_shortcodes;
							if(!empty($my_shortcodes)){
								foreach($my_shortcodes as $key=>$val){
								?>
								<li class="my_transition"><a href="#javascript" title="<?php echo esc_attr($val['tooltip'])?>" class="my_transition my_add_shortcode" data-key="<?php echo esc_attr($key)?>"><i class="fa <?php echo $val['icon']?>"></i><span><?php echo $val['title'];?></span></a></li>
								<?php 
								}
							}
							?>
				</ul>
				</div>
				</div>		
				<?php 
				*/	
			
			?>
			<div class="my_shortcodes_dialog_overlay">
			</div>
			<?php 
			foreach ($this->shortcode_class as $key=>$val){
				?>
				<div class="my_shortcodes_<?php echo $key; ?>">
				<?php echo $val->get_dialog_header();?>
					<div class="my_shortcode_content">
					<?php echo $val->display_element();?>
					</div>
				</div>
				<?php 
				$val->display_content();
			}
			?>
			<script type="text/html" class="my_shortcode_element_object">
				<div class="my_outter_object" id="{id}" data-key="{key}">
					<ul class="my_shotcode_actions_ul">
					<?php foreach($this->shortcode_actions as $key=>$val){?>
					<li>
					<a href="#javascript" class="my_shortcode_action" title="<?php echo esc_attr($val['title'])?>" data-key="<?php echo esc_attr($key)?>">
					<i class="fa <?php echo $val['icon']?>"></i>
					</a>
					</li>
					<?php } ?>
					</ul>
					<div class="my_shortcode_content_new">
					{content}
					</div>
					
				</div>
			</script>
			<?php 
		}
		}

	}
}