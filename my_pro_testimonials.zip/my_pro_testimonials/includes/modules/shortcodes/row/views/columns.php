<?php
if(!defined('ABSPATH'))die('');
ob_start();
?>
<div class="my_shortcode_item" data-w="{width}" style="width:{width}%" id="{id}" data-i="{i}">
	<div class="my_shortcode_item_inner">
	<div class="my_shortcodes_rows_add">
	<h4>
	<i class="fa fa-plus"></i>&nbsp;&nbsp;<?php echo __("Add Shortcode","my_support_theme")?>	
	</h4>
	<div class="my_shortcode_added_html">
	</div>	
	</div>
	</div>	
</div>
<?php 
$html=ob_get_clean();
return $html;
?>						