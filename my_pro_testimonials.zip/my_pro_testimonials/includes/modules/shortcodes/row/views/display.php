<?php
if (! defined ( 'ABSPATH' ))
	die ( '' );
?>
<div class="my_shortcode_rows_div">
	
	<div class="my_accordian" data-on="0">
		<div class="my_accordian_header"><h4><i class="fa fa-plus"></i><i class="fa fa-minus" style="display:none"></i>&nbsp;&nbsp;<?php echo __("Predefined Layouts","my_support_theme")?></h4></div>
		<div class="my_accordian_inner">
	
	<ul class="my_shortocde_rows_ul my_clearfix">
		<?php
		if (!empty($layouts)) {
			foreach($layouts as $key => $val ) {
				$lay=$val['layouts'];
			?>
			<li>
			<ul data-widths="<?php echo implode(",",$lay)?>" class="my_clearfix">
				<?php foreach($lay as $k1=>$v1){?>
				<li style="width:<?php echo $v1.'%'?>">
				<span ><?php 
				switch ($v1){
					case 100:
						echo '1';
					break;	
					case 33.3333:
						echo '1/3';
					break;	
					case 25:
						echo '1/4';
					break;	
					case 20:
						echo '1/5';
					break;	
					case 40:
						echo '2/5';
					break;	
					case 60:
						echo '3/5';
					break;
					case 66.6666:
						echo '2/3';
					break;
					case 75:
						echo '3/4';
					break;			
					case 50:
						echo '1/2';
					break;						
				}
				?></span>
				</li>
				<?php }?>
			</ul>
			</li>
			<?php 
			}
		}
		?>
	</ul>
	</div>
	</div>
	<div class="my_accordian" data-on="0">
		<div class="my_accordian_header"><h4><i class="fa fa-plus"></i><i class="fa fa-minus" style="display:none"></i>&nbsp;&nbsp;<?php echo __("Add new Layout","my_support_theme")?></h4></div>
		<div class="my_accordian_inner">
			<form class="my_form_general">
			<ul class="my_clearfix">
				<li><label for="my_layout_id"><?php echo __("Layout title","my_support_theme")?></label>
			
				<input type="text" name="my_layout_name" id="my_layout_id" placeholder="Title"/>
			</li>
			
			
				<li><label for="my_row_wdith_id"><?php echo __("Column width","my_support_theme")?></label>
				<input type="text" name="my_row_width" id="my_row_width_id" placeholder="15%"/>
			</li>
			
			</ul>
			<ul class="my_clearfix">
			<li>
			<input type="button" class="button button-primary my_button my_action_shortcode_row"  data-key="add_column" value="<?php echo __("Add Column","my_support_theme") ?>"/>
			</li>
			<li>
			<input type="button" class="button button-primary my_button my_action_shortcode_row"  data-key="new_layout" value="<?php echo __("New Layout","my_support_theme") ?>"/>
			</li>
			
			<li>
			<input type="button" class="button button-primary my_button my_action_shortcode_row" data-key="save_layout" value="<?php echo __("Save Laoyut","my_support_theme") ?>"/>
			</li>
			</ul>
			
			<div class="my_new_layout_preview">
				<ul>
				
				</ul>
			</div>
			</form>
			</div>
	</div>
</div>