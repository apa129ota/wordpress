<?php
if(!defined('ABSPATH'))die('');
$units=array(
		'px'=>'px',
		'%'=>'%',
		'px'=>'px',
		'cm'=>'cm',
		'mm'=>'mm',
		'in'=>'in',
		'pt'=>'pt',
		'pc'=>'pc',
		'ch'=>'ch'
);
$background_types=array(
	'static'=>__("Static","my_support_theme"),
	'fixed'=>__("Fixed","my_support_theme"),
	'parallax'=>__("Parallax","my_support_theme"),
	'fade_parallax'=>__("Fade Parallax","my_support_theme"),
	'scale_parallax'=>__("Scale Parallax","my_support_theme"),
	'video'=>__("Video","my_support_theme"),			
);
$properties['background']=array(
	'background-color'=>array(
			'type'=>'jscript_color_picker',
			'tooltip'=>__("Background Color","my_support_theme"),
			'title'=>__("Color","my_support_theme"),
			'pick_title'=>__("Pick a Color","my_support_theme"),
			'close_title'=>__("Close","my_support_theme"),
			'default'=>array(
					'color'=>'#000000',
					'transp'=>0.2
			),
			'jscript'=>array(
					'pick_title'=>__("Pick a Color","my_support_theme"),
					'close_title'=>__("Close","my_support_theme"),
					'hex_title'=>__("Hex value","my_support_theme"),
					'transp_title'=>__("Transparency","my_support_theme")
			),
			'property'=>array(
				'class'=>'{class}',
				'property'=>'background'	
			),
			'transparency'=>true,
	),
	'background-type'=>array(
			'tooltip'=>__("Background Type","my_support_theme"),
			'title'=>__("Type","my_support_theme"),
			'type'=>'jscript_dropdown',	
			'jscript'=>array(
					'max_c'=>1,
					'max_sel'=>__("Maximum elements are selected","my_support_theme"),
					'duration'=>500,
					'animation'=>'fadein',
					'choose_value'=>__("Plese Select value","my_support_theme"),
			),
			'show_filter'=>0,
			'multiple'=>false,
			'choose_value'=>__("Plese Select value","my_support_theme"),
			'default'=>'static',
			'values'=>$background_types
	),
	'background-image'=>array(
				'type'=>'thumb',
				'tooltip'=>__("Image","my_support_theme"),
				'title'=>__("Thumb","my_support_theme"),
				'property'=>array(
					'class'=>'{class}',
					'property'=>'background'
				),
			'choose_title'=>__("Change Thumb","my_related_posts_domain"),
			'no_image'=>__("No Image","my_related_posts_domain"),
			'choose_title'=>__("Choose Media","my_related_posts_domain"),
			'remove'=>__("Remove Media","my_related_posts_domain"),
			'jscript'=>array(
					'can_remove'=>true,
					'multiple'=>0,
					'show_values'=>1,
					'max_c'=>1,
					'choose_title'=>__("Choose Media","my_related_posts_domain"),
					'media_title'=>__("Choose Image","my_related_posts_domain"),
					'button_text'=>__("Insert","my_related_posts_domain"),
					'filter_type'=>'image',//audio video image
			
			),
				
			),
	'backgrond-repeat'=>array(
				'type'=>'checkbox',
				'default'=>1,
				'tooltip'=>__("Repat background","my_support_theme"),
				'title'=>__("Repeat","my_support_theme"),
				'label'=>__("Repeat","my_support_theme"),
			
	),
	'video'=>array(
			'type'=>'button',
			'tooltip'=>__("Choose background Video","my_support_theme"),
			'title'=>__("Video","my_support_theme"),
			'class'=>array('my_buttom'),
			'value'=>__("Choose Video","my_support_theme")
	)			
);
$properties['padding']=array(
	'padding-top'=>array(
		'title'=>__("Padding top","my_support_theme"),
		'type'=>'jscript_spinner',
		'property'=>'height',
		'default'=>'10',
		'default_unit'=>'px',
		'units'=>$units,
		'translate'=>array(
				'class'=>'{class}',
				'property'=>'padding-top'
		)
),
'padding-left'=>array(
		'title'=>__("Padding top","my_support_theme"),
		'type'=>'jscript_spinner',
		'property'=>'height',
		'default'=>'10',
		'default_unit'=>'px',
		'units'=>$units,
		'translate'=>array(
				'class'=>'{class}',
				'property'=>'padding-left'
		)
),
'padding-right'=>array(
		'title'=>__("Padding top","my_support_theme"),
		'type'=>'jscript_spinner',
		'property'=>'height',
		'default'=>'10',
		'default_unit'=>'px',
		'units'=>$units,
		'translate'=>array(
				'class'=>'{class}',
				'property'=>'padding-right'
		)
),
'padding-bottom'=>array(
		'title'=>__("Padding top","my_support_theme"),
		'type'=>'jscript_spinner',
		'property'=>'height',
		'default'=>'10',
		'default_unit'=>'px',
		'units'=>$units,
		'translate'=>array(
				'class'=>'{class}',
				'property'=>'padding-bottom'
		)
));
$properties['margin']=array(
		'margin-top'=>array(
					'title'=>__("Margin top","my_support_theme"),
					'type'=>'jscript_spinner',
					'property'=>'height',
					'default'=>'0',
					'default_unit'=>'px',
					'units'=>$units,
				'translate'=>array(
						'class'=>'{class}',
						'property'=>'margin-top'
				)
			),
			'margin-left'=>array(
					'title'=>__("Margin left","my_support_theme"),
					'type'=>'jscript_spinner',
					'property'=>'height',
					'default'=>'0',
					'default_unit'=>'px',
					'units'=>$units,
					'translate'=>array(
							'class'=>'{class}',
							'property'=>'margin-left'
					)
			),
			'margin-right'=>array(
					'title'=>__("Margin Right","my_support_theme"),
					'type'=>'jscript_spinner',
					'property'=>'height',
					'default'=>'0',
					'default_unit'=>'px',
					'units'=>$units,
					'translate'=>array(
							'class'=>'{class}',
							'property'=>'margin-right'
					)
			),
			'margin-bottom'=>array(
					'title'=>__("Margin bottom","my_support_theme"),
					'type'=>'jscript_spinner',
					'property'=>'height',
					'default'=>'15',
					'default_unit'=>'px',
					'units'=>$units,
					'translate'=>array(
							'class'=>'{class}',
							'property'=>'margin-bottom'
					)
			),
);	