<?php
if(!defined('ABSPATH'))die('');
$arr=array(
	'loading'=>__("Loading","my_support_theme")
);
return $arr;