<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Module_Shortcodes_Html')){
	class Class_My_Module_Shortcodes_Html extends Class_My_Module_Shortcodes_General{
		private $editor_options;
		private $editor_height=100;
		private $editor_id;
		static $num=0;
		function Class_My_Module_Shortcodes_Html($options=array()){
			Class_My_Module_Shortcodes_Html::$num++;
			$this->editor_id='my_editor_'.(Class_My_Module_Shortcodes_Html::$num);
			parent::Class_My_Module_Shortcodes_General($options);
			if(!empty($options['editor_options'])){
				$this->editor_options=$options['editor_options'];
			}else {
				$this->editor_options=array(
							'media_buttons'=>true,
							'wpautop'=>false,
							'editor_height'=>100,
							'teeny'=>true,
							'quicktags'=>false
					);
			}
		}
		public function display_element(){
			$value=$this->lorem;
			wp_editor($value,$this->editor_id,$this->editor_options);
			$this->render_buttons(array(
				'my_insert'=>array(
					'title'=>__("Update Content","my_support_theme")
				)
			));
			
		}
		public function display_content(){
			?>
			<script type="text/html" class="my_shortcode_html">
				<div class="my_shortcode_<?php echo $this->key;?> " id="{id}" data-id="{object_id}" data-i="{i}">
				{content}
				</div>
			</script>
			<script type="text/html" class="my_shortcode_html_default">
			<?php echo $this->lorem; ?>
			</script>			
			<?php 
		}
		
	}
}