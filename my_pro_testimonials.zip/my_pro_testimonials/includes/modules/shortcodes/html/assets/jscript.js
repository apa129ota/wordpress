(function($) { 
	myVusualBuilderShortcodesHtml=function(o){
		var self;
		this.my_working=false;
		this.debug=true;
		this.options=o;
		this.dialog='';
		this.tmpl='';
		this.index=1;
		this.content='';
		this.pre_options={
				dw:600,
				dh:400,
				diff:20
			};
			self=this;
			this.init=function(o){
				if(typeof self.options.debug!='undefined'){
					if(!self.options.debug){
						self.debug=false;
					}
				}
				self.options=$.extend( self.pre_options,self.options);
				
				self.my_debug("options", self.options);
				var o={
					key:self.options.key,
					debug:self.debug,
					dw:self.options.dw,
					dh:self.options.dh,
					diff:self.options.diff
				};
				self.dialog=new myVusualBuilderDialog(o);
				
			};
			this.my_edit=function(content,id){
				self.my_edit_id=id;
				self.dialog.my_open();
				self.my_debug('content',content);
				tinyMCE.get('my_editor_1').setContent(content);
					
			};
			this.get_content=function(){
				var id=self.my_edit_id;
				var content=tinyMCE.get('my_editor_1').getContent();
				return content;
			}
			this.my_show=function(obj){
				//$(self.my_class).dialog('open');
				//self.dialog.my_open(obj);
				var id=obj.id;
				var is=$("#"+id).length;
				if(is){
					self.dialog.my_open();
				}
				
				else return self.my_get_content(obj);
			};
			this.my_get_content=function(obj){
				var tmpl=$("script.my_shortcode_html").html();
				var id='my_shortcode_'+self.options.key+'_'+self.index;
				var is=$("#"+id).length;
				if(is)return false;
				self.my_debug("Is",is);
				var content;
				content=$("script.my_shortcode_html_default").text();
				tmpl=tmpl.replace('{id}',id);
				tmpl=tmpl.replace('{i}',self.index);
				tmpl=tmpl.replace('{content}',content);
				self.index++;
				self.my_debug('tmpl',tmpl);
				return {id:id,tmpl:tmpl};
			};
			this.my_clone_object=function(content){
				var tmpl=$("script.my_shortcode_html").html();
				var id='my_shortcode_'+self.options.key+'_'+self.index;
				var is=$("#"+id).length;
				if(is)return false;
				self.my_debug("Is",is);
				//var content;
				//content=$("script.my_shortcode_html_default").text();
				tmpl=tmpl.replace('{id}',id);
				tmpl=tmpl.replace('{i}',self.index);
				tmpl=tmpl.replace('{content}',content);
				self.index++;
				self.my_debug('tmpl',tmpl);
				return {id:id,tmpl:tmpl};
			};
			this.my_debug=function(t,o){
				if(self.debug){
					if(window.console){
						console.log('Visual builder Main \n'+t,o);
					}
				}
			};
			this.init();
			
	};
	})(jQuery);				
