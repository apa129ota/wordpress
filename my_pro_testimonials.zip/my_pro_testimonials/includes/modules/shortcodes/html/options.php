<?php
if(!defined('ABSPATH'))die('');
global $wp_my_module_shortcode_google_fonts;
$options=array(
	'section_title'=>__("HTML Style Options","my_support_theme"),	
	'elements'=>array(
		'save'=>array(
			'title'=>__("Save Style","my_support_theme"),	
			'type'=>'button',
			'value'=>__("Save Style","my_support_theme"),
			'class'=>'button button-primary my_save_style',
			'type'=>'button',
			'default'=>'0'	
		),	
		'load'=>array(
					'title'=>__("Load Style","my_support_theme"),
					'type'=>'button',
					'value'=>__("Load Style","my_support_theme"),
					'class'=>'button button-primary my_load_style',
					'type'=>'button',
					'default'=>'0'
			),
		'font-size'=>array(
				'title'=>__("Font Size","my_support_theme"),
				'type'=>'text',
				'default'=>'14px',
				'translate'=>array(
						'class'=>'{class} *',
						'property'=>'font-size'
				)		
		),
		'background-color'=>array(
					'type'=>'jscript_color_picker',
					'tooltip'=>__("Background Color if you want to be invisibvle set transparency to 0","my_support_theme"),
					'title'=>__("Bakcground Color","my_support_theme"),
					'pick_title'=>__("Pick a Color","my_support_theme"),
					'close_title'=>__("Close","my_support_theme"),
					'default'=>array(
							'color'=>'#000000',
							'transp'=>0.3
					),
					'jscript'=>array(
							'pick_title'=>__("Pick a Color","my_support_theme"),
							'close_title'=>__("Close","my_support_theme"),
							'hex_title'=>__("Hex value","my_support_theme"),
							'transp_title'=>__("Transparency","my_support_theme")
					),
					'transparency'=>true,
					'translate'=>array(
						'class'=>'{class}',
						'property'=>'background-color'
					)
						
			),
		'font-color'=>array(
				'type'=>'jscript_color_picker',
				'tooltip'=>__("Pick font color","my_support_theme"),
				'title'=>__("Font Color","my_support_theme"),
				'pick_title'=>__("Pick a Color","my_support_theme"),
				'close_title'=>__("Close","my_support_theme"),
				'default'=>'#ffffff',
				'jscript'=>array(
						'pick_title'=>__("Pick a Color","my_support_theme"),
						'close_title'=>__("Close","my_support_theme"),
						'hex_title'=>__("Hex value","my_support_theme"),
						'transp_title'=>__("Transparency","my_support_theme")
				),
				'transparency'=>false,
				'translate'=>array(
						'class'=>'{class} *:not(a)',
						'property'=>'color'
				)
		),
		'line-height'=>array(
					'title'=>__("Line Height","my_support_theme"),
					'type'=>'text',
					'default'=>'18px',
					'translate'=>array(
						'class'=>'{class} *',
						'property'=>'line-height'
					)
		),
		'font-family'=>array(
					'title'=>__("Font Family","my_support_theme"),
					'type'=>'jscript_dropdown',
					'values'=>$wp_my_module_shortcode_google_fonts,
					'widths'=>array(
						600=>'100%',
						1200=>'100%',
					),
					'jscript'=>array(
						'max_c'=>1,
						'max_sel'=>__("Maximum elements are selected","my_support_theme"),
						'duration'=>500,
						'animation'=>'fadein',
						'choose_value'=>__("Plese Select value","my_support_theme"),
					),
					'show_filter'=>1,
					'multiple'=>false,
					'choose_value'=>__("Font","my_support_theme"),
					'default'=>'default',
					'translate'=>array(
						'class'=>'{class} *',
						'property'=>'font-family'
							
					)
		),
		'link-color'=>array(
				'type'=>'jscript_color_picker',
				'tooltip'=>__("Html a color","my_support_theme"),
				'title'=>__("Link Color","my_support_theme"),
				'pick_title'=>__("Pick a Color","my_support_theme"),
				'close_title'=>__("Close","my_support_theme"),
				'default'=>'#0074A2',
				'jscript'=>array(
						'pick_title'=>__("Pick a Color","my_support_theme"),
						'close_title'=>__("Close","my_support_theme"),
						'hex_title'=>__("Hex value","my_support_theme"),
						'transp_title'=>__("Transparency","my_support_theme")
				),
				'transparency'=>false,
				'translate'=>array(
						'class'=>'{class} a',
						'property'=>'color'
				)
		),
		'link-hover-color'=>array(
				'type'=>'jscript_color_picker',
				'tooltip'=>__("Html a hover color","my_support_theme"),
				'title'=>__("Link Hover","my_support_theme"),
				'pick_title'=>__("Pick a Color","my_support_theme"),
				'close_title'=>__("Close","my_support_theme"),
				'default'=>'#0074A2',
				'jscript'=>array(
						'pick_title'=>__("Pick a Color","my_support_theme"),
						'close_title'=>__("Close","my_support_theme"),
						'hex_title'=>__("Hex value","my_support_theme"),
						'transp_title'=>__("Transparency","my_support_theme")
				),
				'transparency'=>false,
				'translate'=>array(
						'class'=>'{class} a:hover',
						'property'=>'color'
				)
				)		
				
	)
);
return $options;
