(function($) { 
	myVusualBuilderMain=function(o){
		var self;
		this.my_working=false;
		this.debug=true;
		
		this.pre_options={
				editor_class:".my_slide_image_inner",
				element_inner:".my_shortcode_content_new",
				ul_button:".my_shotcode_actions_ul",
				outter_class:".my_outter_object",
				form_class:".my_options_form",
				form_element:".my_new_module_element",
				shortcode_content:".my_shortcode_content_new",
				item_add_class:".my_shortcode_added_html",
				item_class:".my_shortcode_item",
			row_class:".my_shortcode_row_row"	
		};
		this.my_disable_change=false;
		this.objects={};
		this.options=o;
		this.my_add_id='';
		this.my_add_object={};
		this.my_edit_id='';
		this.included_fonts={};
		this.my_dont_open=false;
		self=this;
		
		this.init=function(o){
			
			if(typeof self.options.debug!='undefined'){
				if(!self.options.debug){
					self.debug=false;
				}
			}
			
			self.options=$.extend( self.pre_options,self.options);
			self.my_debug("options", self.options);
			$(".my_timeline_modal_close_1").click(function(e){
				$(this).parents('.ui-dialog-content').dialog('close');
			});
			$(self.editor_class).droppable();
			$(document).on('click',".my_action",self.my_action);
			$(document).on("click",".my_shortcode_action",self.my_shortcode_action);
			$(document).on('click',".my_insert",self.my_insert);
			$(document).on('click',self.options.outter_class,function(e){
				var id=$(this).attr('id');
				var key=$(this).data('key');
				self.my_debug('Click select',{id:id,key:key});
				if(id==self.my_edit_id)return;
				$(self.options.outter_class).removeClass("my_selected_el");
				self.my_edit_key=key;
				self.my_edit_id=id;
				self.my_add_id='';
				$(this).addClass("my_selected_el");
				self.my_dont_open=true;
				$(this).find(".my_shotcode_actions_ul li a[data-key='my_box']").trigger('click');
				self.my_dont_open=false;
				
			});
			var ww=$(window).height();
			$(".my_shortcodes_dialog_overlay").height(ww);
			$(self.options.form_class+" "+self.options.form_element).each(function(i,v){
				var id=$(v).attr('id');
				var o=self.get_element_data(id);
				self.my_debug('Init chnage',o);
				switch(o.type){
					case 'jscript_color_picker':
					case 'jscript_dropdown':
					case 'jscript_spinner':	
						self.my_debug('Call change script');
						var sel=$("#"+o.id);
						//var o=self.get_element_data(id);
						var type=o.type;
						$(o.obj).on('my_change',function(e,obj,val,v1){
							if(self.my_disable_change)return;
							self.my_debug("Change my objects",{obj:obj,val:val});
							var form_prefix=$(this).parents('form').find("input[name='my_form_id']").val();
							var id=$(this).attr('id');
							var object_id=self.my_edit_id;
							var object;
							var edit_type=form_prefix;//$("#"+object_id).find(self.options.outter_class).data('key');
							if(self.my_add_id!=''){
								self.my_debug('Styling row',self.my_add_id);
								object_id=self.my_add_id;
								object=self.my_add_object;//myVusualBuilderShortcodesRow_inst[object_id];
								self.my_add_object=object;
								edit_type=form_prefix;
							}else {
								object=self.objects[object_id];
							}
							o.val=val;
							var prop=form_prefix;
							var name=$(this).data('base-name');
							var type=$(this).data('type');
							//var val=obj[1];
							self.my_debug("Edit type",{object:object,edit_type:edit_type,name:name,type:type,form_prefix:form_prefix,translations:self.options.translate});
							var translate=self.options.translate[edit_type];
							self.my_debug("Translate",translate);
							if(typeof translate!='undefined'){
								var p=self.options.translate[prop];
								if(typeof p[name]!=undefined){
									var property=p[name];
									self.my_debug("Property",property);
									var sel=property['class'];
									var css_prop=property.property;
									var p_sel="#"+object_id+"  "+self.options.shortcode_content;
									if(self.my_add_id){
										p_sel='#'+object_id;
									}
									self.my_debug('p_sel',p_sel);
									self.my_debug("property",css_prop);
									sel=sel.replace('{class}',p_sel);
									self.my_debug("sel",sel);
									//if(sel.indexOf(":")!==-1){
										var css_id=object_id+'_'+name;
										if(name=='font-family'){
											if(typeof self.included_fonts[val]=='undefined'){
												self.my_debug("Inlcude new font",val);
												var value=val.replace(/ /g,'+');
												self.my_debug("Inlcude new font",value);
												$("head").append('<link rel="stylesheet" href="https://fonts.googleapis.com/css?family='+value+'"/>');
												self.included_fonts[val]=1;
											}
										}
										var css;
										if(name=='font-family'){
											
											css=sel+"{\n"+css_prop+":"+val+" , serif !important\n}";

										}
										else css=sel+"{\n"+css_prop+":"+val+" !important\n}";
										if($("#"+css_id).length>0){
											$("#"+css_id).text(css);
										}else {
											$("#"+object_id).append('<style type="text/css" id="'+css_id+'">'+css+'</style>');
										}
										
									/*	
									}else {
										$(sel).css(css_prop,value);
									
									}*/
										if(form_prefix=='responsive_box'){
											if(typeof object.responsive=='undefined'){
												object.responsive={};
											}
											object.responsive[o.name]=val;
											self.my_debug("Repossive",self.objects[self.my_edit_id].responsive);
										}
										else	if(form_prefix=='box'){
									if(typeof object.box=='undefined'){
										object.box={};
										
									}	
									object.box[name]=val;
									self.change_box_model(o);
										}else {
									if(typeof object.style=='undefined'){
										object.style={};
									}
									if(type='jscript_color_picker'){
										val=v1;
									}
									object.style[name]=val;
										}
									self.my_debug("Properties style",object);
								}
							}
						});
					break;	
					case 'text':
					case 'radio_list':
					case 'radio':
					case 'checkbox':
						self.my_debug('Call change script');
						var sel=$("#"+o.id);
						var type=o.type;
						if(type=='radio_list' || type=='radio' || type=='checkbox' || type=='checbox_list'){
							sel=$("input[name='"+o.full_name+"']");
						}
						var object_id=self.my_edit_id;
						var object=self.objects[object_id];
						if(self.my_add_id!=''){
							object_id=self.my_add_id;
							object=self.my_add_object;
						}
						
						self.my_debug("Init change",{type:type,sel:sel});
						$(sel).change(function(e){
							if(self.my_disable_change)return;
							var form_prefix=$(this).parents('form').find("input[name='my_form_id']").val();
							var id=$(this).parents(self.options.form_element).attr('id');
							self.my_debug('Outter id',id);
							var o=self.get_element_data(id);
							o.form_prefix=form_prefix;
							o.val=$(this).val();
							self.my_debug('Change element',o);
							if(form_prefix=='responsive_box'){
								if(typeof self.objects[self.my_edit_id]=='undefined'){
									self.objects[self.my_edit_id].responsive={};
								}
								object.responsive[o.name]=val;
								self.my_debug("Repossive",self.objects[self.my_edit_id].responsive);
							}
							else if(form_prefix=='box'){
								self.change_box_model(o);
							}
							else self.my_change_element(o);
						});
					break;	
				}
			});
			$(window).load(function(e){
			//$(".my_shortcode_rows").trigger('click');
			});
		};
		this.set_row=function(id,object){
			self.my_debug("Set selected min script row",{id:id,object:object});
			self.my_add_id=id;
			self.my_add_object=object;
		}
		this.my_action=function(e){
			e.preventDefault();
			var key=$(this).data('key');
			self.my_debug('Action',key);
			switch(key){
				case 'add_rows':
					myVusualBuilderShortcodesRow_inst.my_show();
				break;	
 			}
		}
		this.my_change_element=function(obj){
			self.my_debug("Change jscript color picker",{obj:obj,val:val});
			if(self.my_disable_change)return;
			var form_prefix=obj.form_prefix;//$().parents('form').find("input[name='my_form_id']").val();
			//var id=$(o.obj).attr('id');
			var object_id=self.my_edit_id;
			var prop=form_prefix;
			var name=obj.name;
			var val=obj.val;
			//var val=obj[1];
			if(typeof self.options.translate[prop]!='undefined'){
				var p=self.options.translate[prop];
				self.my_debug("P",p);
				if(typeof p[name]!=undefined){
					var property=p[name];
					self.my_debug("Property",property);
					var sel=property['class'];
					var css_prop=property.property;
					var p_sel="#"+object_id+"  "+self.options.shortcode_content;
					self.my_debug('p_sel',p_sel);
					self.my_debug("property",css_prop);
					sel=sel.replace('{class}',p_sel);
					self.my_debug("sel",sel);
					//if(sel.indexOf(":")!==-1){
						var css_id=object_id+'_'+name;
						var css=sel+"{\n"+css_prop+":"+val+" !important;\n}";
						if($("#"+css_id).length>0){
							$("#"+css_id).text(css);
						}else {
							$("#"+object_id).append('<style type="text/css" id="'+css_id+'">'+css+'</style>');
						}
						if(typeof self.objects[object_id].style=='undefined'){
							self.objects[object_id].style={};
						}
						self.objects[object_id].style[name]=val;
						
						self.my_debug("Properties style",self.objects[object_id].style);
				}
			}
						
		};
		this.resize=function(e){
			var ww=$(window).height();
			$(".my_shortcodes_dialog_overlay").height(ww);
		};
		this.my_insert=function(e){
			e.preventDefault();
			var key=self.my_edit_key;
			var u=key.charAt(0).toUpperCase();
			var k=u+key.substr(1);
			var c='myVusualBuilderShortcodes'+k+'_inst';
			self.my_debug('Shortcode class',c);
			var $o=$("#"+self.my_edit_id);
			if(typeof window[c]!='undefined'){
				var content=window[c].get_content();
				if(key=='text' || key=='html'){
					if($($o).find(self.options.element_inner+" .mCSB_container").length>0){
						$($o).find(self.options.element_inner+" .mCSB_container").html(content);
					}else {
						$($o).find(self.options.element_inner).html(content);
					}
				}
			}else {
				self.my_debug('not defined',c);
			}
		}
		this.update_properties=function(id,object,type){
			self.my_debug("update properties",{id:id,object:object,type:type});
			self.my_disable_change=true;
			var form_id='#my_form_box';
			
			if(type=='responsive'){
				form_id="#my_form_responsive_box";
			}else if(type!='box'){
				form_id="#my_form_"+self.my_edit_key+"_style";
			}
			self.my_debug("form_id",form_id);
			//if(typeof o[type]!='undefined'){
			//	$.each(o[type],function(i,v){
			$(form_id+" "+self.options.form_element).each(function(i,v){
				var id=$(v).attr('id');
				self.my_debug("id",id);
				var el=self.get_element_data(id);
				var name=el.name;
				self.my_debug('Property update',{el:el,o_type:object[type],name:name});
				var id=el.id;
				var $o=el.obj;
				/*
					var id=i+'_'+type+'_style_id';
					if(type=='box'){
						id=i+'_box_id';
					}else if(type=='responsive'){
						id=i+'_responsive_box_id';
					}
					
					var el=self.get_element_data(id);
					self.my_debug("Element types",{el:el,id:id,v:v});
					*/
					if(typeof el!='undefined'){
						var val='';
						var has_val=false;
						if(typeof object[type]!=='undefined'){
							if(typeof object[type][name]!='undefined'){
								val=object[type][name];
								has_val=true;
								
							}
						}
						self.my_debug("Update element",{id:id,val:val,has_val:has_val,el_type:el_type});
						var el_type=el.type;
						
						if(el_type=='text'){
							if(val==''&&!has_val){
								val=$($o).data('default');
							}
							$("#"+id).val(val);
						}else if(el_type=='radio_list'){
							if(val==''&&!has_val){
								val=$($o).data('default');
							}
							$($o).find("input[type='radio'][value='"+v+"']").trigger('click');
						}else if(el_type=='jscript_color_picker'){
							var s=$($o).data('my-script');
							if(val==''&&!has_val){
								s.set_default();
							}
							else s.set_value(val);
						}else if(el_type=='jscript_dropdown'){
							var s=$($o).data('my-script');
							if(val==''&&!has_val){
								s.set_default();
							}
							else s.set_value(val);
						}
						
					}
					
				});
			//}
			self.my_disable_change=false;
		};
		this.get_element_data=function(id){
			var $o=$("#"+id);
			var type=$($o).data('type');
			var name=$($o).data('base-name');
			var name1=$($o).data('name');
			var id1=$($o).data('id');
			return {
				id:id1,
				full_name:name1,
				name:name,
				type:type,
				obj:$o
			};
		};
		this.my_shortcode_action=function(e){
			e.preventDefault();
			var data_key=$(this).data('key');
			self.my_debug('shorcode action',key);
			
			switch(data_key){
					case 'my_copy':
						var $o=$(this).parents(self.options.outter_class);
						var id=$($o).attr('id');
						var content='';
						var id=$($o).attr('id');
						var key=$($o).attr('data-key');
						var o=self.objects[id];
						var base_id=id.match(/my_added_object_[0-9]+_/g);
						var i=myAdminBuilder_inst.index;
						var my_top=myAdminBuilder_inst.my_top;
						var my_diff=myAdminBuilder_inst.my_diff;
						var parent_id=myAdminBuilder_inst.my_edit_id;
						var new_id='my_added_object_'+parent_id+'_'+i;
						var data_key=key;
						var key=$($o).attr('data-key');
						if(key=='text' || key=='html'){
							if($($o).find(self.options.element_inner+" .mCSB_container").length>0){
								content=$($o).find(self.options.element_inner+" .mCSB_container").html();
							}else {
								content=$($o).find(self.options.element_inner).html();
							}
						}else {
							
						}
						var s_tmpl_1=self.my_clone_object(data_key,content);
						var s_tmpl=s_tmpl_1.tmpl;
						
						myAdminBuilder_inst.index++;
						self.objects[new_id]=self.objects[id];
						$("#"+new_id).trigger('click');
						var css_copy='';
						$("#"+id).find("style").each(function(i,v){
							var css_id=$(v).attr('id');
							css_id=css_id.replace(id,new_id);
							var text=$(v).text();
							text=text.replace('#'+id,'#'+new_id);
							self.my_debug("Add css",{cssid:css_id,text:text});
							css_copy+='<style type="text/css" id="'+css_id+'">'+text+'</style>';
						});
						var tmpl=$("script.my_shortcode_element_object").html();
						tmpl=tmpl.replace('{content}',s_tmpl);
						tmpl=tmpl.replace('{id}',new_id);
						tmpl=tmpl.replace('{key}',key);
						$("#"+self.my_edit_id).parents(self.options.item_class).find(self.options.iteam_add_class).append(tmpl);
						self.my_debug("Copy css",css_copy);
						setTimeout(function(){
							$("#"+new_id).append(css_copy);
							self.adjust_element(new_id,key,my_top,my_diff);
							//self.my_top+=$(".my_slide_image_inner").find("#"+id).height()+10;
							self.my_working=false;
						},100);
					break;	
					case 'my_small':
						var $o=$(this).parents(self.options.outter_class);
						var id=$($o).attr('id');
						var key=$($o).attr('data-key');
						self.my_edit_key=key;
						self.my_edit_id=id;
						var o=self.objects[id];
						self.my_debug("Obvject properties",o);
						self.update_properties(id,o,'responsive');
						$(".my_module_shortcodes_form").hide();
						$(".my_module_shortcodes_form[data-key='responsive_box']").show();
						$(".my_slide_in_out .fa-angle-double-right").trigger('click');
					break;	
					case 'my_style':
						var $o=$(this).parents(self.options.outter_class);
						var id=$($o).attr('id');
						var key=$($o).attr('data-key');
						var o=self.objects[id];
						self.my_edit_key=key;
						self.my_edit_id=id;
						self.my_debug("Obvject properties",o);
						self.update_properties(id,o,'style');
						$(".my_module_shortcodes_form").hide();
						$(".my_module_shortcodes_form[data-key='"+key+"_style']").show();
						$(".my_slide_in_out .fa-angle-double-right").trigger('click');
					break;	
					case 'my_box':
						var $o=$(this).parents(self.options.outter_class);
						var id=$($o).attr('id');
						var id=$($o).attr('id');
						var key=$($o).attr('data-key');
						var o=self.objects[id];
						self.my_edit_key=key;
						self.my_edit_id=id;
						self.my_debug("Obvject properties",o);
						self.update_properties(id,o,'box');
						$(".my_module_shortcodes_form").hide();
						$(".my_module_shortcodes_form[data-key='box']").show();
						if(!self.my_dont_open)
						$(".my_slide_in_out .fa-angle-double-right").trigger('click');
					break;	
					case 'my_delete':
						var $o=$(this).parents(self.options.outter_class);
						var id=$($o).attr('id');
						self.my_debug("Delete",id);
						$("#"+id).fadeOut(function(e){$(this).remove()});
						delete self.objects[id];
					break;	
					case 'my_edit':
						var $o=$(this).parents(self.options.outter_class);
						var id=$($o).attr('id');
						var content='';
						
						var key=$($o).attr('data-key');
						if(key=='text' || key=='html'){
							if($($o).find(self.options.element_inner+" .mCSB_container").length>0){
								content=$($o).find(self.options.element_inner+" .mCSB_container").html();
							}else {
								content=$($o).find(self.options.element_inner).html();
							}
						}else {
							
						}
						self.my_edit_id=id;
						self.my_edit_key=key;
						self.my_debug("Id key",{id:id,key:key});
						var u=key.charAt(0).toUpperCase();
						var k=u+key.substr(1);
						var c='myVusualBuilderShortcodes'+k+'_inst';
						self.my_debug('Shortcode class',c);
						if(typeof window[c]!='undefined'){
							var tmpl=window[c].my_edit(content,id);
							return tmpl;
						}else {
							self.my_debug('not defined',c);
						}
					break;	
			}
		};
		this.added_element=function(id,key){
			return;
			$("#"+id).resizable({
				resize: function(event, ui) {
			        //ui.size.width = ui.originalSize.width;
					var id=$(this).attr('id');
					var h=ui.size.height;
					var w=ui.size.width;
					var unit=self.objects[id].box.unit;
					self.my_disable_change=true;
					var w1=$(self.options.editor_class).width();
					var h1=$(self.options.editor_class).height();
					var uw,uh;
					uw=w;uh=h;
					if(unit=='%'){
						uw=w/w1;
						uw=Math.round(uw*100)/100;
						 uh=h/h1;
						uh=Math.round(uh*100)/100;
					}
					$("#width_box_id").val(uw);
					$("#height_box_id").val(uh);
					self.my_disable_change=false;
					self.my_debug('Dimesions',{uw:uw,uh:uh,ui:ui,id:id});
					self.objects[id].box.width=uw;
					self.objects[id].box.height=uh;
					
					var id=$(this).attr('id');
					var data_key=$(this).attr('data-key');
					self.update_height_outter(id);
					/*var h=$("#"+id).find(self.options.ul_button).outerHeight();
					var th=$("#"+id).height();
					var rh=th-h;
					$("#"+id).find(self.options.element_inner).height(rh);
					$("#"+id).find(self.options.element_inner).find(".my_shortcode_"+data_key).height(rh);
					$("#"+id).find(self.options.element_inner).find(".my_shortcode_"+data_key).mCustomScrollbar();
					*/
			    }
			});
			$("#"+id).disableSelection();
			$("#"+id).draggable({
				stop:function(event,ui){
					var id=$(this).attr('id');
					var pos=ui.position;
					var off=ui.offset;
					var unit=self.objects[id].box.unit;
					self.my_disable_change=true;
					var off1=$(self.options.editor_class).offset();
					var pos1=$(self.options.editor_class).position();
					var uw,uh;
					uw=pos.top;uh=pos.left;
					self.my_debug("Drag",{id:id,pos:pos,off:off,off1:off1,pos1:pos1});
					uw=pos.top;
					uh=pos.left;
					if(unit=='%'){
						uw=pos.top/pos1.top;
						uw=Math.round(uw*100)/100;
						 uh=pos.left/pos1.left;
						uh=Math.round(uh*100)/100;
					}
					self.objects[id].box.top=uw;
					self.objects[id].box.left=uh;
					self.objects[id].box.right='';
					self.objects[id].box.bottom='';
					
					
					$("#top_box_id").val(uw);
					$("#left_box_id").val(uh);
					$("#bottom_box_id").val('');
					$("#right_box_id").val('');
					$("#"+id).css('bottom','');
					$("#"+id).css('right','');
					
				}
			});
		};
		this.adjust_element=function(id,data_key,my_top,my_diff){
			/*if(data_key=='html' || data_key=='text'){
				//$(self.options.editor_class).find("#"+id).width(w1);
				var h=$("#"+id).find(self.options.ul_button).outerHeight();
				var th=$("#"+id).height();
				var rh=th-h;
				$("#"+id).find(self.options.element_inner).height(rh);
				$("#"+id).find(self.options.element_inner).find(".my_shortcode_"+data_key).height(rh);
				$("#"+id).find(self.options.element_inner).find(".my_shortcode_"+data_key).mCustomScrollbar();
			}
			var w=$(self.options.editor_class).width();
			var w1=w-my_diff*2;
			self.my_debug('w',w);
			self.my_debug('w',w1);
			$(self.options.editor_class).find("#"+id).width(w1);
			$(self.options.editor_class).find("#"+id).css({top:my_top+'px',left:my_diff+'px'}).animate({opacity:1});
			*/
			self.my_debug("Added element",{id:id,key:data_key});
			self.added_element(id,data_key);
			var o={};
			o.box={};
			o.box.width='';
			o.box.top='';
			o.box.left='';
			self.my_edit_id=id;
			self.my_edit_key=data_key;
			self.update_box_model(o.box);
			o.id=id;
			o.key=data_key;
			o.options={};
			self.objects[id]=o;
			$(self.options.editor_class).find(self.options.outter_class).removeClass("my_selected_el");
			$(self.options.editor_class).find("#"+id).addClass("my_selected_el");
			//self.my_top=$("#"+id).height()+10;
			
		};
		this.update_height_outter=function(id){
			var data_key=$("#"+id).data('key');
			self.my_debug("Update height",{id:id,data_key:data_key});
			if(data_key=='html' || data_key=='text'){
				//$(self.options.editor_class).find("#"+id).width(w1);
				var h=$("#"+id).find(self.options.ul_button).outerHeight();
				var th=$("#"+id).height();
				var rh=th-h;
				var padd=$("#"+id).find(self.options.shortcode_content+" >div").css('padding-top');
				if(typeof padd=='undefined'){
					padd=0;
				}
				else padd=parseInt(padd);
				rh-=padd*2;
				var mar=$("#"+id).find(self.options.shortcode_content).css('margin-top');
				if(typeof mar=='undefined'){
					mar=0;
				}
				else mar=parseInt(mar);
				rh-=mar*2;
				self.my_debug("Update height",{h:h,th:th,padd:padd,mar:mar,rh:rh});
				
				$("#"+id).find(self.options.element_inner).height((rh+2*padd));
				
				$("#"+id).find(self.options.element_inner).find(".my_shortcode_"+data_key).height(rh);
				//$("#"+id).find(self.options.element_inner).find(".my_shortcode_"+data_key).mCustomScrollbar();
			}
		}
		this.change_box_model=function(obj){
			if(self.my_disable_change){
				self.my_debug("Disable change");
				return;
			}
			var name=obj.name;
			var id=self.my_edit_id;
			var object;
			var type='o';
			if(self.my_add_id!=''){
				id=self.my_add_id;
				object=self.my_add_object;
				type='row';
			}else {
				object=self.objects[object_id];
			}
			if(name=='unit'){
				//depreced
				var unit=$("input[name='unit_box']:checked").val();
				self.my_debug('Chang unit',unit);
				$("#my_form_box input[type='text']").trigger('change');
				self.objects[id].box.unit=unit;
				return;
			}
		
			
			//var unit=obj.unit;//$("input[name='unit_box']:checked").val();
			//self.my_debug('Unit',unit);
			var val=obj.val;
			/*
			if(val==''){
				object.box[name]=val;
				
				return;
			}
			if(val.indexOf('%')!==-1){
				unit='%';
				val=parseInt(val);
				self.my_debug('New Unit',{unit:unit,val:val});
				
			}else if(val.indexOf('px')!==-1){
				unit='px';
				val=parseInt(val);
				//self.my_debug('New Unit',unit);
				self.my_debug('New Unit',{unit:unit,val:val});
			}
			if(unit=='%'){
				if(name=='height'){
					if(parseInt(val)>100){
						val=90;
					
					$("input[name='"+obj.full_name+"']").val(val);
					}
				}
				if(name=='top'){
					if(parseInt(val)>100){
						val=5;
					
					$("input[name='"+obj.full_name+"']").val(val);
					}
				}
				if(name=='width'){
					if(parseInt(val)>100){
						val=90;
					
					$("input[name='"+obj.full_name+"']").val(val);
					}
				}
				if(name=='left'){
					if(parseInt(val)>100){
						val=5;
					
					$("input[name='"+obj.full_name+"']").val(val);
					}
				}
				if(name=='right'){
					if(parseInt(val)>100){
						val=5;
					
					$("input[name='"+obj.full_name+"']").val(val);
					}
				}
				if(name=='bottom'){
					if(parseInt(val)>100){
						val=95;
					
					$("input[name='"+obj.full_name+"']").val(val);
					}
				}
				
			}
			if(name=='padding' || name=="margin"){
				unit='px';
			}
			var t=val+unit;
			*/
			var t=val;
			self.my_debug('Chgange box model',{name:name,val:val,id:id});
			object.box[name]=val;
			//self.objects[id].box.unit=unit;
			if(name=='top'){
				
			}
			if((name.indexOf('margin')!==-1) || (name.indexOf('padding')!==-1)){
				if(type=='row'){
					var w1=$("#"+id).width();
					self.my_debug("Width",w1);
					w1-=parseInt(val)*2;
					
				}else {
				var w1=$("#"+id).find(self.options.shortcode_content).width();
				self.my_debug("Width",w1);
				w1-=parseInt(val)*2;
				if(name=='margin'){
					$("#"+id).find(self.options.shortcode_content).width(w1);
				}else {
					//var h=$("#"+id).height();
					
				}
				}
				/*
				var w=$("#"+id).width();
				var h=$("#"+id).height();
				w+=parseInt(val)*2;
				h+=parseInt(val)*2;
				$("#"+id).width(w);
				$("#"+id).height(h);
				*/
				if(name=='padding'){
					$("#"+id+" "+self.options.shortcode_content+" >div").css(name,t);
				}
				else $("#"+id+" "+self.options.shortcode_content+" ").css(name,t);
			}
			else $("#"+id).css(name,t);
			/*if(name=='margin' || name=='padding' || name=="height" || name=="width"){
				self.update_height_outter(id);
			}*/
		};
		this.update_box_model=function(obj){
			self.my_disable_change=true;
			self.my_debug("Upddate option form",obj);
			$.each(obj,function(i,v){
				var id=i+'_box_id';
				$("#"+id).val(v);
			});
			$("#unit_box_0").trigger('click');
			self.my_disable_change=false;
			
		};
		this.my_clone_object=function(key,obj){
			var u=key.charAt(0).toUpperCase();
			var k=u+key.substr(1);
			var c='myVusualBuilderShortcodes'+k+'_inst';
			self.my_debug('Shortcode class',c);
			if(typeof window[c]!='undefined'){
				var tmpl=window[c].my_clone_object(obj);
				return tmpl;
			}else {
				self.my_debug('not defined',c);
			}
		};
		this.my_show=function(key,obj){
			var u=key.charAt(0).toUpperCase();
			var k=u+key.substr(1);
			var c='myVusualBuilderShortcodes'+k+'_inst';
			self.my_debug('Shortcode class',c);
			if(typeof window[c]!='undefined'){
				var tmpl=window[c].my_show(obj);
				return tmpl;
			}else {
				self.my_debug('not defined',c);
			}
				
		};
		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log('Visual builder Main \n'+t,o);
				}
			}
		};
		this.init();
		
};
})(jQuery);		

	