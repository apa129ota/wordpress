<?php
if(!defined('ABSPATH'))die('');
$arr=array(
	/*'cols'=>array(
			'title'=>__("Columns","my_support_theme"),
			'tooltip'=>__("Add columns to design","my_support_theme"),
			'icon'=>'fa-columns'
	),*/
	'row'=>array(
			'group'=>'',
			'title'=>__("Layouts","my_support_theme"),
			'tooltip'=>__("Add Layouts","my_support_theme"),
			'icon'=>'fa-align-left'
	),
	'html'=>array(
		'group'=>'basic',	
		'title'=>__("Html","my_support_theme"),
		'tooltip'=>__("Add html text","my_support_theme"),
		'icon'=>'fa-align-left'		
	),
	'select'=>array(
		'group'=>'',	
		'title'=>__("Select Shortcode","my_support_theme"),
		'tooltip'=>__("Select Shortcode","my_support_theme"),
		'icon'=>'fa-code'
		
	)	
	/*'text'=>array(
				'title'=>__("Text","my_support_theme"),
				'tooltip'=>__("Add new text","my_support_theme"),
				'icon'=>'fa-file-text-o'
		),
	'template'=>array(
			'title'=>__("Template","my_support_theme"),
			'tooltip'=>__("Choose new template","my_support_theme"),
			'icon'=>'fa-desktop'
	)*/	
);
return $arr;
