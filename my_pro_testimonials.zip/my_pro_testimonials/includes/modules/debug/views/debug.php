<?php
if(!defined('ABSPATH'))die('');
$debug=Class_My_Module_Debug::get_debug();
?>
<div class="my_module_debug" data-open="0">
	<div class="my_module_debug_header" >
		<h4><i class="fa fa-plus"></i><i class="fa fa-minus" style="display:none"></i> &nbsp;&nbsp;<?php echo __("Debug Info","my_support_theme")?></h4>
	</div>
	<div class="my_module_debug_inner">
		<ul class="my_debug_module_level_<?php echo '1'?>" data-i="1">
			<?php 
			foreach($debug as $key=>$val){
				?>
				<li class="my_debug_ul_li_tree" data-key="<?php echo $key;?>" data-i="0" data-open="0">
					<i class="fa fa-plus"></i><i class="fa fa-minus" style="display:none"></i>&nbsp;&nbsp;<?php echo $key?>
					<?php echo my_module_debug_render_val($val,1,$key);?>
				</li>
				<?php 
			}
			?>
		</ul>
	</div>
</div>
<?php 