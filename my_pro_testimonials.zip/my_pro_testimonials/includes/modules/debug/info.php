<?php
if(!defined('ABSPATH'))die('');
$info=array(
	'title'=>'Debug Module',
	'description'=>'Module helps to debug code excution',
	'class'=>'Class_My_Module_Debug'		
);
return $info;