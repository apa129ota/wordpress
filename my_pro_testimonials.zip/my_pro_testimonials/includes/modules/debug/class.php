<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Module_Debug')){
	class Class_My_Module_Debug {
		static $is_ajax=false;
		static $debug;
		static $url;
		static $debug_footer=true;
		static $dir;
		static $tmp_debug;
		static $debug_fp;
		static $save=false;
		static function init($save=false){
			self::$save=$save;
			Class_My_Module_Debug::$url=plugin_dir_url(__FILE__);
			self::$dir=plugin_dir_path(__FILE__);
			if(Class_My_Module_Debug::$debug_footer){
				$file=self::$dir.'includes/functions.php';
				require_once $file;
				if(is_admin()){
					add_action ( 'admin_enqueue_scripts', array ('Class_My_Module_Debug','admin_scripts'),PHP_INT_MAX );
					add_action('admin_footer',array('Class_My_Module_Debug','admin_footer'),PHP_INT_MAX);
				}else {
					//add_action ( 'admin_head', array (&$this,'admin_head') );
					add_action ( 'wp_enqueue_scripts', array ('Class_My_Module_Debug','admin_scripts'),PHP_INT_MAX);
					add_action('wp_footer',array('Class_My_Module_Debug','admin_footer'),PHP_INT_MAX);
				}
				
			}
		}
		static function debug_file($key,$title,$var){
			if(!isset(self::$debug_fp[$key])){
				$file=self::$tmp_debug.$key.'.tmp';
				self::$debug_fp[$key]=fopen($file,'w');
			}
			$fp=self::$debug_fp[$key];
			ob_start();
			echo $title;
			var_dump($var);
			$h=ob_get_clean();
			fwrite($fp,$h);
		}
		static function debug_file_1($key,$title,$var){
			if(!isset(self::$debug_fp[$key])){
				$file=self::$tmp_debug.$key.'.tmp';
				self::$debug_fp[$key]=fopen($file,'w');
			}
			$fp=self::$debug_fp[$key];
			ob_start();
			//echo $title;
			//var_dump($var);
			echo maybe_serialize($var);
			$h=ob_get_clean();
			fwrite($fp,$h);
		}
		static function debug_file_close($key){
			$fp=self::$debug_fp[$key];
			fclose($fp);
		}
		static function admin_scripts(){
			$assets_url=Class_My_Module_Debug::$url.'assets/';
			wp_enqueue_style('wp_my_module_debug_css',$assets_url.'debug.css');
			wp_enqueue_script('wp_my_module_debug_js',$assets_url.'jscript.js');
		}
		static function admin_footer(){
			$dir=self::$dir.'views/debug.php';
			require $dir;
			if(self::$save){
				$key='Debug_'.date('Y_m_d_h_i_s');
				self::debug_file_1($key, __("Backend debug","my_support_theme"), self::$debug);
				self::debug_file_close($key);
			}
		}
		static function add_section($key,$values,$source='plugin',$is_array=true){
			if(!isset(Class_My_Module_Debug::$debug[$source])){
				Class_My_Module_Debug::$debug[$source]=array();
			}
			if(!isset(Class_My_Module_Debug::$debug[$source][$key])){
				if($is_array){
					Class_My_Module_Debug::$debug[$source][$key]=array();
				}	
			}
			if($is_array){
				Class_My_Module_Debug::$debug[$source][$key][]=$values;
			}else {
				Class_My_Module_Debug::$debug[$source][$key]=$values;
			}
		}
		static function get_debug_source($source){
			if(isset(Class_My_Module_Debug::$debug[$source])){
				return Class_My_Module_Debug::$debug[$source];
			}else return 0;
		}	
		static function get_debug_source_key($source,$key){
			if(isset(Class_My_Module_Debug::$debug[$source])){
				if(isset(Class_My_Module_Debug::$debug[$source][$key])){
					return Class_My_Module_Debug::$debug[$source][$key];
				}else return 0;
			}else return 0;
		}
		static function get_debug(){
			if ( defined( 'SAVEQUERIES' ) && SAVEQUERIES ) {
				global $wpdb;
				Class_My_Module_Debug::$debug['wpdb_queries']=$wpdb->queries;
			}
				return Class_My_Module_Debug::$debug;
			
		}
	}
}
