jQuery(document).ready(function($){
	my_module_debug_adjust_height=function(){
		var h=window.innerHeight;
		var h1=$(".my_module_debug_header").outerHeight();
		var h_i=h-h1;
		var padd=$(".my_module_debug_inner").css('padding-top');
		h_i-=2*parseInt(padd);
		if(window.console){
			console.log("Height",{h:h,h1:h1,h_i:h_i,padd:padd});
		}
		$(".my_module_debug").find(".my_module_debug_inner").height(h_i);
	};
	my_module_debug_debug=function(msg,o){
		if(window.console){
			console.log(msg,o);
		}
		
	}
	$(".my_module_debug_inner li.my_debug_ul_li_tree").each(function(i,v){
		if($(v).children('ul').length==0){
			$(v).children('.fa-plus ,  .fa-minus').hide();
			$(v).children(".fa-minus").after('<i class="fa fa-caret-down"></i>');
		}
	})
	$(document).on('click',".my_module_debug_inner li.my_debug_ul_li_tree",function(e){
		if($(this).children(".fa-caret-down").length>0)return;
		if(!$(this).is(":visible"))return;
		e.stopPropagation();
		var level=$(this).parent("ul").attr('data-i');
		var level=parseInt(level);
		var is=$(this).attr('data-open');
		level++;
		var set=0;
		if(is==0)set=1;
		if(window.console){
			console.log('Set',{set:set,is:is,levele:level});
		}
		if(set==1){
			$(this).children(".fa-plus").hide();
			$(this).children(".fa-minus").show();
		}else {
			$(this).children(".fa-minus").hide();
			$(this).children(".fa-plus").show();

		}
		$(this).attr('data-open',set);
		$(this).children("ul").slideToggle();
		
	});
	$(document).on('click',".my_module_debug_header",function(e){
		var is=$(this).parents(".my_module_debug").attr('data-open');
		var set=0;
		if(is==0)set=1;
		my_module_debug_adjust_height();
	
		if(window.console){
			console.log('Set',{set:set,is:is});
		}
		if(set==1){
			$(this).parents(".my_module_debug").find(".my_module_debug_header .fa-plus").hide();
			$(this).parents(".my_module_debug").find(".my_module_debug_header .fa-minus").show();
		}else {
			$(this).parents(".my_module_debug").find(".my_module_debug_header .fa-minus").hide();
			$(this).parents(".my_module_debug").find(".my_module_debug_header .fa-plus").show();

		}
		$(this).parents(".my_module_debug").attr('data-open',set);
		$(this).parents(".my_module_debug").find(".my_module_debug_inner").slideToggle();
		
		
	});
	
	$(window).resize(function(e){
		my_module_debug_adjust_height();
	});
});