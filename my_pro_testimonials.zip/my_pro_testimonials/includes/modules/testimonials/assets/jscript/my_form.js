(function($) {
	wpMyModuleTestimonialsForm=function(o){
		var self;
		this.debug=true;
		this.options={};
		self=this;
		this.init=function(o){
			if(typeof o.my_debug!='undefined'){
				if(!o.my_debug){
					self.debug=false;
				}
			}
			//self.debug=true;
			self.options=o;
			self.my_debug("Options",o);
			$(window).load(function(e){
			var o1={};
			o1.data={
					action:self.options.ajax_action,
					my_action:'test_cookie'
			};
			o1.success=function(data){
				if(data.error==1){
					$(".my_testimonials_msgs").html(data.html);
				}
			};
			myGlobalAjaxClass_inst.call_ajax(o1,'');
			});
			$(document).on('click',".my_add_testimonial",self.add_test);
		};
		this.add_test=function(e){
			e.preventDefault();
			var o1={};
			self.form_object=$(this).parents('form');
			var form_data=$(this).parents('form').serialize();
			o1.show_msg=1;
			o1.data={
					action:self.options.ajax_action,
					my_action:'add_testimonial',
					form_data:form_data
			};
			o1.success=function(data){
				self.my_debug("Front data",data);
				if(data.error==0){
					$(self.form_object)[0].reset();
					$form_id=$(self.form_object).attr('id');
					$captcha_name=$(self.form_object).find(".recaptcha_div").data('name');
					$captcha_elem=$(self.form_object).find(".recaptcha_div");
					self.my_debug('Captcha name',$captcha_name);
					if(typeof $captcha_name!='undefined'){
						wpMyModuleNewFormRecaptcha_inst.resetCaptcha($captcha_name);
					}
					wpMyModuleValidateScript_inst.remove_all_errors($form_id);
				}else {
					$form_id=$(self.form_object).attr('id');
					self.my_debug("form id",$form_id);
					$captcha_name=$(self.form_object).find(".recaptcha_div").data('name');
					$captcha_elem=$(self.form_object).find(".recaptcha_div");
					if(typeof $captcha_name!='undefined'){
						wpMyModuleNewFormRecaptcha_inst.resetCaptcha($captcha_name);
					}
					wpMyModuleValidateScript_inst.remove_all_errors();
					if(typeof data.errors!='undefined'){
						
						wpMyModuleValidateScript_inst.show_errors($form_id,data.errors);
					}
				}
				/*if(data.error==1){
					$(self.form_object).find(".my_form_msgs").html(data.html);
				}*/
			};
			myGlobalAjaxClass_inst.call_ajax(o1,self.options.msgs.adding_testimonial);
		};
		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log("***Testimonials form script *** \n"+t,o);
				}
			}
		};
	this.init(o);
	
};
})(jQuery);			