<?php
if(!defined('ABSPATH'))die('');
function my_register_foo_widget() {
	register_widget( 'My_Testimonials_Widget' );
}
add_action( 'widgets_init', 'my_register_foo_widget' );
class My_Testimonials_Widget extends WP_Widget {

	/**
	 * Sets up the widgets name etc
	 */
	public function __construct() {
		$widget_ops = array(
				'classname' => 'my_testimonials_widget',
				'description' => 'Widget for displaying testimonials',
		);
		parent::__construct( 'my_testimonials_widget', 'My Testimonials Widget', $widget_ops );
	}

	/**
	 * Outputs the content of the widget
	 *
	 * @param array $args
	 * @param array $instance
	 */
	public function widget( $args, $instance ) {
		// outputs the content of the widget
		$title = apply_filters( 'widget_title', empty( $instance['title'] ) ? __( 'Testimonials',"my_support_theme" ) : $instance['title'], $instance, $this->id_base );
		global $Class_My_Framework_Main_Class;
		//print_r($instance);
		if(!empty($instance['shortcode'])){
			ob_start();
			echo do_shortcode('[my_testimonial id="'.$instance['shortcode'].'"]');
				$html=ob_get_clean();	
		}else $html='';
		//if(!empty($html)){
			echo $args['before_widget'];
			if ( $title ) {
				echo $args['before_title'] . $title . $args['after_title'];
			}
			echo $html;
			echo $args['after_widget'];
		//}
					
		
	}

	/**
	 * Outputs the options form on admin
	 *
	 * @param array $instance The widget options
	 */
	public function form( $instance ) {
		// outputs the options form on admin
		global $Class_My_Framework_Main_Class;
		$shortcodes=$Class_My_Framework_Main_Class->events->getShortcodes();
		$instance = wp_parse_args( (array) $instance, array('title' => '', 'shortcode' => '') );
		if(!empty($instance['title']))$title=$instance['title'];
		if(!empty($instance['shortcode']))$sh=$instance['shortcode'];
		?>
				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php __( 'Title:',"my_support_theme" ); ?></label>
					<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('title') ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>" />
				</p>
				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'shortcode' ) ); ?>"><?php __( 'Shortcode',"my_support_theme" ); ?></label>
					<select name="<?php echo $this->get_field_name('shortcode')?>" id="<?php echo $this->get_field_id('shortcode')?>">
						<option value=""><?php echo __("Select shortcode","my_support_theme")?></option>
						<?php if(!empty($shortcodes)){
							foreach($shortcodes as $k=>$v){
								?>
						<option <?php  if(isset($sh)&&$sh==$v->ID) echo 'selected="selected"';?> value="<?php echo $v->ID?>"><?php echo $v->title;?></option>		
								<?php 	
							}
						}?>
					</select>
				</p>
		<?php 		
	}

	/**
	 * Processing widget options on save
	 *
	 * @param array $new_instance The new options
	 * @param array $old_instance The previous options
	 */
	public function update( $new_instance, $old_instance ) {
		// processes widget options to be saved
		$instance = $old_instance;
		$instance['title'] = sanitize_text_field( $new_instance['title'] );
		$instance['shortcode'] = $new_instance['shortcode'];

return $instance;
	}
}