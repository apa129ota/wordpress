<?php
if(!defined('ABSPATH'))die('');
wp_my_general_load_module(MY_TESTIMONIALS_LOCAL_MODULES_DIRNAME, 'tableview');
wp_my_general_load_module_class(MY_TESTIMONIALS_LOCAL_MODULES_DIRNAME, 'tableview', 'class-view.php');
if(!class_exists('Class_Wp_My_Testimonials_View_Class')){
	class Class_Wp_My_Testimonials_View_Class extends Class_Wp_My_Module_Table_View_View_Class{
		
		function __construct($options=array()){
			parent::__construct($options);
			
			
		}

		
		
	}
}