<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Module_Testimonials_Image_Upload')){
	class Class_My_Module_Testimonials_Image_Upload{
		protected $debug;
		protected $use_case='my_framework';
		use MyDebug,MyArrayOptions,MyFiles;
		function __construct($options=array()){
			$this->setOptions($options);
			if($this->debug){
				$this->setDebugOptions($this->use_case);
			}
		}
	}
}