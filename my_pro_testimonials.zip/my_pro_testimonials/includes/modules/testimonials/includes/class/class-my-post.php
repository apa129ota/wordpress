<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Module_Testimonials_Post_Type')){
	class Class_My_Module_Testimonials_Post_Type{
		use MyDebug,MyArrayOptions,MySessions;
		private $dir;
		private $url;
		private $post_type;
		private $post_terms;
		private $debug;
		private $use_case;
		private $post_columns;
		public $module_class;
		public $global_plugin;
		private $options_form;
		private $metabox_html='';
		private $is_metabox=false;
		private $meta_prefix='_my_testimonials_1_';
		private $form_prefix='my_test_metabox';
		private $form_shortcode='';
		private $is_form=false;
		private $ajax_action='my_testimonials_add_front';
		private $my_form_id=1;
		function __construct($options=array()){
			$this->setOptions($options);
			
			if($this->debug){
				$this->setDebugOptions($this->use_case);
			}
			$this->startSessionFront(false);
			
		}
		private function startSessionFront($force){
			if(!is_admin() || $force){
				$this->test_cookie_name='my_testimonials_form';
				//$this->name='my_testimonials';
				$this->setSessionName('my_testimonials');
				self::debug("session_name_1", $this->session_name,false);
				$this->startSession();
			}
		}
		public function init(){
			$this->options_form=$this->module_class->loadOptions('form.php');
			if(is_admin()){
			add_action('save_post',array(&$this,'save_metadata'));
			add_action('admin_head', array($this,'wp_head'),PHP_INT_MAX);
			add_action('admin_enqueue_scripts',array($this,'scripts'),PHP_INT_MAX);
			
			add_action('init',array(&$this,'render_form'));
			//$this->render_form();
			add_action( 'add_meta_boxes', array(&$this,'add_metaboxes'), 10, 2 );
				
			add_filter('manage_edit-'.$this->post_type.'_columns',array(&$this,'post_columns'));
			add_action( 'manage_'.$this->post_type.'_posts_custom_column' , array(&$this,'custom_post_column'), 10, 2 );
			global $pagenow;
			if($pagenow=='edit.php'){
				$my_p_t=@$_GET['post_type'];
				if(!empty($my_p_t)&&$my_p_t==$this->post_type){
					add_action('restrict_manage_posts',array(&$this,'my_restrict_manage_posts'));
					add_filter('posts_join',array(&$this,'my_posts_join'));
					add_filter('posts_where',array(&$this,'my_posts_where'));
				}
			}
			}
			add_action('wp_head', array($this,'form_head'),PHP_INT_MAX);
			add_action('wp_enqueue_scripts',array($this,'form_scripts'),PHP_INT_MAX);
			add_shortcode($this->form_shortcode,array(&$this,'form_shortcode'));
			//add_action('init',array(&$this,'render_shortcode_form'));
			add_action('wp',array(&$this,'is_form_page'),10);
			add_action('wp_ajax_nopriv_'.$this->ajax_action,array($this,'ajax_form'));
			add_action('wp_ajax_'.$this->ajax_action,array($this,'ajax_form'));
			
		}
		public function ajax_form_validate($form_data){
			$this->global_plugin->loadModuleFile("new_form","class_validate.php","includes/class/");
			$msgs1=$this->module_class->loadOptions("msgs.php");
			$msgs=$msgs1['form_validate'];
			self::debug("form_data", $form_data,false);
			$options=array(
				'debug'=>$this->debug,
				'msgs'=>$msgs,
				'elements'=>$this->options_form,
				'data'=>$form_data	
			);
			$class=new Class_Wp_My_Module_New_Form_Validate($options);
			$error=$class->validate();
			self::debug("error_form", $error,false);
			if($error!==true){
				return $error;
			}else {
				
				return true;
			}
		}
		public function ajax_form(){
			$this->startSessionFront(true);
			$this->setTestCookie();
			$this->global_plugin->loadController("class-my-general-controller.php");
			$ajax_options=$this->module_class->loadOptions("ajax-actions.php");
			$this_options=$ajax_options['front'];
			$this_options['module_class']=$this;
			$this_options['plugin_object']=$this->global_plugin;
			$this_options['nonce_str']=$this->module_class->get_ajax_nonce_str($this->ajax_action);
			
			self::debug("ajax_options", $this_options);
			self::debug("session",$_SESSION,false);
			self::debug("session_name", $this->session_name,false);
			$this->module_class->routeAjax($this_options);
		}
		public function form_scripts(){
			if($this->is_form){
				wp_enqueue_script("jquery");
				$url=$this->global_plugin->getUrl('jscript').'admin/my_ajax.js';
				wp_enqueue_script('my_framework_ajax',$url);
				$url=$this->global_plugin->getUrl('jscript').'admin/admin_msgs.js';
				wp_enqueue_script("my_framework_msgs",$url);
				$url=$this->module_class->getUrl('css').'form.css';
				
				wp_enqueue_style("my_testimonials_module_form",$url);
				$url=$this->global_plugin->getUrl('css').'msgs.css';
				wp_enqueue_style("my_testimonials_msgs_form",$url);
				
				
				$url=$this->module_class->getUrl('jscript').'my_form.js';
				wp_enqueue_script("my_framework_module_testimonials_form_js",$url);
			}
		}
		public function form_head(){
			if($this->is_form){
				$options=$this->global_plugin->loadOptions("ajax_options.php");
				$msgs=$this->module_class->loadOptions("msgs.php");
				$my_set_debug=0;
				if($this->debug){
					$options['my_debug']=1;
					$my_set_debug=1;
				}
				?>
							<script type="text/javascript">
								jQuery(document).ready(function($){
										var o=<?php echo json_encode($options);?>;
										//my_msg_addding_testimonial="<?php echo esc_attr(__("Saving testimonial","my_support_theme"));?>";
										//my_msg_addding_testimonial_ajax_action="<?php echo $this->ajax_action?>";
										myGlobalAjaxClass_inst=new myGlobalAjaxClass(o);
										var o1={};
										myAdminMsgs_inst=new myAdminMsgs(o1);
										var o2={};
										o2.ajax_action="<?php echo $this->ajax_action;?>";
										o2.msgs=<?php echo json_encode($msgs);?>;
										o2.my_debug=<?php echo $my_set_debug;?>;
										wpMyModuleTestimonialsForm_inst=new wpMyModuleTestimonialsForm(o2);
									});
								
							</script>
			<?php 				
			}
		}
		private function format_email($form_data,$msg,$saved=true){
			global $my_testimonials_shortcodes;
			$options=array(
				'site_url'=>get_site_url(),
				'post_url'=>'',
				'post_title'=>$form_data['name'],
				'stars'=>$form_data['stars'],
				'post_text'=>$form_data['text'],
				'post_category'=>'',
				'user_name'=>$form_data['name'],
				'user_position'=>$form_data['position'],
				'user_email'=>$form_data['email'],
				'url'=>$form_data['company_url']	
			);
			/*if(isset($form_data['term_id'])){
				$options['post_category']=$form_data['term'];//=name;
			}*/
			if($saved){
				$post_id=$form_data['post_id'];
				ob_start();
				edit_post_link(__('Edit','my_support_theme'),'','',$post_id);
				$url=ob_get_clean();
				$options['post_url']=$url;
				if(!empty($form_data['term_id'])){
					
					$term=get_term($form_data['term_id'],$this->post_terms);
					if ( is_wp_error( $term) ) {
					
					}
					else
					$options['post_category']=$term->name;
				}
			}else {
				if(!empty($form_data['term_id'])){
					$term=get_term($form_data['term_id'],$this->post_terms);
					if ( is_wp_error( $term) ) {
						
					}
					else $options['post_category']=$term->name;
				}
			}
			foreach($options as $key=>$val){
				$msg=str_replace('{'.$key.'}', $val, $msg);
			}
			return $msg;

		}
		public function front_save($form_data){
			$my_save=true;
			$not_save=$this->global_plugin->options->getOptionByKey('not_save');
			$notify_email=$this->global_plugin->options->getOptionByKey('notify_email');
			$metadata=array();
			$metadata1=array();
			
			if(isset($form_data['my_category'])){
				$cat_id=$form_data['my_category'];
					$metadata1['term_id']=$form_data['my_category'];
					$metadata1['term']=get_term($cat_id,$this->post_terms);
				}
			$this->global_plugin->loadModuleFile('new_form','functions.php','includes');
			foreach($this->options_form as $key1=>$val1){
				//if(isset($val['front']))continue;
				
				if(in_array($key1,array('captcha','button','thumb','text')))continue;
				$name=my_new_form_module_clean_key($key1).'_'.$this->form_prefix;
				$val=@$form_data[$name];
				$post_meta_key=$this->meta_prefix.'_'.$key1;
				$metadata[$post_meta_key]=$val;
				$metadata1[$key1]=wp_strip_all_tags($val);
			}
			$metadata1['text']=wp_strip_all_tags($form_data['text_'.$this->form_prefix]);
			self::debug("metadata1", $metadata1,false);
			if($not_save=='save_all'){
			}else {
				$stars=$metadata1['stars'];
				if($stars<$not_save){
					$my_save=false;
					$msg=$recaptcha=$this->global_plugin->options->getOptionByKey('notify_msg_not');
					$msg=$this->format_email($metadata1, $msg,$my_save);
					self::debugFile('msg_not_saved', 'Message not saved', $msg,false);
					self::debugFileClose('msg_not_saved');
					$my_file=$this->getSessionVar('my_file');
					$dir=$this->global_plugin->getDir('tmp').'uploads/';
					$my_file_full=$dir.$my_file;
					if(file_exists($my_file_full)){
						unlink($my_file_full);
					}
					self::debug("msg_not_save",$msg,false);
					wp_mail($notify_email, __("Testimonial not accepted","my_support_theme"), $msg);
				}
			}
			if($my_save){
			$post_arr=array(
				'post_title'=>$metadata1['name'],
				'post_content'=>$metadata1['text'],
				'post_type'=>$this->post_type,
				'post_status'=>'draft'	
			);
			self::debug("postarr", $post_arr,false);
				$post_id=wp_insert_post($post_arr);
				$metadata1['post_id']=$post_id;
				self::debug("post_id", $post_id,false);
				$my_file=$this->getSessionVar('my_file');
				$dir=$this->global_plugin->getUrl('plugin').'tmp/uploads/';
				$dir1=$this->global_plugin->getDir('tmp').'uploads/';
				$my_file_full_url=$dir.$my_file;
				$my_file_full_dir=$dir1.$my_file;
				$src=media_sideload_image($my_file_full_url,$post_id,'','src');
				$thumb_id=wp_my_get_attachment_id_form_url($src);
				set_post_thumbnail($post_id, $thumb_id);
				self::debug('thumb_src', $src,false);
				self::debug("thumb_id", $thumb_id,false);
				if(file_exists($my_file_full_dir)){
					unlink($my_file_full_dir);
				}
				foreach($metadata as $key=>$val){
					update_post_meta($post_id, $key, $val);
				}
				if(isset($form_data['my_category'])){
					$cat_id=$form_data['my_category'];
					wp_set_post_terms($post_id,$cat_id,$this->post_terms);
				}
				$metadata1['post_id']=$post_id;
				$msg=$this->global_plugin->options->getOptionByKey('notify_msg');
				$msg=$this->format_email($metadata1, $msg,$my_save);
				self::debugFile('msg_saved', 'Message saved', $msg);
				self::debugFileClose('msg_saved');
				self::debug("msg_save",$msg,false);
				wp_mail($notify_email, __("New testimonial","my_support_theme"), $msg);
			}
		}
		public function form_shortcode($attrs){
			extract($attrs);
			$html=$this->metabox_html;
			if(isset($cat)){
				$this->module_class->set_template_vars('cat',$cat);
				global $wp_query;
				$my_post_id=$wp_query->get_queried_object_id();
				$this->setSessionVariable('my_form_cat_'.$this->my_form_id, $cat);
					
			}
			$logged=$this->global_plugin->options->getOptionByKey('front_submit_not_logged');
			$this->module_class->set_template_vars('id',$this->form_prefix);
			$this->module_class->set_template_vars('logged',$logged);
			$this->module_class->set_template_vars('html',$html);
			$this->module_class->set_template_vars('form_prefix',$this->form_prefix);
			$this->module_class->set_template_vars('msg',__("This form uses cookies, and if your browser is not using cookies form will not work.","my_support_theme"));
			$this->module_class->set_template_vars('msg_logged',__("Not logged usesrs can't submit form, Please register or login to submit testimonial.","my_support_theme"));
			$this->module_class->set_template_vars("my_form_id",$this->my_form_id);
			$this->my_form_id++;	
			ob_start();
			$this->module_class->loadViewFile('form.php');
			$html=ob_get_clean();
			return $html;
					
			
		}
		public function is_form_page(){
			if(is_page()){
				global $wp_query;
				$post_id=$wp_query->get_queried_object_id();
				$my_post=get_post($post_id);
				$content=$my_post->post_content;
				if(preg_match('/\['.$this->form_shortcode.'[^]]*\]/ims', $content)){
					
					$this->is_form=true;
					$this->render_shortcode_form();
					self::debug("is_form_page", array(1,'html'=>$this->metabox_html));
					$this->setTestCookie();
					self::debug("session", $_SESSION,false);
				}
			}
		}
		public function render_shortcode_form(){
			$this->global_plugin->scripts_class->addIncludesObj('fontawesome');
			$my_nonce=$this->module_class->ajax_get_nonce($this->ajax_action);
			$this->options_form['thumb']['jscript']['multipart_params']=array(
				'my_nonce' => $my_nonce,
				'action'      => $this->ajax_action, // The AJAX action name
				'my_action'=>'add_thumb',
			);
			$recaptcha=$this->global_plugin->options->getOptionByKey('recaptcha');
			if(empty($recaptcha)){
				unset($this->options_form['captcha']);
			}else {
				$this->options_form['captcha']['module_dir']=$this->global_plugin->getDir('modules').'recaptcha/class.php';
				$this->options_form['captcha']['public_key']=$this->global_plugin->options->getOptionByKey('recaptcha_public_key');
			}
			self::debug("front_form", $this->options_form);
			ob_start();
			$options=array(
					'id'=>$this->form_prefix,
					'elements'=>$this->options_form,
					'hidden'=>array(
							'my_nonce'=>$this->module_class->ajax_get_nonce($this->ajax_action)
					),
					'element_template'=>'my_li_1.php',
					'form_template'=>'my_noform.php',
					'my_debug'=>$this->debug
			);
			//$file=$this->views_dir.'actions.php';
			$form_class=$this->global_plugin->instantiateModuleClass('new_form',$options);
				
			ob_start();
			?>
						<div class="my_metabox_form">	
							<div>
						<?php $form_class->render_form(); ?>
							</div>
						</div>
						<?php 
						$html=ob_get_clean();
						//return $html;
						$this->metabox_html=$html;
			
		}
		public function save_metadata($post_id){
			if(wp_is_post_revision($post_id)){
				return;
			}
			global $post;
			self::debugFile('save_post','Post',$post);
			
			//if($post->post_type==$this->post_type){
				$nonce=@$_POST['my_nonce_'.$this->form_prefix];
				
				$verify=$this->module_class->ajax_check_nonce($nonce,'my_add_testimonial');
				if(!$verify){
					self::debugFile('save_post','Nonce',array('nonce'=>$nonce,'verify'=>$verify));
					self::debugFileClose('save_post');
					return;
				}else {
					$this->global_plugin->loadModuleFile('new_form','functions.php','includes');
					$metadata=array();
					
					foreach($this->options_form as $key=>$val){
						if(isset($val['front']))continue;
						$name=my_new_form_module_clean_key($key).'_'.$this->form_prefix;
						$val=@$_POST[$name];
						$post_meta_key=$this->meta_prefix.'_'.$key;
						$metadata[$post_meta_key]=$val;
					}
					foreach($metadata as $key=>$val){
						update_post_meta($post_id, $key, $val);
					}
					self::debugFile('save_post','Metadata',array('nonce'=>$nonce,'verify'=>$verify,'metadata'=>$metadata));
					self::debugFileClose('save_post');
				//}
			}
			
		}
		private function get_post_meta($post_id,$key){
			$post_meta_key=$this->meta_prefix.'_'.$key;
			$val=get_post_meta($post_id,$post_meta_key,true);
			return $val;
		}
		private function populate_form($post_id){
			$this->global_plugin->loadModuleFile('new_form','functions.php','includes');
			foreach($this->options_form as $key=>$val){
				//$post_meta_key=$this->meta_prefix.'_'.$key;
				//$val=get_post_meta($post_id,$post_meta_key,true);
				$val=$this->get_post_meta($post_id, $key);
				$this->options_form[$key]['value']=$val;
			}
		}
		public function wp_head(){
			
		}
		public function scripts(){
			global $pagenow;
			if($pagenow=='edit.php'){
				$my_post=@$_GET['post_type'];
				if(!empty($my_post)){
					if($my_post==$this->post_type){
						$url=$this->module_class->getUrl('css').'admin.css';
						self::debug("edit_css", $url,false);
						wp_enqueue_style('my_testimnonials_module_testimonial_admin',$url);
					}
				}
			}	
		
			
		}
		public function add_metaboxes(){
			add_meta_box('my_testimonials', __("Metadata","my_support_theme"), array(&$this,'metabox'),$this->post_type,'normal','default');
				
		}
		public function render_form(){
			global $pagenow;
			$my_do=false;
			if($pagenow=='post-new.php'){
				if(!empty($_GET['post_type'])){
					$p=$_GET['post_type'];
					if($p==$this->post_type)$my_do=true;
				}
			}
			if($pagenow=='post.php'){
				//global $post;
				$my_post_id=@$_GET['post'];
				$my_post=get_post_type($my_post_id);
				self::debug("post_type", $my_post,false);
				if($my_post==$this->post_type){
					$my_do=true;
					$this->populate_form($my_post_id);
				}
			}
			if(!$my_do)return;	
			$this->is_metabox=true;
			$this->global_plugin->scripts_class->addIncludesObj('fontawesome');
			foreach($this->options_form as $key=>$val){
				if(isset($val['front'])){
					unset($this->options_form[$key]);
				}
			}
			ob_start();
			$options=array(
					'id'=>$this->form_prefix,
					'elements'=>$this->options_form,
					'hidden'=>array(
							'my_nonce'=>$this->module_class->ajax_get_nonce('my_add_testimonial')
					),
					'element_template'=>'my_li_1.php',
					'form_template'=>'my_noform.php',
					'my_debug'=>$this->debug
			);
			//$file=$this->views_dir.'actions.php';
			$form_class=$this->global_plugin->instantiateModuleClass('new_form',$options);
			
			ob_start();
			?>
			<div class="my_metabox_form">	
				<div>
			<?php $form_class->render_form(); ?>
				</div>
			</div>
			<?php 
			$html=ob_get_clean();
			//return $html;
			$this->metabox_html=$html;
		}
		public function metabox(){
			echo $this->metabox_html;
		}
		public function my_restrict_manage_posts(){
			$terms=get_terms($this->post_terms,array('hide_empty'=>0));
			if(!empty($terms)){
				$old_terms='';
				if(isset($_REQUEST['my_test_terms']))$old_terms=@$_REQUEST['my_test_terms'];
				?>
				<select name="my_test_terms">
					<option value="">----<?php echo __("Filter by categories","my_support_theme")?>----</option>
					<?php foreach($terms as $key=>$val){?>
					<option <?php if($old_terms==$val->term_id)echo 'selected="selected"'?> value="<?php echo $val->term_id?>"><?php echo $val->name;?></option>
					<?php }?>
					<?php ?>
				</select>
				<?php 
			}
			
		}
		public function my_posts_join($join){
			global $wpdb;
			//$wpdb->show_errors();
			$old_terms='';
			if(isset($_REQUEST['my_test_terms']))$old_terms=@$_REQUEST['my_test_terms'];
			if(!empty($old_terms)){
				$join.=" LEFT join ".$wpdb->term_relationships." AS my_t ON ID=my_t.object_id";
			}
			return $join;
		}
		public function my_posts_where($where){
			global $wpdb;
			$old_terms='';
			if(isset($_REQUEST['my_test_terms']))$old_terms=@$_REQUEST['my_test_terms'];
			if(!empty($old_terms)){
				$where.=" AND my_t.term_taxonomy_id=".mysql_real_escape_string($old_terms)." ";
			}
			return $where;
		}
		public function post_columns($columns){
			self::debug("post_columns", $columns);
			$c=array();
			foreach ($columns as $key=>$val){
				if($key=='date'){
					foreach($this->post_columns as $k1=>$v1){
						$c[$k1]=$v1;
					}
					$c[$key]=$val;
				}else {
					$c[$key]=$val;
				}
			}
			$columns=$c;
			return $columns;
			
		}
		public function custom_post_column($col,$post_id){
			switch($col){
				case 'my_category':
					$terms=wp_get_post_terms($post_id,$this->post_terms);
					if(empty($terms)){
						echo __("Testimonial don't have categories","my_support_theme");
					}else {
						$str='';
						foreach($terms as $key=>$val){
							if(strlen($str)>0)$str.=",";
							$str.=$val->name;
						}
						echo $str;
					}
				break;	
				case 'my_user':
					$user=$this->get_post_meta($post_id, 'name');
					echo $user;
				break;		
				case 'my_image':
					$thumb_id=get_post_thumbnail_id($post_id);
					if(empty($thumb_id)){
						echo __("No Image","my_support_theme");
					}else {
						$t=wp_get_attachment_image_src($thumb_id);
						?>
						<img style="width:60px;height:60px" src="<?php echo $t[0]?>"/>
						<?php 
					}
				break;	
				case 'my_stars':
					$value=$this->get_post_meta($post_id, 'stars');
					?>
					<div class="my_jscript_stars">
					<ul>
			<?php for($f=1;$f<=5;$f++){?>
				<li data-i="<?php echo $f;?>">
					<i  class="fa fa-star <?php if($f<=$value)echo 'my_stars_active'?>"></i>
				</li>
					<?php }?>
				</ul>
				</div>
					<?php 
				break;	
			}
			
		}
	}
}
