<?php
if(!defined('ABSPATH'))die('');
$arr['front']=array(
	'controller_file'=>'class-my-controller.php',
	'controller_name'=>'Class_My_Testimonials_Front_Controller',	
	'my_actions'=>array(
		'test_cookie',
		'add_thumb',
		'add_testimonial'		
	)
);
return $arr;