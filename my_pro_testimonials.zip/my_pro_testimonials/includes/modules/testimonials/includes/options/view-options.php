<?php
if(!defined('ABSPATH'))die('');
$view_options=array(
	'id'=>'my_testimonials',
	'per_page'=>20,
	'columns'=>array(
		'title'=>array('title'=>__("Title","my_support_theme"),'order'=>true),
		'created'=>array('title'=>__("Created","my_support_theme"),'order'=>true),
		'updated'=>array('title'=>__("Updated","my_support_theme"),'order'=>true),
		'shortcode'=>array('title'=>__("Shortcode","my_support_theme"),'order'=>false),	
	),
	'translate'=>array(
		'shortcode'=>'[my_testimonial id="{id}"]'
	),
	'actions'=>array(
			'delete'=>__("Delete","my_support_theme"),
			'edit'=>array('title'=>__("Update","my_social_posts_domain"),'href'=>'','class'=>'my_update_posts')
				
		)			
);
return $view_options;