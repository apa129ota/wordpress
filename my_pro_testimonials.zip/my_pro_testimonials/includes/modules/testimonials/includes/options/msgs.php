<?php
if(!defined('ABSPATH'))die('');
$msgs['adding_testimonial']=__("Adding testimonial","my_support_theme");
$msgs['form_validate']=array(
	'required'=>__("This field is required !","my_support_theme"),
	'email'=>__("Email is not valid !","my_support_theme"),
	'max_length'=>__("Maximum size of this field is ","my_support_theme").'{max_length}'.__(" chars !","my_support_theme"),
	'min_value'=>__("Minimum value is ","my_support_theme").'{min_value}'.' !',
	'max_value'=>__("Maximum value is ","my_support_theme").'{max_value}'.' !',
	'form_has_errors'=>__("Form has errors ","my_support_theme").' !'	
);
return $msgs;