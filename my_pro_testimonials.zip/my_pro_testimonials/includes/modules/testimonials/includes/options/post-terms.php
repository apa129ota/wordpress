<?php
if(!defined('ABSPATH'))die('');
$arr=array(
		'label'=>__("Testimonials Category","my_support_theme"),
		'labels'=>array(
			'name'=>__("Testimonials Category","my_support_theme"),
			'singular_name'=>__("Testimonial Category","my_support_theme"),
			'menu_name'=>__("Categories","my_support_theme"),			
		),
		'public'=>true,
		'show_ui'=>true,
		'show_in_menu'=>true,
		'show_in_quick_edit'=>true,
		'description'=>__("Group testimonials by categories. Allow to filter testimonials by category.","my_support_theme"),
		'hierarchical'=>true,
		
);
return $arr;