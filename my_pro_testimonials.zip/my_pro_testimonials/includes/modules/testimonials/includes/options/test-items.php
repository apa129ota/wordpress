<?php
if(!defined('ABSPATH'))die('');
ob_start();
?>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris luctus placerat dolor, id laoreet ipsum. Vivamus nisl nunc, tincidunt et tellus nec, pulvinar dictum diam. Praesent vitae tincidunt ligula. Aenean dignissim a elit id tempus. Vestibulum faucibus, metus in accumsan aliquam, tortor urna facilisis leo, in vulputate dolor est a dui. Nullam at purus at nunc eleifend elementum. Fusce blandit imperdiet enim a fermentum. Aenean semper neque at massa ornare, quis dapibus neque malesuada. Fusce accumsan orci ut purus blandit, aliquam imperdiet lectus scelerisque. Integer pulvinar efficitur tellus, id fringilla sem tincidunt mollis. Aenean in justo eget augue auctor accumsan. Donec sit amet tincidunt metus.
Phasellus gravida, orci at finibus egestas, tortor quam blandit ipsum, sit amet tristique risus nibh sed dui. Phasellus ex odio, euismod et tincidunt nec, viverra et felis. Proin odio ante, finibus sit amet neque ac, tincidunt tristique nunc. Vivamus sit amet quam enim. Sed quis justo pharetra, laoreet purus ac, consequat sapien. Etiam mollis neque a feugiat tincidunt. Aliquam augue nisi, sodales sed feugiat sed, cursus ac lectus. Praesent sit amet rhoncus sem. Aliquam erat volutpat. Proin varius mauris in mauris imperdiet convallis. Suspendisse at imperdiet magna.
Nullam aliquet in dui et consectetur. Sed dignissim sed nunc et dapibus. Sed sagittis nisi nec iaculis ultricies. Donec consequat arcu dui, vel lacinia dolor porta a. Praesent consequat gravida vestibulum. Nulla facilisi. Quisque finibus, ante nec mattis tempus, libero justo vestibulum augue, vel pretium neque lacus ac massa. In sodales ante nulla, quis pulvinar mauris aliquam quis. Nunc ac laoreet leo, at egestas nulla. Aenean blandit cursus mauris vitae mattis. Fusce bibendum, augue eget auctor congue, mi arcu dictum purus, et ultricies mi neque quis dui.
Nulla eget lorem et mi ornare convallis id eget erat. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus ultricies vitae turpis eu luctus. Sed ut ligula sed est porttitor mattis sit amet et leo. Vivamus rutrum laoreet magna, sed sollicitudin urna egestas vitae. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam placerat dignissim lacinia. Nunc et tristique nisi, ut feugiat lectus. Quisque ipsum est, mattis sit amet congue non, aliquet nec lacus. Pellentesque ante orci, porta a consectetur tempus, aliquam porta arcu. Nullam at hendrerit quam. Nunc rutrum orci tortor, blandit blandit ex auctor quis. Morbi vitae suscipit lorem.
Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Curabitur ultricies luctus tincidunt. Curabitur sit amet elit dictum, convallis ante vitae, dapibus lacus. Curabitur lacinia quis quam sed sollicitudin. Cras pretium enim volutpat, elementum metus at, gravida lacus. Nunc ante urna, egestas id ante nec, luctus gravida nisl. Vivamus vel varius ex. Integer at pharetra risus. Curabitur ornare consequat iaculis. Donec id nulla ipsum. 
<?php 
$my_text=ob_get_clean();
$my_test_images=array(
	'man-1.jpg','man-2.jpg','woman.jpg'
);
$my_test_name=array(
	__("John Doe","my_support_theme"),__("Bob Doe","my_support_theme"),__("Alice Doe","my_support_theme")
);
$my_test_position=array(
		__("designer","my_support_theme"),__("director","my_support_theme"),__("Manager","my_support_theme")
);
$my_test_company=array(
	__("Company","my_support_theme")
);
$my_test_email=array(
	'test@gmail.com'
);
$my_test_url=array(
	'https://www.test.com'
);
function my_get_random_1234($arr){
	if(count($arr)>1){
		$c1=count($arr)-1;
		$c=rand(09,$c1);
		return $arr[$c];
	}else return $arr[0];
}
$my_arr=array();
for($i=0;$i<30;$i++){
	$stars=rand(3,5);
	$obj['stars']=$stars;
	$obj['name']=my_get_random_1234($my_test_name);
	$obj['position']=my_get_random_1234($my_test_position);
	$obj['company_name']=my_get_random_1234($my_test_company);
	$obj['company_url']=my_get_random_1234($my_test_url);
	$obj['email']=my_get_random_1234($my_test_email);
	$obj['text']=$my_text;
	$obj['thumb_name']=my_get_random_1234($my_test_images);
	$my_arr[]=$obj;
}
echo maybe_serialize($my_arr);



