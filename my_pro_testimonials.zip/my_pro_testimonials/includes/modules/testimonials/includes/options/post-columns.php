<?php
if(!defined('ABSPATH'))die('');
$arr=array(
		'my_stars'=>__("Stars","my_support_theme"),
		'my_image'=>__("Thumbnail","my_support_theme"),
		'my_user'=>__("User Name","my_support_theme"),
		'my_category'=>__("Category","my_support_theme")
);
return $arr;