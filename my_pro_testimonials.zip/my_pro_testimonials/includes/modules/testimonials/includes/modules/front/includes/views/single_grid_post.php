<?php
if(!defined('ABSPATH'))die('');
$template=$settings['template'];
$template_file=$views_dir.'templates/post/'.$template.'.php';
$float=$settings['float'];
?>
<?php $my_start_12_123=$my_c_12_123; ?>
				<?php foreach($items as $itemKey=>$item){
					if(!isset($itemVal['post_id']))$post_id=$my_start_12_123;
					else $post_id=$itemVal['post_id'];	
					?>
					<li data-is="0" data-pos="<?php echo esc_attr($my_start_12_123);$my_start_12_123++;?>" data-post-id="<?php echo esc_attr($post_id);?>" data-i="<?php echo $my_c_12_123++;?>" class="my_timeline_li_class"   id="<?php echo 'my_timeline_id_'.$post_id;?>">
					<?php require $template_file;?>
					</li>
				<?php }?>