(function ($) {

  //myproslider: Object Instance
  $.myGrid = function(el, options) {
	var my_grid = $(el);
    var default_settings={
    		working:false,
    		debug:true,
    		marginLeft:0,
    		swipeOn:1,
    		thumbsMargin:0,
    		has_timeline:false,
    		thumbs_animation:350,
    		marginAnimation:500,
    		regionWidth:150,
    		st_thumbs_width:40,
    		show_left_right:false,
    		slider_timeline_class:'.my_testimonial_shortcode',
    		slider_timeline_l_arrow:'.my_timeline_hor_list_nav_left',
    		slider_timeline_r_arrow:".my_timeline_hor_list_nav_right",
    		animate_dialog_time:2000,
    		line_duration:2000,
    		line_easing:'easeOutQuad',
    		duration:2000,
    		easing:"easeOutQuad",
    		use_touch:true,
    		normal_width:960,
    		tooltip_hide:1000,
    		height:'60%',
    		has_thumbs:false,
    		heights:{
    			800:'70%',
    			600:'100%'
    		},
    		//lay_keys:['1600','1280','980','700',],
    		lay_keys:['700','980','1280','1600'],
    		
    		slider_class:'.my_testimoniual_grid_div'
    			
    };
    my_grid.id=$(my_grid).attr('id');
    my_grid.started = false;
    my_grid.startTimeout = null;
    var settings=$.extend(default_settings,options);
    var gesture = window.navigator && window.navigator.msPointerEnabled && window.MSGesture;
    
    var  touch = (( "ontouchstart" in window ) || gesture || window.DocumentTouch && document instanceof DocumentTouch);
    if(typeof touch=='undefined')touch=false;
    else touch=touch&&settings.use_touch;
    
    my_grid.vars=settings;
    my_grid.vars.hasTouch=touch;
    my_grid.transitions=function() {
          var obj = document.createElement('div'),
              props = ['perspectiveProperty', 'WebkitPerspective', 'MozPerspective', 'OPerspective', 'msPerspective'];
          for (var i in props) {
            if ( obj.style[ props[i] ] !== undefined ) {
              my_grid.pfx = props[i].replace('Perspective','').toLowerCase();
              my_grid.prop = "-" + my_grid.pfx + "-transform";
              return true;
            }
          }
          return false;
        }();
        	
    var div_id='#'+$(el).attr('id');
    my_grid.my_debug=function(t,o){
    	if(settings.debug){
    		if(window.console){
    			console.log('Grid :'+t,o);
    		}
    	}
    };
    my_grid.set_widths=function(){
    	var cols=my_grid.layout.cols;
    	var w=$(my_grid).find(my_grid.vars.slider_class).width();
    	my_grid.my_debug("Grid Width",w);
    	var w1=w/cols;
    	var p=$(my_grid).find(my_grid.vars.slider_class+" > ul > li ").css('padding-right');
    	p=parseFloat(p);
    	w1=w1-2*p;
    	my_grid.item_width=w1+2*p;//$(my_grid).find(my_grid.vars.slider_class+" > ul > li ").outerWidth();
    	my_grid.my_debug('Item Width',{w:w,w1:w1,p:p,id:my_grid.vars.id});
    	$(my_grid).find(my_grid.vars.slider_class +" > ul > li ").width(w1);
    	
    	//set thumbs
    	/*$("#my_timeline_"+my_grid.vars.id+" .my_testimonial_item").each(function(i,v){
			if($(v).hasClass('my_testimonial_top') || $(v).hasClass('my_testimonial_bottom')){
							var wthumb=$(v).find(".my_testimonial_thumb_div").width();
							var wall=$(v).find(".my_testimonial_meta_div").width();
							var rmeta=wall-wthumb-30;
							//my_slider.my_debug("Meta data width",{wthumb:wthumb,wall:wall,rmeta:rmeta});
							$(v).find(".my_testimonial_meta_data_div").width(rmeta);
							
						}
			});
    	*/
    };
    my_grid.getLayout=function(){
    	var vars=my_grid.vars.lay_keys;//:['1280','980','700','small'],700,980
    	var w=my_grid.width;
    	w=$(my_grid).find(my_grid.vars.slider_class).width();
    	my_grid.my_debug("Slider width",w);
    	var my_found=false;
    	$.each(vars,function(i,v){
    		var v1=parseFloat(v);
    		my_grid.my_debug("Check lkayout",v1);
    		
    		if(w<v1){
    			my_grid.my_debug("return",v1);
        		
    			return false;
    		}
    		if(w>=v1){
    			
    			my_grid.my_debug("Assign layout",{v1:v1,lay:my_grid.vars.layout[v]});
        		
    			my_found=true;
    			my_grid.layout=my_grid.vars.layout[v];
    			//return false;
    		}
    		
    	});
    	if(!my_found){
    		my_grid.layout=my_grid.vars.layout['small'];
    		
    	}
    	my_grid.my_debug("Layout",my_grid.layout);
    };
    my_grid.set_height=function(){
    	
    	var v=my_grid.getViewportSize();
    	my_grid.my_debug('View port size',v);
    	var hp=my_grid.layout.height;
    	/*
    	var hp=my_grid.vars.height;
    	if(v.w<my_grid.vars.normal_width){
    		/*var hs1=my_grid.vars.heeights;
    		$.each(hs1,function(i,v){
    			if(i<v.w){
    				return false;
    			}else {
    				hp=v;
    			}
    		});*/
    	//}
    	
    	var hp_p=parseFloat(hp);
    	var h=0;
    	my_grid.my_debug('Height',hp_p);
    	
    	if(hp.indexOf('%')!==-1){
    			h=v.h*(hp_p/100);
    		
    	}else {
    		h=hp_p;
    	}
    	my_grid.my_debug('Set height',h);
    	//var ht=$(my_grid).find(".my_timeline_text").height();
    	//my_grid.my_debug('Height timeline',ht);
    	//h+=10;
    	$(my_grid).find(my_grid.vars.slider_class).find(".my_testimoniual_grid_ul > li").height(h);
    	//$(my_grid).find(my_grid.vars.slider_class).height(h);
    	 my_grid.set_test_height();
    	//$(my_grid).find(".my_timeline_slider_nav").height(h);
    	//var emh_l=$(my_grid).find(".my_timeline_slider_nav i").outerHeight();
    	//var pt_12=(h-emh_1)/2;
    	//$(my_grid).find(".my_timeline_slider_nav i").css('')
    	/*var t1=$(my_grid).find(".my_timeline_header").outerHeight();
    	var t2=$(my_grid).find(".my_timeline_media").outerHeight();
    	var t4=$(my_grid).find(".my_timeline_item").css('padding-top');
    	var t6=$(my_grid).find(".my_timeline_item").css('padding-bottom');
    	
    	var t5=$(my_grid).find(".my_timeline_text").css('margin-top');
    	t4=parseFloat(t4);
    	t5=parseFloat(t5);
    	t6=parseFloat(t6);
    	var t3=h-t1-t2-t4-t5-t6;
    	
    	my_grid.my_debug('Height timeline',{t1:t1,t2:t2,t3:t3,t4:t4,t5:t5,t6:t6});
    	
    	$(my_grid).find(".my_timeline_text").height(t3);
    	 my_grid.init_scroll();
    	 */
    };
    my_grid.set_test_height=function(){
    	/*if(my_grid.vars.form.show_thumbs==1){
    		my_grid.my_debug("Set thumbs");
    		var sel_thumbs=".my_testimonial_thumbs_div [data-id='"+my_grid.vars.id+"'] .my_testimonial_thumbs";
    		var h=$(my_grid).siblings(sel_thumbs+" ul > li").outerHeight();
    		$(my_grid).siblings(sel_thumbs).height(h);
    		var w=$(my_grid).siblings(sel_thumbs).width();
    		var cols=8;
    		if(w<600){
    			cols=4;
    		}
    		
    		var count=$(my_grid).siblings(sel_thumbs).data('count');
    		var wperc=100/cols*count+200;
    		my_grid.my_debug("Set thumbs params",{h:h,w:w,cols:cols,count:count,wperc:wperc});
    		
    		$(my_grid).siblings(sel_thumbs+" > ul").css('width',wperc+'%');
    		
    	}*/
    	$("#my_timeline_"+my_grid.vars.id+" .my_testimonial_item").each(function(i,v){
			var h=$(v).height();
			my_grid.my_debug('Height item',h);
			var w=$(v).width();
			var th_w=$(v).find(".my_testimonial_thumb").width();
			var th_h=$(v).find(".my_testimonial_thumb").height();
			my_grid.my_debug("Thumb",{w:th_w,h:th_h});
			var paddp=$(v).css('padding-top');
			paddp=parseInt(paddp);
			var float=$(v).data('float');
			if($(v).hasClass("my_testimonial_center_top") || $(v).hasClass('my_testimonial_top') || $(v).hasClass('my_testimonial_bottom')|| $(v).hasClass("my_testimonial_center_bottom")){
				var h1=$(v).find(".my_testimonial_meta_div").outerHeight();
				var padd=$(v).find(".my_testimonial_p").css('padding-top');
				if($(v).hasClass("my_testimonial_center_top")){
					padd=$(v).find(".my_testimonial_p").css('padding-bottom');
				}
				var h1=$(v).find(".my_testimonial_meta_div").outerHeight();
				h1=$(v).find(".my_testimonials_metadata").outerHeight();
				if($(v).hasClass("my_testimonial_center_top") || $(v).hasClass("my_testimonial_center_bottom")){
					h1+=80;
					
				}else {
					if(h1<80)h1=80;
				}
				padd=parseInt(padd);
				
				/*if($(v).hasClass('my_testimonial_top') || $(v).hasClass('my_testimonial_bottom')){
					h1=(h-2*padd)/2;
					$(v).find(".my_testimonial_meta_div").height(h1);
					$(v).find(".my_testimonials_metadata").height(h1);
				}else {
					var h3=$(v).find(".my_testimonial_meta_div img").height();
					h1=(h-2*padd)/2;
					$(v).find(".my_testimonial_meta_div > div > div").height(h1);
					var h4=h1-h3;
					$(v).find(".my_testimonials_metadata").height(h4);
					$(v).find(".my_testimonials_metadata >ul").height(h4);
					/*var h3=$(v).find(".my_testimonial_meta_center img").height();
					h1=(h-2*padd)/2;
					$(v).find(".my_testimonial_meta_center").height(h1);
					*/
					/*var h3=$(v).find(".my_testimonial_meta_center img").height();
					h1=(h-2*padd)/2;
					$(v).find(".my_testimonial_meta_center").height(h1);
					var h4=h1-h3;
					$(v).find(".my_testimonials_metadata").height(h4);
					$(v).find(".my_testimonials_metadata >ul").height(h4);
					*/
					/*	h1=(h-2*padd)/2;
						$(v).find(".my_testimonial_meta_div").height(h1);
						$(v).find(".my_testimonials_metadata").height(h1);
					
				}*/
				var margin=0;
				if($(v).find(".my_testimonial_thumb_div").hasClass("my_testimonials_thumb_left")){
					margin=$(v).find(".my_testimonial_thumb_div").css('margin-left');
				}else {
					margin=$(v).find(".my_testimonial_thumb_div").css('margin-right');
				}
				margin=parseInt(margin);
				my_grid.my_debug('Height meta div',{w:w,h1:h1,padd:padd,margin:margin});
				
				//var li_w=w-margin-th_w;
				//my_grid.my_debug('Height meta div',{w:w,li_w:li_w,margin:margin});
				
				//$(v).find(".my_testimonials_metadata >li").width(li_w);
				//my_grid.my_debug('Height meta div',h1);
				//my_grid.my_debug('Padd',padd);
				
				var h2=h-h1-2*padd;//-2*paddp;
				//my_grid.my_debug('Height text item',h2);
				
				$(v).find(".my_testimonial_text").height(h2);
			}else {
				
			}
			/*
			if(my_grid.vars.form.scroll_metadata==1){
			var is_mc2=$(v).find(".my_testimonials_metadata").attr('my-c');
			if(typeof is_mc2=='undefined'){
				$(v).find(".my_testimonials_metadata").mCustomScrollbar({
				    axis:"y" // horizontal scrollbar
				});
				$(v).find(".my_testimonials_metadata").attr('my-c',1);
			
			}
			}*/
			var is_mc=$(v).attr('my-c');
			if(typeof is_mc=='undefined'){
				$(v).find(".my_testimonial_p").mCustomScrollbar({
				    axis:"y" // horizontal scrollbar
				});
				$(v).attr('my-c',1);
			}
    	});
    };
    
    my_grid.init_scroll=function(){
    	
    	var is=$(my_grid).find(".my_timeline_content").data('is-scroll-init');
    	my_grid.my_debug("Is init custom scroll bar",is);
    	if(typeof is=='undefined'){
    		my_grid.my_debug('Init scrolls');
    		$(my_grid).find(".my_timeline_text").mCustomScrollbar(
    				{axis:'y',
    				advanced:{
    					updateOnContentResize:true
    					}});
    		$(my_grid).find(".my_timeline_content").data('is-scroll_init',1);
    	}else {
    		//$(my_slider).find(".my_timeline_text").mCustomScrollbar('update');
    	}
    };
    my_grid.getViewportSize=function() {

        // Use the specified window or the current window if no argument
    	var w=window;
    	/*if(my_slider.vars.preview){
    		var iframes = window.frames
        	w=iframes[0].window;
        }*/
    	

        // This works for all browsers except IE8 and before
        if (w.innerWidth != null) return { w: w.innerWidth, h: w.innerHeight };

        // For IE (or any browser) in Standards mode
        var d = w.document;
        if (document.compatMode == "CSS1Compat")
            return { w: d.documentElement.clientWidth,
               h: d.documentElement.clientHeight };

        // For browsers in Quirks mode
        return { w: d.body.clientWidth, h: d.body.clientHeight };

    };
    my_grid.load_more=function(e){
    	e.preventDefault();
		var pages=$(my_grid).attr('data-pages');
		var page=$(my_grid).attr('data-page');
		my_grid.my_debug("Page",{page:page,pages:pages,vars:my_grid.vars});
		if(page==pages)return;
		page=parseInt(page)+1;
    	
    	var data={
    			action:my_grid.vars.ajax_action,
    			nonce:my_grid.vars.ajax_nonce,
    			id:my_grid.vars.id,
    			page:page
    	}
    	if(my_grid.vars.working)return;
    	my_grid.vars.working=true;
    	$(this).find('i').css("display","inline-block");
    	
    	my_grid.my_debug('Load more',data);
    	$.ajax({
    		url:my_grid.vars.ajax_url,
    		action:my_grid.vars.ajax_action,
    		dataType:'json',
    		data:data,
    		cache:0,
    		timeout:my_grid.vars.ajax_timeout,
    		type:'POST',
    		success:function(data){
    			my_grid.my_debug("Data",data);
    			if(data.error==0){
    				var pages=$(my_grid).attr('data-pages');
    				var page=$(my_grid).attr('data-page');
    				page=parseInt(page);
    				page++;
    				pages=parseInt(pages);
    				$(my_grid).attr('data-page',page);
    				my_grid.my_debug("Page",{page:page,pages:pages});
    				if(page>=pages){
    					$(my_grid).find(".my_testimonial_load_more").fadeOut(function(){$(this).remove();});
    				}
    				$(my_grid).find('.my_testimoniual_grid_ul').append(data.html);
    				my_grid.set_height();
    				//my_grid.set_height();
    		    	my_grid.set_widths();	
    				my_grid.vars.working=false;
    				
    				
    			}else {
    				my_grid.vars.working=false;
    				alert(data.msg);
    			}
    			$("#my_testimonial_load_more_"+my_grid.vars.id).find('i').css("display","none");
    		},
    		error:function(){
    			$("#my_testimonial_load_more_"+my_grid.vars.id).find('i').css("display","none");
    			alert('Error');
    		}
    	});
    	
    };
    my_grid.init=function(){
    	var pages=$(my_grid).attr('data-pages');
		var page=$(my_grid).attr('data-page');
		if(page==pages){
			$("#my_testimonial_load_more_"+my_grid.vars.id).hide();
		}
		else $("#my_testimonial_load_more_"+my_grid.vars.id).click(my_grid.load_more);	
    my_grid.my_debug("Options",my_grid.vars);	
   	 my_grid.getLayout();
 	my_grid.set_height();
 	my_grid.set_widths();
 	$(my_grid).animate({opacity:1});
 	$(window).resize(function(e){
    	my_grid.my_debug("Widnow resize");
    	var w=$(my_grid).find(my_grid.vars.slider_class).outerWidth();
    	my_grid.width=w;
    	 my_grid.getLayout();
    	
    	my_grid.set_height();
    	my_grid.set_widths();	
    	
    });
  };
  my_grid.init();
    };
  
    $.fn.myGrid=function(options){
  	  if (options === undefined) { options = {}; }
  	  if(typeof options=='object'){
  	  return this.each(function() {
  		  	var $this = $(this);   
  	        if ($this.data('mygrid') === undefined) {
  	          var inst=new $.myGrid(this, options);
  	          $(this).data('mygrid',inst);
  	        }
  	      });
  	  }else {
  		  //Call slider functions
  		  var $slider=$(this).data('mygrid');
  		  switch (options) {
  		 
  		  }
  		  
  	  }
    };
  })(jQuery);   