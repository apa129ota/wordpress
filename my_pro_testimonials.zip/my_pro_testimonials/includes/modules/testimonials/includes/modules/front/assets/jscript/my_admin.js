(function($) { 
	myAdminTestimonialsFrontAdmin=function(o){
		var self;
		this.my_working=false;
		this.debug=true;
		this.options=o;
		this.network='';
		this.network_ids='';
		this.my_pre_open_post_id='';
		this.search_ids={};
		this.my_get_all=false;
		this.my_save_all=false;
		this.included_fonts={};
		this.pre_options={
				editor_class:".my_slide_image_inner",
				element_inner:".my_shortcode_content_new",
				ul_button:".my_shotcode_actions_ul",
				outter_class:".my_outter_object",
				form_class:".my_options_form",
				form_element:".my_new_module_element",
				shortcode_content:".my_shortcode_content_new",
				item_add_class:".my_shortcode_added_html",
				item_class:".my_shortcode_item",
				row_class:".my_shortcode_row_row"	
		};
		self=this;
		this.init=function(o){
			if(typeof self.options.my_debug!='undefined'){
				if(!self.options.my_debug){
					self.debug=false;
				}
			}
			self.options=$.extend( self.pre_options,self.options);
			self.my_debug("Options",self.options);
			var o={
					key:'save_style',
					debug:self.debug,
					dw:600,
					dh:400,
					diff:20
				};
			self.save_style_dialog=new myVusualBuilderDialog(o);
			var o1={
					key:'load_style',
					debug:self.debug,
					dw:600,
					dh:400,
					diff:20
				};
			self.load_style_dialog=new myVusualBuilderDialog(o1);
			var o2={
					modal:true,
					key:'preview',
					debug:self.debug,
					dw:'90%',
					dh:750,
					diff:50
			};
			self.preview_dialog=new myVusualBuilderDialog(o2);
			$(document).on("change","#my_preview_width_id",function(e){
				var val=$("#my_preview_width_id option:selected").val();
				for(var i=1;i<10;i++)
				self.my_debug('Width',val);
				
				$(".my_preview_div_1 iframe").css('width',val);
			});
			$(document).on('click',".my_action",self.action);
			$(document).on('click',".my_options_form .my_slide_in_out i",function(e){
				e.preventDefault();
				self.my_debug("Click",$(this).attr('class'));
				if($(this).hasClass('fa-angle-double-right')){
					$(".my_options_form").animate({left:'0px'});
					$(this).hide();
					$(this).parents(".my_slide_in_out").find(".fa-angle-double-left").show();
				}else {
					var w123=$(".my_options_form").width()-20;
					$(".my_options_form").animate({left:'-'+w123+'px'});
					$(this).hide();
					$(this).parents(".my_slide_in_out").find(".fa-angle-double-right").show();
				}
			});
			
			$(window).load(function(e){
				if(self.options.is_id==1){
					self.my_debug("Open accordian");
					$(".my_accordian .my_accordian_header").trigger('click');
				}
				//$(".my_actions_shortcodes[data-key='card'] a[data-key='edit_styles']").trigger('click');
			});
			$(window).resize(self.resize);
			$("body").on("my_close_dialog",function(e){
				$(".my_module_debug").show();
				self.my_debug('close_dialog');
				$("body").css('overflow-y','');
			});
			/**
			 * Translate styles
			 */
			$(self.options.form_class+" "+self.options.form_element).each(function(i,v){
				var id=$(v).attr('id');
				var o=self.get_element_data(id);
				self.my_debug('Init chnage',o);
				switch(o.type){
					case 'jscript_color_picker':
					case 'jscript_dropdown':
					case 'jscript_spinner':	
						self.my_debug('Call change script');
						var sel=$("#"+o.id);
						//var o=self.get_element_data(id);
						var type=o.type;
						$(o.obj).on('my_change',function(e,obj,val,v1){
							if(self.my_disable_change)return;
							self.my_debug("Change my objects",{obj:obj,val:val});
							var form_prefix=$(this).parents('form').find("input[name='my_form_id']").val();
							var id=$(this).attr('id');
							var object_id=self.my_edit_id;
							var object;
							var edit_type=form_prefix;//$("#"+object_id).find(self.options.outter_class).data('key');
							if(self.my_add_id!=''){
								self.my_debug('Styling row',self.my_add_id);
								object_id=self.my_add_id;
								object=self.my_add_object;//myVusualBuilderShortcodesRow_inst[object_id];
								self.my_add_object=object;
								edit_type=form_prefix;
							}else {
								object=self.objects[object_id];
							}
							o.val=val;
							var prop=form_prefix;
							var name=$(this).data('base-name');
							if(name=='predefined_styles'){
								self.adjust_predefined_style(prop,name,type,form_prefix,o);
							}else {
								var type=$(this).data('type');
								self.adjust_style(prop,name,type,form_prefix,o);
							}
							//var val=obj[1];
									
						});
					break;	
					case 'text':
					case 'radio_list':
					case 'radio':
					case 'checkbox':
						self.my_debug('Call change script');
						var sel=$("#"+o.id);
						var type=o.type;
						if(type=='radio_list' || type=='radio' || type=='checkbox' || type=='checbox_list'){
							sel=$("input[name='"+o.full_name+"']");
						}
						var object_id=self.my_edit_id;
						var object=self.objects[object_id];
						if(self.my_add_id!=''){
							object_id=self.my_add_id;
							object=self.my_add_object;
						}
						
						self.my_debug("Init change",{type:type,sel:sel});
						$(sel).change(function(e){
							if(self.my_disable_change)return;
							var form_prefix=$(this).parents('form').find("input[name='my_form_id']").val();
							var id=$(this).parents(self.options.form_element).attr('id');
							self.my_debug('Outter id',id);
							var o=self.get_element_data(id);
							o.form_prefix=form_prefix;
							o.val=$(this).val();
							self.my_debug('Change element',o);
							/*if(form_prefix=='responsive_box'){
								if(typeof self.objects[self.my_edit_id]=='undefined'){
									self.objects[self.my_edit_id].responsive={};
								}
								object.responsive[o.name]=val;
								self.my_debug("Repossive",self.objects[self.my_edit_id].responsive);
							}
							else if(form_prefix=='box'){
								self.change_box_model(o);
							}
							else self.my_change_element(o);*/
							self.adjust_style(prop, name, type, form_prefix, o);
						});
					break;	
				}
			});
			$(window).load(function(e){
			//$(".my_shortcode_rows").trigger('click');
			});
		
		};
		this.adjust_predefined_style=function(prop,name,type,form_prefix,o){
			$("#new_css_id").html('');
			self.my_debug("Change style",{prop:prop,name:name,type:type,form_prefix:form_prefix,o:o});
			self.my_debug("All styles",self.options.styles);
			var style=o.val;
			var styles=self.options.styles[style];
			self.my_debug("Choose style",styles);
			var c1,c2;
			var img='';
			if(typeof styles['background_image']!='undefined'){
				img=styles['background_image'];
			}
			
			$.each(styles,function(i,v){
				if(i=='arrows_background_color'){
					c2=v;
				}
				if(i=='arrows_hover_color'){
					c1=v;
				}
				if(i!='background_image'){
					var name=i;
					var id=i+'_'+self.my_edit_id+'_id_div';
					self.my_debug("set value",{name:name,v:v,id:id});
					if($("#"+id).length>0){
						$("#"+id).data('my-script').set_value(v);
					}
					if(name=='arrows_background_color')c2=v;
					else if(name=='arrows_hover_color')c1=v;
					
				}
				if(i=='text_background'&&img!=''){
					var css='.my_testimonial_text{backgorund:'+o.val+' url("'+img+'") !important;}';
					$(".new_css_id").append(css);
				}
				/*var css1='';
				if(i=='text_background'){
					css1+='<style type="text/css" id="'+i+self.my_edit_id+'_1">';
					css1+='.my_top_arrow{border-bottom-color:'+v+' !important;}';
					css1+='.my_bottom_arrow{border-top-color:'+v+' !important}';
					css1+='</style>';
					
				}
				if(i=='text_border_color'){
					css1+='<style type="text/css" id="'+i+self.my_edit_id+'_1">';
					
					css1+='.my_top_arrow_inner{border-bottom-color:'+v+'!important}';
					css1+='.my_bottom_arrow_inner{border-bottom-color:'+v+'!important}';
					css1+='</style>';
				}
				if(css1!=''){
					$("#new_css_id").append(css1);
				}*/
			});
			var edit=self.my_edit_id;
			self.my_debug("Colors",{edit:edit,c1:c1,c2:c2});
			if(edit=='card_style'){
				var sl=$("#my_timeline_1000000").data('myproslider');
				
				sl.vars.form.circle_hover_color=c1;
				sl.vars.form.circle_back_color=c2;
				self.my_debug("Slider Vars",sl.vars);
			}
			
			
		};
		this.adjust_style=function(prop,name,type,form_prefix,o){
			self.my_debug("Edit type",{prop:prop,name:name,type:type,form_prefix:form_prefix,translations:self.options.translate});
			var translate=self.options.translate[name];
			self.my_debug("Translate",translate);
			var c1='',c2='';
			if(name=='arrows_background_color'){
				c2=o.val;
			}
			if(name=='arrows_hover_color'){
				c1=o.val;
			}
			if(typeof translate!='undefined'){
				var p=translate;//self.options.translate[prop];
				//if(typeof p[name]!=undefined){
					var property=p;//p[name];
					var object_id=name;
					self.my_debug("Property",property);
					var sel=property['class'];
					var css_prop=property.property;
					var p_sel="#"+object_id+"  "+self.options.shortcode_content;
					var val=o.val;
					//if(self.my_add_id){
					//	p_sel='#'+object_id;
					//}
					//self.my_debug('p_sel',p_sel);
					self.my_debug("property",css_prop);
					sel=sel.replace('{class}',p_sel);
					self.my_debug("sel",sel);
					
					//if(sel.indexOf(":")!==-1){
						var css_id=object_id+'_'+name;
						if(name=='font-family'){
							if(typeof self.included_fonts[val]=='undefined'){
								self.my_debug("Inlcude new font",val);
								var value=val.replace(/ /g,'+');
								self.my_debug("Inlcude new font",value);
								if($("head").find("#my_testimonial_fonts_css").length>0){
									$("head #my_testimonial_fonts_css").attr('href','https://fonts.googleapis.com/css?family='+value);
									
								}
								else $("head").append('<link id="my_testimonial_fonts_css" rel="stylesheet" href="https://fonts.googleapis.com/css?family='+value+'"/>');
								
								//self.included_fonts[val]=1;
							}
						}
						
						var css;
						if(typeof translate.css !='undefined'){
							css='';
							$.each(property.css,function(i,v){
							var newCss=v;
							newCss=newCss.replace('{val}',val);
							if(css.length>0)css+="\n";
							css+=newCss;//c.replace('{css}',newCss);
							self.my_debug('Property css',css);
							});
							var css_id_1=object_id+'_'+name+'_css';
							if($("#"+css_id_1).length>0){
								$("#"+css_id_1).text(css);
							}else {
								$("#my_new_css").append('<style type="text/css" id="'+css_id_1+'">'+css+'</style>');
							}
							
						}
						if(typeof css_prop.css!='undefined'){
							css=sel;
							var newCss=css_prop.css;
							newCss=newCss.replace('{val}',val);
							css=css.replace('{css}',newCss);
							
							//css=sel+css;
							self.my_debug('Css properyt',css);
						}else {
						if(name=='font-family'){
							
							css=sel+"{\n"+css_prop+":"+val+" , serif !important\n}";

						}
						else css=sel+"{\n"+css_prop+":"+val+" !important\n}";
						}
						if($("#"+css_id).length>0){
							$("#"+css_id).text(css);
						}else {
							$("#my_new_css").append('<style type="text/css" id="'+css_id+'">'+css+'</style>');
						}
						var css1='';
						if(name=='text_background'){
							var id1=name+self.my_edit_id+'_1';
							var has=$("#"+id1).length;
							
							if(!has)css1+='<style type="text/css" id="'+name+self.my_edit_id+'_1">';
							css1+='.my_top_arrow{border-bottom-color:'+val+' !important;}';
							css1+='.my_bottom_arrow{border-top-color:'+val+' !important}';
							if(!has)css1+='</style>';
							if(has){
								$("#"+id1).html(css1);
							}else {
									$("#new_css_id").append(css1);
							}
							self.my_debug("Adjust arrow",{id1:id1,name:name,val:val,css1:css1});
						}
						if(name=='text_border_color'){
							var id1=name+self.my_edit_id+'_1';
							var has=$("#"+id1).length;
							
							if(!has)css1+='<style type="text/css" id="'+name+self.my_edit_id+'_1">';
							
							css1+='.my_top_arrow_inner{border-bottom-color:'+val+'!important}';
							css1+='.my_bottom_arrow_inner{border-bottom-color:'+val+'!important}';
							if(!has)css1+='</style>';
							if(has){
								$("#"+id1).html(css1);
							}else {
									$("#new_css_id").append(css1);
							}
							self.my_debug("Adjust arrow",{id1:id1,name:name,val:val,css1:css1});
						}	
						
						
					
						
					/*	
					}else {
						$(sel).css(css_prop,value);
					
					}*/
						
					/*	if(form_prefix=='responsive_box'){
							if(typeof object.responsive=='undefined'){
								object.responsive={};
							}
							object.responsive[o.name]=val;
							self.my_debug("Repossive",self.objects[self.my_edit_id].responsive);
						}
						else	if(form_prefix=='box'){
					if(typeof object.box=='undefined'){
						object.box={};
						
					}	
					object.box[name]=val;
					self.change_box_model(o);
						}else {
					if(typeof object.style=='undefined'){
						object.style={};
					}
					if(type='jscript_color_picker'){
						val=v1;
					}
					object.style[name]=val;
						}
					self.my_debug("Properties style",object);*/
				}
			var edit=self.my_edit_id;
			
			if(edit=='card_style'){
				var sl=$("#my_timeline_1000000").data('myproslider');
				if(c1!=''){
					sl.vars.form.circle_hover_color=c1;
				}
				if(c2!=''){
					sl.vars.form.circle_back_color=c2;
				}
				self.my_debug("Slider Vars",sl.vars);
			}else if(edit=='slider_style'){
				var sl=$("#my_timeline_100000010").data('myproslider');
				if(c1!=''){
					sl.vars.form.circle_hover_color=c1;
				}
				if(c2!=''){
					sl.vars.form.circle_back_color=c2;
				}
				self.my_debug("Slider Vars",sl.vars);
			
			}
			//}

		};
		this.change_front_style=function(e){
			var object_id=self.my_edit_id;
		};
		this.resize=function(e){
			var width = window.innerWidth;
			var height = window.innerHeight;
			var h1=$(".my_timeline_modal").find(".my_header").outerHeight();
			var h2=height-h1;
			$(".my_timeline_modal").find(".my_slide_image").height(h2);
			$(".my_options_form_inner").height((h2-150));
			$(".my_options_form").height((h2-150));
			var paddl=parseInt($(".my_view_item").css('padding-left'));
			var w=width-2*paddl;
			$(".my_view_item").width(w);
		};
		this.get_element_data=function(id){
			var $o=$("#"+id);
			var type=$($o).data('type');
			var name=$($o).data('base-name');
			var name1=$($o).data('name');
			var id1=$($o).data('id');
			return {
				id:id1,
				full_name:name1,
				name:name,
				type:type,
				obj:$o
			};
		};
		this.action=function(e){
			e.preventDefault();
			var key=$(this).data('key');
			var type=$(this).data('type');
			self.my_debug("Action",{key:key,type:type});
			switch(key){
				case 'preview':
					self.my_debug("Is id",self.options.is_id);
					var id_name='id_'+type;
					var id=$("input[name='"+id_name+"']").val();
					self.my_debug("Id",{id:id,id_name:id_name});
					if(self.options.is_id==0){
						if(typeof id=='undefined' || id==''){
							myAdminMsgs_inst.show_remove(self.options.msgs.first_save,1);
							return;
						}
					}else {
						
						
					}
					$(".my_dialog_preview .my_dialog_preview_loading").show();
					$(".my_dialog_preview .my_preview_div_1").css('visibility','hidden');
					var url=self.options.preview_url;
					url=url.replace('{id}',id);
					$(".my_dialog_preview iframe").attr('src',url);
					if(typeof $(".my_dialog_preview iframe").attr('my_is') =='undefined'){
						$(".my_dialog_preview iframe").load(function(e){
							$(".my_dialog_preview .my_dialog_preview_loading").fadeOut(function(){
							$(".my_dialog_preview .my_preview_div_1").css('visibility','visible');
							});
						});
					}
					self.preview_dialog.my_open();
					/*setTimeout(function(){
						self.my_debug('Assing change');
						$("#my_preview_width_id").change(function(e){
								var val=$("#my_preview_width_id option:selected").val();
								for(var i=1;i<10;i++)
								self.my_debug('Width',val);
								
								$(".my_preview_div_1 iframe").css('width',val);
							});
					},5000);
					*/	
				break;	
				case 'save':
					self.my_save_type_name=type;
					var o1={};
					var title=$('#title_'+type+'_id').val();
					if(title==''){
						myAdminMsgs_inst.show_remove(self.options.msgs.title_is_required,1);
						return;
					}
					o1.show_msg=1;
					
					o1.data={
							action:self.options.ajax_action,
							my_action:'save',
							type:type
					};
					self.my_debug("Save style daa ",o1);
					var data=$("#my_form_"+type).serialize();
					o1.data.form_data=data;
					o1.success=function(data){
						self.my_debug("Return", data);
						if(data.error==0){
							if(typeof self.my_saved_id=='undefined'){
							$(".my_accordian .my_accordian_inner").each(function(i,v){
							if(!$(v).is(":visible")){
								self.my_debug("Hide element",{type:$(v).data('type')});
								$(v).parents(".my_accordian").hide();
								$(v).parents(".my_accordian").remove();
								
								
							}
							});
							}
							self.my_saved_id=data.id;
							$("input[name='id_"+self.my_save_type_name+"']").val(data.id);
							myAdminMsgs_inst.show_remove(data.msg,0);
						}else {
							myAdminMsgs_inst.show_remove(data.msg,1);
						}
						
					};
					myGlobalAjaxClass_inst.call_ajax(o1,self.options.msgs.saving_shortcode);
				break;	
				case 'new_style':
					var e=self.my_edit_id;
					var id='predefined_styles_'+e+'_id_div';
					$("#"+id).data("my-script").set_value("gray");
					$("input[name='id_"+self.my_edit_id+"']").val('');
					$(".my_saved_style_title").fadeOut();
					
				break;	
				case 'load_style':
					var o1={};
					var id=$("#my_style_id option:selected").val();
					if(id==""){
						myAdminMsgs_inst.show_remove(self.options.msgs.select_style,1);
						return;
					}
					self.my_debug("Save style",{title:title,form_id:form_id,form_data:form_data});
					o1.show_msg=1;
					
					o1.data={
							action:self.options.ajax_action,
							my_action:'load_style',
							id:id
					};
					self.my_debug("Save style daa ",o1);
					
					o1.success=function(data){
						self.my_debug("Return", data);
						if(data.error==0){
							var form_id="my_form_"+self.my_edit_id;
						//$("#form_id .").each()
							$.each(data.values,function(i,v){
								var id=i+'_'+self.my_edit_id+'_id_div';
								self.my_debug("set value pre",{form_id:form_id,id:id});
								if($("#"+id).length>0){
									self.my_debug('Set value',{i:i,v:v,id:id});
									$("#"+id).data('my-script').set_value(v);
								}
							});
						if(typeof data.added_style !='undefined'){
							
							var style_id=data.added_style.id;
							
							var type=data.added_style.type;
							var style_title=data.added_style.title;
							self.my_debug("Addded style", {a:data.added_style,type:type,edit:self.my_edit_id});
							if(type==self.my_edit_id){
								var my_i="id_"+self.my_edit_id;
								self.my_debug("Set ids",{el_id:my_i,id:style_id,title:style_title});
								$("input[name='"+my_i+"']").val(style_id);
								$(".my_saved_style_title").html(style_title).fadeIn();
							}
							
							
						}
						self.load_style_dialog.my_close();
						}else {
							myAdminMsgs_inst.show_remove(data.msg,1);
						}
					}
					myGlobalAjaxClass_inst.call_ajax(o1,self.options.msgs.load_style);
					
				break;	
				case 'load_style_dialog':
					self.load_style_dialog.my_open();
					break;	
				case 'save_style_dialog':
					if($(".my_saved_style_title").is(":visible")){
						var t=$(".my_saved_style_title").html();
						$("#my_style_title").val(t);
					}else {
						$("#my_style_title").val('');
					}
					self.save_style_dialog.my_open();
				break;	
				case 'save_style':
					var title=$("#my_style_title").val();
					if(title==''){
						myAdminMsgs_inst.show_remove(self.options.msgs.style_title_required,1);
						$("#my_style_title").focus();
						return;
					}
					var o1={};
					var form_id='my_form_'+self.my_edit_id;
					var form_data=$("#"+form_id).serialize();
					var my_i='id_'+self.my_edit_id;
					var my_id=$("input[name='"+my_i+"']").val();
					if(typeof my_id!= 'unedefined' && my_id!=""){
						self.my_id_1234=my_id;
						self.my_title=title;
					}
					self.my_debug("Save style",{title:title,form_id:form_id,form_data:form_data});
					o1.show_msg=1;
					o1.data={
							action:self.options.ajax_action,
							my_action:'save_style',
							form_data:form_data,
							type:self.my_edit_id,
							title:title
					};
					self.my_debug("Save style daa ",o1);
					
					o1.success=function(data){
						self.my_debug("Return", data);
						
						if(data.error==0){
							if(self.my_id_1234!='undefined'){
								$("#my_style_id option[value='"+self.my_id_1234+"']").text(self.my_title);
								delete self.my_id_1234;
							}
							$("#my_style_title").val('');
							myAdminMsgs_inst.show_remove(data.msg,0);
							self.save_style_dialog.my_close();
							if(typeof data.added_style !='undefined'){
								var style_id=data.added_style.id;
								$("input[name='id_"+self.my_edit_id+"']").val(style_id);
								var style_title=data.added_style.title;
								var o='<option value="'+style_id+'">'+style_title+'</option>';
								$("#my_style_id").append(o);
								$(".my_saved_style_title").html(style_title).fadeIn();
							}
						}else {
							myAdminMsgs_inst.show_remove(data.msg,1);
						}
					}
					myGlobalAjaxClass_inst.call_ajax(o1,self.options.msgs.saving_style);
				break;	
				case	'edit_styles':
					$('body').css('overflow-y','hidden');
					//var id=$(this).parents(".my_img_1").data('id');
					var id=type+'_style';
					if(typeof self.my_edit_id!='undefined'){
						$("#my_new_css").html('');
					}
					if(id=='grid_style'){
						if(typeof $("#my_timeline_100000011").data('mygrid')=='undefined'){
							
							self.my_debug('Init grid',id);
							setTimeout(function(){
								$("#my_timeline_100000011").myGrid(my_timeline_o_100000011);
							},1500);
							}else {
								setTimeout(function(){
								//	var sl=$("#my_timeline_100000011").data('mygrid');
								//sl.resize();
									$(window).trigger('resize');
								},1500);
							}
					}
					else if(id=='card_style'){
						if(typeof $("#my_timeline_1000000").data('myproslider')=='undefined'){
							
						self.my_debug('Init card',id);
						setTimeout(function(){
							$("#my_timeline_1000000").myproslider(my_timeline_o_1000000);
						},1500);
						}else {
							setTimeout(function(){
							//	var sl=$("#my_timeline_1000000").data('myproslider');
							//sl.resize();
								$(window).trigger('resize');
							},1500);
						}
						
					}else if(id=='slider_style'){
						self.my_debug('Init slider',id);
						if(typeof $("#my_timeline_100000010").data('myproslider')=='undefined'){
						setTimeout(function(){
							$("#my_timeline_100000010").myproslider(my_timeline_o_100000010);
						},1500);
						}else {
							setTimeout(function(){
							//	var sl=$("#my_timeline_100000010").data('myproslider');
							//sl.resize();
								$(window).trigger('resize');
							},1500);
						}
					}
					self.my_edit_id=id;
					
					var w=$(this).parents(".my_img_1").data('w');
					var h=$(this).parents(".my_img_1").data('h');
					self.my_debug("Edit slide",{id:id,w:w,h:h});
					$(".my_module_debug").hide();
					//var img=$(this).parents(".my_img_1").data('image');
					//self.my_debug("Img",img);
					//$(".my_timeline_modal").find(".my_slide_image .my_img_slide_inner").remove();
					//$(".my_timeline_modal").find(".my_slide_image").append('<img class="my_img_slide_inner" src="'+img+'"/>');
					//$(".my_timeline_modal").find(".my_slide_image").append('<div class="my_slide_image_inner"><img class="my_img_slide_inner" data-w="'+w+'" data-h="'+h+'" src="'+img+'"/></div>');
					var is_mc=$(".my_timeline_modal").find(".my_slide_image").attr('is-mc');
					var width = window.innerWidth;
					var height = window.innerHeight;
					var h1=$(".my_timeline_modal").find(".my_header").outerHeight();
					var h2=height-h1;
					$(".my_timeline_modal").find(".my_slide_image").height(h2);
					$(".my_view_item").hide();
					$(".my_view_item[data-key='"+type+"']").show();
					$(".my_module_shortcodes_form").hide();
					$(".my_module_shortcodes_form[data-key='"+type+"']").show();
					if(typeof is_mc=='undefined'){
						$(".my_timeline_modal").find(".my_slide_image").mCustomScrollbar({advanced:{
							updateOnContentResize:true
						}});
						$(".my_timeline_modal").find(".my_slide_image").attr('is-mc',1);
					}
					
					var hh=h;
					$(".my_options_form").height((h2-150));
					$(".my_options_form_inner").height((h2-150));
					var is_mc_1=$(".my_options_form").data('is-mc');
					if(typeof is_mc_1=='undefined'){
						
						$(".my_options_form_inner").mCustomScrollbar({advanced:{
							updateOnContentResize:true
						}});
						$(".my_options_form").data('is-mc',1);
						
					}
					myAdminDialog_inst.open_dialog();
				break;	
			}
		};
		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log('Admin Testimonials Front\n'+t,o);
				}
			}
		};
			this.init();
			
	}
})(jQuery);		