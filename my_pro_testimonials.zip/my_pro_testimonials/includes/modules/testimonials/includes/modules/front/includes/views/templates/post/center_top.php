<?php
if(!defined('ABSPATH'))die('');
$image=wp_my_front_testimonials_render_image($item,$my_url);
?>
<div class="my_timeline_item my_testimonial_item my_testimonial_center_top " data-float="<?php echo $float;?>">
	
	<div class="my_testimonial_meta_div my_clear_after">
	<div class="my_testimonial_meta my_clear_after">
		<div class="my_testimonial_meta_center_top">
			<?php 
			//if($float=='left'){
				?>
				
				<?php 
			/*}else {
			wp_my_front_testimonials_render_metadata($item);
			}*/
			?>
			<?php 
			/*if($float=='right'){
				?>
							<img class="my_testimonial_thumb" src="<?php echo $image?>"/>
							<?php 
						}else {
			*/
			//wp_my_front_testimonials_render_metadata($item);
			wp_my_front_testimonials_render_metadata($item,array());
			?>
			<img class="my_testimonial_thumb" src="<?php echo $image?>"/>
			
		</div>
	</div>
	</div>
	<div class="my_testimonial_text">
		
			<div class="my_arrow_border my_top_arrow_inner"> 
			</div>
			<div class="my_arrow my_top_arrow ">
			
			</div>
		<p class="my_testimonial_p">
		<?php echo $item['text'];?>
		</p>
	</div>
	
</div>