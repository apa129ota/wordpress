<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Module_Testimonials_Front')){
	class Class_My_Module_Testimonials_Front extends Class_My_General_Module{
		private $post_type;
		private $post_terms;
		private $post_type_key='my_testimonials';
		private $post_type_terms='my_testimonials_category';
		private $post_class;
		private $form_shortcode="my_testimonials_form";
		public $admin_forms;
		public $shortcodes;
		private $forms;
		private $is_admin_new=false;
		private $edit_styles;
		private $items;
		private $options_forms;
		private $ajax_action='my_testimonial_backend_front';
		private $saved_styles;
		private $user_styles;
		private $meta_module;
		private $saved_styles_type;
		private $is_front;
		private $shortocde_tag='my_testimonial';
		private $is_shortcode=false;
		private $shortcode_matches=array();
		private $shortcode_ids=array();
		private $shortcode_types=array();
		private $grid_pages;
		static $added_includes=false;
		private $include_fonts=array();
		function __construct($options=array()){
			$options['url']=plugin_dir_url(__FILE__);
			$options['dir']=plugin_dir_path(__FILE__);
			parent::__construct($options);
			
		
		}
		private function is_admin(){
			if(is_admin()){
				$page=@$_GET['page'];			
				if(!empty($page) || defined("DOING_AJAX")){
					if($page=='my_testimonials_add_new' || defined("DOING_AJAX")){
						if(!defined("DOING_AJAX")){
							$this->is_admin_new=true;
							$this->global_plugin->loadModuleClass('meta');
							$options=$this->global_plugin->loadOptions('meta_options.php');
							self::debug("meta_options", $options,false);
							$this->meta_module=new Class_My_Module_Meta($options);
							$this->saved_styles=$this->meta_module->getObjectTypes('style');
							$this->saved_styles_type=array(
								'slider'=>array(),
								'grid'=>array()	
							);
							if(!empty($this->saved_styles)){
								foreach($this->saved_styles as $k12=>$v12){
									$id_12=$v12->ID;
									$my_type=$this->meta_module->get_object_meta($id_12, 'type');
									if($my_type=='card_style'  || $my_type=='slider_style'){
										$this->saved_styles_type['slider'][]=$v12;
									}else $this->saved_styles_type['grid'][]=$v12;
									
								}
								
							}
							self::debug("saved_styles_type", $this->saved_styles_type);
						}
						$this->shortcodes=$this->loadOptions('shortcodes.php');
						self::debug("shortcodes", $this->shortcodes);
						$this->edit_styles=$this->loadOptions('styles.php');
						$url=$this->getUrl('images');
						$this->edit_styles['styles']['dark']['background_image']=$url.'background9.jpg';
						self::debug("styles", $this->edit_styles);
						$this->items=$this->global_plugin->events->loadOptions('default-items.php');
						self::debug("items", $this->items,false);
						global $wp_my_google_fonts_fonts;
						$this->edit_styles['default']['font-family']['values']=$wp_my_google_fonts_fonts;
					}
				}
			}
		}
		public function init($options=array()){
			$this->loadFunctions('functions.php');
			$this->is_admin();
			add_action('wp_ajax_my_testimonials_load_more',array(&$this,'load_more'));
			add_action('wp_ajax_nopriv_my_testimonials_load_more',array(&$this,'load_more'));
			add_shortcode($this->shortocde_tag,array($this,'shortcode'));
			if(is_admin()){
				$this->is_shortcode();
				add_action('admin_head', array($this,'admin_head'),PHP_INT_MAX);
				add_action('admin_enqueue_scripts',array($this,'admin_scripts'),PHP_INT_MAX);
				add_action('admin_footer',array($this,'admin_footer'),PHP_INT_MAX);
				add_action('wp_ajax_'.$this->ajax_action,array($this,'backend_ajax'));
			}else {
				
				
				
				add_action('wp',array(&$this,'is_shortcode'));
				add_action('wp_head', array($this,'admin_head'),PHP_INT_MAX);
				add_action('wp_enqueue_scripts',array($this,'admin_scripts'),PHP_INT_MAX);
			}
		}
		public function load_more(){
			$id=@$_POST['id'];
			$page=@$_POST['page'];
			$nonce=@$_POST['nonce'];
			$ret['error']=0;
			$ret['msg']=__("Error","my_support_theme");
			
			if(!wp_verify_nonce($nonce,"my_testimonials_load_more_".$id)){
				$ret['error']=1;
				
			}else {
				$this->global_plugin->loadModuleClass('meta');
				$options=$this->global_plugin->loadOptions('meta_options.php');
				self::debug("meta_options", $options,false);
				$this->meta_module=new Class_My_Module_Meta($options);
				$is=$this->meta_module->get_object($id);
				if(empty($is)){
					$ret['error']=1;
					
				}else {
					if($is->object_type!='shortcode'){
						$ret['error']=1;
					}else {
						$form=$this->global_plugin->events->loadOptions('form.php');
						self::debug("form", $form);
						$meta_keys=array();
						foreach($form as $key=>$val){
							if(empty($val['front'])){
								$meta_keys[]=$key;
							}
						}
						$type=$this->meta_module->get_object_meta($id, 'type');
						$settings=$this->meta_module->get_object_meta($id, 'array');
						$options=$this->generateQueryArray($settings, $type);
						$options['paged']=$page;
						$my_wp_query=new WP_Query($options);
						if($my_wp_query->have_posts()){
							while($my_wp_query->have_posts()){
								$my_wp_query->the_post();
								$arr=array();
								$post_id=get_the_ID();
								$thumb=get_post_thumbnail_id($post_id);
								if(!empty($thumb)){
									$arr['thumb_id']=$thumb;
								}
								$arr['text']=get_the_content();
								$meta=$this->getItemMetadata($post_id, $meta_keys);
								if(!empty($meta)){
									foreach($meta as $k1234=>$v1234){
										$arr[$k1234]=$v1234;
									}
								}
								$items[]=$arr;
							}
							$my_url='';
							self::debug("shortcode_items", $items);
							$my_c_12_123=$settings['per_page']*($page-1)+1;
							
							$views_dir=$this->getDir('views');
							$templ_file=$this->getDir('views').'single_grid_post.php';
							ob_start();
							require $templ_file;
							$ret['html']=ob_get_clean();
							$ret['error']=0;
							
						
						}else {
							$ret['error']=1;
						}
						
						//return $items;
						
					}
					
				}
			}
			echo json_encode($ret);
			exit('');
		}
		private function getItemMetadata($post_id,$keys){
			$prefix='_my_testimonials_1_';
			$arr=array();
			foreach($keys as $key=>$val){
				$k=$prefix.'_'.$val;
				$arr[$val]=get_post_meta($post_id,$k,true);
			}
			self::debug("meta_".$post_id, $arr);
			return $arr;
		}
		private function getShortcodeItems($settings=array(),$type,$id){
			static $my_ident_1234=0;
			$my_ident_1234++;
			$options=$this->generateQueryArray($settings,$type);
			$items=array();
			
			$my_wp_query=new WP_Query($options);			
			$form=$this->global_plugin->events->loadOptions('form.php');
			self::debug("form", $form);
			$meta_keys=array();
			foreach($form as $key=>$val){
				if(empty($val['front'])){
					$meta_keys[]=$key;
				}
			}
			self::debug("meta_keys", $meta_keys);
			if($type=='grid'){
				$this->grid_pages[$id]=$my_wp_query->max_num_pages;
			}
			if($my_wp_query->have_posts()){
				while($my_wp_query->have_posts()){
					$my_wp_query->the_post();
					$arr=array();
					$post_id=get_the_ID();
					$thumb=get_post_thumbnail_id($post_id);
					if(!empty($thumb)){
						$arr['thumb_id']=$thumb;
					}
					$arr['text']=get_the_content();
					$meta=$this->getItemMetadata($post_id, $meta_keys);
					if(!empty($meta)){
						foreach($meta as $k1234=>$v1234){
							$arr[$k1234]=$v1234;
						}
					}
					$items[]=$arr;
				}
			}
			self::debug("shortcode_items", $items);
			return $items;
			
		}
		private function updatedShortcodeSettings($settings,$type){
			self::debug("shortcodes_settings", $settings);
			if($type=='slider' || $type=='card'){
				$settings['thumbs_show']=array('{stars}');
				$settings['layout_cols']=3;
				$settings['nav_type']='circle';
				$settings['show_text_border']=1;
				$style=$settings['style'];
				$settings['form']=array(
					'autoplay'=>$settings['autoplay'],
					'autoplay_timeout'=>(int)$settings['autoplay_timeout'],
					'show_nav'=>$settings['show_nav'],
					'show_thumbs'=>$settings['show_thumbs'],
					'start_item'=>1,
					'circle_hover_color'=>'#08b9f3',
					'circle_back_color'=>'#ccc',
					'circle_duration'=>400,
					//'scroll_metadata'=>$settings['scroll_metadata'],
						
				);
				if($style=='dark'){
					$settings['form']['circle_hover_color']='#dd5555';
					$settings['form']['circle_back_color']='#70747d';
					
				}else if($style=='gray'){
					
				}else if($style=='light'){
					$settings['form']['circle_hover_color']='#dd5555';
					$settings['form']['circle_back_color']='#70747d';
				}else {
					
				}
				if($type=='slider'){
					$height=$settings['layout_1600_height'].$settings['layout_1600_type'];
					$layout=array(
						'1600'=>array(
								'height'=>'500px',
								'cols'=>1
						),
						'1280'=>array(
								'height'=>'500px',
								'cols'=>1
						),
						'980'=>array(
								'height'=>'500px',
								'cols'=>1
						),
						'700'=>array(
								'height'=>'500px',
								'cols'=>1
						),
						'small'=>array(
								'height'=>'500px',
								'cols'=>1
						)

				);
					foreach($layout as $key=>$val){
						$settings['layout'][$key]=$val;
						$settings['layout'][$key]['height']=$height;
					}
				}else {
					$t=array('small','700','980','1280','1600');
					$settings['layout']=array();
					foreach($t as $k1=>$v1){
						$cols=$settings['layout_'.$v1.'_cols'];
						$h=$settings['layout_'.$v1.'_height'].$settings['layout_'.$v1.'_type'];
						$settings['layout'][$v1]=array(
							'height'=>$h,
							'cols'=>$cols	
						);
					}
				}
			}else {
				$t=array('small','700','980','1280','1600');
				$settings['layout']=array();
				foreach($t as $k1=>$v1){
					$cols=$settings['layout_'.$v1.'_cols'];
					$h=$settings['layout_'.$v1.'_height'].$settings['layout_'.$v1.'_type'];
					$settings['layout'][$v1]=array(
							'height'=>$h,
							'cols'=>$cols
					);
				}
				$settings['thumbs_show']=array('{stars}');
				$settings['layout_cols']=3;
				$settings['nav_type']='circle';
				$settings['show_text_border']=1;
				$style=$settings['style'];
				$settings['form']=array(
						'start_item'=>1,
						'per_page'=>$settings['per_page'],
						//'scroll_metadata'=>$settings['scroll_metadata'],
				);
			}
			self::debug("parsed_settings", $settings);
			return $settings;
		}
		private function generateQueryArray($settings,$type){
			
			if($type=='slider' || $type=='card'){
				$limit=$settings['limit'];
				$arr=array(
						'post_type'=>'my_testimonials',
						'post_status'=>'publish',
						'posts_per_page'=>$limit,
				);
				$cat=$settings['category'];
				$order_by=$settings['order_by'];
				$order=$settings['order'];
				if(empty($order))$order='DESC';
				else $order="ASC";
				if($order_by=='post_date'){
					$arr['orderby']='date';
					$arr['order']=$order;
				}else {
					$arr['orderby']='meta_value_num';
					$arr['order']=$order;
					$arr['meta_key']='_my_testimonials_1__stars';
				}
				
				if($cat!='all'){
					$arr['tax_query'] = array(
							array(
									'taxonomy' => 'my_testimonials_category',
									'field'    => 'term_id',
									'terms'    => $cat
							)
					);
				}
				self::debug("query_arr", $arr);
				return $arr;
			}else {
				$limit=$settings['per_page'];
				$arr=array(
						'post_type'=>'my_testimonials',
						'post_status'=>'publish',
						'posts_per_page'=>$limit,
				);
				$cat=$settings['category'];
				$order_by=$settings['order_by'];
				$order=$settings['order'];
				if(empty($order))$order='DESC';
				else $order="ASC";
				if($order=='post_date'){
					$arr['orderby']='post_date';
					$arr['order']=$order;
				}else {
					$arr['orderby']='meta_value_num';
					$arr['order']=$order;
					$arr['meta_key']='_my_testimonials_1__stars';
				}
			
				if($cat!='all'){
					$arr['tax_query'] = array(
							array(
									'taxonomy' => 'my_testimonials_category',
									'field'    => 'term_id',
									'terms'    => $cat
							)
					);
				}
				self::debug("query_arr", $arr);
				return $arr;
				
			}
		}
		public function shortcode($attrs){
			extract($attrs);
			$views_dir=$this->getDir('views');
			ob_start();
			if(!empty($this->shortcode_ids[$id])){
				$my_url='';
				$type=$this->shortcode_ids[$id]['type'];
				$settings=$this->shortcode_ids[$id]['array'];
				//$settings=$this->updatedShortcodeSettings($settings, $type);
				//$settings['nav_type']='circle';
				if($type=='slider' || $type=='card'){
					$items=$this->getShortcodeItems($settings,$type,$id);
					$templ_file=$this->getDir('views').'card.php';
					require $templ_file;
					
					
				}else {
					
					$items=$this->getShortcodeItems($settings,$type,$id);
					$pages=$this->grid_pages[$id];
					$page=1;
					$templ_file=$this->getDir('views').'grid.php';
					require $templ_file;
				}
			}
			self::debug("grid_pages",$this->grid_pages);
			$html=ob_get_clean();
			return $html;
		}
		public function is_shortcode(){
			//if(is_admin()){
				$page=@$_GET['my_testimonial_preview'];
				$my_id=@$_GET['my_id'];
				if(!empty($page)){
					//if($page=='my_testimonials_preview'){
						
						$options=$this->global_plugin->loadOptions('meta_options.php');
						self::debug("meta_options", $options,false);
						if(empty($this->meta_module)){
							$this->global_plugin->loadModuleClass('meta');
							$options=$this->global_plugin->loadOptions('meta_options.php');
							self::debug("meta_options", $options,false);
							$this->meta_module=new Class_My_Module_Meta($options);
						}
						//$this->meta_module=new Class_My_Module_Meta($options);
						$this->is_shortcode=true;
						$id=$my_id;
						//self::debug("id", array('id'=>$id,'m'=>$m));
						$object=$this->meta_module->get_object($id);
						$type=$this->meta_module->get_object_meta($id, 'type');
						if(!in_array($type,$this->shortcode_types))$this->shortcode_types[]=$type;
						$array=$this->meta_module->get_object_meta($id, 'array');
						self::debug("shortcode_id",
								array(
										'id'=>$id,
										'object'=>$object,
										'type'=>$type,
										'array'=>$array
								)
						);
						if(!empty($object)&&$object->object_type=='shortcode'){
							$array=$this->updatedShortcodeSettings($array, $type);
							$style=$array['style'];
							$style_arr=array();
							$style_css=array();
							if(!in_array($style,array('light','dark','gray'))){
								$style_object=$this->meta_module->get_object($style);
								if($style_object->object_type=='style'){
									$style_arr=$this->meta_module->get_object_meta($style, 'style');
									$style_css=$this->meta_module->get_object_meta($style, 'css');
									$settings['form']['circle_hover_color']=$style_arr['arrows_hover_color'];
									$settings['form']['circle_back_color']=$style_arr['arrows_background_color'];
								}
							}
							//$settings['form']['scroll_metadata']=$settings['scroll_metadata'];
							
								
							$this->shortcode_ids[$id]=array(
									'type'=>$type,
									'array'=>$array,
									'style'=>$style_arr,
									'style_css'=>$style_css
							);
						}
			//			}
				//}
				
			
			}else if(!is_admin()) {
			$post_id=get_queried_object_id();
			$my_post=get_post($post_id);
			if(!empty($my_post)){
				if(preg_match_all('/\['.$this->shortocde_tag.'[^\[]+\]/ims', $my_post->post_content,$all_matches)){
					$this->shortcode_matches=$all_matches[0];
					if(!empty($this->shortcode_matches)){
					
					self::debug("shortcode_matches", $this->shortcode_matches,false);
					$this->global_plugin->loadModuleClass('meta');
					$options=$this->global_plugin->loadOptions('meta_options.php');
					self::debug("meta_options", $options,false);
					$this->meta_module=new Class_My_Module_Meta($options);
					foreach($this->shortcode_matches as $k=>$v){
						$m=$v;
						if(preg_match('/id=\"([\d]+)\"/ims', $m,$matches)){
							$this->is_shortcode=true;
							$id=$matches[1];
						self::debug("id", array('id'=>$id,'m'=>$m));
						$object=$this->meta_module->get_object($id);
						$type=$this->meta_module->get_object_meta($id, 'type');
						if(!in_array($type,$this->shortcode_types))$this->shortcode_types[]=$type;
						$array=$this->meta_module->get_object_meta($id, 'array');
						self::debug("shortcode_id", 
							array(
								'id'=>$id,
								'object'=>$object,
								'type'=>$type,
								'array'=>$array			
							)
						);
						if(!empty($object)&&$object->object_type=='shortcode'){
							$array=$this->updatedShortcodeSettings($array, $type);
							$style=$array['style'];
							$style_arr=array();
							$style_css=array();
							if(!in_array($style,array('light','dark','gray'))){
								$style_object=$this->meta_module->get_object($style);
								if($style_object->object_type=='style'){
									$style_arr=$this->meta_module->get_object_meta($style, 'style');
									$style_css=$this->meta_module->get_object_meta($style, 'css');
									$settings['form']['circle_hover_color']=$style_arr['arrows_hover_color'];
									$settings['form']['circle_back_color']=$style_arr['arrows_background_color'];
								}
							}
						//	$settings['form']['scroll_metadata']=$settings['scroll_metadata'];
								
							$this->shortcode_ids[$id]=array(
								'type'=>$type,
								'array'=>$array,
								'style'=>$style_arr,
								'style_css'=>$style_css			
							);
						}
						}
					}
					self::debug("shortcode_ids", $this->shortcode_ids);
				}
				}
			}
			$sidebar_widgets=wp_get_sidebars_widgets();
			self::debug("sidebar_widgets", $sidebar_widgets);
			global $wp_registered_widgets;
			self::debug("register_widgets", $wp_registered_widgets);
			//foreach($sidebar_widgets as $key=>$val){
			//	if(is_active_sidebar($key)){
			$opts=array();
			foreach($wp_registered_widgets as $k1=>$v1){
				
				//self::debug("active_sidebar", $val);
					//$widget_options=get_option('my_testimonials_widget');
					//self::debug("my_widget_optons", $widget_options);
					//foreach($val as $k1=>$v1){
						if(strpos($k1,'my_testimonials_widget')===0){
							$this->is_shortcode=true;
							$widget_id=str_replace('my_testimonials_widget-', '', $k1);
							$params=$v1;//$wp_registered_widgets[$k1];
							self::debug("widget_params", $params);
							//print_r($params['callback'][0]);
							$option_name='';
							/*if(!empty($params['callback'][0]->number)){
								$widget_id=$params['callback'][0]->number;
							}*/
							self::debug("widget_id", $widget_id);
							if(!empty($params['callback'][0]->option_name)){
								$option_name=$params['callback'][0]->option_name;
								//$opts=
								if(empty($opts))$opts=get_option($option_name);
								self::debug("option_name", $option_name);
								self::debug("options", $opts);
								$widget_opt=array();
								if(!empty($opts[$widget_id]))$widget_opt=$opts[$widget_id];
								if(!empty($widget_opt['shortcode'])){
									$id=$widget_opt['shortcode'];
									if(!empty($this->shortcode_ids[$id])){
										unset($wp_registered_widgets[$k1]);
										continue;
									}
									if(empty($this->meta_module)){
										$this->global_plugin->loadModuleClass('meta');
										$options=$this->global_plugin->loadOptions('meta_options.php');
										self::debug("meta_options", $options,false);
										$this->meta_module=new Class_My_Module_Meta($options);
									}
								//self::debug("id", array('id'=>$id,'m'=>$m));
								$object=$this->meta_module->get_object($id);
								$type=$this->meta_module->get_object_meta($id, 'type');
								if(!in_array($type,$this->shortcode_types))$this->shortcode_types[]=$type;
								$array=$this->meta_module->get_object_meta($id, 'array');
								self::debug("shortcode_id",
										array(
												'id'=>$id,
												'object'=>$object,
												'type'=>$type,
												'array'=>$array
										)
								);
								if(!empty($object)&&$object->object_type=='shortcode'){
									$array=$this->updatedShortcodeSettings($array, $type);
									$style=$array['style'];
									$style_arr=array();
									$style_css=array();
									//if($type=='card' || $type=='slider' || $type=''){
										if(($array['template']!='center_top')&&($array['template']!='center_bottom')){
											$array['template']='center_bottom';
										}
									//}
									if(!in_array($style,array('light','dark','gray'))){
										$style_object=$this->meta_module->get_object($style);
										if($style_object->object_type=='style'){
											$style_arr=$this->meta_module->get_object_meta($style, 'style');
											$style_css=$this->meta_module->get_object_meta($style, 'css');
											$settings['form']['circle_hover_color']=$style_arr['arrows_hover_color'];
											$settings['form']['circle_back_color']=$style_arr['arrows_background_color'];
										}
									}
									//$settings['form']['scroll_metadata']=$settings['scroll_metadata'];
										
									$this->shortcode_ids[$id]=array(
											'type'=>$type,
											'array'=>$array,
											'style'=>$style_arr,
											'style_css'=>$style_css,
											'widget'=>1
									);
								}
								}
							}
								
						}
					}
		
			}
		}
		public function backend_ajax(){
			$this->global_plugin->loadController("class-my-general-controller.php");
			$ajax_options=$this->loadOptions("ajax_actions.php");
			$this_options=$ajax_options['backend'];
			$this_options['module_class']=$this;
			$this_options['plugin_object']=$this->global_plugin;
			$this_options['nonce_str']=$this->get_ajax_nonce_str($this->ajax_action);
				
			self::debug("ajax_options", $this_options);
			/*self::debug("session",$_SESSION,false);
			self::debug("session_name", $this->session_name,false);
			*/
			$this->routeAjax($this_options);
		}
		public function admin_footer(){
			if($this->is_admin_new){
				$shortcodes=$this->shortcodes;
				$styles=$this->edit_styles;
				$file=$this->getDir('views').'edit_styles.php';
				$items=$this->items;
				$my_set_debug=$this->debug;
				$views_dir=$this->getDir('views');
				$my_url=$this->global_plugin->events->getUrl('images');
				$options_forms=$this->options_forms;
				if(file_exists($file)){
					require $file;
				}
				$file=$this->getDir('views').'save_style_dialog.php';
				if(file_exists($file)){
					require $file;
				}
				$file=$this->getDir('views').'load_style_dialog.php';
				$styles=$this->saved_styles;
				if(file_exists($file)){
					require $file;
				}
				$file=$this->getDir('views').'preview_dialog.php';
				if(file_exists($file)){
					require $file;
				}
				
				
				//require $file;
			}
			
		}
		public function admin_scripts(){
			
			$url=$this->getUrl('jscript');
			if($this->is_shortcode){
				wp_enqueue_script('jquery');
				wp_enqueue_script("jquery-touch-pounch");
				wp_enqueue_script('jquery-effects-core');
				$url=$this->css_url;
				$css=$url.'card.css';
				wp_enqueue_style("my_testimonials_front_card",$css);
				$css=$url.'general.css';
				
				wp_enqueue_style("my_testimonials_front_general",$css);
				$j_url=$this->jscript_url;
				$css=$url.'themes/light.css';
				wp_enqueue_style("my_testimonials_front_card_light",$css);
				$css=$url.'themes/dark.css';
				wp_enqueue_style("my_testimonials_front_card_dark",$css);
				if((in_array('slider', $this->shortcode_types))||(in_array('card', $this->shortcode_types))){
					$url=$j_url.'myProSlider.js';
					wp_enqueue_script('my_testimonials_front_proslidcer_js',$url);
				}
				if((in_array('grid', $this->shortcode_types))){
					$url=$j_url.'myGrid.js';
					wp_enqueue_script('my_testimonials_front_grid_js',$url);
				}
				$j_url=$this->global_plugin->getUrl('jscript');
				wp_enqueue_script('my_testimoninials_mcustom_scrollbar_js',$j_url.'jquery.mCustomScrollbar.js');
				//$c_url=$this->global_plugin->getUrl('css');
				wp_enqueue_style('my_testimoninials_mcustom_scrollbar_css',$j_url.'jquery.mCustomScrollbar.css');
				wp_enqueue_script('my_testimonials_easing',$j_url.'jquery.easing.1.3.js');
				wp_enqueue_script('my_testimonials_mousewheel',$j_url.'jquery.mousewheel.js');
			}
			if($this->is_admin_new){
				wp_enqueue_script('jquery');
				wp_enqueue_script("jquery-touch-pounch");
				wp_enqueue_script('jquery-ui-core');
				wp_enqueue_script("jquery-ui-widget");
				wp_enqueue_script("jquery-ui-dialog");
				wp_enqueue_script('jquery-effects-core');
				wp_enqueue_script("wp_my_testomonials_front_admin_js",$url.'my_admin.js');
				//$css_url=$this->global_plugin->getUrl('css');
				
				$url=$this->css_url;
				$css=$url.'card.css';
				wp_enqueue_style("my_testimonials_front_card",$css);
				$css=$url.'general.css';
				
				wp_enqueue_style("my_testimonials_front_general",$css);
				
				/*$css=$url.'themes/orange.css';
				
				wp_enqueue_style("my_testimonials_front_orange",$css);
				*/	
				
				//$css=$url.'themes/default_card.css';
				//wp_enqueue_style("my_testimonials_front_theme_card",$css);
				
				//$css=$url.'themes/light.css';
				//wp_enqueue_style("my_testimonials_front_card_light",$css);
				//$css=$url.'themes/dark.css';
				//wp_enqueue_style("my_testimonials_front_card_dark",$css);
				
				
				$css=$url.'admin.css';
				wp_enqueue_style("my_testimonials_front_admin",$css);
				$j_url=$this->jscript_url;
				$url=$j_url.'general.js';
				wp_enqueue_script('my_testimonials_front_general_js',$url);
				$url=$j_url.'myProSlider.js';
				wp_enqueue_script('my_testimonials_front_proslidcer_js',$url);
				$url=$j_url.'myGrid.js';
				wp_enqueue_script('my_testimonials_front_grid_js',$url);
				$url=$this->global_plugin->getUrl('jscript').'admin/my_ajax.js';
				wp_enqueue_script('my_framework_ajax',$url);
				$url=$this->global_plugin->getUrl('jscript').'admin/admin_msgs.js';
				wp_enqueue_script("my_framework_msgs",$url);
				$url=$this->global_plugin->getUrl('css').'msgs.css';
				wp_enqueue_style("my_testimonials_msgs_form",$url);
				
				
			}
		}
		public function admin_head(){
			if(self::$added_includes)return;
			if($this->is_shortcode){
				foreach($this->shortcode_ids as $key=>$val){
					$settings=$this->shortcode_ids[$key]['array'];
					$style_css=$this->shortcode_ids[$key]['style_css'];
					$style_arr=$this->shortcode_ids[$key]['array'];
					$id=$key;
					
					$my_set_debug=0;
					if($this->debug)$my_set_debug=1;
					if(isset($_GET['my_set_debug_123_4567_190'])){
						$my_set_debug=1;
					}
					if(!empty($style_arr['font-family'])){
						$f123=$style_arr['font-family'];
						if($f123!='default'){
							$this->include_fonts[]=$f123;
							self::debug("included_fonts", $f123);
						}
					}
					if(!empty($style_css)){
						?>
						<style type="text/css" id="myTimelineCss<?php echo $id;?>">
							<?php foreach($style_css as $key1=>$val1){?>
							<?php 
							$css=$val1['css'];
							$prep='';
							if(!empty($val1['prep'])){
								$prep=$val1['prep'];
								$prep=str_replace('{id}', $id, $prep);
							}
							echo $prep.' '.$css;
							?>
							
							<?php }?>
							
						</style>
						<?php 
					}
					/*if(empty($settings['scroll_metadata'])){
						?>
						<style type="text/css" id="myTimelineCssNoScroll<?php echo $id;?>">
							#my_timeline_<?php echo $id?> .my_testimonial_meta_data_div > ul , .my_testimonials_metadata > ul{
								width:100%;
							}
							#my_timeline_<?php echo $id?> .my_testimonial_meta_data_div > ul > li ,.my_testimonials_metadata > ul > li{
								width:100%;
								height:25% !important;
							}
							#my_timeline_<?php echo $id?> .my_testimonial_meta_data_div > ul > li span, .my_testimonials_metadata > ul > li span{
								text-overflow:ellipsis;
								display:block;
								overflow:hidden;
	 							white-space: nowrap; 
								width:100%;
							}
						</style>
						
						<?php 
					}*/
					if($settings['shadow']=='on-hover'){
						?>
						<style type="text/css" id="myTimelineCss1<?php echo $id;?>">
							#my_timeline_<?php echo $id;?> .my_testimonial_item{
							box-shadow:none !important;
							border:1px solid  rgba(0, 0, 0, 0.247059);
							}
							#my_timeline_<?php echo $id;?> .my_testimonial_item:hover{
								 box-shadow: rgba(0, 0, 0, 0.247059) 0px 14px 45px, rgba(0, 0, 0, 0.219608) 0px 10px 18px !important;
   								 -webkit-box-shadow: rgba(0, 0, 0, 0.247059) 0px 14px 45px, rgba(0, 0, 0, 0.219608) 0px 10px 18px !important;
   								-moz-box-shadow: rgba(0, 0, 0, 0.247059) 0px 14px 45px, rgba(0, 0, 0, 0.219608) 0px 10px 18px !important;
  
							}
							
						</style>
						<?php 
					}else if($settings['shadow']=='hide'){
					
					}
					if(($this->shortcode_ids[$id]['type']=='slider')||($this->shortcode_ids[$id]['type']=='card')){
					?>
						<script type="text/javascript">
							jQuery(document).ready(function($){
									$(window).load(function(e){
											my_timeline_o_<?php echo $id?>={};
											my_timeline_o_<?php echo $id?>.swipeOn=<?php echo $settings['swipeOn'];?>;
											my_timeline_o_<?php echo $id?>.template="";
											my_timeline_o_<?php echo $id?>.debug=<?php echo $my_set_debug;?>;
											my_timeline_o_<?php echo $id?>.preview=<?php echo '0'?>;
											my_timeline_o_<?php echo $id?>.mobile=<?php $f=wp_is_mobile();if(!empty($f))echo '1';else echo '0';?>;
											my_timeline_o_<?php echo $id?>.ajax_timeout=30000;
											my_timeline_o_<?php echo $id?>.id="<?php echo $id;?>";
											my_timeline_o_<?php echo $id?>.ajax_url="<?php echo admin_url('admin-ajax.php');?>";
											my_timeline_o_<?php echo $id?>.ajax_action="<?php echo 'my_timeline_load_post'?>";
											my_timeline_o_<?php echo $id?>.ajax_nonce="<?php echo wp_create_nonce('my_timeline_load_post_'.$id);?>";								
											my_timeline_o_<?php echo $id?>.form={};
											my_timeline_o_<?php echo $id?>.form=<?php echo json_encode($settings['form']);?>;
											my_timeline_o_<?php echo $id?>.start_item=1;								
											my_timeline_o_<?php echo $id?>.layout=<?php echo json_encode($settings['layout']);?>;
											$("#my_timeline_<?php echo $id?>").myproslider(my_timeline_o_<?php echo $id;?>);
									});
							});
						</script>
						<?php 	
					}else {
						?>
						<script type="text/javascript">
							jQuery(document).ready(function($){
									$(window).load(function(e){
										my_timeline_o_<?php echo $id?>={};
										my_timeline_o_<?php echo $id?>.template="";
										my_timeline_o_<?php echo $id?>.debug=<?php echo $my_set_debug;?>;
										my_timeline_o_<?php echo $id?>.preview=<?php echo '0'?>;
										my_timeline_o_<?php echo $id?>.mobile=<?php $f=wp_is_mobile();if(!empty($f))echo '1';else echo '0';?>;
										my_timeline_o_<?php echo $id?>.ajax_timeout=30000;
										my_timeline_o_<?php echo $id?>.id="<?php echo $id;?>";
										my_timeline_o_<?php echo $id?>.ajax_url="<?php echo admin_url('admin-ajax.php');?>";
										my_timeline_o_<?php echo $id?>.ajax_action="<?php echo 'my_testimonials_load_more'?>";
										my_timeline_o_<?php echo $id?>.ajax_nonce="<?php echo wp_create_nonce('my_testimonials_load_more_'.$id);?>";								
										my_timeline_o_<?php echo $id?>.form={};
										my_timeline_o_<?php echo $id?>.form=<?php echo json_encode($settings['form']);?>;
										my_timeline_o_<?php echo $id?>.start_item=1;								
										my_timeline_o_<?php echo $id?>.layout=<?php echo json_encode($settings['layout']);?>;
										$("#my_timeline_<?php echo $id;?>").myGrid(my_timeline_o_<?php echo $id;?>);
									});
							});
						</script>
						
						<?php 
					}
						
				}
				if(!empty($this->include_fonts)){
					foreach($include_fonts as $k=>$v){
						?>
						<link id="my_testimonial_fonts_css" rel="stylesheet" href="https://fonts.googleapis.com/css?family=<?php echo urlencode($v)?>"/>
						<?php 
					}
				}
			}
			if($this->is_admin_new){
				$my_set_debug=0;
				if($this->debug){
					$my_set_debug=1;
				}
				$msgs=$this->loadOptions('admin_msgs.php');
				$styles=$this->edit_styles;
				$translate=array();
				foreach ($styles['default'] as $k=>$v){
					if(isset($v['translate']))
					$translate[$k]=$v['translate'];
				}
				$options=$this->global_plugin->loadOptions("ajax_options.php");
				if(isset($_GET['my_id'])){
					$is_id=1;//$_GET['my_id'];
				
				}else $is_id='';
				$preview_url=$this->getUrl('views').'preview_iframe.php?my_testimonial_preview=1&my_id={id}';
				//$preview_url=admin_url('admin.php?page=my_testimonials_preview&my_id={id}')
				?>
				<script type="text/javascript">
				jQuery(document).ready(function($){
							var o_ajax=<?php echo json_encode($options);?>;
							
							myGlobalAjaxClass_inst=new myGlobalAjaxClass(o_ajax);
							var o3={};
							myAdminMsgs_inst=new myAdminMsgs(o3);
							
							var o1={};
							o1.my_debug=<?php echo $my_set_debug;?>;
							o1.animation='fade';
							o1.duration=300;
							myAdminDialog_inst=new myDialog(o1);
							var o2={};
							o2.translate=<?php echo json_encode($translate);?>;
							o2.my_debug=<?php echo $my_set_debug;?>;
							o2.msgs=<?php echo json_encode($msgs);?>;
							o2.styles=<?php echo json_encode($styles['styles'])?>;
							o2.ajax_action='<?php echo $this->ajax_action;?>';
							o2.is_id='<?php echo $is_id;?>';
							o2.preview_url="<?php echo $preview_url;?>";
							myAdminTestimonialsFrontAdmin_inst=new myAdminTestimonialsFrontAdmin(o2);
							
							
						
							});
				</script>				
				<?php 
				}
			self::$added_includes=true;
		}
		public function getShortcodeElements($key){
			$default_elements=$this->shortcodes['default']['elements'];
			$elements=array();
			$def=$this->shortcodes[$key]['default'];
			$default_layout=$this->shortcodes['layout'];
			foreach($def as $key1=>$val1){
				if($val1=='layout'){
					foreach($default_layout as $k2=>$v2){
					$elements[$k2]=$v2;
				}
			}
			else $elements[$val1]=$default_elements[$val1];
			}
			return $elements;
		}
		public function getStylesElements($key){
			$styles=$this->edit_styles;
			self::debug("my_edit_styles", $styles,false);
			$default_elements=$styles['default'];
			self::debug("my_default_elements", $default_elements,false);
			self::debug("my_shortcodes", $this->shortcodes,false);
			if(!empty($styles['shortcodes'][$key])){
				$obj=$styles['shortcodes'][$key];
				$elements=array();
				$el_vals=$obj['styles'];
				$title=$obj['title'];
				foreach($el_vals as $keyV=>$valV){
					$elements[$valV]=$default_elements[$valV];
				}
				return $elements;
			}else {
				$msg=__("Shortcode don't exists","my_support_theme");	
				trigger_error($msg,E_USER_NOTICE);
				return false;	
			}
		}
		public function admin_forms(){
			
			
			$this->global_plugin->loadModuleClass('new_form');
			$default_elements=$this->shortcodes['default']['elements'];
			$default_layout=$this->shortcodes['layout'];
			$post_cats=$this->global_plugin->events->get_categories();
			
			if(!empty($post_cats)){
				foreach($post_cats as $key=>$val){
					$default_elements['category']['values'][$val->term_id]=$val->name;
				}
			}
			$my_set_debug=$this->debug;
			$my_set_debug=0;
			self::debug("shortcodes", $this->shortcodes,false);
			$id='';
			//echo 'Id '.$id;
			
			if(!empty($_GET['my_id'])){
				$id=@$_GET['my_id'];
				//echo 'Id '.$id;
				$object=$this->meta_module->get_object($id);
				//print_r($object);
				self::debug("shortcocde_object", $object,false);
				self::debug("my_id", $id,false);
				if($object->object_type!='shortcode'){
					unset($object);
					unset($id);
				}else {
					$short_type=$this->meta_module->get_object_meta($id, 'type');
				}	
				self::debug("shortcode_type", $short_type,false);
				
			}
			foreach($this->shortcodes as $key=>$val){
				if(isset($short_type)){
					if($key!=$short_type)continue;
				}
				if($key=='layout' || $key=='default')continue;
				$this->admin_forms[$key]=array(
					'html'=>'',
					'title'=>$val['title']	
				);
				$elements=array();
				$def=$val['default'];
				foreach($def as $key1=>$val1){
					if($val1=='layout'){
						foreach($default_layout as $k2=>$v2){
							$elements[$k2]=$v2;
						}
					}
					else $elements[$val1]=$default_elements[$val1];
				}
				$my_styles=array();
				$my_styles_pre=array();
				if(!empty($elements['style'])){
					if($key=='grid'){
						if(!empty($this->saved_styles_type['grid'])){
							$my_styles_pre=$this->saved_styles_type['grid'];
							}
					}else {
							$my_styles_pre=$this->saved_styles_type['slider'];
					}
					}
				if(!empty($my_styles_pre)){
					foreach($my_styles_pre as $k123=>$v123){
						$elements['style']['values'][$v123->ID]=$v123->title;
					}
				}	
				if(isset($short_type)){
					$options=$this->meta_module->get_object_meta($id, 'array');
					self::debug("Saved_options", $options,false);
					foreach($elements as $key12=>$val12){
						if(isset($options[$key12]))$elements[$key12]['value']=$options[$key12];
					}
				}
				$options=array(
						'id'=>$key,
						'elements'=>$elements,
						'hidden'=>array(
								'my_nonce'=>wp_create_nonce($key),
								'id'=>$id
						),
						'element_template'=>'my_li.php',
						'form_template'=>'my_form.php',
						'my_debug'=>$my_set_debug
				);
				$this->forms[$key]=new Class_Wp_My_Module_New_Form($options);
				ob_start();
				$this->forms[$key]->render_form();
				$this->admin_forms[$key]['html']=ob_get_clean();
				
			}
			$styles=$this->edit_styles;
			$default_elements=$styles['default'];
			if(isset($default_elements['font-family'])){
				global $wp_my_google_fonts_fonts;
				$default_elements['font-family']['values']=$wp_my_google_fonts_fonts;
			}
							foreach($this->shortcodes as $sh=>$shVal){?>
							<?php if(isset($styles['shortcodes'][$sh])){
								$obj=$styles['shortcodes'][$sh];
								$elements=array();
								$el_vals=$obj['styles'];
								$title=$obj['title'];
								foreach($el_vals as $keyV=>$valV){
									$elements[$valV]=$default_elements[$valV];
								}
								$options=array(
											
										'hidden'=>array(
												'my_nonce'=>wp_create_nonce("shortcodes_module"),
												'my_section'=>$sh,
												'id'=>'',
										),
										'id'=>$sh.'_style',
										'my_debug'=>$my_set_debug,
										'elements'=>$elements,
										'element_template'=>'my_li_1.php',
										'form_template'=>'my_form_1.php'
								);
						$class=new Class_Wp_My_Module_New_Form($options);
						$this->options_forms[$sh]['class']=$class;
						ob_start();
						$class->render_form();
						$this->options_forms[$sh]['html']=ob_get_clean();
							
			}
			}
		}
	}
}
