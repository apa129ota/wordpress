jQuery(document).ready(function($){
	$(window).load(function(e){
		my_resize_testimonial_view=function(e){
			$(".my_testimonial_item").each(function(i,v){
				var h=$(v).height();
				console.log('Height item',h);
				if($(v).hasClass('my_testimonial_top') || $(v).hasClass('my_testimonial_bottom')){
					var h1=$(v).find(".my_testimonial_meta_div").outerHeight();
					console.log('Height meta div',h1);
					
					var h2=h-h1;
					console.log('Height text item',h2);
					
					$(v).find(".my_testimonial_text").height(h2+'px');
				}else {
					
				}
			});
		};
		//my_resize_testimonial_view();
		//$(window).resize(my_resize_testimonial_view);
	/*$(".my_testimonial_p").mCustomScrollbar({
	    axis:"y" // horizontal scrollbar
	});*/
	
	});
});