<?php
if(!defined('ABSPATH'))die('');
function my_register_foo_widget() {
	register_widget( 'My_Testimonials_Widget' );
}
add_action( 'widgets_init', 'my_register_foo_widget' );
class My_Testimonials_Widget extends WP_Widget {

	/**
	 * Sets up the widgets name etc
	 */
	public function __construct() {
		$widget_ops = array(
				'classname' => 'my_testimonials_widget',
				'description' => 'Widget for displaying testimonials',
		);
		parent::__construct( 'my_testimonials_widget', 'My Testimonials Widget', $widget_ops );
	}

	/**
	 * Outputs the content of the widget
	 *
	 * @param array $args
	 * @param array $instance
	 */
	public function widget( $args, $instance ) {
		// outputs the content of the widget
	}

	/**
	 * Outputs the options form on admin
	 *
	 * @param array $instance The widget options
	 */
	public function form( $instance ) {
		// outputs the options form on admin
		global $Class_My_Framework_Main_Class;
		$shortcodes=$Class_My_Framework_Main_Class->events->getShortcodes();
		$instance = wp_parse_args( (array) $instance, array('title' => '', 'shortcode' => '') );
		?>
				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php _e( 'Title:' ); ?></label>
					<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('title') ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>" />
				</p>
				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'shortcode' ) ); ?>"><?php _e( 'Shortcode' ); ?></label>
					<select name="<?php echo $this->get_field_name('shortcode')?>" id="<?php echo $this->get_field_id('shortcode')?>">
						<option value=""><?php echo __("Select shortcode","my_support_theme")?></option>.
						<?php if(!empty($shortcodes)){
							foreach($shortcodes as $k=>$v){
								?>
						<option value="<?php echo $v->ID?>"><?php echo $v->title;?></option>		
								<?php 	
							}
						}?>
					</select>
				</p>
		<?php 		
	}

	/**
	 * Processing widget options on save
	 *
	 * @param array $new_instance The new options
	 * @param array $old_instance The previous options
	 */
	public function update( $new_instance, $old_instance ) {
		// processes widget options to be saved
	}
}