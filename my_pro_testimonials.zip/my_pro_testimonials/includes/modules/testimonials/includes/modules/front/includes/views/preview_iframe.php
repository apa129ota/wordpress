<?php

require '../../../../../../../../../../../wp-blog-header.php';
if(!defined('ABSPATH'))die('');
$my_id=@$_GET['my_id'];
@header('Content-Type: ' . get_option('html_type') . '; charset=' . get_option('blog_charset'));
?>
<html>
	<head>
		<?php echo wp_head();?>
		<style type="text/css">
			body{
				background-color:white !important;
			}
		</style>
	</head>
	<body>
	<?php 
		echo do_shortcode('[my_testimonial id="'.$my_id.'"]');
	?>
	<?php if(class_exists('Class_My_Module_Debug')){?>
		<?php Class_My_Module_Debug::admin_footer();?>
	<?php }?>
	</body>
</html>
