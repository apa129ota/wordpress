<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_dialog_preview">
<div class="my_header_dialog">
<h4 class="my_no_margin"><?php  echo __("Preview","my_support_theme")?></h4>
			<div class="my_timeline_modal_close_1">
				<i class="fa fa-close"></i>
			</div>
	</div>
	<div class="my_dialog_form my_shortcode_content">
		<div class="my_load_preview" style="text-align:center">
			<h4><?php  echo __("Loading preview","my_support_theme")?><i class="fa-spin fa fa-spinner"></i></h4>
		</div>
		<iframe src="" style="display:none;" class="my_preview_iframe"></iframe>
	</div>
	
</div>