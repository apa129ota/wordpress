<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_dialog_load_style">
	<div class="my_header_dialog">
		<h4 class="my_no_margin"><?php  echo __("Load Style","my_support_theme")?></h4>
			<div class="my_timeline_modal_close_1">
				<i class="fa fa-close"></i>
			</div>
	</div>
	<div class="my_dialog_form my_shortcode_content">
		<ul>
			<li>
			<label for="my_style_id"><?php echo __("Select style","my_support_theme")?></label>
			</li>
			<li>
				<select name="my_style_id" id="my_style_id">
					<option value=""><?php echo __("Select Saved styles","my_support_theme") ?></option>
					<?php if(!empty($styles)){?>
						<?php foreach($styles as $k12=>$v12){?>
						<option value="<?php echo $v12->ID?>"><?php echo $v12->title?></option>
						<?php }?>
					<?php }?>
				</select>
			</li>
			<li>
				<input class="button  button-large my_action" type="button" data-key="load_style" value="<?php  echo __("Load Style","my_support_theme") ?>"/>
				
			</li>
			
			
		</ul>
	</div>
	
</div>