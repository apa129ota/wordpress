<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_module_testimonials" id="my_new_css">
</div>
<div class="my_timeline_modal">
	<div class=" my_header my_no_margin" style="margin-bottom: 10px;">
		<h4 class="my_no_margin"><?php echo __("Edit styles","my_support_theme")?></h4>
		<div class="my_timeline_modal_close">
			<i class="fa fa-close"></i>
		</div>
		
	</div>
	<div class="my_timeline_modal_content">
		<div class="my_options_form">
			<div class="my_slide_in_out">
				<i class="fa fa-angle-double-left" style="display:none"></i>
				<i class="fa fa-angle-double-right"></i> 
			</div>
			<div class="my_options_form_inner">
			<?php $c12=0; 
				foreach($options_forms as $sh=>$shVal){
					$obj=$styles['shortcodes'][$sh];
					$title=$obj['title'];
				?>
					<div class="my_module_shortcodes_form" data-key="<?php echo esc_attr($sh)?>" style="<?php if($c12>0)echo 'display:none';?>">
						<h4><?php echo $title?></h4>
						<div class="my_save_div" style="text-align: center;">
							<h4 class="my_saved_style_title" style="text-align: center;display:none;"></h4><br/>
							<input class="button  button-large my_action" type="button" data-key="load_style_dialog" value="<?php  echo __("Load style","my_support_theme") ?>"/>
							<input class="button  button-large my_action" type="button" data-key="new_style" value="<?php  echo __("New style","my_support_theme") ?>"/>	
							<input class="button  button-large my_action" type="button" data-key="save_style_dialog" value="<?php  echo __("Save Style","my_support_theme") ?>"/>
						</div>
						<?php echo $shVal['html'];?>
					</div>
					
				<?php 	
				}?>
			<?php /*global $wp_my_module_forms;
			$c12=0;
			foreach($wp_my_module_forms as $key=>$val){
				?>
				<div class="my_module_shortcodes_form" data-key="<?php echo esc_attr($key)?>" style="<?php if($c12>0)echo 'display:none';?>">
					<?php echo $val;?>
				</div>
				<?php 
				$c12++;
			}	*/
			?>
			</div>
		</div>
		<?php /*
		<div class="my_timeline_modal_loading">
			<span><?php echo __("Loading","my_related_posts_domain").' ... ';?><img src="<?php echo MY_RELATED_POSTS_IMAGES_URL.'wpspin.gif';?>"/></span>
		</div>
		*/ ?>
		<div class="my_timeline_modal_load my_flex_display">
			<div class="my_flex_display my_slide_image" style="">
				<?php 
				$c12=0;
				foreach($shortcodes as $sh=>$shVal){
					if(isset($styles['shortcodes'][$sh])){
					$settings=$styles['shortcodes'][$sh]['settings'];
					$file=$views_dir.''.$sh.'.php';
				?>
				<div class="my_view_item" data-key="<?php echo $sh;?>" style="<?php if($c12>0)echo 'display:none;'; ?>">
				<?php 
				if(file_exists($file)){
				require $file;
				}else echo  $file;
				?>
				
				</div>
				
				<?php
				$c12++; 
				}
				}?>
				<?php /*<div class="my_slide_image_overlay my_transition">
					<ul>
						<li><a href="#javascript" class="my_transition"><i class="fa fa-plus"></i></a>
					</ul>
				</div>
				*/ ?>
			</div>
			<?php /*
			<div class="my_flex_display my_sidebar my_border_one my_h_100 my_bg">
				
				<?php /*<ul class="my_window_actions">
						<li class="my_transition"><a href="#javascript" class="my_transition my_add_element"><i class="fa fa-plus"></i><span><?php echo __("Add Element","my_support_theme") ?></span></a></li>
						
				</ul>
				
				<div class="my_elemenet_section">
					<h4><a href="#javascript" class="my_transition my_open_section"><i class="fa fa-plus"></i><span><?php echo __("Template options","my_support_theme") ?></span></a></h4>
				
				<div class="my_section_inside">
				<ul class="my_window_actions">
							<li style="text-align:center"><span><?php echo __("Select Element","my_support_theme")?></span></li>
							<?php 
						/*	global $my_shortcodes;
							if(!empty($my_shortcodes)){
								foreach($my_shortcodes as $key=>$val){
								?>
								<li class="my_transition"><a href="#javascript" title="<?php echo esc_attr($val['tooltip'])?>" class="my_transition my_add_shortcode" data-key="<?php echo esc_attr($key)?>"><i class="fa <?php echo $val['icon']?>"></i><span><?php echo $val['title'];?></span></a></li>
								<?php 
								}
							}
							?>
				</ul>
				</div>
				</div>		
				<ul class="my_element_actions">
					
				</ul>
			</div>
			*/?>
			<?php //my_new_form_footer();?>
		</div>
	</div>
</div>	