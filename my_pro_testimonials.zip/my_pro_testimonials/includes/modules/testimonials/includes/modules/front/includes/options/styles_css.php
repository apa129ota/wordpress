<?php
if(!defined('ABSPATH'))die('');
$style_css['gray']=array(
	'load_more'=>'.my_testimonial_load_more{
	
	color:white;
	text-align:center;
	border:1px solid white;
	border-radius:5px;
	-moz-border-radius:5px;
	-o-border-radius:5px;
	-webkit-border-radius:5px;
	background-color:rgba(204,204,204,1) !important;
	/*border:2px solid rgba(204,204,204,0.6);*/
	min-width:200px;
	width:200px;
	margin:auto;
	}',	
	'shadow'=>'.my_testimonial_card .my_testimonial_item, .my_testimonial_shortcode_div .my_testimonial_item {
	/*border:1px solid #ccc;*/
	 box-shadow: rgba(0, 0, 0, 0.247059) 0px 14px 45px, rgba(0, 0, 0, 0.219608) 0px 10px 18px;
    -webkit-box-shadow: rgba(0, 0, 0, 0.247059) 0px 14px 45px, rgba(0, 0, 0, 0.219608) 0px 10px 18px;
   -moz-box-shadow: rgba(0, 0, 0, 0.247059) 0px 14px 45px, rgba(0, 0, 0, 0.219608) 0px 10px 18px;
   -webkit-transition: box-shadow 0.3s; 
   -moz-transition: box-shadow 0.3s; 
   transition: box-shadow 0.3s;
	zoom: 1;
	filter: progid:DXImageTransform.Microsoft.Shadow(Color=#888888, Strength=0, Direction=0),
		progid:DXImageTransform.Microsoft.Shadow(Color=#888888, Strength=5, Direction=90),
		progid:DXImageTransform.Microsoft.Shadow(Color=#888888, Strength=5, Direction=180),
		progid:DXImageTransform.Microsoft.Shadow(Color=#888888, Strength=0, Direction=270);
 padding:10px;	
	overflow:hidden;
	width:100%;
	
	}',
	'shadow_hover'=>'.my_testimonial_card .my_testimonial_item:hover, .my_testimonial_shortcode_div .my_testimonial_item:hover {
	/*border:1px solid #ccc;*/
	 box-shadow: rgba(0, 0, 0, 0.247059) 0px 14px 45px, rgba(0, 0, 0, 0.219608) 0px 10px 18px;
    -webkit-box-shadow: rgba(0, 0, 0, 0.247059) 0px 14px 45px, rgba(0, 0, 0, 0.219608) 0px 10px 18px;
   -moz-box-shadow: rgba(0, 0, 0, 0.247059) 0px 14px 45px, rgba(0, 0, 0, 0.219608) 0px 10px 18px;
   -webkit-transition: box-shadow 0.3s; 
   -moz-transition: box-shadow 0.3s; 
   transition: box-shadow 0.3s;
	zoom: 1;
	filter: progid:DXImageTransform.Microsoft.Shadow(Color=#888888, Strength=0, Direction=0),
		progid:DXImageTransform.Microsoft.Shadow(Color=#888888, Strength=5, Direction=90),
		progid:DXImageTransform.Microsoft.Shadow(Color=#888888, Strength=5, Direction=180),
		progid:DXImageTransform.Microsoft.Shadow(Color=#888888, Strength=0, Direction=270);
 padding:10px;	
	overflow:hidden;
	width:100%;
	
	}',
			
);
$style_css['dark']=array(
		'load_more'=>'.my_testimonial_load_more{
		
	color:white;
	text-align:center;
	border:1px solid white;
	border-radius:5px;
	-moz-border-radius:5px;
	-o-border-radius:5px;
	-webkit-border-radius:5px;
	background-color:rgba(204,204,204,1) !important;
	/*border:2px solid rgba(204,204,204,0.6);*/
	min-width:200px;
	width:200px;
	margin:auto;
	}',
		'shadow'=>'.my_testimonial_card .my_testimonial_item, .my_testimonial_shortcode_div .my_testimonial_item {
	/*border:1px solid #ccc;*/
	 box-shadow: rgba(0, 0, 0, 0.247059) 0px 14px 45px, rgba(0, 0, 0, 0.219608) 0px 10px 18px;
    -webkit-box-shadow: rgba(0, 0, 0, 0.247059) 0px 14px 45px, rgba(0, 0, 0, 0.219608) 0px 10px 18px;
   -moz-box-shadow: rgba(0, 0, 0, 0.247059) 0px 14px 45px, rgba(0, 0, 0, 0.219608) 0px 10px 18px;
   -webkit-transition: box-shadow 0.3s;
   -moz-transition: box-shadow 0.3s;
   transition: box-shadow 0.3s;
	zoom: 1;
	filter: progid:DXImageTransform.Microsoft.Shadow(Color=#888888, Strength=0, Direction=0),
		progid:DXImageTransform.Microsoft.Shadow(Color=#888888, Strength=5, Direction=90),
		progid:DXImageTransform.Microsoft.Shadow(Color=#888888, Strength=5, Direction=180),
		progid:DXImageTransform.Microsoft.Shadow(Color=#888888, Strength=0, Direction=270);
 padding:10px;
	overflow:hidden;
	width:100%;

	}',
		'shadow_hover'=>'.my_testimonial_card .my_testimonial_item:hover, .my_testimonial_shortcode_div .my_testimonial_item:hover {
	/*border:1px solid #ccc;*/
	 box-shadow: rgba(0, 0, 0, 0.247059) 0px 14px 45px, rgba(0, 0, 0, 0.219608) 0px 10px 18px;
    -webkit-box-shadow: rgba(0, 0, 0, 0.247059) 0px 14px 45px, rgba(0, 0, 0, 0.219608) 0px 10px 18px;
   -moz-box-shadow: rgba(0, 0, 0, 0.247059) 0px 14px 45px, rgba(0, 0, 0, 0.219608) 0px 10px 18px;
   -webkit-transition: box-shadow 0.3s;
   -moz-transition: box-shadow 0.3s;
   transition: box-shadow 0.3s;
	zoom: 1;
	filter: progid:DXImageTransform.Microsoft.Shadow(Color=#888888, Strength=0, Direction=0),
		progid:DXImageTransform.Microsoft.Shadow(Color=#888888, Strength=5, Direction=90),
		progid:DXImageTransform.Microsoft.Shadow(Color=#888888, Strength=5, Direction=180),
		progid:DXImageTransform.Microsoft.Shadow(Color=#888888, Strength=0, Direction=270);
 padding:10px;
	overflow:hidden;
	width:100%;

	}',
			
);
$style_css['light']=array(
		'load_more'=>'.my_testimonial_load_more{
		
	color:white;
	text-align:center;
	border:1px solid white;
	border-radius:5px;
	-moz-border-radius:5px;
	-o-border-radius:5px;
	-webkit-border-radius:5px;
	background-color:rgba(204,204,204,1) !important;
	/*border:2px solid rgba(204,204,204,0.6);*/
	min-width:200px;
	width:200px;
	margin:auto;
	}',
		'shadow'=>'.my_testimonial_card .my_testimonial_item, .my_testimonial_shortcode_div .my_testimonial_item {
	/*border:1px solid #ccc;*/
	 box-shadow: rgba(0, 0, 0, 0.247059) 0px 14px 45px, rgba(0, 0, 0, 0.219608) 0px 10px 18px;
    -webkit-box-shadow: rgba(0, 0, 0, 0.247059) 0px 14px 45px, rgba(0, 0, 0, 0.219608) 0px 10px 18px;
   -moz-box-shadow: rgba(0, 0, 0, 0.247059) 0px 14px 45px, rgba(0, 0, 0, 0.219608) 0px 10px 18px;
   -webkit-transition: box-shadow 0.3s;
   -moz-transition: box-shadow 0.3s;
   transition: box-shadow 0.3s;
	zoom: 1;
	filter: progid:DXImageTransform.Microsoft.Shadow(Color=#888888, Strength=0, Direction=0),
		progid:DXImageTransform.Microsoft.Shadow(Color=#888888, Strength=5, Direction=90),
		progid:DXImageTransform.Microsoft.Shadow(Color=#888888, Strength=5, Direction=180),
		progid:DXImageTransform.Microsoft.Shadow(Color=#888888, Strength=0, Direction=270);
 padding:10px;
	overflow:hidden;
	width:100%;

	}',
		'shadow_hover'=>'.my_testimonial_card .my_testimonial_item:hover, .my_testimonial_shortcode_div .my_testimonial_item:hover {
	/*border:1px solid #ccc;*/
	 box-shadow: rgba(0, 0, 0, 0.247059) 0px 14px 45px, rgba(0, 0, 0, 0.219608) 0px 10px 18px;
    -webkit-box-shadow: rgba(0, 0, 0, 0.247059) 0px 14px 45px, rgba(0, 0, 0, 0.219608) 0px 10px 18px;
   -moz-box-shadow: rgba(0, 0, 0, 0.247059) 0px 14px 45px, rgba(0, 0, 0, 0.219608) 0px 10px 18px;
   -webkit-transition: box-shadow 0.3s;
   -moz-transition: box-shadow 0.3s;
   transition: box-shadow 0.3s;
	zoom: 1;
	filter: progid:DXImageTransform.Microsoft.Shadow(Color=#888888, Strength=0, Direction=0),
		progid:DXImageTransform.Microsoft.Shadow(Color=#888888, Strength=5, Direction=90),
		progid:DXImageTransform.Microsoft.Shadow(Color=#888888, Strength=5, Direction=180),
		progid:DXImageTransform.Microsoft.Shadow(Color=#888888, Strength=0, Direction=270);
 padding:10px;
	overflow:hidden;
	width:100%;

	}',
			
);