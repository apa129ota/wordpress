<?php
if(!defined('ABSPATH'))die('');
if(!isset($id)){
	$my_not_id=1;
	$id=1000000;//mt_rand(pow(10,2),pow(10,4));
}
$layout_cols=$settings['layout_cols'];
$w123=ceil((100/$layout_cols)*(count($items)))+100;
$my_c_12_123=1;
$template=$settings['template'];
$template_file=$views_dir.'templates/post/'.$template.'.php';
$float=$settings['float'];
$my_show_shadow=false;
if( $settings['shadow']=='hover' || $settings['shadow']=='show'){
	$my_show_shadow=true;
	
}
if(!isset($settings['style'])){
	$settings['style']='gray';
}
if(isset($settings['style'])){
	//if(in_array($settings['style'],array('light','gray') ))
}
?>
<div class="myTimelineTheme<?php echo $settings['style'];?>">
	<div class="my_testimonial_shortcode_div">
		<?php //if(isset($my_not_id)){?>
			<style type="text/css">
				<?php echo wp_my_front_testimonials_styles('card',$settings);?>
			</style>
		<?php // }?>
		<?php if(!empty($settings['show_thumbs'])&&($settings['thumbs_pos']=='above')){?>
			<div class="my_testimonal_thumbs_div" data-id="<?php echo $id;?>">
			<?php 
				if($settings['thumbs_pos']=='above'){
					$file=$views_dir.'thumbs.php';
				require $file;
				}
			?>
			</div>
	<?php }?>

<div class="my_testimonial_shortcode my_timiline_hor_div my_testimonial_card" id="my_timeline_<?php echo esc_attr($id);?>">
	
	<?php if(!empty($settings['show_nav'])){?>
		<?php if($settings['nav_type']=='circle'){?>
		<div class="my_line_nav my_timeline_hor_list_nav_left my_nav my_nav_left my_timeline_slider_nav_1" data-type="left">
			
			<span class="my_nav_arrow"><i class="fa fa-angle-left"></i></span>
			<span class="my_nav_item"></span>
		</div>
		<div class="my_testimonial_next my_testimonial_next_left">
			<div>
				<div>
				</div>
			</div>
		</div>
		<div class="my_testimonial_next my_testimonial_next_rigth">
			<div>
			<div></div>
			</div>
		</div>
		
			<div class="my_line_nav my_timeline_hor_list_nav_right my_nav my_nav_right my_timeline_slider_nav_1" data-type="right">
				<span class="my_nav_arrow"><i class="fa fa-angle-right"></i></span>
				<span class="my_nav_item"></span>
			</div>
	
		<?php }else if($settings['nav_type']=='rectangle'){?>
		
		<?php }?>
	<?php }?>
	<div class="my_timeline_hor_out_div">
	<ul class="my_timeline_hor_ul" data-id="<?php echo esc_attr($id)?>" data-c="<?php $c_p_12=count($items);echo $c_p_12;?>" style="width:<?php echo $w123.'%'?>">
	<?php $my_start_12_123=1; ?>
	<?php foreach($items as $itemKey=>$item){
	if(!isset($itemVal['post_id']))$post_id=$my_start_12_123;
	else $post_id=$itemVal['post_id'];	
	?>
	<li data-pos="<?php echo esc_attr($my_start_12_123);$my_start_12_123++;?>" data-post-id="<?php echo esc_attr($post_id);?>" data-i="<?php echo $my_c_12_123++;?>" class="my_timeline_li_class"   id="<?php echo 'my_timeline_id_'.$post_id;?>">
	<?php require $template_file;?>
	</li>
	<?php }?>
	
	</ul>
	</div>
</div>
<?php if(!empty($settings['show_thumbs'])&&$settings['thumbs_pos']=='below'){?>
<div class="my_testimonal_thumbs_div" data-id="<?php echo $id;?>">
<?php 
			if($settings['thumbs_pos']=='below'){
			$file=$views_dir.'thumbs.php';
			require $file;
			}
		?>
</div>
<?php }?>

	
<?php 
if(is_admin()&&!isset($_GET['my_testimonial_preview'])){
?>
	<script type="text/javascript">
jQuery(document).ready(function($){
	$(window).load(function(e){
								my_timeline_o_<?php echo $id?>={};
								my_timeline_o_<?php echo $id?>.edit_styles=1;								
								my_timeline_o_<?php echo $id?>.template="";
								my_timeline_o_<?php echo $id?>.debug=<?php echo $my_set_debug;?>;
								my_timeline_o_<?php echo $id?>.preview=<?php echo '0'?>;
								my_timeline_o_<?php echo $id?>.mobile=<?php $f=wp_is_mobile();if(!empty($f))echo '1';else echo '0';?>;
								my_timeline_o_<?php echo $id?>.ajax_timeout=30000;
								my_timeline_o_<?php echo $id?>.id="<?php echo $id;?>";
								my_timeline_o_<?php echo $id?>.ajax_url="<?php echo admin_url('admin-ajax.php');?>";
								my_timeline_o_<?php echo $id?>.ajax_action="<?php echo 'my_timeline_load_post'?>";
								my_timeline_o_<?php echo $id?>.ajax_nonce="<?php echo wp_create_nonce('my_timeline_load_post_'.$id);?>";								
								my_timeline_o_<?php echo $id?>.form={};
								my_timeline_o_<?php echo $id?>.form=<?php echo json_encode($settings['form']);?>;
								my_timeline_o_<?php echo $id?>.start_item="";								
								my_timeline_o_<?php echo $id?>.layout=<?php echo json_encode($settings['layout']);?>;
								//$("#my_timeline_<?php echo $id;?>").myproslider(my_timeline_o_<?php echo $id?>);
	});
								});
						</script>
<?php 
}
?>		
	</div>
</div>
<?php 
unset($id);
?>
	
	