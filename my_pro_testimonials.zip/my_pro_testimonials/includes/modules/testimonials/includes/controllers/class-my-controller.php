<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Testimonials_Front_Controller')){
	class Class_My_Testimonials_Front_Controller extends Class_My_General_Controller{
		use MyDebug;
		
		private $use_case='my_framework';
		private $module_class;
		function __construct($options=array()){
			if(!empty($options['debug'])){
				self::setDebugOptions($this->use_case);
			}
			$this->module_class=$options['module_class'];
			unset($options['module_class']);
			self::debug('testimonials_front_controller', $options,false);
			parent::Class_My_General_Controller($options);
			//$this->ret['my_debug']=Class_My_Module_Debug::get_debug_source($this->use_case);	
		}
		public function route_ajax(){
			parent::route_ajax();
			if($this->debug){
				if(!empty($this->ajax_errors)){
					self::debug("errors", $this->ajax_errors,false);		
				}
			}
			if($this->debug){
				//$this->ret['debug']=Class_My_Module_Debug::get_debug_source($this->use_case);
			}
			echo json_encode($this->ret);
			
			die('');	
		}
		private function checkCaptcha($name='my_captcha',$value=''){
			$recaptcha=$this->plugin_object->options->getOptionByKey('recaptcha');
			if(!empty($recaptcha)){
				$key=$this->plugin_object->options->getOptionByKey('recaptcha_private_key');
				if(!empty($key)){
					$this->plugin_object->loadModuleClass('recaptcha');
					if(empty($value)){
						$capctha=@$_REQUEST[$name];
					}else $capctha=$value;
					self::debug("capctha_key", $key,false);
					$ok=wp_my_recaptcha_check_response($capctha,$key);
					self::debug("capctha", $capctha,false);
					if(is_array($ok)){
						//return false;
						$this->ret['error']=1;
						$this->ret['msg']=__("Recapctha is not valid.","my_support_theme");
						return false;
					}
				}
					
			}
			return true;
		}
		protected function add_testimonial(){
			$form_data_str=@$_POST['form_data'];
			$form_data=array();
			parse_str($form_data_str,$form_data);
			$form_prefix='my_test_metabox';
			$nonce='';
			$captcha_name='g-recaptcha-response';
			$captcha_value=$form_data[$captcha_name];
			if(isset($form_data['my_nonce_'.$form_prefix])){
				$nonce=$form_data['my_nonce_'.$form_prefix];
			}
			$this->ret['error']=1;
			$this->ret['msg']=__("Error","my_support_theme");
			if(!wp_verify_nonce($nonce,$this->nonce_str)){
				$this->ret['error']=1;
				$this->ret['msg']=__("Error","my_support_theme");
				self::debug("error_nonce", "Error nonce".$nonce);
				self::debug("error_nonce",$this->nonce_str);
			}else {
				if(!$this->checkCaptcha($captcha_name,$captcha_value)){
					
				}else {
					$error=$this->module_class->ajax_form_validate($form_data);
					if($error===true){
						//insert post
						$old_file=$this->module_class->getSessionVar("my_file");
						self::debug("old_file", $old_file,false);
						if(empty($old_file)){
							$this->ret['error']=1;
							$this->ret['msg']=__("Image is required","my_support_theme");
						}else {
							$dir=$this->plugin_object->getDir('tmp').'uploads/'.$old_file;
							if(!file_exists($dir)){
								$this->ret['error']=1;
								$this->ret['msg']=__("Image is required","my_support_theme");
							}else {
							$my_id=$form_data['my_id'];
							if(empty($my_id)){
								$this->ret['error']=1;
								$this->ret['msg']=__("Error","my_support_theme");
									
							}else {
							$my_cat_id=$form_data['my_category'];
							$my_cat_id1=$this->module_class->getSessionVar('my_form_cat_'.$my_id);
							$form_data['my_category']=$my_cat_id1;
							$this->module_class->front_save($form_data);
							$this->ret['error']=0;
							$this->ret['msg']=__("Testimonial has been added.","my_support_theme");
							}
							}
						}	
					}else {
						
						$this->ret['error']=1;
						$this->ret['msg']=__("Form has errors, Please correct them !","my_support_theme");
						$this->ret['errors']=$error['errors'];
					}
				}
			}
		}
		protected function add_thumb(){
			$upload_optons=array(
				'debug'=>$this->debug,
				'upload_name'=>'async-upload',
				'allowed'=>array(
					'size'=>pow(10,6),
					'types'=>array('jpg','jpeg','png','gif'),
					
					'image'=>1			
				),
				'upload_dir'=>$this->plugin_object->getDir('tmp').'uploads/',
					
			);
			self::debug("upload_options", $upload_optons,false);
			$this->module_class->module_class->loadClass('class-my-image.php');
			$nonce=@$_POST['my_nonce'];
			self::debug("posts_array", $_POST,false);
			self::debug("files", $_FILES);
			if(!$this->checkCaptcha()){
				
			}else {
			/*	
			if(!wp_verify_nonce($nonce,$this->nonce_str)){
				$this->ret['error']=1;
				$this->ret['msg']=__("Error","my_support_theme");
				self::debug("error_nonce", "Error nonce".$nonce);
			}else {
				*/
			if(!$this->module_class->isCookiesEnabled()){
				$this->ret['error']=1;
				$this->ret['msg']=__("Please enable cookies, form will not work without cookies.","my_support_theme");
			}else{
				
				$class=new Class_My_Module_Testimonials_Image_Upload($upload_optons);
				$r=$class->checkUploadFile();
			$old_file=$this->module_class->getSessionVar("my_file");
			
			self::debug("upload", $_FILES,false);
			self::debug("r", $r);
			self::debug("old_file", $old_file,false);	
			if(is_string($r)){
				$this->ret['error']=1;
				$this->ret['msg']=$r;
			}else {
				
				$file=$class->moveTmpFile();
				if($file===false){
					$this->ret['error']=1;
					$this->ret['msg']=__("Error","my_support_theme");
				}else {
					$this->module_class->setSessionVariable('my_file',$file,true);
					if(!empty($old_file)){
						if(file_exists($old_file)){
							unlink($old_file);			
						}
					}
					$this->ret['error']=0;
					$this->ret['msg']=__("Image has been uploaded","my_support_theme");
				}
				self::debug("file_name", $file,false);
				self::debug("session", $_SESSION,false);
			}
			}
			}
			//}
		}
		protected function test_cookie(){
			//$this->module_class->setTestCookie();
			self::debug("cookies", $_COOKIE,false);
			$old_file=$this->module_class->getSessionVar("my_file");
			self::debug("oldf_file", $old_file,false);
			$this->ret=array();
			$this->ret['error']=0;
			if($this->debug){
				$this->ret['test_cookie']=$this->module_class->getCookie("my_testimonials_form");
			}
			if(!$this->module_class->isCookiesEnabled()){
				$this->ret['error']=1;
				$this->ret['html']='';
				ob_start();
				$this->module_class->module_class->loadViewFile('cookie_error.php');
				$this->ret['html']=ob_get_clean();
			}
		}
	}
}
		