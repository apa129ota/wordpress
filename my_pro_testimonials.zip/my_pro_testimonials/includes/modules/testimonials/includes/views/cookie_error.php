<?php
if(!defined('ABSPATH'))die('');
?>
<p class="my_form_error_msg_1">
<?php echo __("Your browser is not acception cookies please enable cookie to procced","my_support_theme")?>
</p>
