<?php
if(!defined('ABSPATH'))die('');
if(!$logged){
?>
<p class="my_form_msg_p">
<?php echo $msg_logged;?>
</p>
<?php }else {?>
<p class="my_form_msg_p">
<?php echo $msg;?>
</p>
<p class="my_form_msg_p">
<?php echo __("Form field with * is required.","my_support_theme");?>
</p>
<div class="my_testimonials_msgs">
</div>
<form method="post" id="my_testimonials_form_<?php echo $my_form_id?>" class="">
<input type="hidden" name="my_id" value="<?php echo $my_form_id;?>"/>
<?php 
global $wp_query;
$my_post_id=$wp_query->get_queried_object_id();
?>
<input type="hidden" name="my_post_id" value="<?php echo $my_post_id;?>"/>

<?php if(isset($cat)){?>
<input type="hidden" name="my_category" value="<?php echo $cat;?>"/>
<?php }?>
<?php if(!empty($hidden_arr)){?>
		<?php foreach($hidden_arr as $key=>$val){?>
		<input type="hidden" name="<?php echo  my_new_form_get_element_name($key,$id);?>" value="<?php echo esc_attr($val)?>"/>
		<?php }?>
	<?php }?>
	<ul>
<?php echo $html;?>
</ul>
<?php /*<input type="button" class="my_add_testimonial" value="<?php echo __("Submit","my_support_theme")?>"/>*/ ?>
</form>
<?php }?>
<?php 