<?php 
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Module_Testimonials')){
	class Class_My_Module_Testimonials extends Class_My_General_Module{
		use MySingleton;
		private $post_type;
		private $post_terms;
		private $post_type_key='my_testimonials';
		private $post_type_terms='my_testimonials_category';
		private $post_class;
		private $form_shortcode="my_testimonials_form";
		public $front_module;
		function __construct($options=array()){
			$options['url']=plugin_dir_url(__FILE__);
			$options['dir']=plugin_dir_path(__FILE__);
			parent::__construct($options);
		
		}
		public function deleteShortcodeObject($object_id){
			$this->global_plugin->loadModuleClass('meta');
			$options=$this->global_plugin->loadOptions('meta_options.php');
			self::debug("meta_options", $options,false);
			$meta_module=new Class_My_Module_Meta($options);
			$is=$meta_module->get_object($object_id);
			self::debug("delete_object",array('id'=>$object_id,'is'=>$is));
			//return false;
			if(!empty($is)){
				if($is->object_type=='shortcode'){
					$meta_module->delete_object($object_id,'shortcode');
					return true;
				}
			}else return false;
		}
		public function getShortcodes(){
			$this->global_plugin->loadModuleClass('meta');
			$options=$this->global_plugin->loadOptions('meta_options.php');
			$meta_module=new Class_My_Module_Meta($options);
			$shortcodes=$meta_module->getObjectTypes('shortcode');
			return $shortcodes;
		}
		public function editView(){
			$this->loadClass('class-my-view.php');
			$options_1=$this->loadOptions('view-options.php');
			$options_1['actions']['edit']['href']=admin_url('admin.php?page=my_testimonials_add_new');
			//$options=$this->get_module_options();
			//$options['post_type']=$this->post_type_key;
			//$options['post_terms']=$this->post_type_terms;
			//$options['post_columns']=$this->loadOptions('post-columns.php');
			$options['module_class']=$this;
			$options['global_plugin']=$this->global_plugin;
			$options['metaOptions']=$this->global_plugin->loadOptions('meta_options.php');
			$options['debug']=$this->debug;
			foreach($options_1 as $k=>$v){
				$options[$k]=$v;
				
			}
			$class=new Class_Wp_My_Testimonials_View_Class($options);
			$edit_view=$class->render();
			return $edit_view;
			
		}
		function init($options=array()){
			$this->loadClass("class-my-widget.php");
			/**
			 * Load front module
			 */
			
			/*if(is_admin()){
				if(defined("DOING_AJAX")){
					$this->loadModuleClass('front');
					$module_options=array(
							'dir'=>$this->global_plugin->getDir('modules').'testimonials/modules/front/',
							'url'=>$this->global_plugin->getUrl('modules').'testimonials/modules/front/',
							'debug'=>$this->debug,
							'global_plugin'=>$this->global_plugin
					);
					$this->front_module=new Class_My_Module_Testimonials_Front($module_options);
					$this->front_module->init();
				}
				
			}//else {
			*/
			
			$my_load_front=false;
			if(defined("DOING_AJAX")){
			$my_load_front=true;
			}
			$page=@$_GET['page'];
			if(in_array($page,array('my_testimonials_add_new')))$my_load_front=true;
			if(is_admin()){
				$page=@$_GET['my_testimonial_preview'];
				$my_id=@$_GET['my_id'];
				if(!empty($page)){
					//if($page=='my_testimonials_preview'){
						$my_load_front=true;
					//}
				}
			}else $my_load_front=true;
				$this->loadModuleClass('front');
				$module_options=array(
						'dir'=>$this->global_plugin->getDir('modules').'testimonials/modules/front/',
						'url'=>$this->global_plugin->getUrl('modules').'testimonials/modules/front/',
						'debug'=>$this->debug,
						'global_plugin'=>$this->global_plugin
				);
				$this->front_module=new Class_My_Module_Testimonials_Front($module_options);
				$this->front_module->init();
			//}
			
			parent::init($options);
			add_action('init',array($this,'wp_init'));
			$this->loadClass('class-my-post.php');
			$options=$this->get_module_options();
			$options['post_type']=$this->post_type_key;
			$options['post_terms']=$this->post_type_terms;
			$options['post_columns']=$this->loadOptions('post-columns.php');
			$options['module_class']=$this;
			$options['global_plugin']=$this->global_plugin;
			$options['form_shortcode']=$this->form_shortcode;
			self::debug("post_type_class_options", $options,false);
			$this->post_class=new Class_My_Module_Testimonials_Post_Type($options);
			$this->post_class->init();
		}
		public function getProperty($key){
			if(!isset($this->$key)){
				trigger_error(__("Property is not set","my_support_theme").' '.$key,E_USER_NOTICE);
			}else {
				return $this->$key;
			}
		}
		public function get_categories(){
			return get_terms($this->post_type_terms,array(
			'hide_empty'=>false
			));
		}
		public function edit_form_top(){
			global $post;
			self::debug("post", $post,false);
			if($post->post_type=='my_help'){
				$url=get_site_url().'?p='.$post->ID."&preview=1&my_visual_admin_bar=1";
			?>
			<h3><?php echo __("Save post as draft and you can use frontend builder to design post content.","my_support_theme")?>&nbsp;&nbsp;<a href="<?php echo $url ?>" target="_blank"><?php echo __("Frontend builder","my_support_theme")?></a></h3>
			<?php 
			}
		}
		/**
		 * Register post taxonomy
		 */
		public function wp_init(){
			$this->post_type=$this->loadOptions('post-type.php');
			self::debug("register_post_type", $this->post_type,false);
			register_post_type($this->post_type_key,$this->post_type);
			$this->post_terms=$this->loadOptions('post-terms.php');
			self::debug("register_post_terms", $this->post_terms,false);
			register_taxonomy($this->post_type_terms,$this->post_type_key, $this->post_terms);
				
		}
		
	}
}