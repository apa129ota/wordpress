<?php
if(!defined('ABSPATH'))die('');
$info=array(
		'title'=>'Testimonials',
		'description'=>'Module for adding testimonials',
		'class'=>'Class_My_Module_Testimonials',
		
);
return $info;