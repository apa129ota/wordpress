<?php
if(!defined('ABSPATH'))die('');
$info=array(
	'text'=>array(
	
	)
);
return $info;