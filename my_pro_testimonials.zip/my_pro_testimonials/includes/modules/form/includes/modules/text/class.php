<?php
if(!defined('ABSPATH'))die('');
if(!class_exists("Class_My_Element_Text")){
	class Class_My_Element_Text extends Class_My_General_Form_Element{
		use MyArrayOptions,MyDebug;
		private $placeholder;
		private $width;
		private $file='text';
		private $size;
		function __construct($options=array()){
			$this->setOptions($options);
			if($this->debug){
				self::setDebugOptions($this->use_case);
			}
			$element_div_class=array("my_form_text");
			if(!empty($this->element_div_class)){
				$element_div_class=array_merge($element_div_class,$this->element_div_class);
				$this->element_div_class=$element_div_class;
			}
			self::debug('init_elemnt_'.$this->form_id, $options,true);
			parent::__construct();
		}
		public function render($echo=true){
			parent::render();
			$html=$this->html;
			$value=$this->getValue();
			ob_start();
			?>
			<input <?php if(!empty($this->size))echo 'size="'.$this->size.'"'?> <?php if(!empty($this->placeholder))echo 'placeholder="'.esc_attr($this->placeholder).'"';?> type="text" id="<?php echo esc_attr($this->element_id);?>" name="<?php echo esc_attr($this->element_id);?>" value="<?php if(!empty($value))echo esc_attr($value);?>"/>
			<?php 
			$el_html=ob_get_clean();
			$html=str_replace('{html}', $el_html, $html);
			$this->html=$html;
			if($echo)echo $this->html;
		}
	}
}