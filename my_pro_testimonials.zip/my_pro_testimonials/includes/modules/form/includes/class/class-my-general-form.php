<?php
if(!defined('ABSPATH'))die('');
if(!class_exists("Class_My_General_Form_Element")){
	class Class_My_General_Form_Element{
		protected $form_id='';
		protected $key='';
		protected $name='';
		protected $id='';
		protected $type='';
		protected $element_id='';
		protected $element_div_id='';
		protected $element_div_class=array();
		protected $has_jscript=false;
		protected $layout='';
		protected $title='';
		protected $tooltip='';
		protected $jscript=array();
		protected $validate=array();
		protected $multi=false;
		protected $use_case='my_framework';
		protected $debug=0;
		protected $styles='';
		protected $value;
		protected $default;
		protected $elements_dir;
		protected $html='';
		function __construct($options=array()){
			$this->genName();
			$this->genId();
			$element_div_class=array("my_form_element");
			if(!empty($this->element_div_class)){
				$element_div_class=array_merge($element_div_class,$this->element_div_class);
				$this->element_div_class=$element_div_class;
			}
		}
		protected function genDivId(){
			$this->element_div_id=$this->element_div_id.'_div_id';
		}
		protected function genId(){
			$this->id=$this->name.'_id';
			$this->element_id=$this->id;
		}
		protected function genName(){
			$name=my_new_form_module_clean_key($this->key).'_'.$this->form_id;
			$this->name=$name;
		}
		public function getValue(){
			if(isset($this->value))return $this->value;
			else if(isset($this->default))return $this->default;
		}
		public function getProperty($key){
			
			if(isset($this->key))	
			return $this->$key;
			else return false;
			
		}
		public function renderElementData(){
			
			foreach($this->jscript as $key=>$var){
				$name='data-jscript-'.my_new_form_module_clean_key($key);
				if(!is_array($var)&&is_object($var)){
					echo $name.'="'.esc_attr($var).'"';
				}else {
					echo $name.'="'.json_encode($var).'"';
				}
			}
		}
		public function renderElementStyles(){
			if(!empty($this->styles)){
				$styles='';
				foreach($this->styles as $key=>$val){
					$styles.=$val.";";
				}
				return $styles;
			}else return '';
		}
		protected function render(){
			ob_start();
			?>
			<div data-base-name="<?php echo esc_attr($this->key);?>" id="<?php echo esc_attr($this->element_div_id);?>" data-type="<?php echo esc_attr($this->type);?>" data-open="<?php //if(!empty($element['open']))echo $element['open']; ?>" data-id="<?php echo esc_attr($this->id);?>" data-name="<?php echo esc_attr($this->name);?>" <?php if(!empty($this->validate))echo 'data-validate="'.json_encode($this->validate).'"'?> class="<?php if(!empty($this->element_div_class)){$str=implode(" ",$this->element_div_class);echo $str;}?>">
			{html}
			</div>
			<?php 
			$this->html=ob_get_clean();	
		}
		
		public function jscript_options(){
			
		}
	}
}