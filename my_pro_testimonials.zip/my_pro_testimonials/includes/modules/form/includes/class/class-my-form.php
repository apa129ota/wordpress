<?php
$dir=plugin_dir_path(__FILE__);
require_once $dir.'class_validate.php';
require_once $dir.'class-my-general-form.php';
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Module_Form_Class')){
	class Class_My_Module_Form_Class{
		use MyArrayOptions,MyDebug,MyLoadFiles;
		private $dir;
		private $url;
		private $form_id;
		private $modules_dir;
		private $views_dir;
		private $debug;
		private $id;
		private $classes;
		private $template='default';
		private $element_template='element.php';
		private $form_template='form.php';
		private $elements;
		private $hidden=array();
		private $layout=false;
		private $action='';
		private $upload=false;
		private $msgs=array();
		private $use_case='my_framework';
		private $has_sections;
		private $sections;
		private $elements_classes;
		private $sections_labels=array();
		private $values;
		private $html;
		static $my_id=0;
		static $called_scripts=false;
		static $jscript_elements;
		static $loaded_modules=array();
		static $color_pickers;
		static $modules=array();
		function __construct($options=array()){
			$this->setOptions($options);
			if($this->debug){
				self::setDebugOptions($this->use_case);
			}
			if(!empty($this->sections_labels)){
				$this->has_sections=true;
			}
			$this->modules_dir=$this->dir.'includes/modules/';
			$this->views_dir=$this->dir.'includes/views/'.$this->template.'/';
			self::$my_id++;
			$this->id=self::$my_id;
			if(isset($options['id'])){
				$this->id=$options['id'];
			}
			self::debug("init_form_".$this->form_id, $options,false);
			$this->loadFile($this->dir.'includes/functions/','functions.php');
			if(empty(self::$modules)){
				self::$modules=require $this->dir.'info.php';
			}
			$this->init_elements();
		}
		private function init_elements(){
			if(!empty($this->elements)){
				foreach($this->elements as $key=>$val){
					$section='';
					if(!empty($val['section'])){
						$section=$val['section'];
					}
					if(!empty($section)){
						if(!isset($this->sections[$section])){
							$this->sections[$section]=array();
						}
						$this->sections[$section][$key]=1;
					}
					$type=$val['type'];
					 if(isset(self::$modules[$type])){
						if(empty(self::$loaded_modules[$type])){
							$d=$this->modules_dir.$type.'/';
							$this->loadFile($d,'class.php');
							self::$loaded_modules[$type]=1;
						}
						$class='Class_My_Element_'.ucfirst($type);
						self::debug("init_element_classes", $class);
						$this->elements_classes[$key]=new $class($val);
					}
				}
			}
		}
		public function renderForm($echo=true){
			$element_tmpl=$this->views_dir.$this->element_template;
			$form_tmpl=$this->views_dir.$this->form_template;
			
			$form_html='';
			foreach ($this->elements_classes as $key=>$val){
				$element_html='';
				ob_start();
				$val->render();
				$my_html=ob_get_clean();
				
				$element_id=$val->getProperty('id');
				$element_name=$val->getProperty('name');
				$title=$val->getProperty('title');
				$tooltip=$val->getProperty('tooltip');
				ob_start();
				require $element_tmpl;
				$element_html=ob_get_clean();
				$form_html.=$element_html;
			}
			$element_html=$form_html;
			$hidden_arr=$this->hidden;
			$action=$this->action;
			$upload=$this->upload;
			$id=$this->id;
			ob_start();
			require $form_tmpl;
			$html=ob_get_clean();
			if($echo)echo $html;
			$this->html=$html;
			return $html;
			
			
		}
		public function scripts(){
			
		}
		public function wp_head(){
			
		}
		public function wp_footer(){
			
		}
		
	}
}