<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_Wp_My_Module_New_Form_Validate')){
	class Class_Wp_My_Module_New_Form_Validate{
		private $msgs;
		private $elements;
		private $data;
		function Class_Wp_My_Module_New_Form_Validate($options=array()){
			if(!empty($options)){
				foreach($options as $key=>$val){
					$this->$key=$val;
				}
			}
			
		}
		function validate(){
			global $wp_my_related_posts_debug;
			global $wp_my_related_posts_debug_data;
			if($wp_my_related_posts_debug){
				$wp_my_related_posts_debug_data['form_elements']=$this->elements;
			}
			$my_form_id=$this->data['my_form_id'];
			$ret['errors']=array();
			$ret['error']=0;
			$ret['form_has_errors']=$this->msgs['form_has_errors'];
			$error=false;
			foreach($this->elements as $key=>$val){
				$has_error=false;
				$value='';
				$name=$key.'_'.$my_form_id;
				$id=$key.'_'.$my_form_id.'_id';
				if(($val['type']=='button')||($val['type']=='submit'))continue;
				if(isset($this->data[$name])){
					$value=$this->data[$name];
				}
				if($wp_my_related_posts_debug){
					$wp_my_related_posts_debug_data['data'][$name]=$value;
				}
				if(isset($val['multiple']))
				$multiple=$val['multiple'];
				else $multiple=false;
				/**
				 * Check for defined 
				 */
				if(in_array($val['type'],array('jscript_checkbox_list','jscript_dropdown','jscript_radio_list'))){
					if(!empty($value)){
					
					if($multiple){
						foreach($value as $key1=>$val1){
							if(!array_key_exists($val1, $val['values'])){
								
								$error=true;
								$has_error=true;
								$ret['errors'][$name]=array('msg'=>$this->msgs['error'],'id'=>$id);
								break;
								
							}	
						}
					}else {
						
						if(!array_key_exists($value, $val['values'])){
							$error=true;
							$has_error=true;
							$ret['errors'][$name]=array('msg'=>$this->msgs['error'],'id'=>$id);
							
							break;
						
						}
					}
					}
				}
				if(!$has_error){
					if(!empty($val['validate'])){
						foreach($val['validate'] as $key1=>$val1){
							switch ($key1){
								case 'required':
									if(isset($val1['empty'])&&$val1['empty']){
										if(empty($value)){
											$error=true;
											$has_error=true;
											$ret['errors'][$name]=array('msg'=>$this->msgs[$key1],'id'=>$id);
										}
									}else {
									if($multiple){
										if(empty($value)){
											$error=true;
											$has_error=true;
											$ret['errors'][$name]=array('msg'=>$this->msgs[$key1],'id'=>$id);
											//break;
										
										}
									}
									else if(empty($value)&&!preg_match('/^0$/ims', $value)){
										$error=true;
										$has_error=true;
										$ret['errors'][$name]=array('msg'=>$this->msgs[$key1],'id'=>$id);
										//break;	
										
									}
									}
									break;
									
							}
						}
					}
				}
			}
			if(!$error)return true;
			else return $ret; 
		}		
	}
}