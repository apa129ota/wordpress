<?php
if(!defined('ABSPATH'))die('');
?>
<div data-base-name="<?php echo $key;?>" data-value="<?php esc_attr(implode(",",$element_value))?>" id="<?php echo $element_id.'_div';?>" data-type="<?php echo $type;?>" data-open="<?php if(!empty($element['open']))echo $element['open']; ?>" data-id="<?php echo $element_id?>" data-name="<?php echo $element_name;?>" <?php if(!empty($element_validate))echo $element_validate;?> class="my_new_module_element jscript_checkbox_list_div <?php if(!empty($element['div_classes'])){$str=implode(" ",$element['div_classes']);echo $str;}?>">
	<ul class="my_checkbox_list_ul <?php $inl='';if(isset($element['display']))$inl=$element['display'];if($inl=='inline')echo 'my_checkbox_list_ul_inline'?> <?php  if(!empty($element['ul_classes'])){$str=implode(" ",$element['ul_classes']);echo $str;}?>" data-button-id="<?php echo $element_id."_button"?>" data-id="<?php echo $element_id?>" data-name="<?php echo $element_name;?>">
	
	<?php 
	if(!empty($element_values)){
		$c=0;
		foreach($element_values as $key_new=>$val_new){
			$el_id=$element_id.'_'.$c;
			$c++;
			$checked=false;
			if(in_array($key_new, $element_value))$checked=true;
			?>
			<li class="<?php if($checked)echo 'my_checkbox_list_ul_li_active'?>">
				<input type="checkbox" <?php if($checked)echo 'checked="checked"'?> id="<?php echo esc_attr($el_id);?>" name="<?php echo esc_attr($element_name);if($element_multiple)echo '[]';?>" value="<?php echo esc_attr($key_new)?>"/>
					<span class="my_checkbox_list_check" data-id="<?php echo esc_attr($el_id)?>">
						<i class="fa fa-check"></i>
					</span>
			<label data-id="<?php echo esc_attr($el_id)?>"  data-value="<?php echo esc_attr($key_new);?>"><?php echo $val_new;?></label>
			
			</li>
			<?php 
		
		}
	}
	?>
	</ul>
</div>