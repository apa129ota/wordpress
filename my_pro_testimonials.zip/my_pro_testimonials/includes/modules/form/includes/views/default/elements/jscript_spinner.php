<?php
if(!defined('ABSPATH'))die('');
$default='';
if(!empty($element['default'])){
	$default=$element['default'];
}
$default_unit='';
if(!empty($element['default_unit'])){
	$default_unit=$element['default_unit'];
}
?>
<div data-default="<?php echo esc_attr($default);?>" data-base-name="<?php echo $key;?>" id="<?php echo $element_id.'_div';?>" data-type="<?php echo $type;?>" data-open="<?php if(!empty($element['open']))echo $element['open']; ?>" data-id="<?php echo $element_id?>" data-name="<?php echo $element_name;?>" <?php if(!empty($element_validate))echo $element_validate;?> class="my_new_module_element sppiner_div <?php if(!empty($element['div_classes'])){$str=implode(" ",$element['div_classes']);echo $str;}?>">
	<input <?php if(isset($element['size']))echo 'size="'.$element['size'].'"'?> <?php if(!empty($element['placeholder']))echo 'placeholder="'.esc_attr($element['placeholder']).'"';?> type="text" id="<?php echo esc_attr($element_id);?>" name="<?php echo esc_attr($element_name);?>" value="<?php if(!empty($element_value))echo esc_attr($element_value)?>"/>
	<?php if(!empty($element['units'])){
		$select_id=$element_id.'_select_id';
		$select_name=$element_id.'_select';
		?>
		<select name="<?php echo esc_attr($select_name)?>" class="my_spinner_units" id="<?php echo esc_attr($select_id);?>">
			<?php foreach($element['units'] as $key_1=>$val_1){?>
			<option <?php if(!empty($default_unit)&&$default_unit==$key_1)echo 'selected="selected"'?> value="<?php echo esc_attr($key_1)?>"><?php echo $val_1?></option>
			<?php }?>
		</select>
	
	<?php }?>
</div>	