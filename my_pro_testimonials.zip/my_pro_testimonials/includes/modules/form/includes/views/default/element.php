<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_form_element_outer my_clearfix" data-id="<?php echo $element_id;?>" data-name="<?php echo $element_name;?>">
	<div class="my_form_element_label"><?php echo $title;?>
	<?php if(!empty($tooltip)){?>
	<div class="my_help my_tooltip">
		<div class="my_content"><?php echo $tooltip?></div>
	</div>
	<?php }?>
	</div>
	<div class="my_form_element_div"><?php echo $my_html;?></div>
	
</div>