<?php
if(!defined('ABSPATH'))die('');
//return 'test';
?>

<div data-base-name="<?php echo $key;?>" id="<?php echo $element_id.'_div';?>" data-type="<?php echo $type;?>" data-open="<?php if(!empty($element['open']))echo $element['open']; ?>" data-id="<?php echo $element_id?>" data-name="<?php echo $element_name;?>" <?php if(!empty($element_validate))echo $element_validate;?> class="my_new_module_element on_off_div <?php if(!empty($element['div_classes'])){$str=implode(" ",$element['div_classes']);echo $str;}?>">
	<span class="imapper-checkbox-on imapper-checkbox-span <?php if(!$element_value)echo 'inactive';?>"><?php if(!empty($element['on']))echo $element['on']; else echo __("On","my_related_posts_domain");?></span>
	<span class="imapper-checkbox-off imapper-checkbox-span <?php if($element_value)echo 'inactive';?>"><?php if(!empty($element['off']))echo $element['off']; else echo __("Off","my_related_posts_domain");?></span>
	<input id="<?php echo $element_id?>" type="checkbox" <?php if(!empty($element_value))echo 'checked="checked"';?> value="1" name="<?php echo $element_name;?>">
</div>	
