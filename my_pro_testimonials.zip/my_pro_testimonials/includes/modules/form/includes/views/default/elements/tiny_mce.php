<?php
if(!defined('ABSPATH'))die('');
?>
<div data-base-name="<?php echo $key;?>" id="<?php echo $element_id.'_div';?>" data-type="<?php echo $type;?>" data-open="<?php if(!empty($element['open']))echo $element['open']; ?>" data-id="<?php echo $element_id?>" data-name="<?php echo $element_name;?>" <?php if(!empty($element_validate))echo $element_validate;?> class="my_new_module_element tiny_mce_div <?php if(!empty($element['div_classes'])){$str=implode(" ",$element['div_classes']);echo $str;}?>">
<?php 
$options=$element['settings'];
$options['textarea_name']=$element_name;
if(defined('DOING_AJAX') && DOING_AJAX){
	//wp_editor($element_value, $element_id,$options);
	$editor_id=$element_id;
	$buttons='';
	$buttons .= '<a id="' . $editor_id . '-html" class="wp-switch-editor switch-html" onclick="switchEditors.switchto(this);">' . _x( 'Text', 'Name for the Text editor tab (formerly HTML)' ) . "</a>\n";
	$buttons .= '<a id="' . $editor_id . '-tmce" class="wp-switch-editor switch-tmce" onclick="switchEditors.switchto(this);">' . __('Visual') . "</a>\n";
	//echo '<div class="wp-editor-tabs">' . $buttons . "</div>\n";
		
	?>
	
	<textarea <?php  my_new_form_render_el_data($options);?> <?php if(!empty($element['placeholder']))echo 'placeholder="'.esc_attr($element['placeholder']).'"'?> name="<?php echo esc_attr($element_name);?>" id="<?php echo esc_attr($element_id)?>"><?php if(!empty($element_value))echo esc_textarea($element_value)?></textarea>
	
	<?php 
}
else wp_editor($element_value, $element_id,$options);
?>
</div>