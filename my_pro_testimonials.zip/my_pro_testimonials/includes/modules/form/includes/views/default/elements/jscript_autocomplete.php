<?php
if(!defined('ABSPATH'))die('');
?>
<div data-base-name="<?php echo $key;?>" id="<?php echo $element_id.'_div';?>" data-type="<?php echo $type;?>" data-open="<?php if(!empty($element['open']))echo $element['open']; ?>" data-id="<?php echo $element_id?>" data-name="<?php echo $element_name;?>" <?php if(!empty($element_validate))echo $element_validate;?> class="my_new_module_element jscript_autocomplete_div <?php if(!empty($element['div_classes'])){$str=implode(" ",$element['div_classes']);echo $str;}?>">
	<input type="hidden" name="<?php echo $element_name.'_my_nonce'?>" value="<?php echo wp_create_nonce($element['nonce_str'])?>" class="my_nonce_str"/>
	<?php if($element['show_values']){?>
	<div class="my_btn my_autocomplete_values">
	<?php if(!empty($element_value)){
		foreach($element_value as $key_new=>$val_new){
			//$my_val_12=$element_value[$key_new];
			if($element_multiple)$my_name_12=$element_name.'[]';
			else $my_name_12=$element_name;
			?>
			<input type="hidden" data-name="<?php echo $element_name;?>" name="<?php echo $my_name_12;?>" value="<?php echo $key_new?>"/>
			<?php if(isset($element['show_values'])&&$element['show_values']){?>
			<div class="my_autocomplete_value" data-val="<?php echo $key_new;?>"><?php echo $val_new;?><span class="fa fa-close"></span></div>
			<?php 
			}
		}
	}
	?>
	</div>
	<?php }?>
	<div class="my_autocomplete_input_div">
		<input class="my_autocomplete_input"/>
		<span class="fa fa-search"></span>
	</div>
	
</div>