<?php
if(!defined('ABSPATH'))die('');
?>
<li <?php my_new_form_render_jscript_data($element)?> class="my_form_element_outer <?php if(isset($my_multi))echo 'my_form_element_display_inline'?> <?php if(!empty($element['outer_classes'])){if(is_array($element['outer_classes']))implode(" ",$element['outer_classes']);else echo $element['outer_classes'];}?> <?php if(isset($element['layout_class']))echo $element['layout_class']; if(!empty($my_clear))echo ' my_clear_after';?>" data-id="<?php echo $element_id;?>" data-type="<?php echo esc_attr($element['type'])?>" data-name="<?php echo $element_name;?>">
	<div class="my_form_element_label"><?php echo $title;?>
	<?php if(!empty($tooltip)){?>
	<div class="my_help my_tooltip">
		<div class="my_content"><?php echo $tooltip?></div>
	</div>
	<?php }?>
	</div>
	<div class="my_form_element_div" data-name="<?php echo esc_attr($element_name)?>"><?php echo $my_html;?></div>
	<div class="my_clear"></div>
	</li>