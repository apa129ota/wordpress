<?php
if(!defined('ABSPATH'))die('');
$inl='';
if(isset($element['display']))$inl=$element['display'];
$default='';
if(!empty($element['default'])){
	$default=$element['default'];
}
$el_value=1;
if(!empty($element['element_value'])){
	$el_value=$element['element_value'];
}
?>
<div data-default="<?php echo esc_attr($default)?>" data-base-name="<?php echo $key;?>" id="<?php echo $element_id.'_div';?>" data-name="<?php echo $element_name;?>" data-type="<?php echo $type;?>" data-open="<?php if(!empty($element['open']))echo $element['open']; ?>" data-id="<?php echo $element_id?>" data-name="<?php echo $element_name;?>" <?php if(!empty($element_validate))echo $element_validate;?> class="my_new_module_element button_div <?php if(!empty($element['div_classes'])){$str=implode(" ",$element['div_classes']);echo $str;}?>">
	<ul class="<?php if(!empty($inl))echo 'my_radio_list_ul_inline';?>">
		
			<?php 
			if(!empty($element_value))$checked=true;
			?>
			<li class="<?php //if($checked)echo 'my_radio_list_ul_li_active'?>">
				<input type="checkbox" <?php if($checked)echo 'checked="checked"'?> id="<?php echo esc_attr($element_id);?>" name="<?php echo esc_attr($element_name);?>" value="<?php echo $el_value?>"/>
				<label data-id="<?php echo esc_attr($element_id)?>"  data-value="<?php echo $el_value;?>"><?php echo $element['label'];?></label>
				
			</li>
			
		
	</ul>	
		
	
</div>