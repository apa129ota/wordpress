<?php
if(!defined('ABSPATH'))die('');
?>
<div data-base-name="<?php echo $key;?>" id="<?php echo $element_id.'_div';?>" data-type="<?php echo $type;?>" data-open="<?php if(!empty($element['open']))echo $element['open']; ?>" data-id="<?php echo $element_id?>" data-name="<?php echo $element_name;?>" <?php if(!empty($element_validate))echo $element_validate;?> class="my_new_module_element jscript_dropdown_div <?php if(!empty($element['div_classes'])){$str=implode(" ",$element['div_classes']);echo $str;}?>">
	<div class="my_media_values">
		<?php 
		if(!empty($element_value)){
			foreach($element_value as $key_new=>$val_new){
				?>
				<input type="hidden" name="<?php echo $element_name.'[]'?>" data-name="<?php echo $element_name;?>"/>
				
				<?php
				if(isset($element['show_values'])&&($element['show_values'])){
					?>
					<div class="my_media_value" data-val="<?php echo $key_new?>">
					<?php ?>
					</div>
					<?php 
				} 

			}
		}
		?>
	</div>
	<button class="my_btn my_media_button" data-id="<?php echo $element_id;?>" data-name="<?php echo $element_name;?>"><?php echo $element['choose_title']?></button> 
</div>