(function($) {
	wpMyModuleNewFormMainScript=function(o){
		var self;
		this.debug=true;
		this.options={};
		this.form_id='';
		this.form_prefix='my_form_';
		this.objects=[];
		self=this;
		//static is_init_section=false;
		this.init=function(o){
			if(typeof o.my_debug!='undefined'){
				if(!o.my_debug){
					self.debug=false;
				}
			}
			self.my_debug("Options",o);
			self.options=o;
			self.form_id=self.form_prefix+self.id;
			self.call_scripts();
			
			
		};
		this.get_values=function(from,to){
			var form_id=$(from).find("form [name='my_form_id']").val();
			var to_id=$(to).find("form [name='my_form_id']").val();
			var values={};
			$(from+" .my_form_element_outer").each(function(i,v){
				var type=$(v).data('type');
				var id=$(v).data('id');
				var div_id=id+"_div";
				var base_name=$("#"+div_id).data('base-name');
				var val='';
				self.my_debug('Set value',{base:base_name,type:type,id:id,div_id:div_id,val:val});
				
				if(type!='text'&&type!='textarea'){
					var object=$("#"+div_id).data('my-script');
					if(typeof object!='undefined'){
						val=object.get_value();
					}
				}else {
					var id=base_name+'_'+form_id+'_'+'id';
					val=$("#"+id).val();
					
				}
				values[base_name]=val;
			});
			self.my_debug("Values",values);
			return values;
			/*$(to+" .my_form_element_outer").each(function(i,v){
				var type=$(v).data('type');
				var id=$(v).data('id');
				var div_id=id+"_div";
				var base_name=$("#"+div_id).data('base-name');
				var val='';
				if((typeof values[base_name]!='undefined')){
				val=values[base_name];
				}
				self.my_debug('Set value',{base:base_name,type:type,id:id,div_id:div_id,val:val});
				
				if(type!='text'&&type!='textarea'){
				//var $div=$(v).find(".my_form_element_div");
					
					
					var object=$("#"+div_id).data('my-script');
					if(typeof object!='undefined'){
						object.set_value(val);
					}
				}else {
					var id=base_name+'_'+form_id+'_'+'id';
					$("#"+id).val(val);
					$("#"+id).trigger('change');
				}
			});
			*/
		};
		this.update_values_simple=function(sel,values){
			var form_id=$(sel).find("form [name='my_form_id']").val();
			self.my_debug("Update Values",{form_id:form_id,values:values});
			$(sel+" .my_form_element_outer").each(function(i,v){
				var type=$(v).data('type');
				var id=$(v).data('id');
				var div_id=id+"_div";
				var base_name=$("#"+div_id).data('base-name');
				var val='';
				if((typeof values[base_name]!='undefined')){
				val=values[base_name];
				}
				self.my_debug('Set value',{base:base_name,type:type,id:id,div_id:div_id,val:val});
				
				if(type!='text'&&type!='textarea'){
				//var $div=$(v).find(".my_form_element_div");
					
					
					var object=$("#"+div_id).data('my-script');
					if(typeof object!='undefined'){
						object.set_value(val);
					}
				}else {
					var id=base_name+'_'+form_id+'_'+'id';
					$("#"+id).val(val);
					$("#"+id).trigger('change');
				}
			});
			
		};
		this.update_values=function(sel,values){
			var form_id=$(sel).find("form [name='my_form_id']").val();
			self.my_debug("Update Values",{form_id:form_id,values:values});
			$(sel+" .my_form_element_outer").each(function(i,v){
				var type=$(v).data('type');
				if(type!='text'&&type!='textarea'){
				//var $div=$(v).find(".my_form_element_div");
					
					var id=$(v).data('id');
					var div_id=id+"_div";
					var base_name=$("#"+div_id).data('base-name');
					if((typeof values[base_name]!='undefined')&&(values[base_name].value!=null)){
					var val=values[base_name].value;
					self.my_debug('Set value',{base:base_name,type:type,id:id,div_id:div_id,val:val});
					var object=$("#"+div_id).data('my-script');
					if(typeof object!='undefined'){
						object.set_value(val);
					}
					}
				}/*else {
					var id=i+'_'+form_id+'_'+'id';
					$("#"+id).val(v.value);
				}*/
			});
			
			$.each(values,function(i,v){
				if((v.type=='text') || (v.type=='textarea')){
					var id=i+'_'+form_id+'_'+'id';
					$("#"+id).val(v.value);
				}
			});
		};
		this.init_new_elements=function(sel,ajax){
			$(sel).find(".my_form_element_outer").each(function(i,v){
				var type=$(v).data('type');
				var id=$(v).data('id');
				self.my_debug("Init element",{type:type,id:id});
				var data=$(v).data();
				self.my_debug("Data",data);
				var o={};
				o.id=id;
				o.type=type;
				o.name=$(v).data('name');
				o.my_debug=self.debug;
				//var $objdiv=$(v).find(".my_form_element_div:first-child");
				o.div_id=id+'_div';//$($objdiv).attr('id');
				self.my_debug("O.div_id",o);
				if(type=='tiny_mce'&&ajax){
					var text_id=$("#"+o.div_id+" textarea").attr('id');
					self.my_debug("Init tinymce");
					data=$("#"+text_id).data();
					var o={};
					$.each(data,function(i1,v1){
						o[i1]=v1;
					});
					if(typeof tinyMCEPreInit !='undefined'){
						$.each(tinyMCEPreInit.mceInit,function(i,v){
							o=v;
							return false;
						});
					}
					var o_h=$(v).find(".wp-editor-tabs").outerHeight();
					self.my_debug("o_h",o_h);
					$(v).find(".wp-editor-tabs").css({position:'relative',top:'-33px'});
					quicktags({id : '#'+text_id});
					o.body_class='#'+text_id;
					o.selector='#'+text_id;
					self.my_debug("Tinymce options",o);
				
					tinymce.init(o);
				}else {
				$.each(data,function(i1,v1){
					self.my_debug("Data",{i1:i1,v1:v1});
					if(i1.indexOf('jscript')!==-1){
						var pos=i1.indexOf('jscript')+6;
						var key=i1.substring(pos);
						key=key.toLowerCase();
						self.my_debug("new key",{key:key,v1:v1});
						o[key]=v1;
					}
				
				});
				}
				self.my_debug("Options",o);
				self.init_element(type,id,o);
			});
		};
		this.init_element=function(type,id,v){
			//return;
			v.my_debug=self.debug;
			if(type=='thumb'){
				self.my_debug("New Thumb ",v);
				self.objects[self.objects.length]=new wpMyModuleNewFormThumb(v);
			}
			else if(type=='date'){
				$("#"+v.div_id).find("input[type='text']").datepicker({
					
				});
			}
			else if(type=='jscript_spinner'){
				self.my_debug("New Spinner ",v);
				self.objects[self.objects.length]=new wpMyModuleNewFormSpinner(v);
			}
			else if(type=='jscript_dropdown'){
				self.my_debug("New Combo Box ",v);
				self.objects[self.objects.length]=new wpMyModuleNewFormComboBox(v);
			}else if(type=='jscript_checkbox_list'){
				self.my_debug("New Checkbox list Box ",v);
				self.objects[self.objects.length]=new wpMyModuleNewFormCheckboxList(v);
			}else if(type=='jscript_radio_list'){
				self.my_debug("New Radio list Box ",v);
				self.objects[self.objects.length]=new wpMyModuleNewFormRadioList(v);
			}else if(type=='jscript_color_picker'){
				self.my_debug("New Color picker ",v);
				self.objects[self.objects.length]=new wpMyModuleNewFormColorPicker(v);
			}else if(type=='jscript_autocomplete'){
				self.my_debug("New Autocomplete ",v);
				self.objects[self.objects.length]=new wpMyModuleNewFormAutocomplete(v);
			}else if(type=='jscript_media'){
				self.my_debug("New Media ",v);
				self.objects[self.objects.length]=new wpMyModuleNewFormMedia(v);
			}else if(type=='on_off'){
				self.my_debug('On off');
				self.objects[self.objects.length]=new wpMyModuleNewFormOnOff(v);
			}
		};
		this.call_scripts=function(){
			//$("#"+self.form_id).each('')
			$.each(self.options.elements,function(i,v){
				var type=v.type;
				var id=v.id;
				self.init_element(type,id,v);
				
			});
		};
		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log("***ModuleFormMainSCript *** \n"+t,o);
				}
			}
		};
		this.init(o);
		
	};
})(jQuery);	