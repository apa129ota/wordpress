<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Module_Form')){
	class Class_My_Module_Form extends Class_My_General_Module{
		use MySingleton;
		private $forms=array();
		function __construct($options=array()){
			$options['url']=plugin_dir_url(__FILE__);
			$options['dir']=plugin_dir_path(__FILE__);
			parent::__construct($options);
		
		}
		function init($options=array()){
			parent::init($options);
		}
		public function addForm($id,$options=array()){
			$options['dir']=$this->dir;
			$options['url']=$this->url;
			self::debug("add_form", $options,true);
			$this->loadClass("class-my-form.php");
			$this->forms[$id]=new Class_My_Module_Form_Class($options);
			
		}
		public function renderForm($id){
			if(isset($this->forms[$id])){
				ob_start();
				$this->forms[$id]->renderForm();
				$html=ob_get_clean();
				return $html;
			}
		}
		
	}
}
