<?php
if(!defined('ABSPATH'))die('');
$info=array(
		'title'=>'Form module',
		'description'=>'Form module',
		'class'=>'Class_My_Module_Form',

);
return $info;