<?php
if(!defined('ABSPATH'))die('');
$arr=array(
		'label'=>__("Events","my_support_theme"),
		'labels'=>array(
			'name'=>__("Events","my_support_theme"),
			'singular_name'=>__("Events","my_support_theme"),
			'add_new'=>__("Add New Events","my_support_theme"),
			'add_new_item'=>__("Add New Events","my_support_theme"),
			'edit_item'=>__("Edit Events","my_support_theme"),
			'new_item'=>__("New Events","my_support_theme"),
			'view_item'=>__("View Events","my_support_theme"),
			'search_items'=>__("Search Events","my_support_theme"),
			'not_found'=>__("Not Found","my_support_theme"),
			'not_found_in_trash'=>__("Not Found in trash","my_support_theme"),
			'parent_item_colon'=>__("Parent","my_support_theme"),
			'all_items'=>__("All Events","my_support_theme"),
			'archives'=>__("Archives","my_support_theme"),
			'insert_into_item'=>__("Insert Into Events","my_support_theme"),
			'uploaded_to_this_item'=>__("Uploaded to this help item","my_support_theme"),
		),
		'public'=>true,
		'exclude_from_search'=>true,
		'publicly_queryable'=>true,
		'show_ui'=>true,
		'show_in_nav_menus'=>true,
		'menu_position'=>5,
		'map_meta_cap'=>true,
		'capability_type'=>'post',
		'supports'=>array('title','editor','thumbnail','excerpt')
			
);
//$ret['my_help']=$arr;
return $arr;