<?php
if(!defined('ABSPATH'))die('');
$info=array(
		'title'=>'Admin bar Menu',
		'description'=>'Form module',
		'class'=>'Class_My_Module_Admin_Bar',

);
return $info;