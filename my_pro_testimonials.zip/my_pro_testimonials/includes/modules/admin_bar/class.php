<?php 
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Module_Admin_Bar')){
	class Class_My_Module_Admin_Bar extends Class_My_General_Module{
		use MySingleton;
		private $post_type;
		private $post_type_key='my_help';
		function __construct($options=array()){
			$options['url']=plugin_dir_url(__FILE__);
			$options['dir']=plugin_dir_path(__FILE__);
			parent::__construct($options);
		
		}
		function init($options=array()){
			parent::init($options);
			add_action('init',array(&$this,'wp_init'));
			add_action('edit_form_top',array(&$this,'edit_form_top'));
		}
		public function edit_form_top(){
			global $post;
			self::debug("post", $post,false);
			if($post->post_type=='my_help'){
				$url=get_site_url().'?p='.$post->ID."&preview=1&my_visual_admin_bar=1";
			?>
			<h3><?php echo __("Save post as draft and you can use frontend builder to design post content.","my_support_theme")?>&nbsp;&nbsp;<a href="<?php echo $url ?>" target="_blank"><?php echo __("Frontend builder","my_support_theme")?></a></h3>
			<?php 
			}
		}
		public function wp_init(){
			$this->post_type=$this->loadOptions('post-type.php');
			self::debug("register_post_type", $this->post_type,false);
			register_post_type($this->post_type_key,$this->post_type);
		}
		
	}
}