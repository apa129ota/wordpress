<?php
if(!defined('ABSPATH'))die('');
$info=array(
		'title'=>'Table View module',
		'description'=>'Table view module',
		'class'=>'Class_My_Module_Form',

);
return $info;