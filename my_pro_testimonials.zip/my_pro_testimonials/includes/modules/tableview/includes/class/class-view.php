<?php
if(!defined('ABSPATH'))die('');

if(!class_exists('Class_Wp_My_Module_Table_View_View_Class')){
	class Class_Wp_My_Module_Table_View_View_Class{
		use MyArrayOptions,MyDebug;
		protected $id;
		protected $per_page;
		protected $pages;
		protected $page;
		protected $count;
		protected $results;
		protected $columns;
		protected $actions;
		protected $mainClass;
		protected $metaClass;
		protected $ret;
		protected $use_case='my_frameowork';
		protected $debug;
		protected $module_class;
		protected $global_plugin; 
		protected $metaOptions;
		protected $my_order_col;
		protected $my_order_str;
		protected $my_order;
		protected $hasOrder=false;
		protected $metaKey='shortcode';
		protected $whereStr='';
		protected $translate;
		protected $formattedResulst;
		function __construct($options=array()){
			$this->setOptions($options);
			if($this->debug){
				self::setDebugOptions($this->use_case);
			}
			$this->global_plugin->loadModuleClass('meta');
			$this->metaClass=new Class_My_Module_Meta($this->metaOptions);
			$page=@$_REQUEST['my_page'];
			if(!isset($page))$page=1;
			$this->page=$page;
			$this->my_order_col='';
			$this->my_order='';
			
			$my_order_str='';
			$my_order_col=@$_REQUEST['my_order_col'];
			$my_order_str='';
			
			if(!empty($my_order_col)){
				$this->hasOrder=$this->checkOrderColumn($my_order_col);
				if($this->hasOrder){
					$my_order=@$_REQUEST['my_order'];
					if(!in_array($my_order,array('asc','desc')))$my_order='asc';
					$this->my_order=$my_order;
					$this->my_order_col=$my_order_col;
					$this->my_order_str='';
					
				}
			
			}
			
		}
		protected function checkOrderColumn($col){
			if(isset($this->columns[$col])){
				return $this->columns[$col]['order'];
			}else return false;
			
		}
		protected function getData(){
			$this->results=array();
			if(empty($this->count))return;
			$this->results=$this->metaClass->pagerQuery($this->metaKey, $this->page,$this->per_page, $this->my_order_col, $this->my_order);
			if(!empty($this->results)){
				foreach($this->results as $key=>$val){
					$obj=new stdClass();
					$id=$val->ID;
					if(!array_key_exists('ID',$this->columns)){
						$obj->ID=$id;
					}
					foreach($this->columns as $k1=>$v1){
						if(isset($this->translate[$k1])){
							$str=$this->translate[$k1];
							$str=str_replace('{id}', $id, $str);
							$obj->$k1=$str;
						}else {
						
						$obj->$k1=$val->$k1;
						}
					}
					
					$this->formattedResulst[]=$obj;
				}
			}
			
		}
		protected function countData(){
			$this->count=$this->metaClass->countObjects($this->metaKey);
			$this->pages=ceil($this->count/$this->per_page);
			if($this->page>$this->pages){
				$this->page=1;
			}
			
		}
		
		protected function getOptions(){
			$options['id']=$this->id;
			$options['columns']=$this->columns;
			$options['pages']=$this->pages;
			$options['page']=$this->page;
			$options['count']=$this->count;
			$options['form_params']=array();
			$options['form_params']['my_page']=$this->page;
			//if(!empty($this->my_order_col)){
				$options['form_params']['my_order_col']=$this->my_order_col;
				$options['form_params']['my_order']=$this->my_order;
			/*}else {
				
			}*/
			$options['results']=$this->formattedResulst;
			$options['actions']=$this->actions;
			$options['msgs']=array(
					'page'=>__("Page","my_support_theme"),
					'pages'=>__("Pages","my_support_theme"),
					'no_data'=>__("There are no results !","my_support_theme"),
					'total_results'=>__("Total Results","my_support_theme"),
					'first_page'=>__("First Page","my_support_theme"),
					'last_page'=>__("Last Page","my_support_theme"),
					'actions'=>__("Actions","my_support_theme"),
			);
			$options['data']=$options;
			return $options;	
		}
		public function render($echo=false){
			/*$options['id']=$this->id;
			$options['columns']=$this->columns;
			$options['data']=$this->ret;
			$options['actions']=$this->actions;
			$options['msgs']=array(
					'page'=>__("Page","my_support_theme"),
					'pages'=>__("Pages","my_support_theme"),
					'no_data'=>__("There are no results !","my_support_theme"),
					'total_results'=>__("Total Results","my_support_theme"),
					'first_page'=>__("First Page","my_support_theme"),
					'last_page'=>__("Last Page","my_support_theme"),
					'actions'=>__("Actions","my_support_theme"),
			);*/
			$this->countData();
			$this->getData();
			$options=$this->getOptions();
			$this->mainClass=new Class_Wp_My_Module_Table_View($options);
			ob_start();
			echo $this->mainClass->render();
			$table_html=ob_get_clean();
			if($echo)echo $table_html;
			return $table_html;
			
		}	
	}
}