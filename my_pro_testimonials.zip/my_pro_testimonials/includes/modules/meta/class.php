<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Module_Meta')){
	class Class_My_Module_Meta{
		use MyDebug;
		private $table_objects='';
		private $tables_objects_meta='';
		private $has_dates=false;
		private $debug=false;
		private $debug_var;
		private $use_case='my_framework';
		function Class_My_Module_Meta($options=array()){
			if(!empty($options)){
				foreach($options as $key=>$val){
					if(!isset($this->$key)){
						trigger_error(__("Parameter is not supported","my_support_theme").' '.$key,E_USER_NOTICE);
						//throw new Exception(__("Parameter is not supported","my_support_theme"),1);
					}else {
						$this->$key=$val;
					}
				}
			}
			if($this->debug){
				self::setDebugOptions($this->use_case);
			}
		}
		public function countObjects($object_type){
			global $wpdb;
			$table=$this->table_objects;
			$query="SELECT count(*) as num FROM ".$table." AS o";// LEFT JOIN ";
			$query.=" WHERE o.object_type=%s ";
			//$query.=" limit 0,".$limit;
			$query=$wpdb->prepare($query, $object_type);
			$res=$wpdb->get_var($query);
			if($this->debug){
				$data=array(
						'object_type'=>$object_type,
						'query'=>$query,
						'res'=>$res
				);
				self::debug("count_meta", $data);
				//Class_My_Module_Debug::add_section('object types', $data,$this->use_case);
			}
			return $res;
				
		}
		public function pagerQuery($object_type,$page,$per_page,$order_col,$order,$where=''){
			global $wpdb;
			$poc=0;
			$poc=($page-1)*$per_page;
			$limit=" limit ".$poc.",".$per_page;
			$table=$this->table_objects;
				$query="SELECT * FROM ".$table." AS o";
				$query.=" WHERE o.object_type=%s ";
				if(!empty($where)){
					$query.=" AND ".$where;
				}
				if(empty($order_col))$query.=" order by ID asc";
				else {
					$query.=" ORDER By ".$order_col." ".$order;
				}
				$query.=$limit;
				$query=$wpdb->prepare($query, $object_type);
				$res=$wpdb->get_results($query);
				if($this->debug){
					$data=array(
							'object_type'=>$object_type,
							'query'=>$query,
							'res'=>$res
					);
					self::debug("pager_query", $data);
					//Class_My_Module_Debug::add_section('object types', $data,$this->use_case);
				}
				return $res;
			
			
		}
		public function getObjectTypes($object_type){
			global $wpdb;
			$table=$this->table_objects;
			$query="SELECT o.ID,o.title FROM ".$table." AS o";// LEFT JOIN ";
			$query.=" WHERE o.object_type=%s ";
			$query.=" order by title desc";
			//$query.=" limit 0,".$limit;
			$query=$wpdb->prepare($query, $object_type);
			$res=$wpdb->get_results($query);
			//echo 'Query '.$query.' '.$this->table_objects.' '.$this->tables_objects_meta;
			if($this->debug){
				$data=array(
						'object_type'=>$object_type,
						'query'=>$query,
						'res'=>$res
				);
				self::debug("objecv_types", $data,true);
				//Class_My_Module_Debug::add_section('object types', $data,$this->use_case);
			}
			return $res;
		}
		/**
		 * Autocomplete object
		 * @param unknown $term
		 * @param unknown $object_type
		 * @param number $limit
		 * @return Ambigous <multitype:, object, NULL, multitype:multitype: , multitype:Ambigous <multitype:, NULL> >
		 */
		public function autocomplete_object($term,$object_type,$limit=30){
			global $wpdb;
			$term=trim($term);
			$term=preg_replace('/%/ims', '', $term);
			$table=$this->table_objects;
			$query="SELECT o.ID,o.title FROM ".$table." AS o";// LEFT JOIN ";
			$query.=" WHERE o.object_type=%s AND o.title like %s ";
			$query.=" order by title desc";
			$query.=" limit 0,".$limit;
			$query=$wpdb->prepare($query,$object_type, $term.'%');
			$res=$wpdb->get_results($query);
			if($this->debug){
				$data=array(
						'object_type'=>$object_type,
						'term'=>$term,
						'query'=>$query,
						'res'=>$res
				);
				self::debug("autocomplete_object", $data);
				//Class_My_Module_Debug::add_section('autocomplete_object', $data,$this->use_case);
			}
			return $res;
		}
		/**
		 * Insert update object
		 * @param unknown $title
		 * @param unknown $type
		 * @param string $id
		 * @return Ambigous <string, number>
		 */
		function insert_update_object($title,$type,$id=''){
			global $wpdb;
			
			$data=array();
			$data['title']=$title;
			$data['object_type']=$type;
			
			$date=date('Y/m/d H:i:s');
			if($this->debug){
				$wpdb->show_errors();
				$datad=array(
						'id'=>$id,
						'title'=>$title,
						'date'=>$date
				);
				self::debug("insert_update_object", $datad);
				//Class_My_Module_Debug::add_section('insert_update_object', $data,$this->use_case);
			}
			if(empty($id)){
				if($this->has_dates){
					$data['created']=$date;
					$data['updated']=$date;
				}
				ob_start();
				$wpdb->insert($this->table_objects, $data);
				$err=ob_get_clean();
				if(!empty($err)){
					self::debug("meta_db_error", $err);
				}
				$id=$wpdb->insert_id;
			}else {
				if($this->has_dates){
					$data['updated']=$date;
				}
				$wpdb->update($this->table_objects, $data, array('ID'=>$id));
			}
			
			return $id;
		}
		/**
		 * Add update objects meta
		 * @param unknown $object_id
		 * @param unknown $key
		 * @param unknown $val
		 * @return Ambigous <number, Ambigous, string, NULL>
		 */
		public function add_update_object_meta($object_id,$key,$val){
			global $wpdb;
			$is=$this->is_exits_object_meta($object_id, $key);
			$data=array();
			$str=maybe_serialize($val);
			$data['meta_value']=$str;
			
			if($this->debug)$wpdb->show_errors();
			if(empty($is)){
				$data['meta_key']=$key;
				$data['object_id']=$object_id;
				
				if($this->debug){
					self::debug('add_update_object_meta', $data);
					//Class_My_Module_Debug::add_section('add_update_object_meta', array('data'=>$data,'is_exists'=>$is),$this->use_case);
				}
				//ob_start();
				$wpdb->insert($this->tables_objects_meta, $data);		
				$is=$wpdb->insert_id;
			}else{
				
				if($this->debug){
					//Class_My_Module_Debug::add_section('add_update_object_meta', array('data'=>$data,'is_exists'=>$is),$this->use_case);
					$datar=array('data'=>$data,'is_exists'=>$is);
					self::debug('add_update_object_meta', $datar);
					
					
				}
				
				$wpdb->update($this->tables_objects_meta, $data, array('meta_id'=>$is));
			}
			return $is;
		}
		/**
		 * Is exists object meta
		 * @param unknown $id
		 * @param unknown $key
		 * @return Ambigous <string, NULL>
		 */
		public function is_exits_object_meta($id,$key){
			global $wpdb;
			$query="SELECT meta_id FROM ".$this->tables_objects_meta." ";
			$query.=" WHERE object_id=%d AND meta_key=%s";
			$query=$wpdb->prepare($query, $id,$key);
			$var=$wpdb->get_var($query);
			if($this->debug){
				$data=array(
						'id'=>$id,
						'key'=>$key,
						'query'=>$query,
						'var'=>$var
				);
				self::debug("is_exists_object_meta", $data);
				//Class_My_Module_Debug::add_section('is_exists_object_meta', $data,$this->use_case);
			}
			return $var;
		}
		/**
		 * Get object meta
		 * @param unknown $object_id
		 * @param unknown $key
		 * @param string $un
		 * @return boolean|Ambigous <mixed, string, string, NULL>
		 */
		public function get_object_meta($object_id,$key,$un=true){
			global $wpdb;
			$table=$this->tables_objects_meta;
			$query="SELECT meta_id FROM ".$table." ";
			$query.=" WHERE meta_key=%s AND object_id=%d ";
			$query=$wpdb->prepare($query, $key,$object_id);
			$var=$wpdb->get_var($query);			
			if($this->debug){
				$data=array(
					'object_id'=>$object_id,
					'key'=>$key,
					'meta_id'=>$var		
				);
				self::debug("get_object_meta", $data);
				//Class_My_Module_Debug::add_section('get_object_meta', $data,$this->use_case);
				}
				if(empty($var))return false;
				$query="SELECT meta_value FROM ".$table." ";
				$query.=" WHERE meta_key=%s AND object_id=%d ";
				$query=$wpdb->prepare($query, $key,$object_id);
				$var=$wpdb->get_var($query);
				if($un){
					$var=maybe_unserialize($var);
				}
			return $var;
	
			}
			/**
			 * Get object metas
			 * @param unknown $object_id
			 * @param string $un
			 * @return boolean|Ambigous <mixed, string, string, NULL>
			 */
		public function get_object_metas($object_id,$un=true){
				$arr=array();
				global $wpdb;
				$table=$this->tables_objects_meta;
				$query="SELECT meta_id FROM ".$table." ";
				$query.=" WHERE object_id=%d ";
				$query=$wpdb->prepare($query,$object_id);
				$var=$wpdb->get_results($query);
				if($this->debug){
					$data=array(
							'object_id'=>$object_id,
							'meta_id'=>$var
					);
					self::debug("get_object_metas", $data);
					//Class_My_Module_Debug::add_section('get_object_metas', $data,$this->use_case);
				}
				if(empty($var))return false;
				foreach($var as $k=>$v){
					$query="SELECT meta_key,meta_value FROM ".$table." ";
					$query.=" WHERE meta_id=%d ";
					$query=$wpdb->prepare($query, $v->meta_id);
					$var=$wpdb->get_row($query);
					
					if($un){
						$var=maybe_unserialize($var->meta_value);
					}
					$key=$var->meta_key;
					$arr[$key]=$var;
				}
				return $arr;
			
			}	
		/**
		 * Get object
		 * @param unknown $id
		 * @return Ambigous <multitype:, object, NULL, void>
		 */	
		public function get_object($id){
			global $wpdb;
			$table=$this->table_objects;
			$query="SELECT * FROM ".$table." WHERE ID=%d";
			$query=$wpdb->prepare($query, $id);
			$var=$wpdb->get_row($query);
			if($this->debug){
				$data=array(
					'id'=>$id,
					'query'=>$query,
					'var'=>$var
				);
				self::debug("get_object", $data);
				//Class_My_Module_Debug::add_section('get_object', $data,$this->use_case);
				}
			return $var;

			}
		/**
		 * Delete object meta
		 * @param unknown $id
		 * @param unknown $key
		 * @return boolean
		 */	
		public function delete_object_meta($id,$key){
			global $wpdb;
			$is=$this->is_exits_object_meta($id, $key);
			if($this->debug){
				$data=array(
						'id'=>$id,
						'key'=>$key,
						'is'=>$is
				);
				self::debug("delete_object_meta", $data);
				//Class_My_Module_Debug::add_section('delete_object_meta', $data,$this->use_case);
			}
			if(empty($is)){
				return false;
			}else {
				$query_1="DELETE FROM ".$this->tables_objects_meta." WHERE ";
				$query_1.=" object_id=%d AND meta_key=%s ";
				$query_1=$wpdb->prepare($query_1, $id,$key);
				$wpdb->query($query_1);
				if($this->debug){
					$data=array(
							'id'=>$id,
							'key'=>$key,
							'is'=>$is,
							'query'=>$query_1
					);
					self::debug("delete_object_meta", $data);
					//Class_My_Module_Debug::add_section('delete_object_meta', $data,$this->use_case);
				}
				return true;
			}
		}	
		/**
		 * Delete object
		 * @param unknown $id
		 * @param string $object_type
		 * @return unknown|Ambigous <string, mixed>
		 */	
		public function delete_object($id,$object_type=''){
				global $wpdb;
				if(empty($object_type)){
					$is=$this->is_exists_object($id);
				}else $is=$this->is_exists_object_by_type($id, $object_type);
				if($this->debug){
					$data=array(
							'id'=>$id,
							'object_type'=>$object_type,
							'is'=>$is,
							
					);
					self::debug("delete_object", $data);
					//Class_My_Module_Debug::add_section('delete_object', $data,$this->use_case);
				}
				if(empty($is)){
					return false;
				}else {
					$query="DELETE FROM ".$this->table_objects." WHERE ";
					$query.=" ID=%d";
					$query=$wpdb->prepare($query, $id);
					$wpdb->query($query);
					$query_1="DELETE FROM ".$this->tables_objects_meta." WHERE ";
					$query_1.=" object_id=%d ";
					$query_1=$wpdb->prepare($query_1, $id);
					$wpdb->query($query_1);
					if($this->debug){
						$data=array(
								'id'=>$id,
								'object_type'=>$object_type,
								'is'=>$is,
								'query'=>$query,
								'query_1'=>$query_1	
						);
						self::debug("delete_object", $data);
						//Class_My_Module_Debug::add_section('delete_object', $data,$this->use_case);
					}
					return true;
				}
			
			}
		/**
		 * Is exists object by id
		 * @param unknown $id
		 * @return Ambigous <string, NULL>
		 */	
		public function  is_exists_object($id){
				global $wpdb;
				$table=$this->table_objects;
				$query="SELECT ID FROM ".$table." WHERE ID=%d ";
				$query=$wpdb->prepare($query, $id);
				$var=$wpdb->get_var($query);
				if($this->debug){
					$data=array(
							'id'=>$id,
							'query'=>$query,
							'var'=>$var
					);
					self::debug("is_exists_object", $data);
					///Class_My_Module_Debug::add_section('is_exists_object', $data,$this->use_case);
				}
				return $var;
			}	
		/**
		 * Ise exists object by type
		 * @param unknown $id
		 * @param unknown $type
		 * @return Ambigous <string, NULL>
		 */
		public function  is_exists_object_by_type($id,$type){
				global $wpdb;
				$table=$this->table_objects;
				$query="SELECT ID FROM ".$table." WHERE ID=%d AND object_type=%s";
				$query=$wpdb->prepare($query, $id,$type);
				$var=$wpdb->get_var($query);
				if($this->debug){
					$data=array(
						'id'=>$id,
						'query'=>$query,
						'var'=>$var
					);
					self::debug("is_exists_object_by_type",$data);
					//Class_My_Module_Debug::add_section('is_exists_object_by_type', $data,$this->use_case);
				}
			return $var;
		}				
	}
}