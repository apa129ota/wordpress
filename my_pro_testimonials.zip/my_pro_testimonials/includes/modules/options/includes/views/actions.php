<?php
if(!defined('ABSPATH'))die('');
?>
<div class="my_buttons">
		<ul>
			<li><input type="button" class="my_action button" data-key="reset_options" value="<?php echo __("Reset Options","my_support_theme")?>"/></li>
			<li><input type="button" class="my_action button button-primary" data-key="save_options" value="<?php echo __("Save Options","my_support_theme")?>"/></li>
		</ul>
	</div>