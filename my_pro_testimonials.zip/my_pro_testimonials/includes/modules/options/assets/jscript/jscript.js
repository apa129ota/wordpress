jQuery(document).ready(function($){
	//console.log('Options',my_msg_saving_option);
	$(document).on('click',".my_action",function(e){
		e.preventDefault();
		var key=$(this).data('key');
		console.log('key',key);
		var nonce=$("input[name='my_nonce_options']").val();
		console.log('noce',nonce);
		
		var o={show_msg:1};
		if(key=='reset_options'){
			o.data={
				action:my_options_ajax_action,
				my_action:'reset_options',
				nonce:nonce,				
			};
			o.success=function(data){
				if(data.error==0){
					window.location.reload(true);
				}
			}
			myGlobalAjaxClass_inst.call_ajax(o,my_msg_options_reset_option);
		}else if(key=='save_options'){
			o.data={
					action:my_options_ajax_action,
					my_action:'save_options',
					nonce:nonce,
					form_data:$("#my_form_options").serialize(),
					
				};
				o.success=function(data){
					console.log('Frotn script',data);
				}
				myGlobalAjaxClass_inst.call_ajax(o,my_msg_options_saving_option);
			
		}
	});
});