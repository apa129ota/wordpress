<?php
if(!defined('ABSPATH'))die('');
$info=array(
		'title'=>'Plugin options',
		'description'=>'Module for rendering plugin options',
		'class'=>'Class_My_Module_Options',

);
return $info;
