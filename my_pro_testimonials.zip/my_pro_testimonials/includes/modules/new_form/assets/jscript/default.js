jQuery(document).ready(function($){
	$(document).on("click",".my_form_section_header",function(e){
		var is=$(this).parents(".my_form_section").attr('data-open');
		var set=0;
		if(is==0)set=1;
		if(window.console){
			console.log('Set',{set:set,is:is});
		}
		if(set==1){
			$(this).parents(".my_form_section").find(".fa-plus").hide();
			$(this).parents(".my_form_section").find(".fa-minus").show();
		}else {
			$(this).parents(".my_form_section").find(".fa-minus").hide();
			$(this).parents(".my_form_section").find(".fa-plus").show();

		}
		$(this).parents(".my_form_section").attr('data-open',set);
		$(this).parents(".my_form_section").find(".my_form_section_inner").slideToggle();
		
		
	});
	$(".my_tooltip").tooltip({
		items:"div",
		
		content:function(){
			var html=$(this).children(".my_content").html();
			///console.log('Html '+html);
			return html;
		}
		});
});