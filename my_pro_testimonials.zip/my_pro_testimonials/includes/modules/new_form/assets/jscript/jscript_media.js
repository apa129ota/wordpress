(function($) {
	wpMyModuleNewFormMedia=function(o){
		var self;
		this.debug=true;
		this.options={};
		this.id='';
		this.name='';
		this.div_id='';
		this.my_working=false;
		this.values={};		
		this.duration=400;
		this.active_class='my_radio_list_ul_li_active';
		this.button_class='my_media_button';
		this.prev_send='';
		this.prev_insert='';
		this.media;
		this.frame='select';
		self=this;
		this.init=function(o){
			if(typeof o.my_debug!='undefined'){
				if(!o.my_debug){
					self.debug=false;
				}
			}
			self.my_debug("Options",o);
			self.options=o;
			self.id=self.options.id;
			self.name=self.options.name;
			self.div_id=self.options.div_id;
			var options={
					title:self.options.media_title,
					multiple:self.options.multiple,
					frame:self.frame,
					button:{text:self.options.button_text}
				};
			if(self.options.filter_type!='undefined'){
				options.library={};
				options.library.type=self.options.filter_type;
			}
			self.media=new wp.media(options);	
			self.media.on('select',self.my_send_attachment);
			$("#"+self.div_id+" ."+self.button_class).click(self.my_open_media);
		};
		this.my_open_media=function(e){
			e.preventDefault();
			if(typeof wp.media.editor.send.attachment!='undefined'){
				self.prev_send=wp.media.editor.send.attachment;
			}
			if(typeof wp.media.editor.insert!='undefined'){
				self.prev_insert=wp.media.editor.insert;
			}
			self.media.open();
		};
		this.my_send_attachment=function(){
			
			var att=self.media.state().get('selection').toJSON();
			self.my_debug('Att',att);
			$.each(att,function(i,v){
				
			});
		};
		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log("***ModuleFormMainSCript *** \n"+t,o);
				}
			}
		};
	this.init(o);
	
};
})(jQuery);		