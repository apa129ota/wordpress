(function($) {
	wpMyModuleNewFormPlupload=function(o){
		var self;
		this.debug=true;
		this.options={};
		this.id='';
		this.name='';
		this.div_id='';
		this.my_working=false;
		this.multiple=false;
		this.duration=200;
		this.animation='slideToggle';
		this.filter=false;
		this.ids={
				my_progress_div:'my_progress_div{name}',
				my_progress_bar:'my_progress_bar{name}',
				my_progress_bar_span:'my_progress_bar_span{name}',
				my_plupload_start_upload:'my_plupload_start_upload{name}',
				my_file_name:'my_file_name_12_12{name}',
				my_remove_file:'my_pluplod_remove_file{name}'
		};
		this.pre_options={
				
		};
		this.val_c=0;
		this.text='';
		this.value='';
		this.default_value='';
		this.my_start_upload=false;
		this.files=[];
		self=this;
		this.init=function(o){
			if(typeof o.my_debug!='undefined'){
				if(!o.my_debug){
					self.debug=false;
				}
			}
		
			self.my_debug("Options",o);
			self.options=o;
			self.id=self.options.id;
			self.name=self.options.name;
			self.div_id=self.options.div_id;
			self.multiple=self.options.multiple;
			self.set_ids();
			self.plupload= new plupload.Uploader(self.options.plupload);
			var my_uploader_121=self.plupload;
			my_uploader_121.bind('Init', self.init_plupload);
			
			self.plupload.init();
			$("#"+self.ids.my_plupload_start_upload).on('click',self.start_upload);
			self.plupload_bind_actions();
			$(document).on('click',"#"+self.div_id+" .my_pluplod_remove_file",self.my_remove_file);
		};
		this.my_remove_file=function(e){
			e.preventDefault();
			var id=$(this).data('i');
			self.my_debug('Remove file',id);
			self.plupload.splice(id,1);
			self.files.splice(id);	
			self.plupload.refresh();
			$(this).parent('li').fadeOut(function(){$(this).remove()});
			self.my_debug("files",self.files);
		};
		this.start_upload=function(){
			self.my_debug("Start ulpoad");
			if(self.my_start_upload)return;
			$captcha_div=$(this).parents('form').find(".recaptcha_div");
			$captcha_name=$(this).parents('form').find(".recaptcha_div").data('name');
			if(typeof wpMyModuleNewFormRecaptcha_inst!='undefined'){
			if(self.options.verify_capctha==1){
				
				var v=wpMyModuleNewFormRecaptcha_inst.verifyElemCaptcha($captcha_div,false);
				if(!v){
					myAdminMsgs_inst.show_remove(self.options.msgs.verify_capctha,1);
					return;
				}
			}
			}
			if(self.plupload.files.length==0){
				myAdminMsgs_inst.show_remove(self.options.msgs.add_files,1);
				return;
			}
			
			self.my_start_upload=true;
			self.plupload.refresh();
			self.plupload.start();
			
		
		};
		this.plupload_error=function(uploader,error){
			self.my_debug("Error",error);
			var msg=self.options.msgs.error_msg;
			msg=msg.replace('{msg}',error);
			myAdminMsgs_inst.show_remove(msg,1);
		};
		this.my_added_files=function(up,files){
			var hundredmb = 100 * 1024 * 1024, max = parseInt(up.settings.max_file_size, 10);
			var count=parseInt(self.options.count);
			if (files.length > count){
				var msg=self.options.msgs.count_files;
				msg=msg.replace('{count}',count)
				myAdminMsgs_inst.show_remove(msg,1);
				return false;
			}
			$.merge(self.files,files);
			self.show_files(self.files);
			self.my_debug("Added files",self.files);
		};
		this.show_files=function(files){
			self.my_debug("files",files);
			var html='';
			$.each(files,function(i,v){
				var name=v.name;
				html+='<li>'+name+'&nbsp;&nbsp;&nbsp;<a href="#javascript" class="my_pluplod_remove_file"  data-i="'+i+'"><i class="fa fa-close"></i></a></li>';
				
			});
		
			$("#"+self.div_id).find("."+self.ids.my_file_name+" ul ").html(html);
		};
		this.upload_progress=function(C,D){
			self.my_debug("Upload",{c:C,d:D});
			var my_progress_div=self.ids.my_progress_div;
			var my_progress_bar=self.ids.my_progress_bar;
			var my_progress_bar_span=self.ids.my_progress_bar_span;
			$("#"+self.div_id+" #"+my_progress_div).show();
			$("#"+self.div_id+" #"+my_progress_bar).css('width','0%');
			$("#"+self.div_id+" #"+my_progress_bar_span).html('0%');
			if(D.percent<=100){
				
				//var width=D.percent*3;
				$("#"+self.div_id+" #"+my_progress_bar).css('width',D.percent+'%');
				$("#"+self.div_id+" #"+my_progress_bar_span).html(D.percent+'%');
				}
			
			
		};
		this.uploadded=function(up, file, response){
			//my_uploader_121.bind('FileUploaded', function(up, file, response) {
				self.my_debug("Uploaded",file);
				var response_12=response.response;
				response_12 = $.parseJSON(response_12);
				self.my_debug("Data",response_12);
				self.my_start_upload=false;
				self.files=[];
				$("#"+self.div_id).find("."+self.ids.my_file_name+" ul li").fadeOut(function(){$(this).remove()});
				var my_progress_div=self.ids.my_progress_div;
				$("#"+self.div_id+" #"+my_progress_div).hide();
				if(typeof wpMyModuleNewFormRecaptcha_inst!='undefined'){
				if(self.options.verify_capctha==1){
					$captcha_name=$("#"+self.div_id).parents('form').find(".recaptcha_div").data('name');
					wpMyModuleNewFormRecaptcha_inst.resetCaptcha($captcha_name);
				}
				}
				var msg=response_12.msg;
				if(response_12.error==1){
					
					myAdminMsgs_inst.show_remove(msg,1);
					}else {
						myAdminMsgs_inst.show_remove(msg,0);
							
						}		
				
			//});
		};
		this.beforeUpload=function(up,file){
			if(typeof wpMyModuleNewFormRecaptcha_inst!='undefined'){
			if(self.options.verify_capctha==1){
				$captcha_div=$("#"+self.div_id).parents('form').find(".recaptcha_div");
				$captcha_name=$($captcha_div).data('name');
				self.my_debug("Capctha name",$captcha_name);
				var val=wpMyModuleNewFormRecaptcha_inst.getCaptchaValue($captcha_div);
				
				$.extend(up.settings.multipart_params, {
					'my_captcha':val
				});
			}
			}
		};
		this.plupload_bind_actions=function(){
			var my_uploader_121=self.plupload;
			my_uploader_121.bind('Error',self.plupload_error);
			my_uploader_121.bind('FilesAdded', self.my_added_files);
			if(self.options.show_progress){
				my_uploader_121.bind("UploadProgress",self.upload_progress);
			}
			my_uploader_121.bind('FileUploaded', self.uploadded);
			my_uploader_121.bind('BeforeUpload', self.beforeUpload);
			/*my_uploader_121.bind('BeforeUpload', function (up, file) 
				    {
				my_class='my_recaptcha_thumb1';
				var captcha_val=$("."+my_class+" .g-recaptcha-response").val();
			    		var my_val=$(".my_upload_image_12_121").data('post-id');
			    		//console.log("Post id",my_val);
						if(typeof my_val !='undefined'){
							console.log('my_val',my_val);
				        	$.extend(up.settings.multipart_params, {
				        	'post_id': my_val,
				        	'my_captcha':captcha_val,
				        	'my_type_12':'company'
				        	});
				        	
								
						}
				    });*/
		
					/*function(C, D) {
				//console.log('upload',D);
				$(my_selection_class+" #my_progress_div1").css('display','block');
				$(my_selection_class+" #my_progress_bar1 >div").css('width','0px');
				$(my_selection_class+" #my_progress_bar_span1 ").html('0%');
				if(D.percent<=100){
					
					var width=D.percent*3;
					$(my_selection_class+" #my_progress_bar1 >div").css('width',width+'px');
					$(my_selection_class+" #my_progress_bar_span1 ").html(D.percent+'%');
					}
				
				});*/
			// A new file was uploaded:
			
			
			
		};
		
		this.init_plupload=function(up){
			var uploaddiv = $('#plupload-upload-ui'+self.name);

			if(up.features.dragdrop){
				uploaddiv.addClass('drag-drop');
				$('#drag-drop-area'+self.namew)
					.bind('dragover.wp-uploader', function(){ uploaddiv.addClass('drag-over'); })
					.bind('dragleave.wp-uploader, drop.wp-uploader', function(){ uploaddiv.removeClass('drag-over'); });

			} else{
				uploaddiv.removeClass('drag-drop');
				$('#drag-drop-area1').unbind('.wp-uploader');
			}

		};
		this.set_ids=function(){
			var name=self.name;
			$.each(self.ids,function(i,v){
				self.ids[i]=v.replace('{name}',name);
			});
			self.my_debug('ids',self.ids);
		};
		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log("***ModuleFormMainSCript *** \n"+t,o);
				}
			}
		};
	this.init(o);
	
};
})(jQuery);			