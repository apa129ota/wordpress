(function($) {
	wpMyModuleNewFormOnOff=function(o){
		var self;
		this.debug=true;
		this.options={};
		this.id='';
		this.name='';
		this.div_id='';
		this.my_working=false;
		this.multiple=false;	
		this.value=0;
		this.val_c=0;
		this.has_events=false;
		self=this;
		this.init=function(o){
			if(typeof o.my_debug!='undefined'){
				if(!o.my_debug){
					self.debug=false;
				}
			}
			self.my_debug("Options",o);
			self.options=o;
			self.id=self.options.id;
			self.name=self.options.name;
			self.div_id=self.options.div_id;
			//self.multiple=self.options.multiple;
			if($("#"+self.div_id).find("input[type='checkbox']").is(":checked")){
				self.value=1;
			
			}else {
				
				self.value='';
			}
			if(typeof self.options.events!='undefined'){
				self.has_events=true;
			}
			self.my_debug("Value",self.value);
			$("#"+self.div_id).find(".imapper-checkbox-on").click(self.check);
			$("#"+self.div_id).find(".imapper-checkbox-off").click(self.uncheck);
			$("#"+self.div_id).data('my-script',this);
			if(self.value==1){
				$("#"+self.div_id).find(".imapper-checkbox-on").trigger('click');
			}else {
				$("#"+self.div_id).find(".imapper-checkbox-off").trigger('click');
			}
		},
		this.trigger_check=function(){
			var obj=[self,self.value,$("#"+self.div_id).data('base-name')];
			self.my_debug("Change on off",obj);
			$("#"+self.div_id).trigger('my_on_off',obj);
		};
		this.set_value=function(value){
			if(value==''){
				$("#"+self.div_id).find(".imapper-checkbox-off").trigger('click');
			}else {
				$("#"+self.div_id).find(".imapper-checkbox-on").trigger('click');
			}
		};
		this.check=function(e){
			self.my_debug("Check",self.value);
			if(self.value==1)return;
			
			self.value=1;
			self.trigger_check();
			$("#"+self.div_id).find("input[type='checkbox']").prop("checked",true);
			$(this).removeClass('inactive');
			$("#"+self.div_id).find(".imapper-checkbox-off").addClass("inactive");
			if(self.has_events &&(typeof self.options.events.change=='string')){
				
			}
			else if(self.has_events &&(typeof self.options.events.change=='function')){
				self.options.events.change(self,1);
			}
			
		},
		this.uncheck=function(e){
			self.my_debug("UnCheck",self.value);
			if(self.value==0)return;
			self.value=0;
			self.trigger_check();
			$("#"+self.div_id).find("input[type='checkbox']").prop("checked",false);
			$("#"+self.div_id).find(".imapper-checkbox-on").addClass('inactive');
			$("#"+self.div_id).find(".imapper-checkbox-off").removeClass("inactive");
			
			//$(this).removeClass('inactive');
			if(self.has_events &&(typeof self.options.events.change=='function')){
				self.options.events.change(self,0);
			}
			
		},
		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log("***ModuleFormMainSCript *** \n"+t,o);
				}
			}
		};
	this.init(o);
	
};
})(jQuery);			