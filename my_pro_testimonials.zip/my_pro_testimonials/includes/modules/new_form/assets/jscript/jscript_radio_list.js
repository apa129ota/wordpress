(function($) {
	wpMyModuleNewFormRadioList=function(o){
		var self;
		this.debug=true;
		this.options={};
		this.id='';
		this.name='';
		this.div_id='';
		this.my_working=false;
		this.value='';
		this.filter=false;
		this.duration=400;
		this.active_class='my_radio_list_ul_li_active';
		this.check_class='my_radio_list_check';
		self=this;
		this.init=function(o){
			if(typeof o.my_debug!='undefined'){
				if(!o.my_debug){
					self.debug=false;
				}
			}
			self.my_debug("Options",o);
			self.options=o;
			self.id=self.options.id;
			self.name=self.options.name;
			self.div_id=self.options.div_id;
			self.value=$("#"+self.div_id).data('value');
			self.my_debug("Value",self.value);
			$("#"+self.div_id+" ."+self.check_class).click(self.my_change);
			$("#"+self.div_id+" label").click(self.my_change);
		};
		this.trigger_change=function(){
			var obj=[self,self.value,$("#"+self.div_id).data('base-name')];
			self.my_debug("Change radio list",obj);
			$("#"+self.div_id).trigger('my_change',obj);
		};
		this.my_change=function(e){
			if(self.my_working)return;
			self.my_working=true;
			//var value=$("#"+self.div_id+" input[name='"+self.name+"']:checked").val();
			var id=$("#"+self.div_id+" input[name='"+self.name+"']:checked").attr('id');
			var id_1=$(this).data('id');
			self.my_debug("Check",{id:id,id_1:id_1});
			if(id==id_1){
				self.my_debug("click on checked");
				self.my_working=false;
				return;
			}else {
				self.my_id=id;
				self.my_id_1=id_1;
				$("#"+self.div_id+" ."+self.check_class+"[data-id='"+self.my_id+"']").parents('li').removeClass(self.active_class);
				
				$("#"+self.div_id+" ."+self.check_class+"[data-id='"+id+"'] i").animate({opacity:0},self.duration);
				$("#"+self.div_id+" ."+self.check_class+"[data-id='"+id_1+"'] i").animate({opacity:1},self.duration,function(){
				
				
				$("#"+self.div_id+" ."+self.check_class+"[data-id='"+self.my_id_1+"']").parents('li').addClass(self.active_class);
				
				self.my_working=false;
				var value=$("#"+self.my_id_1).val();
				$("#"+self.my_id_1).prop('checked',true);
				self.value=value;
				self.my_debug("Value",self.value);
				self.trigger_change();
				});
			}
		};
		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log("***ModuleFormMainSCript *** \n"+t,o);
				}
			}
		};
	this.init(o);
	
};
})(jQuery);			