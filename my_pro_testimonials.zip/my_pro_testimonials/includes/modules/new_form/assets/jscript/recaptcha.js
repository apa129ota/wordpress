(function($) { 
	wpMyModuleNewFormRecaptcha=function(o){
		var self;
		this.debug=true;
		this.options=o;
		this.recaptchas={};
		self=this;
		this.init=function(o){
			if(typeof o.my_debug!='undefined'){
				if(!o.my_debug){
					self.debug=false;
				}
			}
			self.my_debug("Options",o);
			self.options=o;
		};
		this.changeCaptcha=function(response){
				self.my_debug("Response",response);
		};
		this.resetCaptcha=function(name){
			if(typeof self.recaptchas=='undefined'){
				return false;
			}
			var widget=self.recaptchas[name].widget;
			grecaptcha.reset(widget);
		};
		this.initCaptchas=function(){
	
			jQuery('body').find(".recaptcha_div").each(function(i,v){
		var name=jQuery(this).children('div').data('name');
		var id=jQuery(this).children('div').attr('id');
		var key=jQuery(this).children('div').data('sitekey');
		if(typeof self.recaptchas[name]=='undefined'){
		//console.log("Init captchas",{name:name,id:id,key:key});
		self.my_debug("Init captcha",{name:name,id:id,key:key})
		self.recaptchas[name]={};
		self.recaptchas[name].id=id;
		
		self.recaptchas[name].widget=grecaptcha.render(id,{
			'sitekey':key,
			'callback':self.changeCaptcha
			
		});
		}
	});
	};
	this.getCaptchaValue=function($elem){
		var val=jQuery($elem).find(".g-recaptcha-response").val();
		self.my_debug("Captcha val",val);
		return val;
	}
	this.verifyElemCaptcha=function($elem,s){
	var v=jQuery($elem).find(".g-recaptcha-response").val();
	 if(v.length == 0)
	    {
		 	if(s){
		 		var top=$($elem).offset().top;
		 		jQuery("html,body").animate({scrollTop:top+"px"});
		 	}
	    	return false;
	    }else {
	    	return true;
	    }
	};
	this.verifyCaptcha=function(name){
	var widget=self.recapcthas[name].widget;	
	 var v = grecaptcha.getResponse(widget);
	    if(v.length == 0)
	    {
	    	return false;
	    }else {
	    	return true;
	    }
	
	};
	this.my_debug=function(t,o){
		if(self.debug){
			if(window.console){
				console.log('Recaptcha \n'+t,o);
		}
	}
};
	this.init(o);
	
};
})(jQuery);		
