<?php
if(!defined('ABSPATH'))die('');
$max_file_size=10e6;
$arr['plupload']= array(
		'runtimes'            => 'html5,silverlight,flash,html4',
		'browse_button'       => 'plupload-browse-button{name}',
		'container'           => 'plupload-upload-ui{name}',
		'drop_element'        => 'drag-drop-area{name}',
		'file_data_name'      => 'async-upload',
		'multiple_queues'     => false,
		'multi_selection'	  => false,
		//'max_file_size'       => wp_max_upload_size().'b',
		'max_file_size'       => $max_file_size.'b',
		'url'                 => admin_url('admin-ajax.php'),
		'flash_swf_url'       => includes_url('js/plupload/plupload.flash.swf'),
		'silverlight_xap_url' => includes_url('js/plupload/plupload.silverlight.xap'),
		'filters'             => array('max_file_size'=>$max_file_size.'b','mime_types'=>array(array('title' => __('Images', 'wp_my_quiz_domain'), 'extensions' => 'jpg,png,gif,jpeg'))),
		'multipart'           => true,
		'urlstream_upload'    => true,

		// Additional parameters:
		'multipart_params'    => array(
				
		),
);
$arr['jscript']=array(
	'verify_capctha'=>1,
	'show_progress'=>1,
	'count'=>1		
);
$arr['msgs']=array(
	'error'=>__("Error","my_support_theme"),
	'error_msg'=>__("Error : ","my_support_theme").'{msg}',
	'verify_capctha'=>__("Captcha is required","my_support_theme"),
	'add_files'=>__("Add Files , before upload","my_support_theme")		
);
return $arr;