<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_Wp_My_Module_New_Form')){
	class Class_Wp_My_Module_New_Form{
		static $my_id=0;
		static $called_scripts=false;
		private $dir;
		private $url;
		private $skin='default';
		private $template_dir='default';
		private $element_template='';
		private $form_template='';
		private $hidden=array();
		private $form_options;
		private $elements;
		private $elements_dir;
		private $html='';
		private $layout=false;
		private $action='';
		private $upload=false;
		private $jscript_options=array();
		private $jscript_events=array();
		private $my_debug=0;
		private $sections;
		private $has_sections=false;
		static  $render_catchas=false; 
		private $element_types=array(
			'recaptcha',
			'plupload',	
			'jscript_stars',	
			'jscript_dropdown',
			'jscript_checkbox_list',
			'jscript_radio_list',
			'jscript_color_picker',
			'jscript_autocomplete',
			'jscript_media',
			'jscript_spinner',	
			'password',
			'textarea',	
			'on_off',	
			'text',
			'button',
			'date',
			'tiny_mce',
			'thumb',
			'radio_list',
			'checkbox'											
					
		);
		static $jscript_elements;
		static $color_pickers;
		function Class_Wp_My_Module_New_Form($options=array()){
			
			
			if(!empty($options)){
				foreach($options as $key=>$val){
					$this->$key=$val;
				}
			}
			//Class_Wp_My_Module_New_Form::$jscript_elements=array();
			Class_Wp_My_Module_New_Form::$my_id++;
			$this->id=Class_Wp_My_Module_New_Form::$my_id;
			if(isset($options['id'])){
				$this->id=$options['id'];
			}
			$this->dir=plugin_dir_path(__FILE__);
			$this->url=plugin_dir_url(__FILE__);
			$file=$this->dir.'includes/functions.php';
			require_once $file;
			if(is_admin()){
				add_action('admin_head', array($this,'wp_head'),PHP_INT_MAX);
				add_action('admin_enqueue_scripts',array($this,'scripts'),PHP_INT_MAX);
				add_action('admin_footer','my_new_form_footer',PHP_INT_MAX-1);
				/*add_action('wp_head', array($this,'wp_head'),PHP_INT_MAX);
				add_action('wp_enqueue_scripts',array($this,'scripts'),PHP_INT_MAX);
				*/
			}else {
				add_action('wp_footer','my_new_form_footer',PHP_INT_MAX-1);
				add_action('wp_enqueue_scripts',array($this,'scripts'),PHP_INT_MAX);
				add_action('wp_head', array($this,'wp_head'),PHP_INT_MAX);
				
				
				
			}
			$this->elements_dir=$this->dir.'views/'.$this->template_dir.'/elements/';
		}
		public function admin_footer(){
			$p=Class_Wp_My_Module_New_Form::$color_pickers;
			if($this->my_debug){
				Class_My_Module_Debug::add_section("color_pickers",$p,'new_form');
			}
			foreach($p as $key=>$val){
				?>
				<div id="<?php echo $key;?>" class="my_color_picker_iris_holder"  data-open="0">
				</div>
				<?php 
			}
		}
		/**
		 * Admin or wp head
		 */
		public function wp_head(){
			$options=array(
				'id'=>$this->id,
				'elements'=>$this->jscript_options,
				'elements_types'=>$this->element_types,
				'my_debug'=>$this->my_debug			
			);
			?>
						<script type="text/javascript">
							jQuery(document).ready(function($){
								text=<?php echo json_encode(Class_Wp_My_Module_New_Form::$jscript_elements)?>;
								/*if(window.console){
									console.log('Scripts',text);
								}*/
								});
						</script>
						<?php 
			?>
			<?php if(!self::$render_catchas &&isset(self::$jscript_elements['recaptcha'])){				
				self::$render_catchas=true;
				$capctha_options=array(
					'my_debug'=>$this->my_debug
				);
				?>
				<script type="text/javascript">
				jQuery(document).ready(function($){
					
					var c_o=<?php echo json_encode($capctha_options);?>;
					wpMyModuleNewFormRecaptcha_inst=new wpMyModuleNewFormRecaptcha(c_o);
					myRecapcthaInitOnLoad=function(){
					wpMyModuleNewFormRecaptcha_inst.initCaptchas();
					};
				});
				</script>
			<?php }?>
			<script type="text/javascript">
				jQuery(document).ready(function($){
					var o1={};
					o1.test='text';
					o1.my_debug=<?php echo $this->my_debug;?>;
					
					if(typeof wpMyModuleValidateScript_inst=='undefined'){
						wpMyModuleValidateScript_inst=new wpMyModuleNewFormValidate(o1);					
					}
					var o=<?php echo json_encode($options);?>;
					<?php if(!empty($this->jscript_events)){?>
						<?php foreach($this->jscript_events as $key=>$val){?>
						o.elements.<?php echo $key;?>.events={};
							<?php foreach($val as $key_1=>$val_1){?>
								o.elements.<?php echo $key;?>.events.<?php echo $key_1?>=<?php echo $val_1;?>;
							<?php }?>
						<?php }?>	
					<?php }?>
					$(window).load(function(e){
					wpMyModuleNewFormMainScript_<?php echo $this->id;?>=new wpMyModuleNewFormMainScript(o);
					});
				});
			</script>
			
			<?php 
			
		}
		/**
		 * Admin or wp head scrtipts
		 */
		public function scripts(){
			//echo 'Admin scripts new form';
			if(Class_Wp_My_Module_New_Form::$called_scripts)return;
			Class_Wp_My_Module_New_Form::$called_scripts=true;
			
			
			wp_enqueue_script('jquery');
			wp_enqueue_script("jquery-touch-pounch");
			
			wp_enqueue_script("jquery-ui-core");
			wp_enqueue_script("jquery-ui-widget");
			wp_enqueue_script("jquery-ui-dialog");
			wp_enqueue_script("jquery-ui-tooltip");
			$script_url=plugin_dir_url(__FILE__).'assets/jscript/';
			wp_enqueue_script('wp_my_module_new_form_main_script',$script_url.'main_script.js');
			$css_url=plugin_dir_url(__FILE__).'assets/css/';
			$url=$script_url.'default.js';
			wp_enqueue_script('wp_my_module_new_form_default_script',$url);
			wp_enqueue_style('wp_my_module_new_form_general_style',$css_url.'general.css');
			wp_enqueue_style('wp_my_module_new_form_skin',$css_url.$this->skin.'/front.css');
			wp_enqueue_script('wp_my_module_new_form_validate',$script_url.'jscript_validate.js');
			
			foreach(Class_Wp_My_Module_New_Form::$jscript_elements as $key=>$val){
				//echo 'key='.$key.'<br/>';
				if($key=='date'){
					wp_enqueue_script('jquery-ui-datepicker');
				}
				if(in_array($key,array('password','text','button','date','radio_list')))continue;
				if($key=='jscript_spinner'){
					wp_enqueue_script( 'jquery-ui-spinner' );
						
				}
				if($key=='recaptcha'){
					$lang='en';
					if(defined('ICL_LANGUAGE_CODE'))
						$lang=ICL_LANGUAGE_CODE;
					
					if(!defined($lang))$lang='en';
					$url='https://www.google.com/recaptcha/api.js?lang='.$lang.'&onload=myRecapcthaInitOnLoad&render=explicit';
					wp_enqueue_script('my_google_recaptcha',$url);
					
				}
				if($key=='plupload'){
					wp_enqueue_script('plupload');
					wp_enqueue_script('plupload-html5');
					wp_enqueue_script('plupload-flash');
					wp_enqueue_script('plupload-html4');
				}
				if($key=='jscript_color_picker'){
					if(is_admin()){
					wp_enqueue_script('iris');
					}else {
						wp_enqueue_style( 'wp-color-picker' );
						wp_enqueue_script( 'iris', admin_url( 'js/iris.min.js' ), array( 'jquery-ui-draggable', 'jquery-ui-slider', 'jquery-touch-punch' ), false, 1 );
						//wp_enqueue_script( 'cp-active', plugins_url('/js/cp-active.js', __FILE__), array('jquery'), '', true );
						
					}
				}
				if($key=='jscript_autocomplete'){
					wp_enqueue_script("jquery-ui-autocomplete");
				}
				if($key=='jscript_media' || $key=='thumb'){
					wp_enqueue_media();
				}
				$file=plugin_dir_path(__FILE__).'assets/jscript/'.$key.'.js';
				if(file_exists($file)){
					$url=$script_url.$key.'.js';
					wp_enqueue_script('wp_my_module_new_form_script_elements_'.$key,$url);
					
				}
				}
				
			if($this->my_debug){
				Class_My_Module_Debug::add_section('jscripts', Class_Wp_My_Module_New_Form::$jscript_elements,'new_form',true);
			
			}	
			$url=$css_url.'jquery.mCustomScrollbar.css';
			wp_enqueue_style('mcustomscrollbar_css',$url);
			$url=$script_url.'jquery.mCustomScrollbar.js';
			wp_enqueue_script('customscrollbar_js',$url);
				
		}
		static function clean_key($key){
			$key=preg_replace('/[\s]+/', '_', $key);
			return $key;
		}	
		static function generate_element_id($key,$id){
			$key=Class_Wp_My_Module_New_Form::clean_key($key);
			$new_id=$key.'_'.$id.'_id';
			return $new_id;
		}
		static function generate_element_name($key,$id){
			$key=Class_Wp_My_Module_New_Form::clean_key($key);
			$name=$key.'_'.$id;
			return $name;
		}
		public function render_form(){
			if(!empty($this->elements['sections'])){
				$sections=$this->elements['sections'];
				if($this->my_debug){
					Class_My_Module_Debug::add_section('form_sections', array('sections'=>$this->elements['sections']),'new_form',false);
				}
				$this->elements=array();
				foreach ($sections as $k=>$v){
					$this->sections[$k]=array(
						'elements'=>$v['elements'],
						'title'=>$v['title'],
						'html'=>''			
					);
					if(!empty($v['open'])){
						$this->sections[$k]['open']=true;
					}
					if(!empty($v['tooltip'])){
						$this->sections[$k]['tooltip']=$v['tooltip'];
					}
					foreach($v['elements'] as $k1=>$v1){
						if($v1['type']=='multi'){
							if(!empty($v1['elements'])){
								foreach($v1['elements'] as $key2=>$val2){
									$this->elements[$k1.'_'.$key2]=$val2;
									$this->elements[$k1.'_'.$key2]['key']=$k1.'_'.$key2;
									$this->elements[$k1.'_'.$key2]['multi']=$k1;
									$this->elements[$k1.'_'.$key2]['section']=$k;
								}
							}
							$this->elements[$k1]=$v1;
							unset($this->elements[$k1]['elements']);
						}else {
						$this->elements[$k1]=$v1;
						$this->elements[$k1]['section']=$k;
						}
					}
				}
				$this->has_sections=true;
				if($this->my_debug){
					Class_My_Module_Debug::add_section('elements', $this->elements,'new_form',true);
				}
			}else {
				foreach($this->elements as $key=>$val){
					if(!empty($val['multi'])){
						if(!empty($val['elements'])){
							foreach($val['elements'] as $key1=>$val1){
								$this->elements[$key.'_'.$key1]=$val1;
								$this->elements[$key.'_'.$key1]['multi']=$key;
								$this->elements[$key.'_'.$key2]['key']=$key.'_'.$key2;
							}
						}
						
					}
				}
			}
			//echo '<pre>';print_r($this->elements);echo '</pre>';
			//echo '<pre>';print_r($this->sections);echo '</pre>';
				
			if(!empty($this->elements)){
				foreach($this->elements as $key=>$element){
					$type=$element['type'];
					if($type=='multi')continue;
					//echo 'Element '.$key.' type '.$type;
					if(!isset(Class_Wp_My_Module_New_Form::$jscript_elements[$type])){
						if($this->my_debug){
							Class_My_Module_Debug::add_section('add_jscript_type', $type,'new_form');
						}
						Class_Wp_My_Module_New_Form::$jscript_elements[$type]=0;
					}
					if(!in_array($type,$this->element_types)){
						//print($element);
						//echo 'Element not exists ';
						continue;
					}
					$element_classes=array();
					if(!empty($element['classes'])){
						$element_classes=$element['classes'];
					}
					$element_values=array();
					if(!empty($element['values'])){
						$element_values=$element['values'];
					}
					if(!isset($element['multiple']))$element_multiple=false;
					else $element_multiple=$element['multiple'];
					if($element_multiple){
						$element_value=array();
						if(isset($element['value'])){
							$element_value=$element['value'];
						}else if(isset($element['default'])){
								$element_value=$element['default'];
							}
					}	
						else {
							$element_value='';
							if(isset($element['value'])){
								$element_value=$element['value'];
							}else if(isset($element['default'])){
								$element_value=$element['default'];
							}
							//echo 'Element value '.$key.='='.$element_value;
						}
				
					$element_name=Class_Wp_My_Module_New_Form::generate_element_name($key, $this->id);
					$element_id=Class_Wp_My_Module_New_Form::generate_element_id($key, $this->id);
					$this->elements[$key]['id']=$element_id;
					$this->elements[$key]['name']=$element_name;
					$this->elements[$key]['div_id']=$element_id.'_div';
					$this->jscript_options[$key]=array(
						'type'=>$type,
						'id'=>$element_id,
						'name'=>$element_name,
						'div_id'=>$element_id.'_div',
						'multiple'=>$element_multiple
					);
					if($type=='jscript_color_picker'){
						Class_Wp_My_Module_New_Form::$color_pickers[$element_id.'_div_picker']=1;
					}
					$this->jscript_options['values']=$element_values;
					$this->jscript_options['value']=$element_value;
					if($type=='plupload'){
						$my_options_file=$this->dir.'options/plupload.php';
						$my_options1=require $my_options_file;
						if($this->my_debug){
							Class_My_Module_Debug::add_section("plupload_options", $my_options1);
						}
						$my_options=$my_options1['plupload'];
						$my_change=array('browse_button','container','drop_element');
						foreach ($my_change as $keyv1=>$valv){
							$keyv=$valv;
							$my_options[$keyv]=str_replace('{name}', $element_name, $my_options[$keyv]);
						}
						if($this->my_debug){
							Class_My_Module_Debug::add_section("plupload_options_after", $my_options);
						}
						if(!empty($my_options1['jscript'])){
							foreach($my_options1['jscript'] as $k3=>$v3){
								$this->jscript_options[$key][$k3]=$v3;
									
							}
						}
						if(!empty($element['jscript'])){
							foreach($element['jscript'] as $key_1=>$val_1){
								if(array_key_exists($key_1, $my_options)){
									$my_options[$key_1]=$val_1;
								}else{
									$this->jscript_options[$key][$key_1]=$val_1;
								}
							}
						}
						$this->jscript_options[$key]['msgs']=$my_options1['msgs'];
						$this->jscript_options[$key]['plupload']=$my_options;
					}else {
					if(!empty($element['jscript'])){
						foreach($element['jscript'] as $key_1=>$val_1){
							if($key_1=='events'){
								foreach($val_1 as $key_2=>$val_2){
									$this->jscript_events[$key][$key_2]=$val_2;
								}
								
							}
							$this->jscript_options[$key][$key_1]=$val_1;
						
						}
					}
					}
					$element_show_value='';
					if(!$element_multiple){
						if(in_array($type,array('jscript_dropdown'))){
							if(isset($element['values'][$element_value])){
								$element_show_value=$element['values'][$element_value];
							}	
						}
					}
					$element_file=$this->elements_dir.$type.'.php';
					//echo '<br/>File name '.$element_file.'<br/>';
					if(file_exists($element_file)){
						//echo 'File exists '.$type.'<br/>';
						ob_start();
						require $element_file;
						if(!empty($this->elements[$key]['multi'])){
							$multi=$this->elements[$key]['multi'];
							/*if(!isset($this->elements[$multi]['render_html'])){
								$this->elements[$multi]['render_html']='';
							}*/
							$this->elements[$multi]['render_html']=ob_get_clean();
						}
						else $this->elements[$key]['render_html']=ob_get_clean();
						 
					}else {
						echo 'Not found '.$element_file.'<br/>';
					}
					if($this->has_sections){
						$section=$element['section'];
						if(!empty($this->elements[$key]['multi'])){
							$multi=$this->elements[$key]['multi'];
							if(!isset($this->sections[$section]['html'][$multi])){
							$this->sections[$section]['html'][$multi]=array();
								}
								$this->sections[$section]['html'][$multi][$key]=$this->elements[$multi]['render_html'];
						}
						
						else $this->sections[$section]['html'][$key]=$this->elements[$key]['render_html'];
					}
				}
				$templ=$this->dir.'views/'.$this->skin.'/element.php';
				$multi_tmpl=$this->dir.'views/'.$this->skin.'/multi_template.php';
				if($this->layout==false){
					$element_html='';
					if(!empty($this->element_template)){
						$templ=$this->dir.'views/'.$this->skin.'/'.$this->element_template;
		
					}
					$sections_html=array();
					if($this->has_sections){
						if($this->my_debug){
							Class_My_Module_Debug::add_section('all_sections', $this->sections,'new_form',false);
						}
						foreach($this->sections as $key1=>$val1){
							if($this->my_debug){
								Class_My_Module_Debug::add_section('added_sections_first_top', $key1,'new_form');
							}
							$element_html='';
							$html1=$val1['html'];
							unset($my_multi);
							foreach($html1 as $key=>$val){
							//echo 'key '.$key.'<br/>';
							$c=0;
							if(is_array($val)){
								$multi_html='';
								
								//print_r($val);
								foreach($val as $key2=>$val2){
									if($this->my_debug){
										Class_My_Module_Debug::add_section('added_sections_first_top_'.$key2, $key1,'new_form',false);
									}
								$element=$this->elements[$key2];
									
								
								//if($c==0)$element_html.='<ul>';
								$my_html=$val2;
								$my_multi=1;	
								$c++;	
								unset($title);
								unset($tooltip);
								if(!empty($element['multi'])){
									$multi=$element['multi'];
									$title=$this->elements[$multi]['title'];
									if(isset($this->elements[$multi]['tooltip'])){
										$tooltip=$this->elements[$multi]['tooltip'];
									}
								}else {
									$title=$element['title'];
									if(isset($element['tooltip']))
										$tooltip=$element['tooltip'];
										
								}
								$type=$element['type'];
								/*if(!empty($element['multi'])){
									$my_key=$element['key'];
									$element_name=$this->jscript_options[$my_key]['name'];
									$element_id=$this->jscript_options[$my_key]['id'];
								}else {*/
									$element_name=$this->jscript_options[$key2]['name'];
									$element_id=$this->jscript_options[$key2]['id'];
								//}
								ob_start();
								require $multi_tmpl;
								
								$multi_html.=ob_get_clean();
								}
								//$element_html.='</ul>';
								//reset($val);
								//$first_key = key($val);
								//echo $first_key;
								$multi=$key;//$val[$first_key]['multi'];
								$title=$this->elements[$multi]['title'];
								unset($tooltip);
								if(isset($this->elements[$multi]['tooltip'])){
								$tooltip=$this->elements[$multi]['tooltip'];
								}
								$my_html=$multi_html;
								ob_start();
								require $templ;
								
								$element_html.=ob_get_clean();
								if($this->my_debug){
									Class_My_Module_Debug::add_section('added_sections_first_bottom_'.$key2, $key1,'new_form',false);
								}
								
							}else {
							if($this->my_debug){
								Class_My_Module_Debug::add_section('added_sections_first_top_'.$key, $key1,'new_form',false);
							}
							$element=$this->elements[$key];
							//print_r($element);
							$my_html=$val;
							
							
							unset($title);
							unset($tooltip);
							if(!empty($element['multi'])){
								$multi=$element['multi'];
								$title=$this->elelements[$multi]['title'];
								if(isset($this->elelements[$multi]['tooltip'])){
									$tooltip=$this->elelements[$multi]['tooltip'];
								}
							}else {
							$title=$element['title'];
							if(isset($element['tooltip']))
								$tooltip=$element['tooltip'];
							
							}
							$type=$element['type'];
							if(!empty($element['multi'])){
								$my_key=$element['key'];
								$element_name=$this->jscript_options[$my_key]['name'];
								$element_id=$this->jscript_options[$my_key]['id'];
							}else {
								$element_name=$this->jscript_options[$key]['name'];
								$element_id=$this->jscript_options[$key]['id'];
							}
							ob_start();
							require $templ;
								
							$element_html.=ob_get_clean();
							}
							}
							$title=$val1['title'];
							$tooltip='';
							$open=false;
							if(!empty($this->sections['open'])){
								$open=true;
							}
							if(!empty($val1['tooltip'])){
								$tooltip=$val1['tooltip'];
							}
							if($this->my_debug){
								Class_My_Module_Debug::add_section('added_sections_first_bottom_'.$key, $key1,'new_form',false);
							}
								
							
						
						$templ_section=$this->dir.'views/'.$this->skin.'/section.php';
						
						ob_start();
						require $templ_section;
						$sections_html[$key1]=ob_get_clean();
						if($this->my_debug){
							Class_My_Module_Debug::add_section('added_sections_first', array('key'=>$key1),'new_form');
						}
						}
					}else {
					if(!empty($this->elements)){
						
						foreach($this->elements as $key=>$val){
							$element=$val;
							$my_html=$val['render_html'];
							unset($title);
							unset($tooltip);
							$title=$val['title'];
							if(isset($val['tooltip']))
							$tooltip=$val['tooltip'];
							$type=$element['type'];
							$element_name=$this->jscript_options[$key]['name'];
							$element_id=$this->jscript_options[$key]['id'];
							ob_start();
							require $templ;
							
							$element_html.=ob_get_clean();//$val['render_html'];
							
						}
					}
					}
					
					$id=$this->id;
					$action=$this->action;
					$upload=$this->upload;
					if($this->has_sections){
						if($this->my_debug){
							Class_My_Module_Debug::add_section('sections_html',$sections_html,'new_form',false);
						}
							$file=$this->dir.'views/'.$this->template_dir.'/section_form.php';
						$hidden_arr=$this->hidden;
						require $file;
						
					}else {
					if(!empty($this->form_template)){
						$file=$this->dir.'views/'.$this->template_dir.'/'.$this->form_template;;
					}
					else $file=$this->dir.'views/'.$this->template_dir.'/form.php';
					$hidden_arr=$this->hidden;
					require $file;
					}
				}

			
			}

		}
	}
}	
