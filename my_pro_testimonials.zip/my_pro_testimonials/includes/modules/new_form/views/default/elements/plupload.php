<?php
if(!defined('ABSPATH'))die('');
$default='';
?>

<div data-default="<?php echo esc_attr($default); ?>" data-base-name="<?php echo $key;?>" data-value="<?php if(!$element_multiple)esc_attr($element_value)?>" id="<?php echo $element_id.'_div';?>" data-type="<?php echo $type;?>" data-open="<?php if(!empty($element['open']))echo $element['open']; ?>" data-id="<?php echo $element_id?>" data-name="<?php echo $element_name;?>" <?php if(!empty($element_validate))echo $element_validate;?> class="my_new_module_element jscript_dropdown_div <?php if(!empty($element['div_classes'])){$str=implode(" ",$element['div_classes']);echo $str;}?>">
<div class="my_uploaded_images_<?php echo $element_name?>"></div>
<div class="my_msg_uploaded_<?php echo $element_name?>">
</div>
	<div id="uploaderSection<?php echo $element_name?>" style="position: relative;">
				<div id="plupload-upload-ui<?php echo $element_name?>" class="hide-if-no-js">
					<div id="drag-drop-area<?php echo $element_name;?>">
						<div class="drag-drop-inside">
							<p class="drag-drop-buttons"><input id="plupload-browse-button<?php echo $element_name?>" type="button" value="<?php esc_attr_e('Select Files',"my_support_theme"); ?>" class="button" /></p>
						</div>
					</div>
				</div>
	</div>
	<div class="my_plupload_added_files my_file_name_12_12<?php echo $element_name?>">
		<ul></ul>
	</div>
	<div id="my_progress_div<?php echo $element_name?>" class="my_proggress_div" style="display:none">	
		<h2><?php echo __("Upload Progress","my_support_theme");?></h2>
		<h3 class="my_upload_file"></h3>
		<div style="">
			<div id="my_progress_bar<?php echo $element_name?>" class="my_progress"><div></div></div>
		</div>
		<div style="" id="my_progress_bar_span<?php echo $element_name?>"></div>
		<div style="clear:both"></div>	
	</div>
	<div class="my_upload_button">
		<input id="my_plupload_start_upload<?php echo $element_name;?>" type="button" value="<?php echo __("Start Upload","my_support_theme"); ?>"/>
	</div>
</div>
