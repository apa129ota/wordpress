<?php
if(!defined('ABSPATH'))die('');
$info=array(
		'title'=>'Form Bulder',
		'description'=>'Form module builder',
		'class'=>'Class_Wp_My_Module_Form_Builder',

);
return $info;