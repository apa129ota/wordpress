<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_Wp_My_Module_Form_Builder')){
	class Class_Wp_My_Module_Form_Builder extends Class_My_General_Module{
		private $form;
		private $table_objects='';
		private $tables_objects_meta='';
		private $has_dates=false;
		function __construct($options=array()){
			$options['url']=plugin_dir_url(__FILE__);
			$options['dir']=plugin_dir_path(__FILE__);
			parent::__construct($options);
		}
		public function init($options){
			parent::init($options);
			
		}
	}
}