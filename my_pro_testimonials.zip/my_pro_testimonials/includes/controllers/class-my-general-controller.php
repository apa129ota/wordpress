<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_General_Controller')){
	class Class_My_General_Controller{
		protected $ajax_single=0;
		protected $ajax=0;
		protected $admin_pages;
		protected $ajax_actions;
		protected $slug;
		protected $nonce_key='my_nonce';
		protected $data_type='post';
		protected $data_key='data';
		protected $action;
		protected $multisite=false;
		protected $die_msg;
		protected $html;
		protected $template='';
		protected $views_dirname='';
		protected $debug;
		protected $plugin_object;
		protected $template_vars=array();
		protected $nonce_str='';
		protected $ret;
		protected $ajax_errors='';
		public function Class_My_General_Controller($options){
			$this->debug['options']=$options;
			if(!empty($options)){
				foreach($options as $key=>$val){
					$this->$key=$val;
				}
			}
			$file=$this->plugin_object->getDir('views');
			$this->template_vars['my_views_dirname']=$file;
		}
		protected function checkAjaxAction(){
			if(!in_array($this->action, $this->ajax_actions) &&!array_key_exists($this->action, $this->ajax_actions)){
				$this->ret['error']=1;
				$this->ret['msg']=__("Error","my_support_theme");
				///self::debug("", array('action'=>$this->action,'actions'=>$this->ajax_actions));
				
				return false;
			}
			return true;
		}
		protected function add_template_var($key,$var){
			$this->template_vars[$key]=$var;
		}
		/**
		 * Check capability
		 * @param unknown $cap
		 * @return void|boolean
		 */
		protected function check_capabilty($cap){
			if(is_multisite()){
				$blog_id=get_current_blog_id();
				if(!current_user_can_for_blog($blog_id, $cap)){
					return false;
				}
			}else {
				//$this->debug['check_cap']=$cap;
				if(!current_user_can($cap)){
					//$this->debug['ret_cap']=false;
					return false;
				}
			}
			//$this->debug['ret_cap']=true;
			return true;
		}
		/**
		 * Check user cap to action
		 * @return string
		 */
		protected function check_cap(){
			if($this->ajax){
				$this->debug['ajax']=1;
				$this->debug['action']=$this->action;
				$action=$this->ajax_actions[$this->action];
				$this->debug['action']=$action;
				if(isset($action['is_logged'])&&$action['is_logged']){
					$this->debug['is_logged_is_set']=1;
					if(!is_user_logged_in()){
						$this->debug['user_is_not_logged'];
						return 'not_logged';
					}
				}
				if(isset($action['capability'])&&!empty($action['capability'])){
					if(is_array($action['capability'])){
						$has=false;
						foreach($action['capability'] as $key=>$val){
							$has=$this->check_capabilty($val);
							if($has){
								break;
							}
						}
						return $has;
					}
					else return $this->check_capabilty($action['capability']);
					
				}
			}else {
				$slug=$this->slug;
				$action=$this->admin_pages[$slug];
				if(isset($action['is_logged'])&&$action['is_logged']){
					if(!is_user_logged_in()){
						return 'not_logged';
					}
				}
				if(isset($action['capability'])&&!empty($action['capability'])){
					if(is_array($action['capability'])){
						$has=false;
						foreach($action['capability'] as $key=>$val){
							$has=$this->check_capabilty($val);
							if($has){
								break;
							}
						}
						return $has;
					}
					else return $this->check_capabilty($action['capability']);
						
				}
				
			}
			
		}
		protected function debugAjax($key,$val){
			if($this->debug){
				if(!isset($this->ret['debug']))$this->ret['debug']=array();
				$this->ret['debug'][$key]=$val;
			}
		}
		protected function loadFile($file){
			//$html='';
			//$my_views_dirname=$this->plugin_object->getDir('views');
			if(!empty($this->template_vars))
			extract($this->template_vars);
			if(file_exists($file)){
				ob_start();
				require $file;
				$html=ob_get_clean();
				$this->html=$html;
				
			}else {
				trigger_error(__("Template not found","my_support_theme").$file,E_USER_NOTICE);
			}
		}
		public function route(){
			
		}
		protected function route_ajax(){
			if($this->checkAjaxAction()){
				if(!method_exists($this, $this->action)){
					$this->ret['error']=1;
					$this->ret['msg']=__("Slide Options","my_support_theme");
					//$this->debugAjax('method_dont_exists', $this->action);
				}else {
					ob_start();
					$my_action=$this->action;
					$this->$my_action();
					$errors=ob_get_clean();
					$this->ajax_errors=$errors;
				}
			}
		}
		public function get_html(){
			/*if(!empty($this->template)){
				$file=$this->views_dirname.$this->template;
				$html=$this->html;
				ob_start();
				require $file;
				$html_new=ob_get_clean();
				return $html_new;
				
			}*/
			return $this->html;
		}
		
 	}
}