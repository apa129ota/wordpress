<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Framework_Backend_Controller')){
	class Class_My_Framework_Backend_Controller extends Class_My_General_Controller{
		use MyDebug;
		protected $ret;
		private $use_case='my_framework';
		
		function __construct($options=array()){
			if(!empty($options['debug'])){
				self::setDebugOptions($this->use_case);
			}
			self::debug('framework_backend_controller', $options,false);
			parent::Class_My_General_Controller($options);
			
		}
		public function route(){
			$can=parent::check_cap();
			//echo 'Route '.var_dump($can);
			if($can!==true){
				wp_die($this->die_msg);
			}else {
				//echo 'Slug '.$this->slug;
				$f=$this->slug;
				$f=str_replace('-', '_', $f);
				$this->$f();
			}
		}
		private function my_testimonials_preview() {
			ob_start();
			?>
			<style type="text/css">
			#wpadminbar,#adminmenumain{
				display:none !important;
			}
			</style>
			<?php 
			$file=$this->plugin_object->getDir('modules').'testimonials/includes/modules/front/includes/views/preview_iframe.php';
			require $file;
			$html=ob_get_clean();
			$this->html=$html;
		}
		private function my_testimonials_add_new(){
			//We have id load shortcode
			$this->plugin_object->events->loadModuleClass('front');
			wp_my_general_load_module_function(MY_TESTIMONIALS_LOCAL_MODULES_DIRNAME,'google_font','functions.php');
			global $wp_my_google_fonts_fonts;
			$wp_my_google_fonts_fonts=wp_my_google_fonts_get_fonts_arr();
			
			/*$module_options=array(
					'dir'=>$this->plugin_object->getDir('modules').'testimonials/modules/front/',
					'url'=>$this->plugin_object->getUrl('modules').'testimonials/modules/front/',
					'debug'=>$this->debug,
					'global_plugin'=>$this->plugin_object
			);
			$class=new Class_My_Module_Testimonials_Front($module_options);
			*/
			//$class->init();
			$class=&$this->plugin_object->events->front_module;
			$id=@$_GET['my_id'];
			$class->admin_forms();
			$this->add_template_var('admin_forms', $class->admin_forms);
			$file=$this->plugin_object->getDir('views');
			$file.='pages/add_new.php';
			$this->loadFile($file);
		}
		private function my_testimonials(){
			/*$this->plugin_object->loadModule('testimonials');
			$module_options=array(
					'dir'=>$this->plugin_object->getDir('modules').'testimonials/',
					'url'=>$this->plugin_object->getUrl('modules').'testimonials/',
					'debug'=>$this->debug,
					'global_plugin'=>$this->plugin_object
			);
			$class=new Class_My_Module_Testimonials($module_options);
			*/
			//$class->init();
			if(!empty($_POST['my_action'])){
				$my_action=@$_POST['my_action'];
				if($my_action=='delete'){
					$object_id=@$_POST['my_object_id'];
					$r=$this->plugin_object->events->deleteShortcodeObject($object_id);
					if($r)$this->add_template_var('msg', __("Shortcode is deleted !","my_support_theme"));
					else $this->add_template_var('err_msg', __("Error !","my_support_theme"));
				}
			}
			$edit_view=$this->plugin_object->events->editView();
			$this->add_template_var('edit_view', $edit_view);
			$terms=$this->plugin_object->events->get_categories();
			$this->add_template_var('terms', $terms);
			$shotcode=$this->plugin_object->events->getProperty('form_shortcode');
			$this->add_template_var('shortcode', $shotcode);
			self::debug("terms", $terms,false);
			$file=$this->plugin_object->getDir('views');
			$file.='pages/index.php';
			$this->loadFile($file);
		}
		private function my_testimonials_options(){
			/*ob_start();
			$this->plugin_object->events->loadOptions('test-items.php');
			$str=ob_get_clean();
			Class_My_Module_Debug::debug_file('items', '', $str);
			*/
			$file=$this->plugin_object->getDir('views');
			ob_start();
			echo $this->plugin_object->options->renderForm();
			$html=ob_get_clean();
			$this->template_vars['html']=$html;
			$file.='pages/options.php';
			$this->loadFile($file,$html);
			
			//self::debug("html", $this->html,$this->use_case);
			//echo $this->html;
		}
		
		private function my_events_plugin(){
			$module_options=array(
				'dir'=>$this->plugin_object->getDir('modules').'form/',
				'url'=>$this->plugin_object->getUrl('modules').'form/',
				'debug'=>$this->debug		
			);
			global $wp_my_related_posts_plugin_options;
			$this->plugin_object->loadOptions('test_form.php');
			$form_module=$this->plugin_object->instantiateModuleClass('form',$module_options);
			$options=array(
				'id'=>'plugin',
				'elements'=>$wp_my_related_posts_plugin_options['elements'],
				'msgs'=>$wp_my_related_posts_plugin_options['msgs']		
			);
			$form_module->addForm('plugin',$options);
			ob_start();
			$form_module->renderForm('plugin');
			$ret_html=ob_get_clean();
			$this->html=$ret_html;
		}
		public function get_html(){
			//self::debug("html_call", $this->html,$this->use_case);
			return $this->html;
		}
	}
}