<?php
if (! class_exists( 'Class_My_General_Backend_Class' )) {
	class Class_My_General_Backend_Class {
		use MyDebug,MyLoadFiles;
		protected $ajax_single=false;
		protected $ajax_actions = array ();
		protected $admin_pages;
		protected $controllers_dir;
		protected $controller_file;
		protected $controller_name;
		protected $ajax_controller_file;
		protected $ajax_controller_name;
		protected $is_plugin_admin = false;
		protected $admin_slug = '';
		protected $admin_slugs = array ();
		protected $controller;
		protected $ajax_controller;
		protected $die_msg;
		protected $styles=array();
		protected $views_dirname;
		protected $all_pages;
		protected $debug=true;
		protected $is_from_front=false;
		protected $use_case='my_framework';
		protected $plugin_object;
		function Class_My_General_Backend_Class($options = array()) {
			if (! empty ( $options )) {
				foreach ( $options as $k => $v ) {
					$this->$k = $v;
				}
			}
			
			if(!empty($this->admin_pages)){
				foreach($this->admin_pages as $key=>$val){
					if(!isset($val['is_exists']))$this->all_pages[$key]=$val;
					if(!empty($val['my_subpages'])){
						foreach($val['my_subpages'] as $key1=>$val1){
							$this->all_pages[$key1]=$val1;
						}
					}
				}
			}
			
		}
		/**
		 * Is plugin admin
		 */
		protected function is_plugin_admin() {
			$page = @$_GET ['page'];
			if (! empty ( $page )) {
				if (array_key_exists( $page, $this->all_pages )) {
					$this->is_plugin_admin = true;
					$this->admin_slug = $page;
				}
			}
			if(!empty($this->admin_slug)){
				$this->is_plugin_admin=true;
			}
			if($this->is_plugin_admin){
				$this->loadFile($this->controllers_dir, 'class-my-general-controller.php');
			}
		}
		/**
		 * Check cap
		 * @param unknown $cap
		 * @return boolean
		 */
		protected function check_capabilty($cap){
			if(is_multisite()){
				$blog_id=get_current_blog_id();
				if(!current_user_can_for_blog($blog_id, $cap)){
					return false;
				}
			}else {
				if(!current_user_can($cap)){
					return false;
				}
			}
			return true;
		}
		/**
		 * Check capability
		 * @return string|boolean
		 */
		protected function check_cap(){
			
				$slug=$this->admin_slug;
				$action=$this->all_pages[$slug];
				if(isset($action['is_logged'])&&$action['is_logged']){
					
					if(!is_user_logged_in()){
						return 'not_logged';
					}
				}
				if(isset($action['capability'])&&!empty($action['capability'])){
					if(is_array($action['capability'])){
						$has=false;
						foreach($action['capability'] as $key=>$val){
							$has=$this->check_capabilty($val);
							if($has){
								break;
							}
						}
						return $has;
					}else return $this->check_capabilty($action['capability']);
		
				}
		
				
		}
		/**
		 */
		function init() {
			if (! empty ( $this->admin_pages )) {
				add_action ( "admin_menu", array (
						&$this,
						'admin_menu' 
				) );
			}
			//print_r($this->ajax_actions);
			if (! empty ( $this->ajax_actions )) {
				if(is_array($this->ajax_actions['actions'])){
					$this->ajax_single=true;
					if(isset($this->ajax_actions['controllers_file'])){
						$this->ajax_controller_file=$this->ajax_actions['controllers_file'];
					}else $this->ajax_controller_file=$this->controller_file;
					if(isset($this->ajax_actions['controllers_name'])){
						$this->ajax_controller_name=$this->ajax_actions['controllers_name'];
					}else $this->ajax_controller_name=$this->controller_name;
					$action=$this->ajax_actions['action'];
					$only_logged=true;
					if(isset($this->ajax_actions['only_logged'])){
						$only_logged=$this->ajax_actions['only_logged'];
					}
					add_action('wp_ajax_'.$action,array($this,'call_ajax'));
					/*if(!only_logged){
						add_action('wp_ajax_nopriv_'.$action,array($this,'call_ajax'));
					}*/
				}else {
					foreach ( $this->ajax_actions as $key => $action ) {
						add_action ( 'wp_ajax_' . $key, array (
								$this,
								'call_ajax' 
						) );
					}
				}
			}
			add_action('admin_init',array(&$this,'can_view'));
			if($this->is_from_front){
				add_action ( 'wp_head', array (
				&$this,
				'admin_head'
						) );
						add_action ( 'wp_enqueue_scripts', array (
						&$this,
						'admin_scripts'
								) );
						$this->is_plugin_admin=true;
						add_action('init', array(&$this,'can_view'));
							
			}else {
			add_action ( 'admin_head', array (
					&$this,
					'admin_head' 
			) );
			add_action ( 'admin_enqueue_scripts', array (
					&$this,
					'admin_scripts' 
			) );
			
			$this->is_plugin_admin ();
			}
			if ($this->is_plugin_admin ()) {
				$file = $this->controllers_dir . $this->controller_file;
				require_once $file;
			}
			
		}
		/**
		 * Not permitted action
		 */
		protected function can_view(){
			if($this->is_plugin_admin){
				$cap=$this->check_cap();
				//var_dump($cap);
				if($cap!==true){
					wp_die($this->die_msg);
				}
				//$file = $this->controllers_dir . $this->controller_file;
				//require_once $file;
				$this->loadController($this->controller_file);
				$options['debug']=$this->debug;
				$options ['admin_pages'] = $this->all_pages;
				$options ['slug'] = $this->admin_slug;
				$options['views_dirname']=$this->views_dirname;
				$options['plugin_object']=&$this->plugin_object;
				//$options['views_dirname']=MY_HELPBAR_VIEWS_DIRNAME;
				if(isset($this->admin_pages[$this->admin_slug]['template'])){
					$options['template']=$this->admin_pages[$this->admin_slug]['template'];
				}
				$options['ajax']=0;
			//	print_r($options);
				$this->controller = new $this->controller_name ( $options );
				$this->controller->route();
			
			}
		}
		protected function admin_head() {
			
			
		}
		protected function admin_scripts() {
			if(!empty($this->all_pages[$this->admin_slug]['styles'])){
				foreach ($this->all_pages[$this->admin_slug]['styles'] as $key=>$val){
					wp_enqueue_style($key,$val);
				}
			}
			if(!empty($this->all_pages[$this->admin_slug]['scripts'])){
				foreach ($this->all_pages[$this->admin_slug]['scripts'] as $key=>$val){
					wp_enqueue_script($key,$val);
				}
			}
			
		}
		/**
		 * Add admin pages
		 */
		protected function admin_menu() {
			
			if (! empty ( $this->admin_pages )) {
				foreach ( $this->admin_pages as $key => $page ) {
					$page_title = $page ['title'];
					$menu_title = $page_title;
					$capability = $page ['capability'];
					$menu_slug = $key;
					add_menu_page ( $page_title, $menu_title, $capability, $menu_slug, array (
							&$this,
							'call_page' 
					) );
					$this->admin_slugs [] = $menu_slug;
					if (! empty ( $page ['my_subpages'] )) {
						foreach ( $page ['my_subpages'] as $key_1 => $subpage ) {
							$page_title = $subpage ['title'];
							$menu_title = $page_title;
							$parent_slug = $menu_slug;
							$menu_slug_1 = $key_1;
							$this->admin_slugs [] = $menu_slug_1;
							$capability = $subpage ['capability'];
							add_submenu_page ( $parent_slug, $page_title, $menu_title, $capability, $menu_slug_1, array (
									&$this,
									'call_page' 
							) );
						}
					}
				}
			}
		}
		/**
		 * Route request to page
		 */
		public function call_page() {
			echo $this->controller->get_html();
			
		}
		/**
		 * Call ajax
		 */
		protected function call_ajax() {
			$my_action = @$_POST ['my_action'];
			$action=@$_POST['action'];
			if (! preg_match ( '/^[a-zA-Z_]+$/', $my_action )){
				
				$ret['error']=1;
				echo json_encode($ret);
				exit();
				
			}
			
			if (isset ( $this->ajax_actions [$action] )) {
				$action=$this->ajax_actions[$action];
				if(isset($action['controller'])){
					$contr=$action['controller'];
					$dir=$this->controllers_dir;
					if(isset($action['controller_dir'])){
						$dir=$action['controller_dir'];
					}
					$file=$dir.$this->ajax_controller_file;
					if(isset($action['controller_file'])){
						$file=$dir.$action['controller_file'];
					}
					$name=$this->ajax_controller_name;
					if(isset($action['controller_name'])){
						$name=$action['controller_name'];
					}
					require_once $file;
					$options['ajax']=1;
					$options ['action'] = $action;
					$options ['ajax_single']=$this->ajax_single;
					$options ['ajax_actions'] = $this->ajax_actions;
					$this->ajax_controller=new $name($options);
					$this->ajax_controller->route_ajax();
					
				}else {
					$file = $this->ajax_controllers_dir . $this->ajax_controller_file;
					require_once $file;
					$options['ajax']=1;
					$options ['action'] = $my_action;
					$options ['ajax_single']=$this->ajax_single;
					$options ['ajax_actions'] = $this->ajax_actions;
					$this->controller = new $this->ajax_controller_name ( $options );
					$this->controller->route_ajax ();
				}
				/*
				$file = $this->controllers_dir . $this->controller_file;
				require_once $file;
				$options['ajax']=1;
				$options ['ajax_actions'] = $this->ajax_actions;
				$options ['action'] = $my_action;
				$this->controller = new $this->controller_name ( $options );
				$this->controller->route_ajax ();
				*/
			}
		}
	}
}