<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Framework_Plugin_Class')){
	class Class_My_Framework_Plugin_Class{
		use MyArrayOptions,MyModules,MyLoadFiles;
		protected $is_admin=false;
		protected $dir;
		protected $url;
		protected $version='1.0';
		protected $css_url;
		protected $images_url;
		protected $jscript_url;
		protected $modules_dir;
		protected $modules_url;
		protected $class_dir;
		protected $controllers_dir;
		protected $models_dir;
		protected $options_dir;
		protected $functions_dir;
		protected $tmp_dir;
		protected $views_dir;
		protected $debug=0;
		protected $backed_class_file;
		protected $backend_class_name;
		protected $admin_pages;
		protected $use_case='my_framework';
		public $scripts_class;
		protected $framework_options;
		function __construct($options=array()){
			$this->setOptions($options);
			$this->css_url=$this->url.'assets/css/';
			$this->images_url=$this->url.'assets/images/';
			$this->modules_url=$this->url.'includes/modules/';
			$this->jscript_url=$this->url.'assets/jscript/';
			$this->modules_dir=$this->dir.'includes/modules/';
			$this->class_dir=$this->dir.'includes/class/';
			$this->functions_dir=$this->dir.'includes/functions/';
			$this->options_dir=$this->dir.'includes/options/';
			$this->views_dir=$this->dir.'includes/views/';
			$this->models_dir=$this->dir.'includes/models/';
			$this->controllers_dir=$this->dir.'includes/controllers/';
			$this->tmp_dir=$this->dir.'tmp/';		
		}
		public function getUrl($type='css'){
			switch($type){
				case 'plugin':
					return $this->url;
				break;
				case 'css':
					return $this->css_url;
				break;
				case 'images':
					return $this->images_url;
				break;
				case 'modules':
					return $this->modules_url;
				case 'jscript':
					return $this->jscript_url;
				break;
				default:
					return false;
					//throw new Exception(__("Property with key dont exists","my_support_theme").$type);
					trigger_error(__("Property with key dont exists","my_support_theme").$type,E_NOTICE);
				break;
			}				
						
		}
		public function getDir($type='plugin'){
			switch($type){
				case 'tmp':
					return $this->tmp_dir;
				break;	
				case 'plugin':
				 return $this->dir;
				break;
				case 'class':
					return $this->class_dir;
				break;	 	
				case 'controllers':
					return $this->controllers_dir;
				break;
				case 'modules':
					return $this->modules_dir;
				break;
				case 'models':
					return $this->models_dir;
				break;
				case 'functions':
					return $this->functions_dir;
				break;
				case 'views':
					return $this->views_dir;
				break;	
				case 'options':
					return $this->options_dir;
				break;
				default:
					trigger_error(__("Property with key dont exists","my_support_theme").$type,E_NOTICE);
					return false;
					//throw new Exception(__("Property with key dont exists","my_support_theme").$type);
				break;						
			}
		}
		
		protected function init($options=array()){
			$this->setOptions($options);
			$this->initBackend();
		}
		
		protected function my_debug($key,$val,$all){
			if($this->debug){
				Class_My_Module_Debug::add_section($key, $val,$this->use_case,$all);
			}
		}
		protected function initBackend(){
			if(is_admin()){
				
				$file=$this->options_dir.'options.php';
				$this->framework_options=require $file;
				if(empty($this->framework_options['controllers_dir'])){
					$this->framework_options['controllers_dir']=$this->controllers_dir;
				}
				/*if($this->debug){
					Class_My_Module_Debug::add_section('framework_options', $this->framework_options,'my_framework');
				}*/
				$this->my_debug('framework_options', $this->framework_options, false);
				foreach($this->framework_options as $key=>$val){
					if(property_exists($this, $key)){
						$this->$key=$val;
					}
				}
				if(!empty($this->backed_class_file)){
				
					$file=$this->class_dir.$this->backed_class_file;
					require_once $file;
					$options['debug']=$this->debug;
					$options['plugin_object']=&$this;
					foreach($this->framework_options as $key=>$val){
						$options[$key]=$val;
					}
					$this->backend_class=call_user_func($this->backend_class_name.'::singleton',$options);//$this->backend_class_name::singleton($this->framework_options);
					$this->backend_class->init();
				}
				
			}
		}
		public function debug_footer(){
			if($this->debug){
			$debug=Class_My_Module_Debug::get_debug_source($this->use_case);
			?>
			<script type="text/javascript">
				jQuery(document).ready(function($){
					var my_debug_<?php echo $this->use_case?>=<?php echo json_encode($debug);?>;
					if(window.console){
						console.log("Global Debug <?php echo $this->use_case;?>",my_debug_<?php echo $this->use_case?>);
						}
					});
			</script>
			<?php 
			}
		}
	}
}