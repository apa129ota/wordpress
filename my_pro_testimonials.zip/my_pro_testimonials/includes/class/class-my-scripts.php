<?php
$dir=plugin_dir_path(__FILE__);
require $dir.'class-my-global-scripts.php';
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Framework_Scripts_Class')){
	class Class_My_Framework_Scripts_Class extends Class_My_Global_Scripts_Class{
		function __construct($options=array()){
			parent::__construct($options);
		}	
	}
}