<?php
if(!defined('ABSPATH'))die('');
if(!class_exists('Class_My_Global_Scripts_Class')){
	class Class_My_Global_Scripts_Class{
		use MySingleton,MyArrayOptions,MyDebug;
		protected $debug;
		protected $objects;
		protected $includes;
		protected $styles;
		protected $scripts;
		protected $wpscripts=array();
		protected $wpstyles=array();
		protected $wphead=array();
		protected $wpfooter=array();
		protected $keys;
		protected $min=false;
		protected $my_debug=false;
		protected $assets_url;
		protected $use_case;
		protected $custom_includes=array();
		//static $debug=false;
		function __construct($options=array()){
				
			$this->setOptions($options);	
			if(!empty($options['debug'])){
				//self::$trait_debug=true;
				//self::$trait_use_case=$options['use_case'];
				self::setDebugOptions($options['use_case']);
			}
			$this->objects['fontawesome']=array(
					'css'=>'css/font-awesome.css',
					'css_min'=>'css/font-awesome.min.css'
			);
			$this->objects['fotorama']=array(
					'css'=>'fotorama.css',
					'jscript'=>'fotorama.js'
			);
			$this->objects['flexslider']=array(
					'css'=>'flexslider.css',
					'jscript'=>'jquery.flexslider.js'
			);
			$this->styles['mCustomScrollBar']='jquery.mCustomScrollbar.css';
			$this->scripts['mCustomScrollBar']='jquery.mCustomScrollbar.js';
			$this->styles['jqueryUi']='jquery-ui.css';
			$this->styles['prettyPhoto']='prettyPhoto.css';
			$this->scripts['prettyPhoto']='jquery.prettyPhoto.js';
			if(is_admin()){
				add_action ( 'admin_head', array (&$this,'admin_head'),PHP_INT_MAX );
				add_action ( 'admin_enqueue_scripts', array (&$this,'admin_scripts'),PHP_INT_MAX );
				add_action('admin_footer',array(&$this,'admin_footer'),PHP_INT_MAX);
			}else {
				add_action ( 'wp_head', array (&$this,'admin_head'),PHP_INT_MAX );
				add_action ( 'wp_enqueue_scripts', array (&$this,'admin_scripts'),PHP_INT_MAX );
				add_action('wp_footer',array(&$this,'admin_footer'),PHP_INT_MAX);
			}
			
		}
		protected function setScriptOptions($options=array()){
			if(!empty($options['min'])){
				$this->min=true;
			}
			if(!empty($options['debug'])){
				//self::$trait_debug=true;
				//self::$trait_use_case=$options['use_case'];
				self::setDebugOptions($options['use_case']);
			}
			if(!empty($options['assets_url'])){
				$this->assets_url=$options['assets_url'];
			}
			//self::debug("instantiate_options",$options,false);
			$this->callOnce();
		}
		
		public function addIncludesObj($include=array()){
			self::debug('add_includes', $include,true);
			if(is_array($include)){
				if(!empty($include)){
					foreach($include as $key=>$val){
						if(!isset($this->includes[$val])){
							$this->includes[$val]=1;
						}
					}
				}
			}else {
				$this->includes[$include]=1;
			}
			self::debug("after_adding", $this->includes,false);
		}
		public function addItem($array){
			if($array['type']=='script'){
				$this->wpscripts[]=$array['handle'];
			}else if($array['type']=='style'){
				$this->wpstyles[]=$array['handle'];
			}else if($array['type']=='head'){
				$this->wphead[]=$array['head'];
			}else if($array['type']=='footer'){
				$this->wpfooter[]=$array['head'];
			}
		}
		static function addCustomInclude($key,$arr=array()){
			$instance=self::singleton();
			$instance->custom_includes[$key]=$arr;
			if(!isset($instance->includes[$key])){
				$instance->includes[$key]='custom';
			}
		}
		static function addWordpressFooter($head){
			$instance=self::singleton();
			$instance->addItem(array('head'=>$head,'type'=>'footer'));
		
		}
		static function addWordpressHead($head){
			$instance=self::singleton();
			$instance->addItem(array('head'=>$head,'type'=>'head'));
		
		}
		static function addWordpressScript($script){
			$instance=self::singleton();
			$instance->addItem(array('handle'=>$script,'type'=>'script'));
				
		}
		static function addWordpressStyle($style){
			$instance=self::singleton();
			$instance->addItem(array('handle'=>$style,'type'=>'style'));
		}
		static function addIncludes($includes=array()){
			$instance=self::singleton();
			$instance->addIncludesObj($includes);
		}
		public function admin_scripts(){
			if(!empty($this->wpscripts)){
				foreach($this->wpscripts as $key=>$val){
					wp_enqueue_script($val);
				}
			}
			if(!empty($this->wpstyles)){
				foreach($this->wpstyles as $key=>$val){
					wp_enqueue_style($val);
				}
			}
			//Class_My_Module_Debug::add_section('includes', $this->includes,$this->use_case,false);
			self::debug('includes', $this->includes,true);
			if(!empty($this->includes)){
				foreach($this->includes as $key=>$val){
					$my_found=false;
					if($val=='custom'){
						$obj=$this->custom_includes[$key];
						self::debug("custom_includes", $obj);
						if($obj['type']=='script'){
							wp_enqueue_script($key,$obj['url']);
						}else if($obj['type']=='css'){
							wp_enqueue_style($obj['key'],$obj['url']);
						}
					}else {
					if(array_key_exists($key, $this->objects)){
						$obj=$this->objects[$key];
						$css='';
						$script='';
						if($this->min){
							if(!empty($obj['css_min'])){
								$css=$val['css_min'];
							}
						}
						if(empty($css)){
							if(!empty($obj['css'])){
								$css=$obj['css'];
							}
						}
						$url=$this->getUrl($key, $css);
						$key1=$this->genKey($key,true);
						self::debug('inlcude_style', array('key'=>$key1,'url'=>$url));
						wp_enqueue_style($key1,$url);
						if(!empty($obj['jscript'])){
							$jscript=$obj['jscript'];
							$url=$this->getUrl($key, $jscript);
							$key1=$this->genKey($key,false);
							wp_enqueue_script($key1,$url);
							self::debug('inlcude_script', array('key'=>$key1,'url'=>$url));
						}
					}else {
						if(array_key_exists($key, $this->styles)){
							$file=$this->styles[$key];
							$url=$this->getUrl($key, $file,true,false);
							$key1=$this->genKey($key);
							wp_enqueue_style($key1,$url);
						}
						if(array_key_exists($key, $this->scripts)){
							$file=$this->styles[$key];
							$url=$this->getUrl($key, $file,false,false);
							$key1=$this->genKey($key,false);
							wp_enqueue_script($key1,$url);
						}
					}
					}
				}
			}
		}
		protected function genKey($key,$style=true){
			if($style){
				$key='my_'.$key.'_style';
			}else {
				$key='my_'.$key.'_script';
			}
			return $key;
		}
		protected function getUrl($key,$file,$css=false,$isObject=true){
			$url=$this->assets_url;
			if($isObject){
				$url.=''.$key.'/';
				$url.=$file;
			}else {
				if($css)
					$url.='css/';
				else $url.='jscript/';
				$url.=$file;
			}
			return $url;
		}
		protected function renderItem($val){
			$type=$val['type'];
			if($type=='css'){
				?>
						<style type="text/css"><?php echo $val['value']?></style>
						<?php
					}else if($type='script'){
						?>
						<script type="text/javascript"><?php echo $val['value']; ?></script>
						<?php
					}
											
				}
				public function admin_head(){
					if(!empty($this->wphead)){
						foreach($this->wphead as $key=>$val){
							$this->renderItem($val);
						}
					}
				}
				public function admin_footer(){
					if(!empty($this->wpfooter)){
						foreach($this->wpfooter as $key=>$val){
							$this->renderItem($val);
						}
					}
				}
				
			
	}
}