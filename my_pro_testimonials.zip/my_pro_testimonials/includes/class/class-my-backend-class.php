<?php
if(!defined('ABSPATH'))die('');
$dir=plugin_dir_path(__FILE__);
require_once $dir.'class-my-general-backend-class.php';
if(!class_exists('Class_My_Framework_Backend_Class')){
	class Class_My_Framework_Backend_Class extends Class_My_General_Backend_Class{
		use MySingleton;
		function __construct($options=array()){
			//print_r($options);
			if(!empty($options['debug'])){
				
					self::setDebugOptions($this->use_case);
				
				self::debug('backend_class_options', $options);
			}
			parent::Class_My_General_Backend_Class($options);
		}
		public function init(){
				
			parent::init();
		}
		public function admin_scripts(){
			parent::admin_scripts();
		}
		public function admin_head(){
			parent::admin_head();
		}
		public function admin_menu(){
			parent::admin_menu();
		}
		/*public function call_page(){
			parent::call_page();
		}*/
		public function call_ajax(){
			parent::call_ajax();
		}
		public function can_view(){
			parent::can_view();
		}
	}
}