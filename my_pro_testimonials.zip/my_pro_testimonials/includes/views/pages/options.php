<?php
if(!defined('ABSPATH'))die('');
$my_header_msg=__("Plugin Options","my_support_theme");
?>

<div class="wrap">

	<?php 
	$file=$my_views_dirname.'elements/my_header.php';
	require $file;
	?>
	<div class="my_container_inner">
	<p><?php echo __("Set Global Plugin options","my_support_theme");?></p>
	
	<?php echo $html;?>
	</div>
</div>	