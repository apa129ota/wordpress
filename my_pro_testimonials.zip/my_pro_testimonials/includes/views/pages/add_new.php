<?php
if(!defined('ABSPATH'))die('');
$my_header_msg=__("Add new/Edit Testimonials shortcodes","my_support_theme");
function wp_my_loto($count=7){
	$arr=array();
	for($i=0;$i<$count;$i++){
		$val=mt_rand(1,39);
		while(in_array($val, $arr)){
			$val=mt_rand(1,39);
		}
		$arr[]=$val;
	}
	sort($arr);
	echo '<h4>Loto</h4><pre>'.print_r($arr,true).'</pre>';
}
function wp_my_loto_joker($count=6){
	$arr=array();
	for($i=0;$i<$count;$i++){
		$val=mt_rand(0,9);
		
		$arr[]=$val;
	}
	echo '<h4>Loto joker</h4><pre>'.print_r($arr,true).'</pre>';
}
function wp_my_loto_komb($t=3){
	for($i=0;$i<$t;$i++)
		wp_my_loto();
	
	wp_my_loto_joker();
}
?>
<div class="wrap">
	
	<?php 
	$file=$my_views_dirname.'elements/my_header.php';
	require $file;
	?>
	<div class="my_container_inner">
	<?php
	 //wp_my_loto_joker();
	 //wp_my_loto_komb(1);
	?>
	<?php
	foreach($admin_forms as $key=>$val){
		$accordian_title=$val['title'];
		ob_start();
		
		?>
		<ul class="my_actions1 my_actions_shortcodes" data-key="<?php echo esc_attr($key)?>">
		<li>
		<h4><?php echo __("Actions ","my_support_theme").' : '?></h4>
		</li>
		<li>
		<a href="#javascript" class="my_action" data-type="<?php echo esc_attr($key) ?>" data-key="edit_styles" title="<?php echo __("Edit Styles","my_support_theme");?>"><i class="fa fa-edit"></i></a>
		</li>
		<li>
		<a href="#javascript" class="my_action" data-type="<?php echo esc_attr($key) ?>" data-key="preview" title="<?php echo __("Preview","my_support_theme");?>"><i class="fa fa-desktop"></i></a>
		</li>
		<li>
		<a href="#javascript" class="my_action" data-type="<?php echo esc_attr($key) ?>" data-key="save" title="<?php echo __("Save","my_support_theme");?>"><i class="fa fa-file"></i></a>
		</li>
		
		</ul>
		<?php echo $val['html'];?>
		<?php 
		$accordian_html=ob_get_clean();
		//$accordian_file=$my_views_dirname.'elements/form_shortcode.php';
		$file=$my_views_dirname.'elements/my_accordian.php';
		require $file;
		}
	?>
	
	</div>
</div>	