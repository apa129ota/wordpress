<?php
if(!defined('ABSPATH'))die('');
?>

<div class="wrap">

	<?php 
	$file=MY_VISUAL_VIEWS_DIRNAME.'admin/elements/my_header.php';
	require $file;
	?>
	<form class="my_global_form">
		<input type="hidden" name="my_id" value="<?php if(isset($my_id))echo esc_attr($my_id);?>"/>
	<div class="my_container my_container_1">
		<div class="my_col_100">
			<div class="my_slider_title">
				
				<input type="text" class="my_title" placeholder="<?php echo __("Slider Title","my_support_theme")?>" value="<?php if(isset($title))echo esc_attr($title);?>"/>
			</div>
		</div>
		<div style="margin:20px 0px 0px 0px;border-top:1px solid #dedede;"></div>
		<div class="my_col_100 my_clearfix my_main_container my_flex_display">
	
			<div class="my_flex_display  my_main_content my_h">
				<div class="my_saved_images my_clarfix">
					<?php
						if(!empty($my_saved_images)){ 
							foreach($my_saved_images as $key=>$val){
							$t=wp_get_attachment_image_src($val,'full')
					?>
					<div class="my_img_1 my_col my_col_33" data-type="images" data-id="<?php echo esc_attr($val)?>" data-image="<?php echo $t[0];?>" data-w="<?php echo $t[1]?>" data-h="<?php echo $t[2]?>">
						<div class="my_img">
						<div class="my_img_bg my_transition" style="background-image:url('<?php echo $t[0]; ?>')">
							<div class="my_overlay">
								<i class="fa fa-search my_transition"></i>
							</div>
						</div>
						<ul class="my_actions">
						<?php 
						foreach($wp_my_visial_item_actions as $k1=>$v1){
						?>
						<li><a href="#javascript" data-id="<?php echo esc_attr($val);?>" class="my_item_action my_transition <?php echo $k1;?>" data-action="<?php echo esc_attr($k1)?>" title="<?php echo esc_attr($v1['title'])?>"><i class="fa <?php echo $v1['icon']?>"></i></a></li>
						
						<?php 
						}
						?>
						</ul>
						</div>
						<div class="my_data">
						</div>
					</div>
					<?php 
					}}
					?>
				</div>	
			</div>
				<div class="my_flex_display  my_sidebar my_h">
			sidebar content
			</div>
			
		</div>
	</div>
	</form>
	<div class="my_dialog">
	
	</div>
</div>