<?php
if(!defined('ABSPATH'))die('');
if(!function_exists('wp_my_general_show_admin_msg')){
	function wp_my_general_show_admin_msg($msg,$error=false){
		if($error){
			?>
			<div class="error">
			<p>
							<?php echo $msg?>
							</p>
						</div>
		<?php				
		}else {
		?>
			<div class="updated">
			<p>
							<?php echo $msg?>
							</p>
						</div>
		<?php
		}
	}
}
if(!function_exists('wp_my_general_rgba_color')){
	function wp_my_general_rgba_color($color,$tr){
		$color_rgba='rgba(';
		if(strpos($color,"#")===0)
			$col=substr($color,1);
		else $col=$color;
		if((strlen($col)!=6)||(strlen($col)!=3)){
			if(strlen($col)>3){
				$start=strlen($col);
				for($i=$start;$i<6;$i++)$col.='0';
			}else if(strlen($col)<3){
				$start=strlen($col);
				for($i=$start;$i<3;$i++)$col.='0';
			}
		}
		if(strlen($col)==6){
			list($r,$g,$b)=array(
					$col[0].$col[1],
					$col[2].$col[3],
					$col[4].$col[5]
			);
	
		}else if(strlen($col)==3){
			list($r,$g,$b)=array(
					$col[0].$col[0],
					$col[1].$col[1],
					$col[2].$col[2]
			);
		}
		$r_dec=hexdec($r);
		$g_dec=hexdec($g);
		$b_dec=hexdec($b);
		$color_rgba.=$r_dec.','.$g_dec.','.$b_dec.','.$tr.')';
		return $color_rgba;
	
	
	}
}
if(!function_exists('wp_my_general_generate_simple_css_new')){
	function wp_my_general_generate_simple_css_new($values,$prep,$rules){
		$gen_css=array();
		foreach($rules as $key=>$val){
			if(!empty($values[$key])){
				if(!empty($rules['prep'])){
					$prep=$rules['prep'];
				}
			$value=$values[$key];
			if(strpos($value,",")!==false){
				$arr=explode(",",$value);
				$value=wp_my_general_rgba_color($arr[0], $arr[1]);
			}
			$translate=$val;//$val['translate'];
			$css='';
			if(!empty($translate['css'])){
				foreach($translate['css'] as $key1=>$val1){
					$newCss=$val1;
					$newCss=str_replace('{val}', $value, $newCss);
					if(strlen($css)>0)$css.="\n";
					$css.=$newCss;
					
				}
			}
			$sel=$translate['class'];
			$cssProp=$translate['property'];
			/*$gen_css['translate_'.$key]=array(
				'sel'=>$sel,
				'value'=>$value,
				'val'=>$val	
			);*/     
			if(!empty($translate['property']['css'])){
				$css1=$translate['class'];
				$newCss=$translate['property']['css'];
				
				$newCss=str_replace('{val}',$value,$newCss);
				$css1=str_replace('{css}',$newCss,$css1);
				//$css.=$sel."{".$css1."}\n";
				$css=$css1;
				/*$gen_css['translate_'.$key]['properyt']=array(
					'css1'=>$css1,'css'=>$css,'new'=>$newCss
				);*/
			}else if(!empty($translate['css'])){
				if(!is_array($translate['css'])){
				 	$newCss=$translate['css'];
					$newCss=str_replace('{val}',$value,$newCss);
					$css=str_replace('{css}',$newCss,$css);
				}
			}else {
				if($key=='font-family'){
					if($value!='default'){
					$css.=$sel."{\n ".$cssProp.":".$value." , serif !important;}";
					}
				}else {
					$css.=$sel."{\n ".$cssProp.":".$value."!important;}";
				}
			}
			$gen_css[$key]=array(
				'prep'=>$prep,
				'css'=>$css	
			);
			
		}
		}
		return $gen_css;
	}
}

if(!function_exists('wp_my_general_generate_simple_css')){
	function wp_my_general_generate_simple_css($values,$prep,$rules,$network_key=''){
		$gen_css=array();
		foreach($rules as $key=>$val){
			$sel=$val['sel'];
			if(!isset($gen_css[$sel])){
				$gen_css[$sel]=array();
			}
			$value=$values[$key];
			if(strpos($value,",")!==false){
				$arr=explode(",",$value);
				$value=wp_my_timeline_rgba_color($arr[0], $arr[1]);
			}
			$unit='';
			if(!empty($val['unit']))$unit=$val['unit'];
			$gen_css[$sel][]=$val['property']." : ".$value."$unit !important;";
			if($val['property']=='font-size'){
				if($key=='header_font_size' || $key=='share_font_size'){
					$gen_css[$sel][]="line-height : ".($value+10)."$unit !important;";

				}
			}
		}
		$css='';
		foreach($gen_css as $key=>$val){
			$css.=$prep.' '.$key." {\n";
			$css.=implode("\n",$val);
			$css.="\n}\n";
		}
		$up_height=0;
		$h=$values['header_padding'];
		$l_h=$values['header_font_size']+10;
		//$h-=10;
		$h=$h*2;
		$h_h=$l_h+$h;
		$up_height=$h_h-40;
		$css.=$prep." .my_social_header {\n";
		$css.="height : ".$h_h."px !important }\n";
		$s_h=$values['share_padding'];
		$l_h=$values['share_font_size']+10;
		//$s_h-=10;

		$s_h=$s_h*2;
		$h_h=$l_h+$s_h;
		$up_height+=$h_h-38;
		$up_height+=0;
		$css.=$prep." .my_social_share{\n";
		$css.=" height : ".$h_h."px !important }\n";
		$h=265+$up_height;
		$css.="#my_timeline_{id} .my_timeline_ver_item.my_1_$network_key {\n ";
		$css.=" height : ".$h."px !important }";
		$h1=250+$up_height;
		$css.="#my_timeline_{id} .my_timeline_ver_content.my_$network_key {\n";
		$css.=" height : ".$h1."px !important }";

		return $css;
	}

}

if(!function_exists('wp_my_general_generate_css')){
	/**
	 * Generate css for posts
	 * @param unknown $values
	 * @param unknown $prep
	 */
	function wp_my_general_generate_css($values,$prep,$rules){
		global $wp_my_social_posts_debug;
		global $wp_my_social_posts_debug_data;
		$css='';
		foreach($rules as $key=>$val){
			$sel=$val['selector'];
			if(is_array($sel)){
				$sel_gen='';
				foreach($sel as $k21=>$v21){
					if(strlen($sel_gen)>0)$sel_gen.=" , ";
					$sel_gen='#'.$prep.' '.$v21;
				}
			}
			else $sel_gen='#'.$prep.' '.$sel;
			$type='';
			if(isset($val['type']))$type=$val['type'];
			ob_start();
			if(isset($val['style'])){
				$css_1=$val['style'];
				$value=$values[$val['key']];
				if(strpos($value,",")!==false){
					$arr=explode(",",$value);
					$value=wp_my_timeline_rgba_color($arr[0], $arr[1]);
				}
				if(!empty($val['replace'])){
					$css_1=str_replace('{val}', $value, $css_1);

				}
				if(!empty($val['after'])){
					$sel_gen.='::after ';
				}
			}else {
				foreach($val['properties'] as $key1=>$val1){
					if(is_array($val1)){
						$v=$val1['val'];
						$value=$values[$val1['key']];
						if(strpos($value,",")!==false){
							$arr=explode(",",$value);
							$value=wp_my_timeline_rgba_color($arr[0], $arr[1]);
						}
						if($type=='replace'){
							$v=str_replace('{val}', $value, $v);
								
								
						}
						echo $key1.':'.$v.' !important;'."\n";
					}else {
						$value=$values[$val1];
						//echo $value;
						if(strpos($value,",")!==false){
							$arr=explode(",",$value);
							$value=wp_my_timeline_rgba_color($arr[0], $arr[1]);
						}
						if(strpos($key1,'width')){
							echo $key1.':'.$value.'px !important;'."\n";
						}
						else echo $key1.':'.$value.' !important;'."\n";
					}
				}
					
				$css_1=ob_get_clean();
				if($type=='predefined'){
					$pre_str=$val['predefined'];
					$sel_gen=$val['new_sel'];
					ob_start();
					echo $sel_gen.'{';
					echo $css_1;
					echo $pre_str;
					echo '}';
					$css_1=ob_get_clean();
				}
				$css.=$css_1;
				if($wp_my_social_posts_debug){
					$wp_my_social_posts_debug_data['generate_css'][]=array(
							'selector'=>$sel_gen,
							'css_value'=>$css_1
					);
				}
			}


		}
		return $css;
	}
}
if(!function_exists('wp_my_get_attachment_id_form_url')){
	function wp_my_get_attachment_id_form_url($url, $ignore_path = false) {
		if (! $ignore_path) {
	
			$dir = wp_upload_dir ();
	
			$dir = trailingslashit ( $dir ['baseurl'] );
	
			if (false === strpos ( $url, $dir ))
					
				return false;
		}
	
		$file = basename ( $url );
	
		$query = array (
					
				'post_type' => 'attachment',
					
				'fields' => 'ids',
					
				'meta_query' => array (
							
						array (
									
								'value' => $file,
									
								'compare' => 'LIKE'
						)
	
				)
	
		)
		;
	
		$query ['meta_query'] [0] ['key'] = '_wp_attached_file';
	
		$ids = get_posts ( $query );
	
		foreach ( $ids as $id ) {
			$atts= wp_get_attachment_image_src ( $id, 'full' );
			$match = $atts[0];
	
			if ($url == $match || ($ignore_path && strstr ( $match, $file )))
					
				return $id;
		}
	}
}
/**
 * Load module
 * @param unknown $module_dir
 * @param unknown $module
 */
if(!function_exists('wp_my_general_load_module')){
	function wp_my_general_load_module($module_dir,$module){
		$file=$module_dir.$module.'/class.php';
		if(file_exists($file)){
			require_once $file;
			return true;
		}else {
			trigger_error(__("Module class dont exist.","my_support_theme").$file,E_USER_NOTICE);
			return false;
		}
	}
}
/**
 * Load module class
 * @param unknown $module_dir
 * @param unknown $module
 * @param unknown $class
 * @return boolean
 */
if(!function_exists('wp_my_general_load_module_class')){
	function wp_my_general_load_module_class($module_dir,$module,$class){
		$file=$module_dir.$module.'/includes/class/'.$class;
		if(file_exists($file)){
			require_once $file;
			return true;
		}else {
		//return false;
			trigger_error(__("Module class dont exist.","my_support_theme").$file,E_USER_NOTICE);
		
		}
	}
}
/**
 * 
 * @param unknown $module_dir
 * @param unknown $module
 * @param unknown $class
 * @return boolean
 */
if(!function_exists('wp_my_general_load_module_function')){
	function wp_my_general_load_module_function($module_dir,$module,$function){
		$file=$module_dir.$module.'/includes/'.$function;
	//echo $file;
		if(file_exists($file)){
			require_once $file;
			return true;
		}else {
			trigger_error(__("Module function dont exist.","my_support_theme").$file,E_USER_NOTICE);
			return false;
		}
	}
}