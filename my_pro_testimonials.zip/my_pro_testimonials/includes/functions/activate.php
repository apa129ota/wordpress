<?php
if(!defined('ABSPATH'))die('');
function wp_my_testimonials_activate(){
	global $wpdb;
	$wpdb->show_errors();
	ob_start();
	echo "Activate \n";
	echo date('Y/m/d H:i:s')."\n";
	$table_name = $wpdb->prefix . 'my_testimonials_objects';
		
	if ($wpdb->get_var ( "SHOW TABLES LIKE '$table_name'" ) != $table_name) {
		$sql = "CREATE TABLE IF NOT EXISTS " . $table_name . "
									(	ID bigint(20) NOT NULL AUTO_INCREMENT,
										title tinytext NOT NULL COLLATE utf8_general_ci,
										object_type char(255) NOT NULL,
										created datetime,
										updated datetime,
										PRIMARY KEY (ID),
										KEY object_type(object_type)
										)";
		$wpdb->query ( $sql );
	}
	$table_name = $wpdb->prefix . 'my_testimonials_object_meta';
	if ($wpdb->get_var ( "SHOW TABLES LIKE '$table_name'" ) != $table_name) {
		$sql = "CREATE TABLE IF NOT EXISTS " . $table_name . " (
  									meta_id bigint(20) unsigned NOT NULL auto_increment,
  									object_id bigint(20) unsigned NOT NULL default '0' COLLATE utf8_general_ci,
  									meta_key varchar(255) default NULL COLLATE utf8_general_ci,
  									meta_value longtext COLLATE utf8_general_ci,
  									PRIMARY KEY  (meta_id),
  									KEY object_id (object_id),
  									KEY meta_key (meta_key)
					)";
		$wpdb->query ( $sql );
	}
	$str=ob_get_clean();
	$file=MY_TESTIMONIALS_TMP_DEBUG_DIRNAME.'activate.log';
	$fp=fopen($file,'w');
	fwrite($fp,$str);
	fclose($fp);
}

