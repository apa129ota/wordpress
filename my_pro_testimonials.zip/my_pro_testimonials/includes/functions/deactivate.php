<?php
if(!defined('ABSPATH'))die('');
function wp_my_testimonials_deactivate(){
	ob_start();
	echo "Deactivate \n";
	echo date('Y/m/d H:i:s')."\n";
	$str=ob_get_clean();
	$file=MY_TESTIMONIALS_TMP_DEBUG_DIRNAME.'deactivate.log';
	$fp=fopen($file,'w');
	fwrite($fp,$str);
	fclose($fp);
}