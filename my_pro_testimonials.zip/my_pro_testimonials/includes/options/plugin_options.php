<?php
global $my_testimonials_shortcodes;
$my_testimonials_shortcodes=array(
	'site_url'=>__("Site url","my_support_theme"),
	'post_url'=>__("Post url","my_support_theme"),
	'post_title'=>__("Post title","my_support_theme"),
	'stars'=>__("Stars","my_support_theme"),
	'text'=>__("Post text","my_support_theme"),
	'post_category'=>__("Post category","my_support_theme"),
	'user_name'=>__("User Name","my_support_theme"),
	'user_position'=>__("User position","my_support_theme"),
	'user_email'=>__("User Email","my_support_theme"),	
	'url'=>__("Company Url","my_support_theme"),								
);
$my_notify_below_text='';
ob_start();
echo __("In Form you can use this tags :","my_support_theme")."<br/>";
//echo '{site_url} : '.__("Site url","my_support_theme").",";
foreach($my_testimonials_shortcodes as $key=>$val){
	echo '{'.$key.'} : '.$val.',';
}
$my_notify_below_text=ob_get_clean();
$my_notify_msg='';
ob_start();
echo __("Dear ,","my_support_theme")."\n";
echo __("New testimonial is subbmitted to your site","my_support_theme").' : {site_url}'."\n";
echo __("Testimonial url","my_support_theme").' : {post_url}'."\n";
echo __("Title","my_support_theme").' : {post_title}'."\n";
echo __("Stars","my_support_theme").' : {stars}'."\n";
echo __("Url","my_support_theme").' : {url}'."\n";
echo __("Text","my_support_theme").' : {post_text}'."\n";
echo __("Category","my_support_theme").' : {post_category}'."\n";
echo __("User","my_support_theme").' : {user_name}'."\n";
echo __("User Position","my_support_theme").' : {user_position}'."\n";
echo __("User Email","my_support_theme").' : {user_email}'."\n";
$my_notify_msg=ob_get_clean();
$my_notify_msg_1='';
ob_start();
echo __("Dear ,","my_support_theme")."\n";
echo __("New testimonial is subbmitted to your site","my_support_theme").' : {site_url}'."\n";
//echo __("Testimonial url","my_support_theme").' : {post_url}'."\n";
echo __("But stars is less than you choosed from options and post is not saved ,","my_support_theme")."\n";
echo __("Title","my_support_theme").' : {post_title}'."\n";
echo __("Stars","my_support_theme").' : {stars}'."\n";
echo __("Url","my_support_theme").' : {url}'."\n";
echo __("Text","my_support_theme").' : {post_text}'."\n";
echo __("Category","my_support_theme").' : {post_category}'."\n";
echo __("User","my_support_theme").' : {user_name}'."\n";
echo __("User Position","my_support_theme").' : {user_position}'."\n";
echo __("User Email","my_support_theme").' : {user_email}'."\n";
$my_notify_msg_1=ob_get_clean();

$options_form=array(
'elements'=>array(
		'my_debug'=>array(
				'save'=>true,
				'type'=>'on_off',
				'default'=>'0',
				'title'=>__("Enable plugin debuging capability." ,"my_support_theme"),
				'tooltip'=>__("This options allow , to debug functionality and don't use it.If you have problems with plugin this option can be turned on.","my_support_theme"),
				'display'=>'inline',

		),
		'recaptcha'=>array(
				'save'=>true,
				'type'=>'on_off',
				'default'=>'0',
				'title'=>__("Protect forms with recaptcha." ,"my_support_theme"),
				'tooltip'=>__("This options allow , add recaptcha to front forms.","my_support_theme"),
				'display'=>'inline',
		
		),
		'recaptcha_public_key'=>array(
				'save'=>true,
				'type'=>'password',
				'default'=>'',
				'title'=>__("Recaptcha public key." ,"my_support_theme"),
				'tooltip'=>__("Recapctha public key.","my_support_theme"),
				'display'=>'inline'
		),
		'recaptcha_private_key'=>array(
				'save'=>true,
				'type'=>'password',
				'default'=>'',
				'title'=>__("Recaptcha private key." ,"my_support_theme"),
				'tooltip'=>__("Recapctha private key.","my_support_theme"),
				'display'=>'inline'
		),
		'front_submit_not_logged'=>array(
				'save'=>true,
				'type'=>'on_off',
				'default'=>'1',
				'title'=>__("Allow not logged user to submit testimonials." ,"my_support_theme"),
				'tooltip'=>__("This option allow user which is not logged to submit testimonials.","my_support_theme"),
				'display'=>'inline',
		),
		'notify_email'=>array(
				'save'=>true,
				'type'=>'text',
				'default'=>get_option('admin_email'),
				'title'=>__("Notify email about new testimonials submission." ,"my_support_theme"),
				'tooltip'=>__("Plugin will notify user with email about new submissions.","my_support_theme"),
				'display'=>'inline',
		),
		'notify_msg'=>array(
				'save'=>true,
				'title'=>__("Notify email format." ,"my_support_theme"),
				'tooltip'=>__("Plugin will notify user with email about new submissions.","my_support_theme"),
				'type'=>'textarea',
				'default'=>$my_notify_msg,
				'below_text'=>$my_notify_below_text
		),
		'notify_msg_not'=>array(
				'save'=>true,
				'title'=>__("Notify email format for not saved post." ,"my_support_theme"),
				'tooltip'=>__("Plugin will notify user with email about new submissions.","my_support_theme"),
				'type'=>'textarea',
				'default'=>$my_notify_msg_1,
				'below_text'=>$my_notify_below_text
		),
		'not_save'=>array(
				'save'=>true,
				'title'=>__("Below x stars submission will not be saved, but emailed","my_support_theme"),
				'tooltip'=>__("Plugin will notify user with email about new submissions when stars is below this option.","my_support_theme"),
				
				'type'=>'jscript_dropdown',
				'values'=>array(
				'save_all'=>__("Save All","my_support_theme"),
					2=>'2',
					3=>'3',
					4=>'4',
					5=>'5'			
				),
				'widths'=>array(
						600=>'100%',
						1200=>'100%',
				),
				'jscript'=>array(
						'max_c'=>1,
						'max_sel'=>__("Maximum elements are selected","my_support_theme"),
						'duration'=>500,
						'animation'=>'fadein',
						'choose_value'=>__("Plese Select value","my_support_theme"),
				),
				'show_filter'=>0,
				'multiple'=>false,
				'choose_value'=>__("","my_support_theme"),
				'default'=>4,
				
		)
		));
$ret['options_form']=$options_form;
$ret['pre_options']=array(
	'my_debug'=>0,
	'front_submit_not_logged'=>1,
	'not_save'=>4,
	'notify_email'=>get_option('admin_email'),
	'notify_msg'=>$my_notify_msg,
	'notify_msg_not'=>$my_notify_msg_1,
	'recaptcha'=>0
);
$ret['options_name']='my_testimonials_options_1234';
return $ret;