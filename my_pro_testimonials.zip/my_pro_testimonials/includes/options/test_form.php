<?php
$wp_my_related_posts_validate_msgs=array(
		'form_has_errors'=>__("Form  has errors please correct them !","my_related_posts_domain"),
		'required'=>__("This field is required !","my_related_posts_domain"),
		'error'=>__("Error !","my_related_posts_domain")
);
global $wp_my_related_posts_plugin_options;
$wp_my_related_posts_plugin_options=array(
		'msgs'=>$wp_my_related_posts_validate_msgs,
		'elements'=>array(
				'text'=>array(
					'type'=>'text',
					'title'=>__("Enable plugin debuging capability." ,"my_related_posts_domain"),
					'tooltip'=>__("This options allow , to debug functionality and don't use it.If we have problems with plugin this option can be turned on.","my_related_posts_domain"),
					'placeholder'=>'Text',
					'default'=>'',		
				),
				'my_debug'=>array(
						'save'=>true,
						'type'=>'on_off',
						'default'=>'0',
						'title'=>__("Enable plugin debuging capability." ,"my_related_posts_domain"),
						'tooltip'=>__("This options allow , to debug functionality and don't use it.If we have problems with plugin this option can be turned on.","my_related_posts_domain"),
						'display'=>'inline',

				),
				'enabled_posts'=>array(
						'save'=>true,
						'type'=>'jscript_checkbox_list',
						'tooltip'=>__("Enable plugin for following post types." ,"my_related_posts_domain"),
						'title'=>__("This post types will be used to create timeline.","my_related_posts_domain"),
						'display'=>'inline',
						'default'=>array('post','page'),
						'multiple'=>true,
						'validate'=>array(
								'required'
						)
				),
				'limit_post_text_type'=>array(
						'save'=>true,
						'type'=>'jscript_radio_list',
						'tooltip'=>__("Limit post text type." ,"my_related_posts_domain"),
						'title'=>__("Limit post type text by total chars , total words.","my_related_posts_domain"),
						'display'=>'inline',
						'default'=>'chars',
						'multiple'=>false,
						'values'=>array(
								'chars'=>__("Limit post text by chars." ,"my_related_posts_domain"),
								'words'=>__("Limit post text by words." ,"my_related_posts_domain")
						),
						'validate'=>array(
								'required'
						)
				),
				'limit_post_text'=>array(
						'save'=>true,
						'type'=>'text',
						'tooltip'=>__("Limit post text number." ,"my_related_posts_domain"),
						'title'=>__("Limit post type text by total number.","my_related_posts_domain"),
						'display'=>'inline',
						'default'=>'500',
						'multiple'=>false,
							
						'validate'=>array(
								'required'
						)
				),
				'vertical_timeline_custom_css'=>array(
						'save'=>true,
						'display'=>'inline',
						'title'=>__("Add custom css to this Vertical timeline timeline","my_related_posts_domain"),
						'type'=>'textarea',
						'default'=>'%',
						'layout_class'=>'my_col_100',
						'default'=>''
				),
				'horizontal_timeline_custom_css'=>array(
						'save'=>true,
						'display'=>'inline',
						'title'=>__("Add custom css to this Horizontal timeline timeline","my_related_posts_domain"),
						'type'=>'textarea',
						'default'=>'%',
						'layout_class'=>'my_col_100',
						'default'=>''
				),

		)
);
global $wp_my_timeline_single_post_form;
$wp_my_timeline_single_post_form=array(
		'hidden'=>array(
				'post_id'=>'',
				'start_item'=>'',
		),
		'elements'=>array(

				'override_post_title'=>array(
						'layout_class'=>'my_col_25',
						'element_id'=>'',
						'name'=>'overide_post_title',
						'title'=>__("Override post title","my_related_posts_domain"),
						'tooltip'=>__("By default  post title is showed, this  option allows to change post title.","my_related_posts_domain"),
						'outer_classes'=>'override_post_title',
						'type'=>'on_off',
						'default'=>0
				),
				'override_post_content'=>array(
						'layout_class'=>'my_col_25',
						'element_id'=>'',
						'name'=>'overide_post_title',
						'title'=>__("Override post content","my_related_posts_domain"),
						'tooltip'=>__("By default  post exceprt is showed, this  option allows to change post content.","my_related_posts_domain"),
						'outer_classes'=>'override_post_content',
						'type'=>'on_off',
						'default'=>0
				),
				/*'override_post_thumb'=>array(
					'layout_class'=>'my_col_25',
						'element_id'=>'',
						'name'=>'overide_post_title',
						'title'=>__("Override post thumb","my_related_posts_domain"),
						'tooltip'=>__("By default  post date is showed, this  option allows to change post date.","my_related_posts_domain"),
						'layout_class'=>'my_col_25',
						'type'=>'on_off',
						'default'=>0
				),*/
				'override_post_url'=>array(
						'layout_class'=>'my_col_25',
						'element_id'=>'',
						'name'=>'overide_post_title',
						'title'=>__("Override post url","my_related_posts_domain"),
						'tooltip'=>__("By default  post url is used for read more, this  option allows to change post url.","my_related_posts_domain"),
						'outer_classes'=>'override_post_url',
						'type'=>'on_off',
						'default'=>0
				),
				'post_thumb'=>array(
						'layout_class'=>'my_col_25',
						'element_id'=>'',
						'name'=>'overide_post_title',
						'title'=>__("Override post thumb","my_related_posts_domain"),
						'tooltip'=>__("By default  post thumb is showed, but you can choose new thumb in this option.","my_related_posts_domain"),
						'outer_classes'=>'post_thumb',
						'type'=>'thumb',
						'default'=>'',
						'value'=>'',
						'choose_title'=>__("Change Thumb","my_related_posts_domain"),
						'no_image'=>__("No Image","my_related_posts_domain"),
						'choose_title'=>__("Choose Media","my_related_posts_domain"),
						'remove'=>__("Remove Media","my_related_posts_domain"),
						'jscript'=>array(
								'can_remove'=>false,
								'multiple'=>0,
								'show_values'=>1,
								'max_c'=>2,
								'choose_title'=>__("Choose Media","my_related_posts_domain"),
								'media_title'=>__("Choose Image","my_related_posts_domain"),
								'button_text'=>__("Insert","my_related_posts_domain"),
								'filter_type'=>'image',//audio video image
									
						)
				),
			//	'open_link'=>$wp_my_timeline_add_new_options['my_horizintal_timeline']['elements']['open_link'],
				'post_title'=>array(
						'outer_classes'=>'post_title',
						'type'=>'text',
						'title'=>__("Post title","my_related_posts_domain"),
						'tooltip'=>__("Enter new post title , showed for this post.","my_related_posts_domain"),
						'default'=>'',
						'layout_class'=>'my_col_100',
						'placeholder'=>__("Post title","my_related_posts_domain")
				),
				'post_url'=>array(
						'outer_classes'=>'post_url',
						'type'=>'text',
						'title'=>__("Post Url","my_related_posts_domain"),
						'tooltip'=>__("Enter new post url , and this post will open that url.","my_related_posts_domain"),
						'default'=>'',
						'layout_class'=>'my_col_100',
						'placeholder'=>__("Post url","my_related_posts_domain")
				),
				'post_content'=>array(
						'outer_classes'=>'post_content',
						'type'=>'tiny_mce',
						'settings'=>array(
								'media_buttons'=>false,
								'wpautop'=>false,
								'editor_height'=>100,
								'teeny'=>true,

									
						),
						'title'=>__("Post Content","my_related_posts_domain"),
						'tooltip'=>__("Enter new post content , and this will be showed at content timeline.","my_related_posts_domain"),
						'default'=>'',
						'layout_class'=>'my_col_100',
						'placeholder'=>__("Post content","my_related_posts_domain")
				),
					
				/*
				 'override_post_content'=>array(
				 		'layout_class'=>'my_col_16',
				 		'element_id'=>'',
				 		'title'=>__("Override post content","my_related_posts_domain"),
				 		'tooltip'=>__("By default post execrpt is showed, this option allows to change post_content.","my_related_posts_domain"),
				 		'layout_class'=>'my_col_16',
				 		'type'=>'tinymce',
				 		'default'=>''
				 )*/
		)
);
global $wp_my_help_bar_test_form;
$wp_my_help_bar_test_form=array(
		'elements'=>array(
				'my_media'=>array(
						'type'=>'jscript_media',
						'tooltip'=>__("Serbia","my_related_posts_domain"),
						'title'=>__("Test","my_related_posts_domain"),
						'max_c'=>2,
						'multiple'=>true,
						'show_values'=>true,
						'choose_title'=>__("Choose Media","my_related_posts_domain"),
						'jscript'=>array(
								'multiple'=>0,
								'show_values'=>1,
								'max_c'=>2,
								'choose_title'=>__("Choose Media","my_related_posts_domain"),
								'media_title'=>__("Choose Image","my_related_posts_domain"),
								'button_text'=>__("Insert","my_related_posts_domain"),
								'filter_type'=>'video',//audio video image

						)
							
				),
				'my_autocomplete'=>array(
						'type'=>'jscript_autocomplete',
						'tooltip'=>__("Serbia","my_related_posts_domain"),
						'title'=>__("Test","my_related_posts_domain"),
						'nonce_str'=>'my_get_post',
						'multiple'=>true,
						'value'=>array('sr1'=>'Serbia'),
						'show_values'=>true,
						'jscript'=>array(
								'show_values'=>1,
								'url'=>admin_url('admin-ajax.php'),
								'my_action'=>'my_get_posts',
								'action'=>'my_get_post',
								'max_c'=>2,
								'max_sel'=>__("Maximum elements are selected","my_related_posts_domain"),
								'duration'=>500,
								'animation'=>'fadein',
								'events'=>array(
										'select_event'=>'function(obj,val){console.log("Select event",val);}',
										'close_event'=>'function(obj,val){console.log("cLOSE event",val);}'
								)

						)
				),
				'my_color_picker'=>array(
						'type'=>'jscript_color_picker',
						'tooltip'=>__("Serbia","my_related_posts_domain"),
						'title'=>__("Test","my_related_posts_domain"),
						'pick_title'=>__("Pick a Color","my_related_posts_domain"),
						'close_title'=>__("Close","my_related_posts_domain"),
						'default'=>array(
								'color'=>'#ccc',
								'transp'=>0.5
						),
						'jscript'=>array(
								'pick_title'=>__("Pick a Color","my_related_posts_domain"),
								'close_title'=>__("Close","my_related_posts_domain"),
								'hex_title'=>__("Hex value","my_related_posts_domain"),
								'transp_title'=>__("Transparency","my_related_posts_domain")
						),
						'transparency'=>true,
							
				),
				'my_radio'=>array(
						'type'=>'jscript_radio_list',
						'tooltip'=>__("Serbia","my_related_posts_domain"),
						'title'=>__("Test","my_related_posts_domain"),
						'default'=>'sr1',
						'display'=>'inline',
						'values'=>array(
								'sr1'=>__("A Serbia 1","my_related_posts_domain"),
								'sr2'=>__("A Serbia 2","my_related_posts_domain"),
								'sr3'=>__("B Serbia 3","my_related_posts_domain"),
								'sr4'=>__("C Serbia 4","my_related_posts_domain"),
								'sr5'=>__("C Serbia 5","my_related_posts_domain"),
								'sr6'=>__("C Serbia 6","my_related_posts_domain"),
								'sr7'=>__("D Serbia 7","my_related_posts_domain"),

						)
				),
				'my_checkbox'=>array(
						'type'=>'jscript_checkbox_list',
						'tooltip'=>__("Serbia","my_related_posts_domain"),
						'title'=>__("Test","my_related_posts_domain"),
						'default'=>array('sr1','sr6'),
						'display'=>'inline',
						'multiple'=>true,
						'values'=>array(
								'sr1'=>__("A Serbia 1","my_related_posts_domain"),
								'sr2'=>__("A Serbia 2","my_related_posts_domain"),
								'sr3'=>__("B Serbia 3","my_related_posts_domain"),
								'sr4'=>__("C Serbia 4","my_related_posts_domain"),
								'sr5'=>__("C Serbia 5","my_related_posts_domain"),
								'sr6'=>__("C Serbia 6","my_related_posts_domain"),
								'sr7'=>__("D Serbia 7","my_related_posts_domain"),
									
						),
						'jscript'=>array(
								'events'=>array(
										'check'=>'function(obj,ch,val){console.log("Check",{ch:ch,val:val});}'
								)
						)
				),
				'my_choose_1'=>array(
						'type'=>'jscript_dropdown',
						'title'=>__("Test","my_related_posts_domain"),
						'tooltip'=>__("Serbia","my_related_posts_domain"),
						'widths'=>array(
								600=>'100%',
								1200=>'25%',

						),
						'jscript'=>array(
								'max_c'=>2,
								'max_sel'=>__("Maximum elements are selected","my_related_posts_domain"),
								'duration'=>500,
								'animation'=>'fadein',
								'choose_value'=>__("Plese Select value","my_related_posts_domain"),
						),
						'show_filter'=>1,
						'multiple'=>true,
						'choose_value'=>__("Plese Select value","my_related_posts_domain"),
						'default'=>array(),
						'values'=>array(
								'sr1'=>__("A Serbia 1","my_related_posts_domain"),
								'sr2'=>__("A Serbia 2","my_related_posts_domain"),
								'sr3'=>__("B Serbia 3","my_related_posts_domain"),
								'sr4'=>__("Serbia","my_related_posts_domain"),
								'sr5'=>__("Serbia","my_related_posts_domain"),
								'sr6'=>__("Serbia","my_related_posts_domain"),
								'sr7'=>__("Serbia","my_related_posts_domain"),

						)
				),
				'my_choose'=>array(
						'type'=>'jscript_dropdown',
						'title'=>__("Test","my_related_posts_domain"),
						'tooltip'=>__("Serbia","my_related_posts_domain"),
						'widths'=>array(
								600=>'100%',
								1200=>'25%',
									
						),
						'jscript'=>array(
								'duration'=>500,
								'animation'=>'fadein'
			
						),
						'show_filter'=>1,
						'default'=>'',
						'values'=>array(
								''=>__("Plese Select value","my_related_posts_domain"),
								'sr1'=>__("A Serbia 1","my_related_posts_domain"),
								'sr2'=>__("A Serbia 2","my_related_posts_domain"),
								'sr3'=>__("B Serbia 3","my_related_posts_domain"),
								'sr4'=>__("Serbia","my_related_posts_domain"),
								'sr5'=>__("Serbia","my_related_posts_domain"),
								'sr6'=>__("Serbia","my_related_posts_domain"),
								'sr7'=>__("Serbia","my_related_posts_domain"),
									
						)
				)
		)
);


