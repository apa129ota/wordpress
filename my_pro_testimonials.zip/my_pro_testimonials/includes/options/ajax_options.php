<?php
if(!defined('ABSPATH'))die();
$options=array(
	
	'msg_window_timeout'=>3000,
	'my_debug'=>0,
	'msgs'=>array(
		'network_error'=>__("Slide Options","my_support_theme"),
	),	
	'ajax_options'=>array(
		'url'=>admin_url("admin-ajax.php"),
		'dataType'=>'json',
		'cache'=>0,
		'timeout'=>5000,
		'type'=>'POST'			
	)			
);
return $options;