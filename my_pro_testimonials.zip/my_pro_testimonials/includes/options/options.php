<?php
if(!defined('ABSPATH'))die('');
$my_framework_options=array(
	'backed_class_file'=>'class-my-backend-class.php',
	'backend_class_name'=>'Class_My_Framework_Backend_Class',
	'global_plugin_class_instance'=>'Class_My_Framework_Main_Class',
	'controllers_dir'=>'',	
	'controller_name'=>'Class_My_Framework_Backend_Controller',
	'controller_file'=>'class-my-backend-controller.php',	
	'admin_pages'=>array(
		'my_testimonials'=>array(
				
				'title'=>__("My Testimonials","my_support_theme"),
				'capability'=>'manage_options',
				'is_logged'=>true,
				'template'=>'',
				'styles'=>array(
					'my_table_view_css'=>MY_TESTIMONIALS_MODULES_URL.'tableview/assets/css/admin.css',	
					'my_admin_css'=>MY_TESTIMONIALS_CSS_URL.'admin.css',
					'my_admin_menu_css'=>MY_TESTIMONIALS_MODULES_URL.'admin_menu/assets/css/admin.css',
					'my_jquery_ui'=>MY_TESTIMONIALS_CSS_URL.'jquery-ui.css'	
				),
				'scripts'=>array(
						'my_general_js'=>MY_TESTIMONIALS_JSCRIPT_URL.'admin/my_general.js'
				),
				'my_subpages'=>array(
				  'my_testimonials_add_new'=>array(
								'title'=>__("Add New","my_support_theme"),
								'capability'=>'manage_options',
								'is_logged'=>true,
								'template'=>'',
								'styles'=>array(
										'my_admin_css'=>MY_TESTIMONIALS_CSS_URL.'admin.css',
										'my_admin_menu_css'=>MY_TESTIMONIALS_MODULES_URL.'admin_menu/assets/css/admin.css',
										'my_jquery_ui'=>MY_TESTIMONIALS_CSS_URL.'jquery-ui.css'
								),
								'scripts'=>array(
										'myUiDialog'=>MY_TESTIMONIALS_JSCRIPT_URL.'admin/myUiDialog.js',
										'my_general_js'=>MY_TESTIMONIALS_JSCRIPT_URL.'admin/my_general.js',
										'my_admin_msgs_js'=>MY_TESTIMONIALS_JSCRIPT_URL.'admin/admin_msgs.js',
										'my_dialog_js'=>MY_TESTIMONIALS_JSCRIPT_URL.'admin/my_dialog.js'
										
								),
						),
				/*	'my_testimonials_styles'=>array(
								'title'=>__("Style","my_support_theme"),
								'capability'=>'administrator',
								'is_logged'=>true,
								'template'=>'',
								'styles'=>array(
										'my_admin_css'=>MY_TESTIMONIALS_CSS_URL.'admin.css',
										'my_admin_menu_css'=>MY_TESTIMONIALS_MODULES_URL.'admin_menu/assets/css/admin.css',
										'my_jquery_ui'=>MY_TESTIMONIALS_CSS_URL.'jquery-ui.css'
								),
								'scripts'=>array(
											
								),
						),
					*/		
					'my_testimonials_options'=>array(
							'title'=>__("Options","my_support_theme"),
							'capability'=>'administrator',
							'is_logged'=>true,
							'template'=>'',
							'styles'=>array(
									'my_admin_css'=>MY_TESTIMONIALS_CSS_URL.'admin.css',
									'my_admin_menu_css'=>MY_TESTIMONIALS_MODULES_URL.'admin_menu/assets/css/admin.css',
									'my_jquery_ui'=>MY_TESTIMONIALS_CSS_URL.'jquery-ui.css'
							),
							'scripts'=>array(
							
							),
					)/*,
					'my_testimonials_preview'=>array(
								'title'=>__("Preview","my_support_theme"),
								'capability'=>'manage_options',
								'is_logged'=>true,
								'template'=>'',
								'styles'=>array(
										'my_admin_css'=>MY_TESTIMONIALS_CSS_URL.'admin.css',
										'my_admin_menu_css'=>MY_TESTIMONIALS_MODULES_URL.'admin_menu/assets/css/admin.css',
										'my_jquery_ui'=>MY_TESTIMONIALS_CSS_URL.'jquery-ui.css'
								),
								'scripts'=>array(
										'myUiDialog'=>MY_TESTIMONIALS_JSCRIPT_URL.'admin/myUiDialog.js',
										'my_general_js'=>MY_TESTIMONIALS_JSCRIPT_URL.'admin/my_general.js',
										'my_admin_msgs_js'=>MY_TESTIMONIALS_JSCRIPT_URL.'admin/admin_msgs.js',
										'my_dialog_js'=>MY_TESTIMONIALS_JSCRIPT_URL.'admin/my_dialog.js'
						
								),
						),*/
				)
			
		)
	),				
	'die_msg'=>__("Action is not permitted !","my_support_theme")
);
return $my_framework_options;
