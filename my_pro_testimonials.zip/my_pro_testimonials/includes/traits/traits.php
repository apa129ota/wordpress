<?php
if(!trait_exists('MySessions')){
	trait MySessions{
		protected $test_cookie_name='my_test';
		protected $sesssion_vars=array();
		protected $cookie_enabled=true;
		protected $session_name;
		public function startSession(){
			session_start();
		}
		public function setSessionName($name){
			$this->session_name=$name;
			if(!isset($_SESSION[$this->session_name])){
				$_SESSION[$this->session_name]=array();
				$this->sesssion_vars=array();
			}else {
				$this->sesssion_vars=$_SESSION[$this->sesssion_name];
			}
				
		}
		public function setSessionVariable($key,$val,$force=false){
			
			if(!isset($_SESSION[$this->session_name])){
				$_SESSION[$this->session_name]=array();
				$this->sesssion_vars=array();
			}
			if(!isset($_SESSION[$this->session_name][$key])){
				$_SESSION[$this->session_name][$key]=$val;
				$this->sesssion_vars[$key]=$val;
			}else if($force){
				$_SESSION[$this->session_name][$key]=$val;
				$this->sesssion_vars[$key]=$val;
			}
		}
		public function getSessionVar($key){
			if(isset($_SESSION[$this->session_name][$key])){
				return $_SESSION[$this->session_name][$key];
			}else return false;
		}
		public function setTestCookie(){
			if(isset($_COOKIE[$this->test_cookie_name])){
				
				//setcookie($this->test_cookie_name,2,0,'/');
			}else {
				setcookie($this->test_cookie_name,1,0,'/');
			}
		}
		public function setCookie($name,$val){
			setcookie($name,$val,0,'/');
		}
		public function getCookie($name){
			if(isset($_COOKIE[$name])){
				return $_COOKIE[$name];
			}else return false;
		}
		public function isCookiesEnabled(){
			$name=$this->test_cookie_name;
			
			if(isset($_COOKIE[$name])){
				$val=$_COOKIE[$name];
				return true;
				//if($val==2)return true;
			}
			return false;
		}
		public function removeTestCookie(){
			$name=$this->test_cookie_name;
			if(isset($_COOKIE[$name])){
				unset($_COOKIE[$name]);
				setcookie($name,null,-1);
			}	
		}
		
	}
	
}
if(!trait_exists('MyLoadFiles')){
	trait MyLoadFiles{
		public function loadClass($file=''){
			$f=$this->class_dir.$file;
			$this->myLoadFile($f);
		}
		public function loadController($file){
			$f=$this->controllers_dir.$file;
			$this->myLoadFile($f);
			
		}
		public function loadFile($dir,$file){
			$f=$dir.$file;
			$this->myLoadFile($f);
			
		}
		public function loadModel($file){
			$f=$this->modules_dir.$file;
			$this->myLoadFile($f);
		}
		
		public function loadOptions($file){
			$f=$this->options_dir.$file;
			//$this->myLoadFile($f);
			if(file_exists($f)){
				return require $f;
			}else {
				$msg=__("File dont exists in dir","my_support_theme").' '.$f;
				trigger_error($msg,E_USER_NOTICE);
			}
		}
		public function loadFunctions($file){
			$f=$this->functions_dir.$file;
			$this->myLoadFile($f);
		}
		private function myLoadFile($f){
			if(file_exists($f)){
				require_once $f;
			}else {
				$msg=__("File dont exists in dir","my_support_theme").' '.$f;
				trigger_error($msg,E_USER_NOTICE);
			}
		}
	}
}
/**
 * Trait singleton
 * @author awa292opa
 *
 */
if(!trait_exists('MySingleton')){
	trait MySingleton
	{
		private static $instance = null;

		public static function singleton($options=array())
		{
			if( self::$instance == null )
			{
				self::$instance = new self($options);
			}
			return self::$instance;
		}
	}
}
if(!trait_exists('MyTraitSingleton')){
	trait MyTraitSingleton
	{
		private static $trait_instance = null;

		public static function singleton()
		{
			if( self::$trait_instance == null )
			{
				self::$trait_instance = new self();
			}
			return self::$trait_instance;
		}
	}
}
/*if(!trait_exists('MyWordpressAdminPageClass')){
	trait MyWordpressAdminPageClass{
		protected $title;
		protected $menu_title;
		protected $capability;
		protected $is_logged;
		protected $styles;
		protected $scripts;
		protected $subpages;
		function __construct($options=array())
	}
}
*/
if(!trait_exists('MyDebug')){
	trait MyDebug{
		static $trait_debug=false;
		static $trait_use_case="";
		static function debug($key,$val,$arr=true){
			if(self::$trait_debug){
				if(class_exists('Class_My_Module_Debug')){
					Class_My_Module_Debug::add_section($key, $val,self::$trait_use_case,$arr);
				}
			}
		}
		static function setDebugOptions($use_case){
			self::$trait_debug=true;
			self::$trait_use_case=$use_case;
		}
		static function debugFile($key,$title,$var){
			if(self::$trait_debug){
				if(class_exists('Class_My_Module_Debug')){
					Class_My_Module_Debug::debug_file($key, $title, $var);
				}
			}
		}
		static function debugFileClose($key){
			if(self::$trait_debug){
				if(class_exists('Class_My_Module_Debug')){
					Class_My_Module_Debug::debug_file_close($key);
				}
			}
		}
	}
}
/*
if(!trait_exists('MyGlobalScripts')){
	trait MyGlobalScripts{
		use MySingleton,MyDebug;
		protected $objects;
		protected $includes;
		protected $styles;
		protected $scripts;
		protected $wpscripts=array();
		protected $wpstyles=array();
		protected $wphead=array();
		protected $wpfooter=array();
		protected $keys;
		protected $min=false;
		protected $my_debug=false;
		protected $assets_url;
		//static $debug=false;
		function callOnce($options=array()){
			
			
			$this->objects['fontawesome']=array(
				'css'=>'font-awesome.css',
				'css_min'=>'font-awesome.min.css'	
			);
			$this->objects['fotorama']=array(
				'css'=>'fotorama.css',
				'jscript'=>'fotorama.js'
			);
			$this->objects['flexslider']=array(
				'css'=>'flexslider.css',
				'jscript'=>'jquery.flexslider.js'	
			);
			$this->styles['mCustomScrollBar']='jquery.mCustomScrollbar.css';
			$this->scripts['mCustomScrollBar']='jquery.mCustomScrollbar.js';
			$this->styles['jqueryUi']='jquery-ui.css';
			$this->styles['prettyPhoto']='prettyPhoto.css';
			$this->scripts['prettyPhoto']='jquery.prettyPhoto.js';
			if(is_admin()){
				add_action ( 'admin_head', array (&$this,'admin_head'),PHP_INT_MAX );
				add_action ( 'admin_enqueue_scripts', array (&$this,'admin_scripts'),PHP_INT_MAX );
				add_action('admin_footer',array(&$this,'admin_footer'),PHP_INT_MAX);
			}else {
				add_action ( 'wp_head', array (&$this,'admin_head'),PHP_INT_MAX );
				add_action ( 'wp_enqueue_scripts', array (&$this,'admin_scripts'),PHP_INT_MAX );
				add_action('wp_footer',array(&$this,'admin_footer'),PHP_INT_MAX);
			}
		}
		private function setScriptOptions($options=array()){
			if(!empty($options['min'])){
				$this->min=true;
			}
			if(!empty($options['debug'])){
				//self::$trait_debug=true;
				//self::$trait_use_case=$options['use_case'];
				self::setDebugOptions($options['use_case']);
			}
			if(!empty($options['assets_url'])){
				$this->assets_url=$options['assets_url'];
			}
			//self::debug("instantiate_options",$options,false);
			$this->callOnce();
		}
		
		private function addIncludesObj($include=array()){
			self::debug('add_includes', $include,true);
			if(is_array($include)){
			if(!empty($include)){
				foreach($include as $key=>$val){
					if(!isset($this->includes[$val])){
						$this->includes[$val]=1;
					}
				}
			}
			}else {
				$this->includes[$include]=1;
			}
			self::debug("after_adding", $this->includes,false);
		}
		public function addItem($array){
			if($array['type']=='script'){
				$this->wpscripts[]=$array['handle'];
			}else if($array['type']=='style'){
				$this->wpstyles[]=$array['handle'];
			}else if($array['type']=='head'){
				$this->wphead[]=$array['head'];
			}else if($array['type']=='footer'){
				$this->wpfooter[]=$array['head'];
			}
		}
		static function addWordpressFooter($head){
			$instance=self::singleton();
			$instance->addItem(array('head'=>$head,'type'=>'footer'));
		
		}
		static function addWordpressHead($head){
			$instance=self::singleton();
			$instance->addItem(array('head'=>$head,'type'=>'head'));
				
		}
		static function addWordpressScript($script){
			$instance=self::singleton();
			$instance->addItem(array('handle'=>$script,'type'=>'script'));
			
		}
		static function addWordpressStyle($style){
			$instance=self::singleton();
			$instance->addItem(array('handle'=>$style,'type'=>'style'));
		}
		static function addIncludes($includes=array()){
			$instance=self::singleton();
			$instance->addIncludesObj($includes);
		}
		public function admin_scripts(){
			if(!empty($this->wpscripts)){
				foreach($this->wpscripts as $key=>$val){
					wp_enqueue_script($val);
				}
			}
			if(!empty($this->wpstyles)){
				foreach($this->wpstyles as $key=>$val){
					wp_enqueue_style($val);
				}
			}
			//Class_My_Module_Debug::add_section('includes', $this->includes,$this->use_case,false);
			self::debug('includes', $this->includes,true);
			if(!empty($this->includes)){
				foreach($this->includes as $key=>$val){
					$my_found=false;
					if(array_key_exists($key, $this->objects)){
						$obj=$this->objects[$key];
						$css='';
						$script='';
						if($this->min){
							if(!empty($val['css_min'])){
								$css=$val['css_min'];
							}
						}
						if(empty($css)){
							if(!empty($val['css'])){
								$css=$val['css'];
							}
						}
						$url=$this->getUrl($key, $css);
						$key1=$this->genKey($key,true);
						wp_enqueue_style($key1,$url);
						if(!empty($obj['jscript'])){
							$jscript=$obj['jscript'];
							$url=$this->getUrl($key, $jscript);
							$key1=$this->genKey($key,false);
							wp_enqueue_script($key1,$url);
						}
					}else {
						if(array_key_exists($key, $this->styles)){
							$file=$this->styles[$key];
							$url=$this->getUrl($key, $file,true,false);
							$key1=$this->genKey($key);
							wp_enqueue_style($key1,$url);
						}
						if(array_key_exists($key, $this->scripts)){
							$file=$this->styles[$key];
							$url=$this->getUrl($key, $file,false,false);
							$key1=$this->genKey($key,false);
							wp_enqueue_script($key1,$url);
						}
					}
				}
			}
		}
		private function genKey($key,$style=true){
			if($style){
					$key='my_'.$key.'_style';
			}else {
					$key='my_'.$key.'_script';
			}
			return $key;
		}
		private function getUrl($key,$file,$css=false,$isObject=true){
			$url=$this->assets_url;
			if($isObject){
				$url.='/'.$key.'/';
				$url.=$file;
			}else {
				if($css)
				$url.='css/';
				else $url.='jscript/';
				$url.=$file;
			}
			return $url;
		}
		private function renderItem($val){
			$type=$val['type'];
			if($type=='css'){
				?>
				<style type="text/css"><?php echo $val['value']?></style>
				<?php
			}else if($type='script'){
				?>
				<script type="text/javascript"><?php echo $val['value']; ?></script>
				<?php
			}
									
		}
		public function admin_head(){
			if(!empty($this->wphead)){
				foreach($this->wphead as $key=>$val){
					$this->renderItem($val);
				}
			}
		}
		public function admin_footer(){
			if(!empty($this->wpfooter)){
				foreach($this->wpfooter as $key=>$val){
					$this->renderItem($val);
				}
			}
		}
		
	}
}
*/
if(!trait_exists('MyFiles')){
	trait MyFiles{
		protected $upload_dir;
		protected $base_name;
		protected $upload_name;
		protected $file_name_size=20;
		protected $allowed;
		public function checkUploadFile($name=''){
			if(empty($name))$name=$this->upload_name;
			$file=@$_FILES[$name];
			$tmp_name=$file['tmp_name'];
			if(!empty($allowed['size'])){
				$t=$this->checkSize($tmp_name, $allowed['size']);
				$max_size=$this->fileSizeConvert($allowed['size']);
				if(!$t){
					return __("Maximum Allowed File Size Is ","my_support_theme").' : '.$max_size;
				}
			}
			if(!empty($allowed['types'])){
				//$ext=$this->getFileExt($tmp_name);
				$t=$this->checkExtension($tmp_name,$allowed['types']);
				if(!$t){
					return __("Allowed file extensions are :","my_support_theme").' : '.implode(",",$allowed['types']);
					
				}
			}
			if(!empty($allowed['image'])){
				$t=$this->checkImage($tmp_name);
				if(!$t){
					return __("Allowed file extensions are :","my_support_theme").' : '.implode(",",$allowed['types']);
						
				}
			}
			return true;
			
		}
		public function moveTmpFile($name='',$t_dir=''){
			$tmp_dir=$t_dir;
			if(empty($tmp_dir)){
				$tmp_dir=$this->upload_dir;
			}
			if(empty($name))$name=$this->upload_name;
			$file=@$_FILES[$name];
			$tmp_name=$file['tmp_name'];
			$name=$file['name'];
			$file_name=$this->randomFileName($name);
			$file_full=$tmp_dir.$file_name;
			while(file_exists($file_full)){
				$file_name=$this->randomFileName($name);
				$file_full=$tmp_dir.$file_name;
					
			}	
			self::debug("full_name",$file_full,false);
			if(!move_uploaded_file($tmp_name, $file_full)){
				return false;
			}
			return $file_name;
			
		}
		function fileSizeConvert($bytes)
		{
			$bytes = floatval($bytes);
			$arBytes = array(
					0 => array(
							"UNIT" => "TB",
							"VALUE" => pow(1024, 4)
					),
					1 => array(
							"UNIT" => "GB",
							"VALUE" => pow(1024, 3)
					),
					2 => array(
							"UNIT" => "MB",
							"VALUE" => pow(1024, 2)
					),
					3 => array(
							"UNIT" => "KB",
							"VALUE" => 1024
					),
					4 => array(
							"UNIT" => "B",
							"VALUE" => 1
					),
			);
		
			foreach($arBytes as $arItem)
			{
				if($bytes >= $arItem["VALUE"])
				{
					$result = $bytes / $arItem["VALUE"];
					$result = str_replace(".", "," , strval(round($result, 2)))." ".$arItem["UNIT"];
					break;
				}
			}
			return $result;
		}
		public function checkSize($file,$size){
			$sizet=filesize($file);
			if($sizet>$size){
				return false;
			}
			return true;
		}
		public function checkExtension($file,$allowed=array()){
			$ext=$this->getFileExt($file);
			if(!in_array($ext, $allowed))return false;
			return true;
		}
		public function checkImage($file){
			if(function_exists('getimagesize')){
				if(@is_array(getimagesize($file))){				
					$image = true;
				} else {
					$image = false;
				}
		}else $image=false;
			return $image;
		}
		
		private function getFileExt($file){
			$this->base_name=basename($file);
			$ext=pathinfo($file,PATHINFO_EXTENSION);
			$ext=strtolower($ext);
			return $ext;
		}
		private function randomFileName($file){
			$ext=$this->getFileExt($file);
			$str=rand(1,9);
			for($i=0;$i<$this->file_name_size;$i++){
				$str.=rand(0,9);
			}
			return $str.'.'.$ext;
		}
	}
}

if(!trait_exists('MyDirectories')){
	trait MyDirectoriesFiles{
		static function readDirs($dir){
			$dirs=array();
			if (is_dir($dir)) {
				if ($dh = opendir($dir)) {
					while (($file = readdir($dh)) !== false) {
				
						if(in_array($file,array(".","..")))continue;
						$new_file=$dir.$file;
						if(is_dir($new_file)){
							$dirs[]=$file;
						}	
					}
					closedir($dh);
				}
			}
			return $dirs;		
		}
		static function readFiles($dir,$include=array()){
			$patterns=array();
			$extensions=array();
			foreach($include as $key=>$val){
				if(preg_match_all('/^\*\.([.]+)$/ims', $val,$matches)){
					//print_r($matches);
					$extensions=$matches[1][0];
					//$patterns[]='/[.]*\.'.
				}else {
					$paterns[]=$val;
				}
			}
			//print_r($extensions);
		}
		static function getFileExt($file){
			$arr=explode(".",$file);
			$ext=false;
			if(!empty($arr)){
				foreach($arr as $key=>$val){
					if(!empty($val)){
						$ext=$val;
					}
				}
			}
			return $ext;
		}
	}
}
/**
 * Get all modules traits
 */
if(!trait_exists('MyModules')){
	trait MyModules{
		use MyDirectoriesFiles;
		protected $modules;
		protected $instances;
		static $instance_count=array();
		/**
		 * Get all modules
		 * @param unknown $dir
		 * @throws Exception
		 */
		function getModules($dir){
			$dirs=self::readDirs($dir);
			$file=self::readFiles($dir,array("*.php"));
			//print_r($dirs);
			foreach($dirs as $key=>$val){
				$file=$dir.$val.'/info.php';
				$class_file=$dir.$val.'/class.php';
				$this->modules[$val]['info']=require $file;
				$this->modules[$val]['dir']=$dir.$val.'/';
				if(file_exists($class_file)){
					$this->modules[$val]['class']=$class_file;
				}else {
					//throw new Exception(__("Module has no class.php","my_support_theme").'-'.$val);
					trigger_error(__("Module has no class.php","my_support_theme").'-'.$val,E_USER_NOTICE);
				}
			}
			
		}
		/**
		 * Load module class
		 * @param string $module
		 * @throws Exception
		 */
		function loadModuleClass($module=''){
			if(!empty($this->modules[$module])){
				$file=$this->modules[$module]['class'];
				require_once $file;
			}else {
				//throw new Exception(__("Module has no class.php","my_support_theme").'-'.$module);
				trigger_error(__("Module has no class.php","my_support_theme").'-'.$module,E_USER_NOTICE);
			}
		}
		function loadModuleFile($module,$file,$subdir=''){
			if(!empty($this->modules[$module])){
				$dir=$this->modules[$module]['dir'];
				if(!empty($subdir)){
					$dir.=$subdir.'/';
					
				}	
				$dir.=$file;
				if(file_exists($dir)){
					require_once $dir;
					
				}else {
					trigger_error(__("Module has no file ","my_support_theme").'-'.$module.' '.$dir,E_USER_NOTICE);
						
				}
				
			}
		}
		/**
		 * Get module Class
		 * @param unknown $module
		 */
		private function getModuleClass($module){
			$class='Class_My_Module_'.ucfirst($module);
		}
		/**
		 * instantiate module class
		 * @param string $module
		 * @param unknown $options
		 * @return unknown
		 */
		function instantiateModuleClass($module='',$options=array()){
			$this->loadModuleClass($module);
			$module_class=$this->modules[$module]['info']['class'];
			if(empty($module_class)){
				$module_class=$this->getModuleClass($module);
			}
			$instance=new $module_class($options);
			if(!isset(self::$instance_count[$module])){
				self::$instance_count[$module]=1;
			}else self::$instance_count[$module]++;
			$i=self::$instance_count[$module];
			$this->instances[$module][$i]=&$instance;
			return $instance;
			
		}
	}
}


/**
 * Trat array options to function
 * @author awa292opa
 *
 */
if(!trait_exists('MyArrayOptions')){
	trait MyArrayOptions{
		
		public function setOptions($options=array()){
			$class=get_class();
		//echo 'Class '.$class;
			if(!empty($options)){
				foreach($options as $key=>$val){
					if(!property_exists($class, $key)){
						$msg=__("Class has no defined property ","my_support_theme").' '.$key.' - '.$class;
						//throw new \Exception($msg,8000);
						trigger_error($msg,E_USER_NOTICE);
					}
					$this->$key=$val;
				}
			}
		}
		public function __toString(){
			ob_start();
			foreach($this as $key=>$val){
			?>
				<h4><?php echo $key;?></h4>
				<pre><?php print_r($val);?></pre>
				<?php 
			}
			$html=ob_get_clean();
			return $html;
		}
		public function myDebug($key,$var,$arr=true){
			if(!isset($this->debug_arr[$key])){
				if($arr)$this->debug_arr[$key]=array();
			}
			if($arr){
				$this->debug_arr[$key][]=$var;
			}else {
				$this->debug_arr[$key]=$var;
			}
		}
	}
}
if(!trait_exists("MyBaseModel")){
	trait MyBaseModel{
		use MyArrayOptions,MySingleton;
		// INSERT_REPLACE=1,DELETE_UPDATE=2,SELECT=3,OTHER=4;
		private $table_name;
		private $queries=array();
		private $errors=array();
		function __construct($options=array()){
			$this->set_options($options);
		}
		private function prepare_query($query,$params){
			global $wpdb;
			$query=$wpdb->prepare($query, $params);
			return $query;
		}
		private function micro_time(){
			return microtime(true);
		}
		private function get_query_type($query){
			if(preg_match( '/^\s*(insert|replace)\s/i', $query )){
				return self::INSERT_REPLACE;
			}else if(preg_match( '/^\s*(delete|update)\s/i', $query )){
				return self::DELETE_UPDATE;
			}else if(preg_match('/^\s*(select)\s/i', $query)){
				return self::SELECT;
			}else return self::OTHER;
		}
		public function query($query,$params=array()){
			global $wpdb;
			if($this->debug){
				$wpdb->show_errors(true);
			}	
			if($this->debug){
				ob_start();
			}
			if(!empty($params)){
				$query=$this->prepare_query($query, $params);
			}
			$query_type=$this->get_query_type($query);
			$start=$this->micro_time();
			$wpdb->query($query);
			$end=$this->micro_time();
			if($query_type==self::SELECT){
				$res=$wpdb->get_results();
				return $res;
			}
			
			if($this->debug){
				$wpdb->show_errors(false);
			}
		}
	}
}