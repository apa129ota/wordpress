/*jQuery(document).ready(function($){
	if(window.console){
		console.log("Global Debug",my_debug_123);
	}
});*/