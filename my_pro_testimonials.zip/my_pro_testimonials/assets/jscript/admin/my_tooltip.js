jQuery(document).ready(function($){
	$(".my_tooltip").tooltip({
		items:"div",
		
		content:function(){
			var html=$(this).children(".my_content").html();
			///console.log('Html '+html);
			return html;
		}
		});
});