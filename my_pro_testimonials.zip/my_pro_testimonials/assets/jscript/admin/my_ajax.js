(function($) { 
	myGlobalAjaxClass=function(o){
		var self;
		this.my_working=false;
		this.debug=true;
		this.pre_options={};
		this.working=false;
		self=this;
		
		this.init=function(o){
			self.options=o;
			if(typeof self.options.my_debug!='undefined'){
				if(!self.options.my_debug){
					self.debug=false;
				}
			}
			self.options=$.extend( self.pre_options,self.options);
			self.my_debug("Options",self.options);
		};
		this.call_ajax=function(obj,msg){
			if(self.working)return;
			self.working=true;
			var o=$.extend(self.options.ajax_options,obj);
			self.my_debug("Call Ajax",o);
			self.obj=obj;
			o.success=self.success;
			o.error=self.error;
			if(typeof obj.show_msg!='undefined'){
				myAdminMsgs_inst.my_show_working_window(msg);
			}
			$.ajax(o);
			
		};
		this.success=function(data,status,jq){
			self.working=false;
			self.my_debug("Ajax data",data);
			if(typeof self.obj.success!='undefined'){
				self.show_msg(data);
				self.obj.success(data);
				
			}else {
				self.show_msg(data);
			}
		};
		this.show_msg=function(data){
			if(typeof self.obj.show_msg!='undefined'){
				myAdminMsgs_inst.my_remove_window();
			}
			if(data.error==1){
				if(typeof data.msg!='undefined'){
					myAdminMsgs_inst.my_show_error_window(data.msg);
					self.remove_msg();
				}
			}else {
				if(typeof data.msg!='undefined'){	
				myAdminMsgs_inst.my_show_success_window(data.msg);
				self.remove_msg();
				}
			}
		};
		this.remove_msg=function(){
			setTimeout(function(){
				myAdminMsgs_inst.my_remove_window();
				//self.my_working=false;
			},self.options.msg_window_timeout);
		};
		this.error=function(jq,status){
			self.working=false;
			if(typeof self.obj.show_msg!='undefined'){
				myAdminMsgs_inst.my_remove_window();
			}
			var msg=self.options.msgs.network_error;
			myAdminMsgs_inst.my_show_error_window(msg);
			setTimeout(function(){
				myAdminMsgs_inst.my_remove_window();
				//self.my_working=false;
			},self.options.msg_window_timeout);
			if(typeof self.obj.error!='undefined'){
				self.obj.error(data);
			}
		};
		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log('Ajax module \n'+t,o);
				}
			}
		};
			this.init(o);
			
	}
})(jQuery);		
		