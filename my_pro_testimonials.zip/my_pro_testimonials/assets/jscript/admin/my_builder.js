(function($) { 
	myAdminBuilder=function(o){
		var self;
		this.my_working=false;
		this.debug=true;
		self=this;
		this.item_width;
		this.index=1;
		self.my_top=10;
		self.my_diff=15;
		this.init=function(o){
			self.options=o;
			if(typeof self.options.my_debug!='undefined'){
				if(!self.options.my_debug){
					self.debug=false;
				}
			}
			self.my_debug("Options",self.options);
			$(".my_tooltip").tooltip({
				items:"div",
				content:function(){
					var html=$(this).children(".my_content").html();
					return html;
				}
				});
			$(".my_saved_images").sortable({
			      revert: true
		    });
			$(document).on("click",".my_accordian_header",function(e){
				e.preventDefault();
				var is=0;
				if($(this).parents(".my_accordian").find(".my_accordian_inner").is(":visible")){
					is=1;
				}
				is=!is;
				if(!is){
					$(this).parents(".my_accordian").find(".fa-minus").hide();
					$(this).parents(".my_accordian").find(".fa-plus").show();
					
				}else {
					$(this).parents(".my_accordian").find(".fa-plus").hide();
					$(this).parents(".my_accordian").find(".fa-minus").show();
					
					
				}
				if(!is)
				$(this).parents(".my_accordian").attr('data-on',0);
				else $(this).parents(".my_accordian").attr('data-on',1);
				
			    $(this).parents(".my_accordian").find(".my_accordian_inner").slideToggle('fast');
			});
			$(document).on('click',".my_options_form .my_slide_in_out i",function(e){
				e.preventDefault();
				self.my_debug("Click",$(this).attr('class'));
				if($(this).hasClass('fa-angle-double-right')){
					$(".my_options_form").animate({left:'0px'});
					$(this).hide();
					$(this).parents(".my_slide_in_out").find(".fa-angle-double-left").show();
				}else {
					$(".my_options_form").animate({left:'-300px'});
					$(this).hide();
					$(this).parents(".my_slide_in_out").find(".fa-angle-double-right").show();
				}
			});
			var hh=$(document).height();
			$(".my_options_form").height(hh);
			$(".my_options_form_inner").mCustomScrollbar();
			self.item_width=$(".my_saved_images .my_img_1").width();
			$(".my_saved_images .my_img_1").width(self.item_width);
			self.set_draggable_droppable();
			$(window).resize(self.my_resize);
			$(document).on("click",".my_actions li a",self.my_action);
			$(window).load(function(e){
				$(".my_img_1[data-id='18'] .my_edit").trigger('click');
			});
			$(document).on('click','.my_open_section',function(e){
				e.preventDefault();
				var is=$(this).attr('data-is');
				self.my_debug("Click open section ")
				if(typeof is !='undefined' && is==1){
					$(this).parents(".my_sidebar").find(".my_section_inside").slideToggle();
					$(this).parents(".my_sidebar").find(".my_section_inside").attr('is',0);
					return;
				}
				$(this).parents(".my_sidebar").find(".my_section_inside[data-is='1']").slideToggle();
				$(this).parents(".my_elemenet_section").find(".my_section_inside").slideToggle(function(){
					$(this).attr('data-is',1);
				});
				
				//$(".my_window_elements").slideToggle('slow');
			});
			$(document).on('click',".my_add_shortcode",function(e){
				if(self.my_working)return;
				self.my_working=true;
				e.preventDefault();
				var data_key=$(this).data('key');
				self.my_debug('Key',data_key);
				var content='';
				var s_tmpl_1=myVusualBuilderMain_inst.my_show(data_key,content);
				if(s_tmpl_1!==false){
					var s_tmpl=s_tmpl_1.tmpl;
					//var id=s_tmpl_1.id;
					
					var id="my_added_object_"+self.my_edit_id+"_"+self.index;
					self.index++;
					//self.my_debug("Add object",id);
					//s_tmpl=s_tmpl.replace('{id}',id);
					//s_tmpl=s_tmpl.replace('{key}',data_key);
					
					s_tmpl=s_tmpl.replace('{object_id}',self.my_edit_id);
					var tmpl=$("script.my_shortcode_row").html();
					tmpl=tmpl.replace('{content}',s_tmpl);
					tmpl=tmpl.replace('{id}',id);
					tmpl=tmpl.replace('{key}',data_key);
					$(".my_slide_image_inner").append(tmpl);
					
					setTimeout(function(){
						
						myVusualBuilderMain_inst.adjust_element(id,data_key,self.my_top,self.my_diff);
						//self.my_top+=$(".my_slide_image_inner").find("#"+id).height()+10;
						self.my_working=false;
					},100);
					}
			});
		};
		this.my_action=function(e){
			
			e.preventDefault();
			var action=$(this).data('action');
			self.my_debug("Action",action);
			
			switch(action){
				case 'my_edit':
					var id=$(this).parents(".my_img_1").data('id');
					self.my_edit_id=id;
					
					var w=$(this).parents(".my_img_1").data('w');
					var h=$(this).parents(".my_img_1").data('h');
					self.my_debug("Edit slide",{id:id,w:w,h:h});
					
					var img=$(this).parents(".my_img_1").data('image');
					self.my_debug("Img",img);
					$(".my_timeline_modal").find(".my_slide_image .my_img_slide_inner").remove();
					//$(".my_timeline_modal").find(".my_slide_image").append('<img class="my_img_slide_inner" src="'+img+'"/>');
					$(".my_timeline_modal").find(".my_slide_image").append('<div class="my_slide_image_inner"><img class="my_img_slide_inner" data-w="'+w+'" data-h="'+h+'" src="'+img+'"/></div>');
					var is_mc=$(".my_timeline_modal").find(".my_options_form").attr('is-mc');
					if(typeof is_mc=='undefined'){
						$(".my_timeline_modal").find(".my_options_form_inner").mCustomScrollbar();
						$(".my_timeline_modal").find(".my_options_form").attr('is-mc',1);
					}
					
					/*var w1=$(".my_timeline_modal").find(".my_slide_image").width();
					var h1=$(".my_timeline_modal").find(".my_slide_image").height();
					if(w<w1){
						$(".my_timeline_modal").find('.my_slide_image_inner').width(w);
					}
					$(".my_timeline_modal").find('.my_slide_image_inner').width(h1);
					*/
					myAdminDialog_inst.open_dialog();
					
				break;
			}
		};
		this.my_resize=function(e){
			var hh=$(document).height();
			//$(".my_options_form").height(hh);
			self.item_width=$(".my_saved_images .my_img_1").width();
			$(".my_saved_images .my_img1").width(self.item_width);
			if($(".my_timeline_modal").is(":visible")){
				/*var w=$(".my_timeline_modal").find(".my_img_slide_inner").data('w');
				var h=$(".my_timeline_modal").find(".my_img_slide_inner").data('h');
				
				var w1=$(".my_timeline_modal").find(".my_slide_image").width();
				var h1=$(".my_timeline_modal").find(".my_slide_image").height();
				if(w<w1){
					$(".my_timeline_modal").find('.my_slide_image_inner').width(w);
				}
				$(".my_timeline_modal").find('.my_slide_image_inner').width(h1);
				*/
			}
		};
		this.set_draggable_droppable=function(){
			$(".my_img_1").each(function(i,v){
				var is=$(v).attr('is-draggable');
				if(typeof is=='undefined'){
					
					$(v).draggable({
					      connectToSortable: ".my_saved_images",
					     // helper: "clone",
					      revert: "invalid",
					      start:function( event, ui ){
					    	  self.my_debug("Start",ui);
					    	  self.my_debug("Width",self.item_width);
					    	  $(ui.helper).width(self.item_width);
					      }
					    });
					$(v).disableSelection();
					$(v).attr('is-draggable',1);
				}
			});
		};
		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log('Get Social Posts \n'+t,o);
				}
			}
		};
			this.init(o);
			
	}
})(jQuery);		
		