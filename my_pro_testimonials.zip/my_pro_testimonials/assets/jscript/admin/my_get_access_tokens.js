jQuery(document).ready(function($){
	var my_get_query_vars=function(q){
		var o={};
		var q_arr=q.split('&');
		$.each(q_arr,function(i,v){
			var t=v;
			if(t.indexOf('=')!==-1){
				var t_arr=v.split('=');
				o[t_arr[0]]=t_arr[1];
			}
		});
		console.log("Query args",o);
		return o;
	};
	var href=window.location.href;
	console.log('Href',href);
	var token=location.hash.split('=')[1];
	console.log('Token',token);
	query  = window.location.search;
	console.log('Query',query);
	var my_do=false;
	var network='';
	if(query.indexOf('my_pinterest=1')!==-1){
		my_do=true;
		network='pinterest';
		
	}else if(query.indexOf('my_instagram=1')!==-1){
		my_do=true;
		network='instagram';
	}
	
	if(my_do){
		var q_args=my_get_query_vars(query);
		var state='';
		if(network=='pinterest'){
			token=q_args['access_token'];
		}else if(network=='instagram'){
			token=q_args['code'];
			state=q_args['state'];
			if(q_args['erorr']=='access_denied'){
				state='';
			}
		}
		
		var data={
				action:'my_get_access_token',
				my_action:'my_get_access_token',
				network:network,
				token:token,
				state:state
			};
			//self.my_debug("Ajax data",data);
			console.log('Data',data);
			//var msg=my_saving_token_msg;
			//myAdminMsgs_inst.my_show_working_window(msg);
			$.ajax({
				url:my_ajax_url,
				dataType:'json',
				data:data,
				cache:false,
				timeout:30000,
				type:'POST',
				success:function(data,status,jq){
					//self.my_debug('data',data);
					console.log('data',data);
					//myAdminMsgs_inst.my_remove_window();
					if(data.error==0){
						//$("."+self.network+"_dont_have_access").hide();
						//$("."+self.network+"_have_access").show();
						var class_1=network+'_dont_have_access';
						var class_2=network+'_have_access';
						$("."+class_1).fadeOut();
						$("."+class_2).fadeIn();
					}else {
						myAdminMsgs_inst.my_show_error_window(data.msg);
					}
					setTimeout(function(){
						myAdminMsgs_inst.my_remove_window();
						//self.my_working=false;
					},4000);
				},
				error:function(jq,status){
				self.my_working=false;
				alert('Error');
				//var msg=self.options.msgs.network_error;
				//myAdminMsgs_inst.my_show_error_window(msg);
				
				/*setTimeout(function(){
					myAdminMsgs_inst.my_remove_window();
					//self.my_working=false;
				},4000);
				*/
			}
			});
		
		
	}
});