jQuery(document).ready(function($){
	$(document).on('click',".my_action",function(e){
		var key=$(this).data('key');
		if(key=='my_generate_shortcode'){
			var s=$(".my_shortcode_content").data('key');
			var short='['+s;
			var cat=$("#my_category_id").val();
			if(cat!=''){
				short+=' cat="'+cat+'"';
				
			}
			short+=']';
			$(".my_shortcode_content").html(short);
		}
	});
	$(document).on("click",".my_accordian_header",function(e){
		e.preventDefault();
		var is=0;
		if($(this).parents(".my_accordian").find(".my_accordian_inner").is(":visible")){
			is=1;
		}
		is=!is;
		if(!is){
			$(this).parents(".my_accordian").find(".fa-minus").hide();
			$(this).parents(".my_accordian").find(".fa-plus").show();
			
		}else {
			$(this).parents(".my_accordian").find(".fa-plus").hide();
			$(this).parents(".my_accordian").find(".fa-minus").show();
			
			
		}
		if(!is)
		$(this).parents(".my_accordian").attr('data-on',0);
		else $(this).parents(".my_accordian").attr('data-on',1);
		
	    $(this).parents(".my_accordian").find(".my_accordian_inner").slideToggle('fast');
	});
});