(function($) { 
	myAdminTemplates=function(o){
		var self;
		this.my_working=false;
		this.debug=true;
		this.options=o;
		this.network='';
		this.network_ids='';
		this.my_pre_open_post_id='';
		this.search_ids={};
		this.my_get_all=false;
		this.my_save_all=false;
		self=this;
		this.init=function(o){
			if(typeof self.options.my_debug!='undefined'){
				if(!self.options.my_debug){
					self.debug=false;
				}
			}
			self.options=o;
			self.my_debug("Options",self.options);
			$(".my_tooltip").tooltip({
				items:"div",
				
				content:function(){
					var html=$(this).children(".my_content").html();
					///console.log('Html '+html);
					return html;
				}
				});
				
			//$("#my_preview_small_template").click(self.get_preview_style);
			$(".my_preview_post").each(function(i,v){
				self.change_scroller(v,false);
			});
			$(".my_preview_post").find(".my_social_content_text").mCustomScrollbar();
			$("#my_form_inner_1 .my_social_networks li").click(self.my_choose_network);
			//$(".my_social_networks li[data-type='youtube']").trigger('click');
			$("form li .my_form_element_div div").on('my_change',self.change_style);
			$("form input[type='text']").change(self.change_text);
			$(".my_social_post .my_social_content").mouseenter(function(e){
				$(this).parents(".my_social_post").find(".my_social_owner").css({opacity:1,height:'56px'});
			});
			$(".my_social_post .my_social_content").mouseleave(function(e){
				$(this).parents(".my_social_post").find(".my_social_owner").css({opacity:0,height:'0px'});
			});
			$("#my_save_small_template").click(self.my_save);
			$("#my_copy_small_template").click(self.my_copy);
		};
		this.my_copy=function(e){
			var from=$("#my_from_tmpl_id option:selected").val();
			if(from==""){
				var msg=self.options.msgs.from_tmpl;
				myAdminMsgs_inst.my_show_error_window(msg);
				setTimeout(function(){
					myAdminMsgs_inst.my_remove_window();
				//self.my_working=false;
				},self.options.msg_window_timeout);
				return;
			}
			var to=$("#my_to_tmpl_id option:selected").val();
			if(to==""){
				var msg=self.options.msgs.to_tmpl;
				myAdminMsgs_inst.my_show_error_window(msg);
				setTimeout(function(){
					myAdminMsgs_inst.my_remove_window();
				//self.my_working=false;
				},self.options.msg_window_timeout);
				return;
			}
			if(from==to){
				var msg=self.options.msgs.same_tmpl;
				myAdminMsgs_inst.my_show_error_window(msg);
				setTimeout(function(){
					myAdminMsgs_inst.my_remove_window();
				//self.my_working=false;
				},self.options.msg_window_timeout);
				return;
			}
			if(self.my_working)return;
			$("ul.my_social_networks li[data-type='"+to+"']").trigger('click');
			
			self.my_working=true;
			self.my_debug("Copy style",{from:from,to:to});
			var values=wpMyModuleNewFormMainScript_1.get_values(".my_form_"+from);
			//self.network=to;
			wpMyModuleNewFormMainScript_1.update_values_simple(".my_form_"+to+" ",values);
			self.my_working=false;
			
		};
		this.autocomplete_form=function(obj,all_obj,val,text){
			self.my_debug("Select autocomplete",{val:val,text:text,all_obj:all_obj});
			$("#my_id_10000").val(val);
			$("#my_title_10000").val(text);
			$("ul.my_social_networks li").each(function(i,v){
				var type=$(v).data('type');
				if(typeof all_obj[type]!='undefined'){
					self.my_debug("All values",all_obj[type]);
					self.network=type;
					$("ul.my_social_networks li[data-type='"+type+"']").trigger('click');
					wpMyModuleNewFormMainScript_1.update_values_simple(".my_form_"+type+" ",all_obj[type]);
					
				}
			});
			$("ul.my_social_networks li[data-type='google']").trigger('click');
		};
		this.my_save=function(e){
			e.preventDefault();
			var forms_data={};
			$("ul.my_social_networks li").each(function(i,v){
				var type=$(v).data('type');
				var form_class='.my_form_'+type;
				forms_data[type]=$(form_class+" form ").serialize();
			});
			var id=$("#my_id_10000").val();
			var title=$("#my_title_10000").val();
			var msg=self.options.msgs.saving_tmpl;
			var data={
					action:'my_save_template',
					my_action:'my_save_template',
					data:forms_data,
					id:id,
					title:title
				};
			self.my_debug("Ajax data",data);
				//var msg=self.options.msgs.my_delete_social_id;
				myAdminMsgs_inst.my_show_working_window(msg);
				$.ajax({
					url:self.options.ajax_url,
					dataType:'json',
					data:data,
					cache:false,
					timeout:self.options.ajax_timeout,
					type:'POST',
					success:function(data,status,jq){
						self.my_debug('data',data);
						myAdminMsgs_inst.my_remove_window();
						if(data.error==0){
							//$("."+self.network+"_dont_have_access").hide();
							//$("."+self.network+"_have_access").show();
							myAdminMsgs_inst.my_show_success_window(data.msg);
							$("#my_id_10000").val(data.id);
							//$(self.my_a_12).parents('tr').remove();
							//self.my_page_1234=data.page;	
						}else {
							
							myAdminMsgs_inst.my_show_error_window(data.msg);
						}
							setTimeout(function(){
								myAdminMsgs_inst.my_remove_window();
							//self.my_working=false;
							},self.options.msg_window_timeout);
						
					},
					error:function(jq,status){
					self.my_working=false;
					var msg=self.options.msgs.network_error;
					myAdminMsgs_inst.my_show_error_window(msg);
					
					setTimeout(function(){
						myAdminMsgs_inst.my_remove_window();
						//self.my_working=false;
					},self.options.msg_window_timeout);
				}
				});
			
		};
		this.change_text=function(e){
			var form_id='_'+$(this).parents('form').find("input[name='my_form_id']").val();
			var name=$(this).attr('name');
			name=name.replace(form_id,'');
			self.my_debug("Change text",{form_id:form_id,name:name});
			var op=self.options.translate_style;
			var form=".my_form_"+self.network+" .my_small_post";
			var value=$(this).val();
			
			self.my_debug("Change Style",{value:value,name:name,op:op,val:value});
			
			if(typeof op[name]!='undefined'){
				var opt=op[name];
				var prop=opt.property;
				self.my_debug("Found op",opt);
				var sel=opt.sel;
				var num=parseFloat(value);
				if(typeof opt.unit!='undefined'){
					value+=opt.unit;
				}
				
				if(prop=='padding'){
					var h_pre=$(form+" "+sel).outerHeight();
					var p_pre=$(form+" "+sel).css('padding');
					h_pre=parseFloat(h_pre);
					p_pre=parseFloat(p_pre)*2;
					var new_h=num*2-p_pre+h_pre;
					$(form+" "+sel).css('height',new_h+'px');
				}
				if(name=='header_font_size' || name=='share_font_size'){
					var sel1=".my_social_header";
					var p_pre=$(form+" "+sel1+" div").css('line-height');
					if(name=='share_font_size'){
						sel1=".my_social_share";
						p_pre=$(form+" "+sel1+" span").css('line-height');
					}
					
					var h_pre=$(form+" "+sel1).css('height');
					
					h_pre=parseFloat(h_pre);
					p_pre=parseFloat(p_pre);
					var new_h=num+10-p_pre+h_pre;
					self.my_debug("Change",{sel1:sel1,h_pre:h_pre,p_pre:p_pre,new_h:new_h});
					$(form+" "+sel1).css('height',new_h+'px');
				
				}
				if(prop=='font-size' && name!='text_font_size'){
					var num1=num+10+opt.unit;
					$(form+" "+sel).css('line-height',num1);
				}
				$(form+" "+sel).css(prop,value);
				//if(name=='thumb_height'){
					self.change_scroller($(".my_form_"+self.network),true);
				//}
			}
			
		};
		this.change_scroller=function(v,update){
			var h=$(v).find(".my_social_post").height();
			var h1=$(v).find(".my_social_header").outerHeight();
			var h2=$(v).find(".my_social_share").outerHeight();
			var pr=$(v).find(".my_social_thumb").css('height');
			self.my_debug('Pr',pr);
			if(typeof pr=='undefined')pr='40%';
			if(pr.indexOf('px')===-1){
			self.my_debug('Pr',pr);
			pr=parseFloat(pr)/100;
			self.my_debug('Pr',pr);
			
			var h3=h*pr;//$(v).find(".my_social_thumb").outerHeight();
		} else h3=parseFloat(pr);
			var h5=$(v).find(".my_social_content_text").css('padding');
			h5=parseFloat(h5)*2;
			var h4=h-h1-h2-h3-h5;
			self.my_debug("Change scroller",{post:h,header:h1,share:h2,thumb:h3,rem:h4,pr:pr});
			$(v).find(".my_social_content_text").height(h4);
			if(update){
				$(v).find(".my_social_content_text").mCustomScrollbar('update');
			}
		};
		this.change_style=function(e,obj1,value,name){
			self.my_debug("obj1",obj1);
			/*var obj=obj1[0];
			var value=obj1[1];
			var name=obj1[2];
			*/
			var op=self.options.translate_style;
			var form=".my_form_"+self.network+" .my_small_post";
			self.my_debug("Change Style",{value:value,name:name,op:op});
			
			if(typeof op[name]!='undefined'){
				var opt=op[name];
				var prop=opt.property;
				self.my_debug("Found op",opt);
				var sel=opt.sel;
				if(sel.indexOf(":")!==-1){
					var css='';
					var css_in='';
					var css_id=self.network+name;
					css='<style type="text/css" id="'+css_id+'">';
					css_in+=sel+"{\n";
					css_in+=prop+':'+value+" !important\n";
					css_in+="}";
					css+=css_in;
					if($(".my_added_style_"+self.network+" #"+css_id).length>0){
						$(".my_added_style_"+self.network+" #"+css_id).html(css_in);
					}else $(".my_added_style_"+self.network).append(css);
					
				}
				else $(form+" "+sel).css(prop,value);
			}
		};
		this.get_preview_style=function(){
			e.preventDefault();
			var network=self.network;
			self.my_debug('Network',network);
			self.my_debug('save All');
			if(typeof network=='undefined' || network==''){
				var msg=self.options.msgs.select_network;
				myAdminMsgs_inst.my_show_error_window(msg);
				setTimeout(function(){
					myAdminMsgs_inst.my_remove_window();
					//self.my_working=false;
				},self.options.msg_window_timeout);
				return;
			}
			var form_sel='.my_form_'+network;
			myAdminDialog_inst.open_dialog();
			$(".my_timeline_modal_loading").show();
			
			var data={
					action:'my_get_access_token',
					my_action:'my_get_access_token',
					network:network
				};
			self.my_debug("Ajax data",data);
				var msg=self.options.msgs.my_get_access_token;
				myAdminMsgs_inst.my_show_working_window(msg);
				$.ajax({
					url:self.options.ajax_url,
					dataType:'json',
					data:data,
					cache:false,
					timeout:self.options.ajax_timeout,
					type:'POST',
					success:function(data,status,jq){
						self.my_debug('data',data);
						myAdminMsgs_inst.my_remove_window();
						if(data.error==0){
							//$("."+self.network+"_dont_have_access").hide();
							//$("."+self.network+"_have_access").show();
						}else {
							myAdminMsgs_inst.my_show_error_window(data.msg);
						}
						setTimeout(function(){
							myAdminMsgs_inst.my_remove_window();
							//self.my_working=false;
						},self.options.msg_window_timeout);
					},
					error:function(jq,status){
					self.my_working=false;
					var msg=self.options.msgs.network_error;
					myAdminMsgs_inst.my_show_error_window(msg);
					
					setTimeout(function(){
						myAdminMsgs_inst.my_remove_window();
						//self.my_working=false;
					},self.options.msg_window_timeout);
				}
				});
			$(document).on('click',"a.my_pretty_photo",function(e){
				e.preventDefault();
				var href=$(this).attr('href');
				self.my_debug("Preview photo",href);
				
			});
			
		};
		this.autocomplete_social_template=function(obj,data,id,title){
			//var data=obj.data;
			self.my_debug("Autocomplete social id",{data:data,id:id,title:title});
			$(".my_social_networks li[data-type='"+data.network+"']").trigger('click');
			
			var form=".my_form_"+self.network+" form";
			var form_id=$(form).find("input[name='my_form_id']").val();
			
			var check={page:'page_'+form_id+'_id',next:'next_'+form_id,prev:'prev_'+form_id};
			$.each(check,function(i,v){
					var sel="input[type='hidden'][name='"+v+"']";
					if(i=='page')$(sel).val(1);
					else $(sel).val('');
				});
			$(".my_form_"+self.network+" .my_load_more_posts ").hide();
			$(".my_form_"+self.network+" .my_social_posts_inner .my_post_single ").remove();
			$("#title_"+form_id+"_id").val(data.title);
			if(data.network=='facebook'){
				if(data.subtype=='album_posts'){
					$("#id_"+form_id+"_id").val("/"+data.idstr);
				}else $("#id_"+form_id+"_id").val(data.idstr);
			}else {
				$("#id_"+form_id+"_id").val(data.idstr);
			}
			var cron_limit=100;
			if(typeof data.add_options.cron_limit!='undefined')cron_limit=data.add_options.cron_limit;
				
			$("#cron_limit_"+form_id+'_id').val(cron_limit);
			if(data.network=='twitter'){
				
				if(data.add_options.exclude_replies){
					$("#exclude_replies_"+form_id+"_id_div").find(".imapper-checkbox-on").trigger('click');
				}else {
					$("#exclude_replies_"+form_id+"_id_div").find(".imapper-checkbox-off").trigger('click');
				}
				if(typeof data.lang!='undefined' && data.lang!=''){
					$("#lang_"+form_id+"_id_div").data('my-script').set_value(data.lang);
				}
				
			}
			if(data.run_cron==1){
				$("#auto_get_"+form_id+"_id_div .imapper-checkbox-on").trigger('click');
			}else {
				$("#auto_get_"+form_id+"_id_div .imapper-checkbox-off").trigger('click');
			}
			
			//$("#category_"+form_id+"_id_button").trigger('click');
			$("#category_"+form_id+"_id_div").data('my-script').set_value(data.cat_id);
			
			
			$("#title_"+form_id+"_id").focus();
		};
		this.my_choose_network=function(e){
			if(self.my_working)return;
			self.my_working=true;
			
			e.preventDefault();
			var type=$(this).data('type');
			self.my_debug("Open network",type);
			var form_prefix='my_form_';
			if(type==self.network){
				self.my_working=false;
				
				return;
			}
			$("#my_form_inner_1 .my_social_networks li").removeClass('my_selected');
			$(this).addClass('my_selected');
			var my_form_new_class=form_prefix+type;
			if(self.network!=''){
				var my_form_pre_class=form_prefix+self.network;
				self.network=type;
				$("."+my_form_pre_class).fadeOut(function(){
					$("."+my_form_new_class).fadeIn(function(){
						
						self.my_working=false;
					});
				}
						
				);
			}else {
				self.network=type;
				$("."+my_form_new_class).fadeIn(function(){
						self.my_working=false;
					});
			}
		};
		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log('Get Social Posts \n'+t,o);
				}
			}
		};
			this.init(o);
			
	}
})(jQuery);		