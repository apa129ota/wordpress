(function($) { 
	myVusualBuilderDialog=function(o){
		var self;
		this.pre_options={
				dw:600,
				dh:400,
				diff:20,
				modal:false
			};
		
		this.options=o;
		this.debug=true;
		self=this;
		this.init=function(o){
			if(typeof self.options.debug!='undefined'){
				if(!self.options.debug){
					self.debug=false;
				}
			}
			self.options=$.extend( self.pre_options,self.options);
			
			self.my_debug("options", self.options);
			var ww=$(window).width();
			var wh=$(window).height();
			var dw=self.options.dw;
			var dh=self.options.dh;
			/*var modal=false;
			if(typeof self.options.modal!='undefined'){
				modfal=true;
			}*/
			if(self.options.dw>ww)dw=ww-self.options.diff;
			if(self.options.dh>wh)dh=wh-self.options.diff;
			self.my_class=".my_dialog_"+self.options.key;
			$(self.my_class).find(".my_timeline_modal_close_1").on("click",function(e){
				e.preventDefault();
				self.my_debug("Dialog close");
				$(self.my_class).dialog("close");
			});
			$(self.my_class).dialog({
				dialogClass:self.my_class,
				autoOpen: false,
				width:dw,
				modal:self.options.modal,
				height:dh,
				modal:false,
				draggable:false,
				resizable:false,
				open:function(e,ui){
					var h=$(self.my_class+" .my_header_dialog").outerHeight();
					var th=$(self.my_class).height();
					var pd=$(self.my_class+" .my_shortcode_content").css('padding-top');
					pd=parseInt(pd);
					var h1=th-h-2*pd;
					$(self.my_class+" .my_shortcode_content").height(h1);
					self.my_debug("Adjust window size",{h:h,th:th,pd:pd});
					self.show=true;
					var obj=[self,self.options.key];
					self.my_debug("Open dialog",obj);
					$('body').trigger('my_open_dialog',obj);
					$(".my_shortcodes_dialog_overlay").show();
				},
				close:function(e,ui){
					$(".my_shortcodes_dialog_overlay").hide();
					self.show=false;
					var obj=[self,self.options.key];
					self.my_debug("Close dialog",obj);
					$('body').trigger('my_close_dialog',obj);
				}
			});
			$(window).resize(self.my_resize);	
		};
		this.my_open=function(){
			$(self.my_class).dialog('open');
		};
		this.my_close=function(){
			$(self.my_class).dialog('close');
		}
		this.my_resize=function(e){
			if(self.show){
				var ww=$(window).width();
				var wh=$(window).height();
				var dw=self.options.dw;
				var dh=self.options.dh;
				if(self.options.dw>ww)dw=ww-self.options.diff;
				if(self.options.dh>wh)dh=wh-self.options.diff;
				var left=(ww-dw)/2;
				var top=(wh-dh)/2;
				top+=$(window).scrollTop();
				/*if(window.console){
					console.log("Width",{left:left,top:top,dw:dw,dh:dh});
				}*/
				$(self.my_class).parents('.ui-dialog').width(dw);
				$(self.my_class).parents('.ui-dialog').height(dh);
				$(self.my_class).parents('.ui-dialog').css('top',top+'px');
				$(self.my_class).parents('.ui-dialog').css('left',left+'px');
				/*}else {
					$(self.my_class).dialog("option","width",dw);
					$(self.my_class).dialog("option","height",dh);
					$(self.my_class).parents('.ui-dialog').width(dw);
					$(self.my_class).parents('.ui-dialog').height(dh);
					
					}
				*/
			}
		};
		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log('Visual builder Dialog \n'+t,o);
				}
			}
		};
		this.init();
		
};
})(jQuery);				
