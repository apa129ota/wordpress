(function($) { 
	myAdminMsgs=function(o){
		var self;
		this.my_working=false;
		this.debug=false;
		this.options=o;
		this.window_msg='<div id="my_loader_div" class="my_info_window"><div class="my_loader_img"><span class="my_msg">{msg}</span></div></div>';
		this.error_msg='<div id="my_loader_div" class="my_info_window my_error_window"><div class="my_error_img"><span class="my_msg">{msg}</span></div></div>';
		this.success_msg='<div id="my_loader_div" class="my_info_window my_ok_window"><div class="my_ok_img"><span class="my_msg">{msg}</span></div></div>';
		this.msg_timeout=3000;
		self=this;
		this.init=function(o){
			self.my_debug("options", self.options);
			
		};
		this.my_remove_window=function(){
			$("body #my_loader_div").remove();
			//$('body').removeClass('my_info_window_overlay');
			self.my_remove_action_overlay();
		};
		this.show_remove=function(msg,type){
			if(type==0){
				self.my_show_success_window(msg);
				
			}else if(type==1){
				self.my_show_error_window(msg);
			}
			setTimeout(function(){
				self.my_remove_window();
			},self.msg_timeout);
		};
		this.my_show_window=function(html,msg){
			var top=parseFloat($(window).scrollTop());
			var width = window.innerWidth;
			var height = window.innerHeight;
			$('body').append(html);
			self.my_add_action_overlay();
			self.my_debug("Show window",{top:top,height:height,width:width})
			setTimeout(function(){
			var h=$("#my_loader_div").height();
			var w=$("#my_loader_div").width();
			
			var top_1=Math.floor((height-h)/2)+top;
			var left=Math.floor((width-w)/2);
			self.my_debug("Position",{top:top,height:height,width:width})
			
			$("#my_loader_div").css('left',left+'px');
			$("#my_loader_div").css('top',top_1+'px');
			},200);
		};
		this.my_show_success_window=function(msg){
			var html=self.success_msg;
			html=html.replace('{msg}',msg);
			self.my_show_window(html, msg);
			return;
			/*
			var top=parseFloat($(window).scrollTop());
			var height=$('body').height();
			var width=$('body').width();
			$('body').append(html);
			//$('body').addClass('my_info_window_overlay');
			self.my_add_action_overlay();
			self.my_debug("Show window",{top:top,height:height,width:width})
			setTimeout(function(){
			var h=$("#my_loader_div").height();
			var w=$("#my_loader_div").width();
			
			var top_1=Math.floor((height-h)/2)+top;
			var left=Math.floor((width-w)/2);
			self.my_debug("Position",{top:top,height:height,width:width})
			
			$("#my_loader_div").css('left',left+'px');
			$("#my_loader_div").css('top',top_1+'px');
			},200);
			*/
		};
		this.my_show_error_window=function(msg){
			var html=self.error_msg;
			html=html.replace('{msg}',msg);
			self.my_show_window(html, msg);
			return;
			/*
			var top=parseFloat($(window).scrollTop());
			var height=$('body').height();
			var width=$('body').width();
			$('body').append(html);
			//$('body').addClass('my_info_window_overlay');
			self.my_add_action_overlay();
			self.my_debug("Show window",{top:top,height:height,width:width})
			setTimeout(function(){
			var h=$("#my_loader_div").height();
			var w=$("#my_loader_div").width();
			
			var top_1=Math.floor((height-h)/2)+top;
			var left=Math.floor((width-w)/2);
			self.my_debug("Position",{top:top,height:height,width:width})
			
			$("#my_loader_div").css('left',left+'px');
			$("#my_loader_div").css('top',top_1+'px');
			},200);*/
		};
		this.my_add_action_overlay=function(){
			var width=$(document).width();
			var height=$(document).height();
			self.my_debug("Window height width",{width:width,height:height});
			var html='<div class="my_info_window_overlay"';
			html+=' style="position:absolute;top:0;left:0;width:'+width+'px;height:'+height+'px"></div>';
			$('body').append(html);
		};
		this.my_remove_action_overlay=function(){
			$("body .my_info_window_overlay").remove();
		};
			
		this.my_show_working_window=function(msg){
			var html=self.window_msg;
			html=html.replace('{msg}',msg);
			self.my_show_window(html, msg);
			return;
			/*
			var top=parseFloat($(window).scrollTop());
			var height=$('body').height();
			var width=$('body').width();
			$('body').append(html);
			//$('body').addClass('my_info_window_overlay');
			self.my_add_action_overlay();
			self.my_debug("Show window",{top:top,height:height,width:width})
			setTimeout(function(){
			var h=$("#my_loader_div").height();
			var w=$("#my_loader_div").width();
			
			var top_1=Math.floor((height-h)/2)+top;
			var left=Math.floor((width-w)/2);
			self.my_debug("Position",{top:top,height:height,width:width})
			
			$("#my_loader_div").css('left',left+'px');
			$("#my_loader_div").css('top',top_1+'px');
			},200);
			*/
		};
		this.my_debug=function(t,o){
			if(self.debug){
				if(window.console){
					console.log('Admin Msgs \n'+t,o);
				}
			}
		};
			this.init();
			
	};
})(jQuery);		
	