<?php
$dir=plugin_dir_path(__FILE__);
require_once $dir.'includes/traits/traits.php';
require_once $dir.'includes/class/class-general-plugin.php';
require_once $dir.'includes/modules/class-my-general-module.php';
/*
Plugin Name: My Pro Testimonials
Description: Create testimonials, front end submission form, show testimonials in the card slider, slider , grid.Choose 3 predefined styles or create new styles with visual editor. Use 6 predefined templates with plugin options . Create widgets with your testimonials.
Version: 1.0
Author: newprocoders
Text Domain: my_support_theme
*/	

if(!class_exists('Class_My_Framework_Main_Class')){
	class Class_My_Framework_Main_Class extends Class_My_Framework_Plugin_Class{
		use MySingleton,MyDebug; 
		public $events;
		private $is_addon=false;
		private $global_modules_dir='';
		private $local_modules_dir='';
		private $global_debug=0;
		private $plugin_dir;
		private $plugin_url;
		public $options;
		protected $debug=0;		
		//private $use_case='my_framework';
		function Class_My_Framework_Main_Class($options=array()){
			parent::__construct(array(
				'dir'=>plugin_dir_path(__FILE__),
				'url'=>plugin_dir_url(__FILE__),
					
			));
			$this->plugin_dir=plugin_dir_path(__FILE__);
			$this->plugin_url=plugin_dir_url(__FILE__);
			//$this->setOptions($options);
		}
		
		/**
		 * Set main script loader class
		 */
		private function setScriptsOptionsMain(){
			$options['assets_url']=$this->url.'assets/';
			$options['debug']=$this->debug;
			$options['use_case']=$this->use_case;
			//$this->setScriptOptions($options);
			$this->loadGlobalClass('Class_My_Framework_Scripts_Class',$options);
		}
		protected function loadGlobalClass($class='',$options=array()){
			switch($class){
				case 'Class_My_Framework_Scripts_Class':
					$file=$this->class_dir.'class-my-scripts.php';
					require_once $file;
					$this->scripts_class=Class_My_Framework_Scripts_Class::singleton($options);
					break;
				default:
					
		
					//case 'Class_My_Framwork_Scripts_Class':
			}
		}
		private function init_contsants(){
			$this->global_modules_dir=$this->plugin_dir.'includes/modules/';
			/**
			 * Dirnames
			*/
			define('MY_TESTIMONIALS_DIRNAME',$this->plugin_dir);
			define('MY_TESTIMONIALS_TMP_DIRNAME',$this->plugin_dir.'tmp/');
			define('MY_TESTIMONIALS_TMP_UPLOADS_DIRNAME',$this->plugin_dir.'tmp/uploads/');
			define('MY_TESTIMONIALS_TMP_ERRORS_DIRNAME',$this->plugin_dir.'tmp/errors/');
			define('MY_TESTIMONIALS_TMP_DEBUG_DIRNAME',$this->plugin_dir.'tmp/debug/');
			define('MY_TESTIMONIALS_CLASS_DIRNAME',$this->plugin_dir.'includes/class/');
			define('MY_TESTIMONIALS_VIEWS_DIRNAME',$this->plugin_dir.'includes/views/');
			define('MY_TESTIMONIALS_CONTROLLERS_DIRNAME',$this->plugin_dir.'includes/controllers/');
			define('MY_TESTIMONIALS_FUNCTIONS_DIRNAME',$this->plugin_dir.'includes/functions/');
			define('MY_TESTIMONIALS_MODELS_DIRNAME',$this->plugin_dir.'includes/models/');
			define('MY_TESTIMONIALS_GLOBAL_MODULES_DIRNAME',$this->global_modules_dir);
			define('MY_TESTIMONIALS_LOCAL_MODULES_DIRNAME',$this->plugin_dir.'includes/modules/');
			define('MY_TESTIMONIALS_SHORTCODES_DIRNAME',$this->plugin_dir.'includes/modules/shortcodes/');
			define('MY_TESTIMONIALS_ADDONS_DIRNAME',$this->plugin_dir.'includes/modules/addons/');
			define('MY_TESTIMONIALS_URL',$this->plugin_url);
			/**
			 * URLS
			*/
			define('MY_TESTIMONIALS_CSS_URL',$this->plugin_url.'assets/css/');
			define('MY_TESTIMONIALS_IMAGES_URL',$this->plugin_url.'assets/images/');
			define('MY_TESTIMONIALS_JSCRIPT_URL',$this->plugin_url.'assets/jscript/');
			define('MY_TESTIMONIALS_MODULES_URL',$this->plugin_url.'includes/modules/');
			define('MY_TESTIMONIALS_ADDONS_URL',$this->plugin_url.'includes/modules/addons/');
			/**
			 * db tables
			 */
			global $wpdb;
			$table_name = $wpdb->prefix . 'my_testimonials_objects';
			define('MY_TESTIMONIALS_TABLE_OBJECTS',$table_name);
			global $wpdb;
			$table_name = $wpdb->prefix . 'my_testimonials_object_meta';
			define('MY_TESTIMONIALS_TABLE_OBJECTS_META',$table_name);
				
				
		}
		public function init($options=array()){
			$this->init_contsants();
			//Reqitre activate deactivate functuions
			$file1=MY_TESTIMONIALS_FUNCTIONS_DIRNAME.'activate.php';
			$file2=MY_TESTIMONIALS_FUNCTIONS_DIRNAME.'deactivate.php';
			require_once $file2;	
			require_once $file1;
			
			register_activation_hook(__FILE__, 'wp_my_testimonials_activate');
			register_deactivation_hook(__FILE__,'wp_my_testimonials_deactivate');
			
		
			$this->getModules($this->modules_dir);
			$this->setScriptsOptionsMain();
			$my_set_debug=1;
			if(!$this->global_debug)$my_set_debug=0;
			if($this->global_debug){
				if(!empty($this->modules['debug'])){
					$this->loadModuleClass('debug');
					Class_My_Module_Debug::init();
					Class_My_Module_Debug::$tmp_debug=MY_TESTIMONIALS_TMP_DEBUG_DIRNAME;
					Class_My_Framework_Scripts_Class::addIncludes('fontawesome');
			
			
					Class_My_Module_Debug::add_section('modules', $this->modules,$this->use_case,false);
					if(is_admin()){
						add_action('admin_footer',array(&$this,'debug_footer'));
					}else {
						add_action('wp_footer',array(&$this,'debug_footer'));
					}
				
				self::setDebugOptions($this->use_case);
				}
			}
			parent::init(array('debug'=>$my_set_debug));
			$this->load_functions();
			add_action('admin_notices',array(&$this,'admin_notices'));
			$module_options=array(
					'dir'=>$this->getDir('modules').'options/',
					'url'=>$this->getUrl('modules').'options/',
					'debug'=>$this->debug,
					'global_plugin'=>$this
			);
				
				
			$options=$this->loadOptions("plugin_options.php");
			$module_options=array_merge($module_options,$options);
			self::debug("module_options", $module_options,false);
			$this->options=$this->instantiateModuleClass('options',$module_options);
			$this->options->init();
			self::debug("plugin_options",$this->options->getOptions(),false);
			$options_plugin=$this->options->getOptions();
			if(!empty($options_plugin['my_debug'])){
				if(!empty($this->modules['debug'])){
					$this->loadModuleClass('debug');
					Class_My_Module_Debug::init(true);
					Class_My_Module_Debug::$tmp_debug=MY_TESTIMONIALS_TMP_DEBUG_DIRNAME;
					Class_My_Framework_Scripts_Class::addIncludes('fontawesome');
						
						
					Class_My_Module_Debug::add_section('modules', $this->modules,$this->use_case,false);
					if(is_admin()){
						add_action('admin_footer',array(&$this,'debug_footer'));
					}else {
						add_action('wp_footer',array(&$this,'debug_footer'));
					}
				
					self::setDebugOptions($this->use_case);
				}
						
			}else {
				Class_My_Framework_Scripts_Class::addIncludes('fontawesome');
			}
			/**
			 * Set script trait options
			 */
			$module_options=array(
					'dir'=>$this->getDir('modules').'testimonials/',
					'url'=>$this->getUrl('modules').'testimonials/',
					'debug'=>$this->debug,
					'global_plugin'=>$this
			);
			$this->events=$this->instantiateModuleClass('testimonials',$module_options);
			$this->events->init();
				
			
			add_action('admin_menu',array(&$this,'admin_menu'));
		}
		
		public function admin_menu(){
			add_menu_page('Test', 'test', 'administrator', 'my-test-framework',array($this,'test_admin'));
		}
		
		function test_admin(){
			$file=plugin_dir_path(__FILE__);
			$file.='includes/views/test.php';
			require $file;
		}
		public function admin_notices(){
			$tmp_1=MY_TESTIMONIALS_TMP_DIRNAME;
			$tmp_2=MY_TESTIMONIALS_TMP_UPLOADS_DIRNAME;
			$tmp_3=MY_TESTIMONIALS_TMP_ERRORS_DIRNAME;
			if(!is_writable($tmp_1) || (!is_writeable($tmp_2)) || (!is_writeable($tmp_3)) ){
				?>
						<div class="error">
						
							<?php if(!is_writable($tmp_1)) {?>
							<p><strong><?php echo __("Testimonials plugin : Please make this folder writeable by server ","my_support_theme");?> : <?php echo $tmp_1?></strong>
							
							<?php }?>
							<?php if(!is_writable($tmp_2)) {?>
							<p><strong><?php echo __("Testimonials Plugin : Please make this folder writeable by server ","my_support_theme");?> : <?php echo $tmp_2?></strong>
							
							<?php }?>
								<?php if(!is_writable($tmp_3)) {?>
							<p><strong><?php echo __("Testimonials Plugin : Please make this folder writeable by server ","my_social_posts_domain");?> : <?php echo $tmp_3?></strong>
				
							<?php }?>
						</div>
						<?php 
						}
			
		}
		public function load_functions(){
			$file=MY_TESTIMONIALS_FUNCTIONS_DIRNAME.'general.php';
			require_once $file;
			
			
		}
		
		
	}
}
if(!defined('MY_FRAMEWORK_AS_ADDON')){
	if(class_exists('Class_My_Framework_Main_Class')){
		global $Class_My_Framework_Main_Class;
		$Class_My_Framework_Main_Class=Class_My_Framework_Main_Class::singleton();
		$Class_My_Framework_Main_Class->init();
		
	}
}